"""Isolated HEART A/B continual pilot task. Existing continual implementation is unchanged.

A: General + Ugi train. B: General + Ugi + sampled LNPDB train.
Both include the identical LNPDB held-out validation *if supplied*.

This compares a combined validation objective, NOT source-specific objective scores.
"""
import logging
import os

import numpy as np
from unicore.data import EpochShuffleDataset
from unicore.tasks import register_task
from unimol.data import Add2DConformerDataset
from unimol.data.merged_sampling_dataset import MergedSampledLMDBDataset
from unimol.tasks.unimol_contrastive_continual import UniMolTaskContrastiveContinual
from unimol.tasks.unimol_contrastive import PairSampledNestedDictionaryDataset

logger = logging.getLogger(__name__)


class PilotSourceSampledDataset(MergedSampledLMDBDataset):
    """Retain original General/Ugi semantics, with LNPDB replacement sampling.

    Training only; LNPDB samples are repeated as needed to hit desired
    fraction *within the lipid stream*. Dataset index mapping remains original.
    """

    def __init__(self, paths, weights, *, lnpdb_indices=(), fraction=0.05, seed=1, names=None, max_open_envs=64):
        super().__init__(paths, weights, seed=seed, names=names, max_open_envs=max_open_envs)
        lnpdb_indices = tuple(lnpdb_indices)
        if not lnpdb_indices:
            return
        if not 0 < fraction < 1:
            raise ValueError("LNPDB lipid fraction must be between 0 and 1")
        lipid_indices = tuple(range(1, lnpdb_indices[0]))
        ugi_n = sum(self._n_sampled[i] for i in lipid_indices)
        if ugi_n == 0:
            raise ValueError("Ugi sample count zero")
        requested = int(round(ugi_n * fraction / (1.0 - fraction)))
        sizes = [self.sizes[i] for i in lnpdb_indices]
        total_unique = sum(sizes)
        if total_unique == 0:
            raise ValueError("No LNPDB records")
        allocated = [requested * n // total_unique for n in sizes]
        allocated[-1] += requested - sum(allocated)
        for i, k in zip(lnpdb_indices, allocated):
            rng = np.random.default_rng([int(seed), int(i), 7162])
            # True source-ratio sampling: replacement necessary for 10K vs 15M.
            self._sel[i] = rng.integers(0, self.sizes[i], size=k, dtype=np.uint32 if self.sizes[i] < 2**32 else np.int64)
            self._n_sampled[i] = k
        self.cumulative_length = [0]
        for k in self._n_sampled:
            self.cumulative_length.append(self.cumulative_length[-1] + k)
        self._len = self.cumulative_length[-1]
        logger.warning("Pilot LNPDB sampled WITH replacement; record repeats are expected."
                       " Retain this as a pilot, not generalization proof.")


@register_task("unimol_contrastive_pilot")
class UniMolTaskContrastivePilot(UniMolTaskContrastiveContinual):
    @staticmethod
    def add_args(parser):
        UniMolTaskContrastiveContinual.add_args(parser)
        parser.add_argument("--pilot-variant", required=True, choices=["A", "B"])
        parser.add_argument("--lnpdb-splits", default=None)
        parser.add_argument("--lnpdb-lipid-fraction", type=float, default=0.05)

    def load_dataset(self, split, combine=False, **kwargs):
        general_path = os.path.join(self.args.data, split + ".lmdb")
        if not os.path.isfile(general_path):
            raise FileNotFoundError(general_path)
        ugi, ugi_meta = self.lipid_lmdbs(split)
        if not ugi:
            raise ValueError("Ugi split is empty")
        lnpdb = []
        if getattr(self.args, "lnpdb_splits", None):
            lnpdb, lnpdb_meta = self._load_splits_json(self.args.lnpdb_splits, split)
            if lnpdb_meta.get("smoke") or not lnpdb_meta.get("complete"):
                raise ValueError("LNPDB split must be final verified full dataset")
            if not lnpdb:
                raise ValueError("LNPDB split empty")
        if self.args.pilot_variant == "B" and not lnpdb:
            raise ValueError("B requires LNPDB split")
        # Same held-out datasets for BOTH A and B; A never trains on LNPDB.
        include_lnpdb = bool(lnpdb) and (split != "train" or self.args.pilot_variant == "B")
        paths = [general_path] + ugi + (lnpdb if include_lnpdb else [])
        # Keep all valid LMDB records; original general/Ugi per-epoch weights train.
        weights = [self.args.general_data_weight] + [self.args.lipid_data_weight] * len(ugi)
        if include_lnpdb:
            weights += [1.0] * len(lnpdb)
        names = ["general:" + split] + ["ugi:" + os.path.basename(os.path.dirname(p)) for p in ugi]
        if include_lnpdb:
            names += ["lnpdb:" + os.path.basename(os.path.dirname(p)) for p in lnpdb]
        # validation uses no replacement and identical datasets for A/B.
        lnpdb_indices = range(1 + len(ugi), len(paths)) if split == "train" and include_lnpdb else ()
        merged = PilotSourceSampledDataset(paths, weights, lnpdb_indices=lnpdb_indices,
                                           fraction=self.args.lnpdb_lipid_fraction,
                                           seed=self.args.seed, names=names,
                                           max_open_envs=getattr(self.args, "max_open_lmdb_envs", 64))
        slot_report = self._coordinate_slot_check(merged, None)
        merged.close()
        counts = merged.mixture_counts()
        logger.info("PILOT %s split=%s source counts %s", self.args.pilot_variant, split,
                    [(c["name"], c["n_sampled"]) for c in counts])
        if getattr(self.args, "mixture_report", None):
            self._write_mixture_report(split, counts, slot_report,
                                       {"ugi_splits": self.args.lipid_splits,
                                        "lnpdb_splits": self.args.lnpdb_splits,
                                        "pilot_variant": self.args.pilot_variant,
                                        "lnpdb_fraction": self.args.lnpdb_lipid_fraction,
                                        "validation_is_combined": True})
        raw_dataset = merged
        if self.args.mode == "train":
            raw_dataset = Add2DConformerDataset(raw_dataset, "smi", "atoms", "coordinates",
                invalid_policy=getattr(self.args, "invalid_smiles_policy", "skip-2d"),
                max_invalid_fraction=getattr(self.args, "max_invalid_smiles_fraction", 0.01))
        views = [self._build_view(raw_dataset, self.args.seed, self.args.seed)]
        if getattr(self.args, "contrastive_view_mode", "identical") == "independent":
            view_seed = self.args.seed + self.args.view_seed_offset
            views.append(self._build_view(raw_dataset, view_seed, view_seed))
        dataset = PairSampledNestedDictionaryDataset(*[{"net_input": n, "target": t} for n,t in views])
        if split in ("train", "train.small"):
            dataset = EpochShuffleDataset(dataset, len(dataset), self.args.seed)
        self.datasets[split] = dataset
