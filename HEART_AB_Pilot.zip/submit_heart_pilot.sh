#!/usr/bin/env bash
# Submit isolated HEART pilot A or B, or both. No existing scripts overwritten.
set -euo pipefail
VARIANT="${1:-}"
case "$VARIANT" in A|B|both) ;; *) echo "Usage: bash submit_heart_pilot.sh A|B|both [smoke|pilot]" >&2; exit 2;; esac
STAGE="${2:-smoke}"
case "$STAGE" in smoke|pilot) ;; *) echo "stage must be smoke or pilot" >&2; exit 2;; esac
REPO="${HEART_REPO:-/home/ypan/heart_liver/model_train/heart-molecular-pretraining}"
ROOT="${HEART_PILOT_OUTPUT_ROOT:-/project/yli4/ypan/heart_pilot_runs}"
UGI="${HEART_LIPID_SPLITS:-/project/yli4/ypan/lipid_library/lmdb/splits.json}"
LNPDB="${HEART_LNPDB_SPLITS:-/project/yli4/ypan/lipid_library/lnpdb_heart/lmdb_full/splits.json}"
GENERAL="${HEART_DATA_PATH:-/project/yli4/ypan/UniMolReference/ligand_data/ligands}"
CHECKPOINT="${HEART_GENERAL_CHECKPOINT:-/project/yli4/ypan/runs/h200/full/heart-h200-b448-v1/checkpoint_best.pt}"
SCRIPT="$REPO/model/pretrain/scripts/continual_pilot_h200.sbatch"
for f in "$UGI" "$LNPDB" "$GENERAL/dict.txt" "$GENERAL/train.lmdb" "$GENERAL/valid.lmdb" "$CHECKPOINT" "$SCRIPT" "$REPO/model/unimol/tasks/unimol_contrastive_pilot.py"; do
  [ -f "$f" ] || { echo "ERROR: missing $f" >&2; exit 2; }
done
if [ "$STAGE" = smoke ]; then
  STEPS=200
else
  STEPS="${HEART_PILOT_STEPS:-5000}"
fi
mkdir -p /project/yli4/ypan/heart_pilot_logs "$ROOT"
submit_one() {
  local v="$1" run="heart-pilot-${1,,}-${STAGE}"
  # Correctly isolate outputs, so A/B can be scheduled separately.
  if [ "$STAGE" = smoke ]; then
    export HEART_CONTINUAL_SMOKE_UPDATES="$STEPS"
    unset MAX_STEPS
  else
    unset HEART_CONTINUAL_SMOKE_UPDATES
    export MAX_STEPS="$STEPS"
  fi
  export HEART_PILOT_VARIANT="$v" RUN_NAME="$run" HEART_CONFIRM_CONTINUAL=1
  export HEART_REPO="$REPO" HEART_OUTPUT_ROOT="$ROOT" HEART_DATA_PATH="$GENERAL"
  export HEART_GENERAL_CHECKPOINT="$CHECKPOINT" HEART_LIPID_SPLITS="$UGI" HEART_LNPDB_SPLITS="$LNPDB"
  export HEART_LNPDB_LIPID_FRACTION="${HEART_LNPDB_LIPID_FRACTION:-0.05}"
  export HEART_REQUIRE_LIBRARY_READY=0
  echo "Submitting $v ($STAGE) as $run, steps=$STEPS; GPU allocation subject to Slurm"
  sbatch --export=ALL --job-name="HEART-${v}-${STAGE}" \
    --output="/project/yli4/ypan/heart_pilot_logs/%x-%j.out" \
    --error="/project/yli4/ypan/heart_pilot_logs/%x-%j.err" "$SCRIPT"
}
if [ "$VARIANT" = both ]; then submit_one A; submit_one B; else submit_one "$VARIANT"; fi
