# HEART — LNPDB 3D preparation adapter

This tool reuses the **existing** `model/pretrain/lipid_library/conformers.py` of HEART. It does not modify the model, the already validated Ugi library, checkpoints, or existing project layout. All new outputs are isolated under a new LNPDB output directory.

## Local analysis already completed

- Input: original bundled `LNPDB.csv`, 19,797 records (formulation/experiment rows).
- Canonical isomeric SMILES identities: 12,835; 5 exceed HEART's 256 **heavy-atom** ceiling; **12,830** remain before applying the actual HPC dictionary vocabulary filter.
- Pre-selected by stable molecular identity hash: 12,195 training identities, 635 validation identities. **This is an identity-held-out diagnostic split, not a chemical-family holdout.**
- Test 6 actual unique lipids with 14–55 heavy atoms: **6/6 PASS**, 10 real 3D embeddings each, 0 2D fallback, 9 distinct geometries each by the existing HEART check (the initial RDKit seeds 0 and 1 can duplicate).
- Local **LMDB writing was not run**: `python-lmdb` is not installed in the local runtime. Writing and read-back must be completed in the HPC `heart_gpu` environment.
- The prepared CSV is a *preliminary* structure-ready metadata file; `dict.txt` was not present in the uploaded ZIP. On HPC, **run `prepare` again with the real General model `dict.txt`** before building the LMDB.

## 1. Copy the adapter to HPC (only one new .py file)

Place `lnpdb_to_heart.py` in any accessible directory on HPC, for example at the top level of the existing `heart-molecular-pretraining/` repository. The code will import HEART's original `conformers.py` from the location specified by `--repo`.

The CSV already exists in the uploaded repository root; if your HPC checkout does not contain it, use the existing `lipid_library/input/LNPDB.csv` instead.

In an HPC shell, set these variables **after checking that all four paths exist**:

```bash
export REPO=/home/ypan/heart_liver/model_train/heart-molecular-pretraining
export CSV="$REPO/LNPDB.csv"
export GENERAL_DICT=/home/ypan/heart_liver/model_train/UniMolReference/ligand_data/ligands/dict.txt
export ADAPTER="$REPO/lnpdb_to_heart.py"
export LNPDB_ROOT=/project/yli4/ypan/lipid_library/lnpdb_heart
export PY="$HOME/.conda/envs/heart_gpu/bin/python"

ls -lh "$CSV" "$GENERAL_DICT" "$ADAPTER" "$REPO/model/pretrain/lipid_library/conformers.py"
"$PY" -c 'import rdkit, numpy, lmdb; print("Dependencies OK")'
```

If the `CSV` is elsewhere, update just `CSV`. This is an example of the **current physical path**, not a request to rename your project.

## 2. Prepare LNPDB identity-only records (no training targets)

```bash
"$PY" "$ADAPTER" prepare \
  --csv "$CSV" --dict "$GENERAL_DICT" \
  --out "$LNPDB_ROOT/prepared" --max-atoms 256
```

Creates `lnpdb_unique_prepared.csv`, `lnpdb_rejected.csv`, and `preparation_report.json`. No mTP, luciferase, formulations, cargo, cell types, or normalized outcomes are incorporated. Exact neutral/charged form is preserved from `IL_SMILES`.

If you already tried preparation in that exact output directory, use a new empty directory or explicitly pass `--overwrite` (it overwrites **only** this adapter's preparation files).

## 3. Probe 10 actual 3D slots before committing to all 12K

```bash
"$PY" "$ADAPTER" probe \
  --repo "$REPO" \
  --prepared "$LNPDB_ROOT/prepared/lnpdb_unique_prepared.csv" \
  --count 10 --min-probe-heavy 0 --max-probe-heavy 65 \
  --json-out "$LNPDB_ROOT/probe_light.json"
```

Repeat a smaller test with larger molecules to assess extrapolation:

```bash
"$PY" "$ADAPTER" probe \
  --repo "$REPO" \
  --prepared "$LNPDB_ROOT/prepared/lnpdb_unique_prepared.csv" \
  --count 4 --min-probe-heavy 80 --max-probe-heavy 125 \
  --json-out "$LNPDB_ROOT/probe_large.json"
```

Large flexible lipids may be expensive or fail; this matters for representativeness and should be documented. When each SMILES yields 10 slots, training automatically adds an eleventh, dynamically generated 2D coordinate representation using `Add2DConformerDataset`; **do not store a duplicate 2D slot in the LMDB.**

## 4. Smoke-test LMDB writing (small, isolated output)

```bash
"$PY" "$ADAPTER" build \
  --repo "$REPO" \
  --prepared "$LNPDB_ROOT/prepared/lnpdb_unique_prepared.csv" \
  --dict "$GENERAL_DICT" \
  --out "$LNPDB_ROOT/smoke" --num-shards 1 --shard-id 0 --limit 3

"$PY" "$ADAPTER" finalize \
  --out "$LNPDB_ROOT/smoke" \
  --prepared "$LNPDB_ROOT/prepared/lnpdb_unique_prepared.csv" \
  --num-shards 1 --allow-smoke

"$PY" "$ADAPTER" verify \
  --repo "$REPO" --dict "$GENERAL_DICT" \
  --out "$LNPDB_ROOT/smoke" --check-all
```

`--limit 3` means *up to 3 train and 3 valid* molecules per shard. It is **only** a smoke test, never full model training. Do not use a smoke `splits.json` without the explicit task safety override.

## 5. Full parallel build on the HPC CPU partition

First review `lnpdb_build.sbatch` and choose an appropriate CPU partition / QoS for your cluster; these are intentionally not guessed here. Run:

```bash
export LNPDB_PREPARED="$LNPDB_ROOT/prepared/lnpdb_unique_prepared.csv"
export LNPDB_FULL_OUT="$LNPDB_ROOT/lmdb_full"
export NUM_SHARDS=16

sbatch --export=ALL --array=0-15 lnpdb_build.sbatch
```

If one shard fails or runs out of time, rerun into a **new** output directory after correcting the issue. This first version intentionally refuses to overwrite incomplete/previous outputs. Before full-scale production, inspect timing and the 3D-success rate from the smoke and larger-molecule probes. For a larger CPU array, change both `NUM_SHARDS` and `--array` consistently.

Once **all** shards succeed:

```bash
"$PY" "$ADAPTER" finalize \
  --out "$LNPDB_FULL_OUT" --prepared "$LNPDB_PREPARED" --num-shards "$NUM_SHARDS"

"$PY" "$ADAPTER" verify \
  --repo "$REPO" --dict "$GENERAL_DICT" \
  --out "$LNPDB_FULL_OUT" --sample 100
```

The full dataset is accepted only if it has both nonempty train and valid, all expected shards, matching CSV and dictionary fingerprints, SHA-verified LMDBs, and correctly shaped records.

## 6. What we can and cannot compare next

**Ready after the full LMDB passes `verify`:** LNPDB molecules have `smi` / `atoms` / `coordinates` with 10 stored slots, integer-keyed pickles, and the existing training loader can add one 2D representation. Their chemistry is not forced to be Ugi-like.

**Not implemented in this adapter:** HEART-B's three-source *balanced* sampling. The current `unimol_contrastive_continual` task handles General plus **one** lipid source. Its `--lipid-data-weight` is a per-dataset epoch sample fraction, **not** a batch ratio. Do not simply combine the Ugi and LNPDB paths and claim a 5% LNPDB batch fraction. Adding actual source-aware Ugi/LNPDB sampling is the next separate code change.

**Not proven by structural compatibility:** improved delivery prediction, downstream mTP prediction, or generalization to held-out *lipid families*. The built-in 5% identity-hash validation split is for technical QC; a family-held-out validation split must be designed separately if the goal is extrapolation beyond Ugi chemistry.

## Exact record representation

```python
{
  'smi': 'canonical isomeric IL_SMILES',
  'atoms': ['C', 'N', 'O', ..., 'H'],       # RDKit AddHs order
  'coordinates': [np.ndarray((n_atoms,3), dtype=np.float32)] * 10
}
```

Ten slots might include 2D fallbacks when the HEART generator fails to embed all conformers; `records.csv` reports actual `n_3d_success`, `n_distinct_3d` and `n_2d_filled`. Default `--min-3d 1` matches the existing Ugi acceptance policy, but a quality threshold should be decided after observing the report rather than quietly using 2D-only records.
