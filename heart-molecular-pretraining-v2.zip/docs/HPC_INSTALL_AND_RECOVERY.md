# HEART v2 on CMRI — install, run, recover

Nothing below was executed on CMRI by the development session. Every `--submit` is an explicit user
decision. All other commands are read-only or previews.

## 1. Clone next to the historical checkout (no migration, nothing moved)

```bash
cd /home/ypan/heart_liver/model_train
git clone https://github.com/andypan0214/heart-molecular-pretraining-v2.git
cd heart-molecular-pretraining-v2
git checkout v2/lipid-continual        # or main once the PR is merged
git log -1 --oneline
```

* The old `heart-molecular-pretraining/` checkout, its `runs/` (incl. the general H200 checkpoints), the
  ligand data, the `heart_gpu` env and `lipid_library/` stay where they are and are only **read**.
* v2 code runs from the v2 clone (jobs resolve their own checkout; the old path is never used for code).
* Continual runs are written to `heart-molecular-pretraining-v2/runs/h200/continual/<run name>`.
* Environment: the existing `heart_gpu` (Python 3.11, torch 2.2.2+cu121, Uni-Core `ace6fae`); v2 adds no
  package. `bin/heart` uses `/home/ypan/.conda/envs/heart_gpu/bin/python` (needs PyYAML, already present).

## 2. Read-only checks (login node)

```bash
bin/heart check                              # must end with: check: PASS
bin/heart baseline                           # frozen general code: PASS (69 files vs 73a5f9d)
bash scripts/check_heart_hpc_readonly.sh      # diagnostics -> ~/heart_v2_acceptance/<time>/ (full.log, summary.txt, task63/)
bin/heart library --status                   # what exists under /home/ypan/heart_liver/model_train/lipid_library
```

## 3. Resume the production library (the state after jobs 1013342-1013347)

```bash
bin/heart library --resume --dry-run         # read the plan: expected 02 --array=<failed task ids> -> 03 -> 03b -> 04 -> 05
bin/heart library --resume --submit          # explicit
bin/heart library --status                   # repeat to follow progress (stage 04: stage04_progress.json)
```

* **Stage 02 / task 63.** First read the evidence (G7 of the acceptance script, or
  `sacct -j 1013343_63 --format=JobID,State,ExitCode,NodeList,Start,End` and
  `lipid_library/logs/lipid-02-enum-1013343_63.err`). The root cause is not confirmed
  (`docs/CODE_AUDIT.md` §5). `--resume` resubmits only the task ids of missing chunks with the original
  stride 64 (chunk ↔ task mapping unchanged); finished chunks are hash-verified and skipped; nothing is
  regenerated or deleted. If a chunk receipt from another configuration is found, `--status` shows
  `FAILED` and `--resume` refuses: never mix configurations in one root.
* **Stage 03** refuses to start until `enumeration_complete.json` verifies every chunk.
* **Stage 04** (one job, 250 CPUs on `cmri-gpu04`). If it ends with shards left (time limit, node issue),
  stage 05 still runs and fails closed with `finalize_report.json` listing missing shards; run
  `bin/heart library --resume --submit` again. Finished shards are verified and skipped. Never start the
  array-mode fallback on the same directory (it is locked out).
* **Stage 05** writes `library_ready.json` only after finalize + splits + validation all pass.

Pilot first (optional, isolated, never usable for production):
```bash
bin/heart library --pilot 100 --dry-run      # 03b/04/05 of the first 100 products into lipid_library/pilot_v2/lmdb-limit100
bin/heart library --pilot 100 --submit
```

Before stage 04 is submitted, `bin/heart` measures the real general LMDB slot policy (must be `10/0` for
`STORE_2D=0`) and refuses on any mismatch; the stage-04 job repeats the check (`docs/LIBRARY_QUALITY_CRITERIA.md` §3).
Stage 05 refuses `library_ready.json` if a production-quality criterion fails (`<lmdb>/quality_report.md`).

## 4. Continual pretraining (only after `library_ready.json`)

```bash
bin/heart library --verify-full --dry-run    # full sha256 of every shard as a 16-CPU job (needed if the last
bin/heart library --verify-full --submit     #   full verification is > 14 days old, or after copying the library)
```


```bash
bin/heart continual --check                  # read-only: real data compatibility + strict checkpoint dry run
bin/heart continual --dry-run                # prints the exact 1-H200 / 16-CPU / 200G sbatch command
bin/heart continual --smoke --submit         # 200 updates into runs/h200/continual/heart-lipid-continual-smoke
bin/heart continual --submit                 # production: 200,000 updates; repeat the same command to resume
bin/heart evaluate --check                   # after checkpoints exist: read-only general-vs-continual comparison
```

* New stage: `checkpoint_best.pt` is opened read-only; `continual_init.pt` holds weights only, so the
  optimizer, LR schedule (200K), fp16 scaler and update counter start fresh.
* Resume: only from the continual `checkpoint_last.pt`; changed science or lipid splits are refused.
* The runner refuses a lipid library without a valid `library_ready.json` (`HEART_REQUIRE_LIBRARY_READY=1`).

## 5. Changing a setting

Edit `config/heart_v2.yaml` (commit it), or override once with `--set`, e.g.
`bin/heart --set slurm.profiles.lipid_04.time=1-12:00:00 library --resume --dry-run`. The effective config is
frozen to `<root>/jobs/heart_v2_config-<sha>.json` and read by the jobs; every submission is appended to
`<root>/jobs/submissions.jsonl`. Contradictions (generic/T4 GRES, a CPU stage with a GPU, continual with the
250-CPU profile, more workers than CPUs, …) are refused before anything is submitted.

## 6. Stage-04 CPU scaling benchmark (launcher ready — needs approval; not run)

```bash
bin/heart bench                  # preview: 3 x (03b + 04) with LIPID_WORKERS 64 / 128 / 250, 15,000 molecules each
bin/heart bench --submit         # each 04 uses the production allocation (250 CPUs, 500G, gpu:h200:1, cmri-gpu04),
                                 # serialised with afterany; outputs in lipid_library/pilot_v2/bench-n15000-r20-w<W>
cd model/pretrain && python -m lipid_library.bench_report <the three printed dirs>
```

Background and the manual procedure the launcher automates:

`cmri-gpu04` has about 128 physical cores / 256 hardware threads; 250 SLURM CPUs are logical CPUs. Before
claiming any speed-up:

1. Make a pilot partition with `--pilot 3000 --pilot-records-per-shard 25` (120 shards).
2. Run the stage-04 job three times with `--set library.stage04_workers=64`, `128`, `250` (each into its own
   pilot directory: `--set paths.lipid_pilot_root=…/bench-64` etc.).
3. Compare from each `stage04_run-<job>.json` / `stage04_progress.json`: wall time,
   `measured_sec_per_molecule_cpu`, molecules/hour (= rows / wall time), and from `sacct`
   `MaxRSS`/`TotalCPU`. Choose the worker count with the highest molecules/hour within 500G.
4. Full-library estimate = 15.24M × (s/molecule at that concurrency) ÷ workers; if it exceeds 2 days the
   job simply resumes in a second submission.

## 7. What never to do

`git push --force`, `git reset --hard` or deleting anything in the old checkout; editing the general
launcher/`heart_lib.sh`; deleting enumeration chunks or shard receipts to "start clean"; pointing two
stage-04 jobs at one LMDB directory; resuming continual training from the general checkpoint.
