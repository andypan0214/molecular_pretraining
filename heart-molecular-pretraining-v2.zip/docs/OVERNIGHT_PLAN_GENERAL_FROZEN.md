# HEART Molecular Pretraining v2 — Claude Code Overnight Plan (General Pretraining Frozen)

**Mission:** Create a **complete independent successor of the existing HEART repository**, preserving the **already-successful general pretraining implementation exactly as-is** and concentrating all new engineering effort on **lipid virtual-library generation, general+lipid continual pretraining, integration, recovery, and evaluation**. The new repository must contain the original general pretraining code for completeness, but **general pretraining is NOT a development target**.

**Read-only source repository:** `https://github.com/andypan0214/heart-molecular-pretraining`  
**Proposed NEW destination repository:** `https://github.com/andypan0214/heart-molecular-pretraining-v2` (create as a **private** repository if authorized; if the name is unavailable, use a clearly named complete HEART successor repository owned by `andypan0214` and report its URL).  
**Working mode:** autonomous overnight **source-code development/testing/pushing**; **no real HPC submission**, no deletion of existing production outputs, no checkpoint edits.  
**Date prepared:** 2026-11-07.

## 0. CRITICAL: What the user actually wants

1. **Keep the entire HEART project, but FREEZE the working general pretraining code.** Start from the complete, latest, tracked upstream repository, not only `model/pretrain/lipid_library/` or three shell scripts. Retain the general trainer, model, losses, original task/loader, checkpoint handling, training configs, evaluation notebooks, tests, environment documentation, licensing and notices **without modifying them**. Pin the original upstream commit SHA and compare protected-file hashes at delivery. Never deliver a lipid-only repository.
2. **Make the complete workflow work end-to-end:** completed general H200 checkpoint → reproducible Ugi lipid virtual library → 3D/HEART-compatible LMDB → strict validation → mixed general+lipid continual pretraining → continual checkpoint/resume → embedding/quality evaluation.
3. **Ensure there is one authoritative HPC configuration for NEW lipid and continual jobs only.** Production lipid conformer generation and continual training require DIFFERENT H200 CPU/RAM profiles. The old, successful general-training launcher is **not** part of this refactor and must stay unchanged. No contradictory `#SBATCH`, `sbatch` CLI or environment defaults are allowed among library/continual entrypoints.
4. **You may redesign/refactor only the lipid-generation, continual-training and new integration code**, including lipid stage boundaries, if it improves correctness and usability. First inspect the actual implementation, trace its dependencies and explain the decision. Preserve scientific outputs, recovery, and fail-closed validation. Do not delete Stage 04's 3D conformer/LMDB capabilities or Stage 05's final QC/split capabilities just to reduce the script count.
5. **Push source, tests, and documents to the separate HEART v2 GitHub repo incrementally** so tomorrow ChatGPT can inspect the current code, commits, and `docs/HANDOFF_FOR_CHATGPT.md` directly from GitHub. The original HEART repository is read-only for this task.
6. **Do not pretend to have tested real HPC data** unless actually available. Write executable acceptance checks for real CMRI data and label all unperformed checks `PENDING_HPC`.

## 0A. NON-NEGOTIABLE SCOPE FREEZE — general pretraining is already DONE

**The user explicitly says: "General already works; do not change it."** Respect this throughout the overnight development. The H200 general pretraining reached **1,000,000 updates**, its checkpoints exist, and the 192-ligand evaluation already succeeded. Do **NOT** try to repair, optimize, reorganize, modernize, rerun, or reconfigure this already-working part.

**Immutable baseline in the new repo:**

- Copy the complete original Git-tracked repository into the new complete HEART repository, including all general training code, configuration, modules and evaluation notebooks.
- **Do not edit general-pretraining behavior, numerical algorithms, existing shared model backbone, encoder weights/parameter names/shapes, losses, original task `unimol_contrastive`, base data preprocessing, general loader, existing general SLURM launcher, checkpoint format or its validated arguments.**
- In particular, treat `model/pretrain/scripts/pretrain_heart-h200.sh`, the general-pretraining task, general model/loss code, common molecular data transforms and historical evaluation notebooks as **read-only**. Also leave other general training scripts/configs untouched. Do not edit shared `heart_lib.sh` or other base helpers to accommodate the new repository; implement a separate v2 configuration adapter or new helper for library/continual work.
- Do not alter the original general ligand LMDBs, `dict.txt`, general checkpoint files, or original HPC run directories. The new continual training **reads** these existing inputs; it writes only to isolated continual output directories.
- Do not automatically regenerate general checkpoints, change the training objective, change previously validated hyperparameters, retrain 1M updates, or re-run general pretraining smoke/production jobs.
- **Only adapt newly added/modified lipid-generation, continual-training, integration, and deployment files.** Adding new wrappers, adapters and tests is allowed, but avoid editing immutable general files. If a change to a shared original module seems necessary, first develop an isolated adapter/continual-specific implementation; document a `BLOCKED_GENERAL_FREEZE` technical issue rather than silently violating the freeze.
- Unit/contract tests may *read* general source and use it unchanged to verify lipid/continual interoperability. Verify **baseline integrity** by comparing SHA256 or Git blob SHAs of the protected original tracked files against the pinned upstream commit, and publish the comparison in `docs/GENERAL_BASELINE_INTEGRITY.md`. No source diff for those files is permitted in the v2 implementation.
- Preserve the general project's known-working paths/commands as historical references. Use **new repo-aware wrappers** for lipid and continual execution rather than modifying the existing general launcher to handle a different clone path.

**This is NOT a general-pretraining rewrite. Development priorities are:**

1. Lipid library Stage 01–05 correctness, performance and recovery (especially Stage 04/05).
2. Exact lipid LMDB compatibility with the unchanged general ligand `dict.txt` and original HEART data pipeline.
3. General checkpoint → **new** continual-pretraining initialization, mixed data ingestion, 200K updates, checkpoint resume and evaluation.
4. Consistent H200 `sbatch` arguments for **library Stage 04** and **continual training**, without altering general pretraining's existing resource settings.
5. A full, independent **HEART** GitHub repository with incremental pushed commits and `docs/HANDOFF_FOR_CHATGPT.md`.

---

## 1. Starting facts and existing tested state

These are facts from past CMRI runs; inspect GitHub source rather than assuming any file matches a local HPC copy.

- H200 **general pretraining** finished **1,000,000 updates**, batch **448**, best validation loss approximately **0.624**. General run: `/home/ypan/heart_liver/model_train/heart-molecular-pretraining/runs/h200/full/heart-h200-b448-v1/`; important **read-only** files `checkpoint_best.pt`, `checkpoint_last.pt`, `checkpoint_24_1000000.pt`. Never put them in GitHub or overwrite them.
- H200 192-molecule general-ligand embedding evaluation has completed; this is a **representation diagnostic**, not downstream lipid-delivery accuracy.
- Input chemical space: 64 amines × 61 accepted isocyanides (exclude invalid B62) × 64 aldehydes × 61 acids = **15,241,216 raw Ugi-4CR combinations**, before chemical failures and deduplication.
- Scientific generation requirements: accepted building-block chemistry; fixed Ugi-4CR product rules; ETKDGv3 + MMFF; **10 stored 3D coordinate slots**, up to 15 attempts, MMFF max 4,000 iterations, **`STORE_2D=0`** matching the audited general ligand data; training-time 2D is added by the HEART pipeline; preserve per-record successful-3D/fallback accounting and all schema constraints. Never silently alter molecular identities or drop nonconverged records.
- New Stage 04 / Stage 05 100-molecule smoke test: **job 1013331** `COMPLETED` `0:0`, **100 records / 10 LMDB shards**, final QC passed. Do not regress the manifest aggregate-list check (`stored_2d_conformer=[False]`, `coordinate_slots_per_record=[10]`). Earlier job 1013330 failed due to a smoke assertion, not generated-LMDB corruption.
- Full previous production: stage 01 `1013342` completed; stage 02 array `1013343`, **task 63 FAILED `13:0` after ~1 second**, other tasks apparently completed; stages 03 `1013344`, 03b `1013345`, 04 `1013346`, 05 `1013347` were blocked/cancelled. **Actual task-63 traceback not provided.** Must not fabricate a root cause, erase completed chunks, or tell the user to regenerate all 15M combinations.
- CMRI requests for `cmri-gpu04` H200 with 250 logical CPUs / 400–500 GB were accepted by real `sbatch` submissions; 300/400 CPUs rejected. Acceptance does not prove node allocation or 250-worker speed. `cmri-gpu04` H200 machine has approximately 128 physical cores / 256 logical threads: benchmark 64/128/250 workers later before claiming any runtime speedup.

## 2. Files / APIs to retain and understand, not replace blindly

**Copy the entire Git-tracked upstream repository as the starting tree** of the new repo; do not manually reconstruct a subset. Inspect at least:

| Subsystem | Upstream code examples | Required behavior |
| --- | --- | --- |
| General pretraining — **FROZEN** | `model/pretrain/scripts/pretrain_heart-h200.sh`, `model/pretrain/scripts/heart_lib.sh`, configs, `model/pretrain/README_HEART.md`, general training tools/tests | **Copy unchanged from pinned upstream SHA. No editing, optimization or retraining.** Test file hashes remain identical. |
| General model / base datasets — **FROZEN** | `model/unimol/models/`, `model/unimol/tasks/unimol_contrastive.py`, existing shared `model/unimol/data/` preprocessing, losses, dictionaries | **No modifications to shared general behavior.** New/continual-specific files may be added or fixed independently; preserve general encoder, losses, token semantics, geometry and independent views. |
| Lipid library | `model/pretrain/lipid_library/*.py`, `model/pretrain/scripts/lipid_library/*.sh` and `.sbatch` | Chemistry → enumeration → global dedup → optional partitioning → 3D+LMDB → strict finalization/splits. |
| Mixed continual task | `model/unimol/tasks/unimol_contrastive_continual.py`, `model/unimol/data/merged_sampling_dataset.py` | Mix **actual general and lipid** LMDBs without modifying the original general data; handle thousands of shard files with bounded LMDB descriptors. |
| Continual runner | `model/pretrain/scripts/continual_pretrain_heart-h200.sh` | Initialize from general **best** checkpoint with strict parameter match, reset optimizer/scheduler for 200K; subsequently resume from continual **last** checkpoint including optimizer state. |
| Data / checkpoint gates | `model/pretrain/tools/check_continual_data.py`, `init_continual_checkpoint.py`, `check_continual_stage.py`, `check_resume_args.py`, related tools | Reject incompatible LMDBs, dictionary, checkpoint weights/shapes, incomplete splits, invalid resume, or accidental output collision. |
| Evaluation | existing H200 best-checkpoint embedding evaluation notebook(s), diagnostics, tests | **Copy existing general evaluation unchanged**; add separate post-continual read-only diagnostics instead of editing historical notebooks. |
| Infrastructure | requirements/env documentation, Uni-Core pin and notices, `.gitignore`, license | Reproducible deployment in new checkout without hard-coded old repo imports; no large data or checkpoints in Git. |

Before coding, produce `docs/CODE_AUDIT.md` with an actual import/execution dependency diagram and the data contracts for **the frozen general train baseline**, **lipid library**, **continual train**, and **evaluation**. Record protected-file hashes in `docs/GENERAL_BASELINE_INTEGRITY.md`. Identify outdated READMEs/status claims and update them without inventing HPC results. Preserve upstream license/attribution.

## 3. Scientific/data compatibility: non-negotiable acceptance gates

The lipid dataset is not useful until the **same model** used for general ligand pretraining can load it via the **actual existing continual task**.

1. General reference dataset (read-only): `/home/ypan/heart_liver/model_train/UniMolReference/ligand_data/ligands/{train.lmdb,valid.lmdb,dict.txt}`. Do NOT copy its full content to GitHub. A sample may be inspected read-only on HPC by the user later.
2. Lipid output: `/home/ypan/heart_liver/model_train/lipid_library/lmdb/` with `manifest.json`, `splits.json`, `validation.json`, per-shard LMDB receipts, and deterministic provenance.
3. **Keys:** contiguous ASCII integer keys in each LMDB as supported by the existing general loader and `MergedSampledLMDBDataset`; no SMILES-key LMDB variant.
4. **Records:** exact `smi`, `atoms`, `coordinates` fields and compatible data types/shape; matching atom order / 3D coordinate arrays; appropriate hydrogen removal policy (`only_polar=0`) / max 256 heavy atoms; no silent vocabulary modifications. Use the original general `dict.txt` for all lipid records.
5. **Stored slots:** general `train.lmdb` and `valid.lmdb` have actual reference 10-slot / 2D policy; lipid output must match, including training-time 2D augmentation and two independent contrastive views. Audit failed conformer/fallback slots rather than accepting any array of shape 10 as 10 successful 3D conformers.
6. **Splits/completeness:** full enumeration and dedup accounted for; all expected LMDB shards complete and fingerprint-verified; train/valid disjoint, nonempty, manifest hash consistent; final checks return nonzero when incomplete.
7. **Real integration tests:** construct a synthetic representative general-format LMDB + lipid LMDB; run the **actual** general loader, `MergedSampledLMDBDataset`, `unimol_contrastive_continual` task and collator to construct a batch; verify tensor shapes, independent views, atom/distance/coordinate operations, no unexpected token errors. Add a read-only CMRI acceptance command using the original `check_continual_data.py`. Do not claim real general LMDB compatibility `PASS` without that HPC read-only check.
8. **Checkpoint-to-continual model compatibility:** `checkpoint_best.pt` was trained as `unimol_contrastive`, while the continual task is `unimol_contrastive_continual`; model weights and embedding/dictionary dimensions must match exactly, without partial loading. Dry-run `init_continual_checkpoint.py` / runner preflight with synthetic or authorized inputs; retain the original `checkpoint_best.pt` untouched.
9. **Avoid leakage:** do not mix lipid train and validation shard lists; if sampling weights change effective epoch proportions, document actual `n_sampled` rather than advertising them as a simple 50:50 batch mixture.

Create `docs/HEART_GENERAL_TO_LIPID_COMPATIBILITY.md` and executable `tests/integration/` + `scripts/check_heart_hpc_readonly.sh`. Report each gate separately (`PASS_LOCAL`, `PENDING_HPC`, or `FAIL`) with evidence.

## 4. Stage architecture audit — preserve the functions, optimize the boundaries

Before altering stages, trace all Python entrypoints, inputs/outputs, hash/receipt locks, exit codes and resources.

- **01 Building blocks/QC:** validate source Excel and reagent categories; B62 exclusion; chemistry review gate. Determine whether review warnings are expected or risky.
- **02 Enumeration:** deterministic mixed-radix indexing, 64 array tasks, 50K chunks, receipts, SHA checks; investigate **task 63 exit 13** using source and logs when available. Check zero-assigned-task boundaries, concurrent config lock, `set -e`, provenance read/write race and SLURM startup. Distinguish hypotheses from proven causes. Existing successful chunks must be skipped on resume.
- **03 Dedup:** global canonical molecular identity policy, exact product/failure count reconciliation.
- **03b Partition:** performance optimization to avoid each conformer worker rereading the 15M stream. May be merged if equivalent deterministic, cheap, resumable I/O can be proved.
- **04 Conformers/LMDB — ESSENTIAL:** ETKDGv3/MMFF settings, deterministic seeds, explicit 3D success/fallback accounting, bounded workers, memory/I/O, mutually exclusive writers, per-shard atomic commits/checksums and restart-safe skip logic.
- **05 Finalization — ESSENTIAL:** fail-closed completeness, manifest, split accounting, LMDB record/checkpoint-loader compatibility and hashes; `afterany` may generate an incomplete report but must **not** mark missing output as complete.

It is fine to keep six jobs if it is safer. A simpler orchestration is allowed ONLY with equivalent chemistry and strong regression/integration tests. Do not automatically reduce the original 15.24M combination scope to a sampled library. A small pilot should use its **own** directory.

## 5. One central HPC configuration for all modes

Implement a **single canonical source of SLURM resource settings** with generated CLI parameters and enforced consistency. Do not allow contradictory `#SBATCH --gres=gpu:1` and `sbatch --gres=gpu:h200:1` declarations to appear as competing sources. Fail fast if requested node/GRES/resource class conflicts. A dry-run must print **the exact `sbatch` command** and dependencies for each stage.

### A. Library stages 01–03b and 05 (CPU tasks)

- CMRI partition: `gpu` (current known working partition; CPU-only jobs there have been accepted). Request **no GPU GRES** unless an actual allocation policy requires one and it is documented.
- Preserve per-stage CPU, RAM, time limits appropriate to actual workload and explain tuning; do not reserve 250 CPUs for each of the 64 enumeration array tasks.

### B. Library Stage 04 (CPU-intensive but restricted to H200 node)

| Field | Required currently established production setting |
| --- | --- |
| partition | `gpu` |
| H200 GRES | **`gpu:h200:1`**, NOT `gpu:h200a:1` or generic `gpu:1` |
| H200 node | `cmri-gpu04` (allow `cmri-gpu05` if explicitly configured) |
| allocation | **250 SLURM logical CPUs**, **500G RAM**, **1 H200** |
| RDKit workers | default **250** until measured; do NOT claim 250 physical cores |
| wall time | `2-00:00:00` |
| environment | `OMP_NUM_THREADS=1`, `MKL_NUM_THREADS=1`, `OPENBLAS_NUM_THREADS=1` |
| geometry | preserved 1,000-task shard stride; `STORE_2D=0`; 10 stored slots |

CPU-based RDKit does not gain GPU CUDA acceleration; an H200 GRES is used to select the available high-core-count node. Show a future **CPU scaling benchmark** plan (64/128/250 workers, throughput and memory). Do not start benchmark jobs on HPC unattended.

### C. H200 Continual pretraining — SEPARATE resource profile

- Partition `gpu`, GRES **`gpu:h200:1`**, valid H200 node or scheduler policy (never T4).
- **1 H200, 16 CPUs, 200G RAM**, H200 `heart_gpu` environment, 4 DataLoader workers, per-device batch 448, one GPU, fp16 (from the existing successful general H200 setup; check actual script).
- Start from `runs/h200/full/heart-h200-b448-v1/checkpoint_best.pt` **read-only** for a NEW continual stage. The new continual training output is a separate run directory, never the full/general run directory.
- Continual training science: **200,000 new updates**, LR `2e-5`, warmup 1,000, weight decay `1e-4`, general sampling weight `0.5`, lipid sampling weight `1.0` (subsampling fractions, **not a guaranteed per-batch ratio**), unchanged backbone/losses/independent contrastive views.
- Initialize weights strictly but reset optimizer/learning rate schedule, fp16 scaler, elapsed-time state and step count. On interrupted continuation, resume strictly from the **continual** `checkpoint_last.pt`, preserving optimizer/scheduler/update counters. Never use the general checkpoint as the direct resume file.
- A **small real-HPC continual smoke test** with a separate isolated output should be made possible and described; it requires user authorization for a real HPC job. Do not call a CPU mock a successful H200 training run.

### D. Historical general pretraining — IMMUTABLE, out of scope

- **Copy unchanged; do not reconfigure.** Its completed 1M run, H200 checkpoint format and 192-molecule evaluation are the proven reference. Ensure new library/continual components can import and interact with the baseline, but do not touch the general launcher/model/training scripts or historical evaluation notebooks.
- If a single new submission config is introduced, it governs **new lipid and continual jobs only**, not the old general launcher.

**Acceptance:** mock `sbatch` assertions for **library stages and continual H200 only**; independently check protected general-pretraining file hashes against upstream. Error if Stage 04 targets T4 or continual accidentally uses 250 CPUs/500G.

## 6. End-to-end integration: library MUST connect to continual training

Build a **single documented user workflow** with separate explicit commands that are safe by default (names are illustrative; use a maintainable CLI or a clear master launcher):

```text
heart --check                      # source/env/general data/checkpoint paths, no writes
heart library --dry-run            # preview complete library jobs (no submissions)
heart library --submit             # ONLY when explicitly requested, full library jobs
heart library --status             # progress, failed tasks and receipts
heart library --resume --dry-run   # preview ONLY missing/broken work and dependencies
heart library --resume --submit    # ONLY when explicitly requested after review
heart continual --check            # read-only real general+lipid preflight and checkpoint shape check
heart continual --dry-run          # print actual 1-H200, 16-CPU continual job request
heart continual --smoke --submit   # ONLY with user approval; separate run name/output
heart continual --submit          # ONLY with user approval, start or resume continual run
heart evaluate --check            # verify read-only evaluation setup
```

- The launcher MUST gate continual production on a complete **non-smoke** lipid manifest/splits and general LMDB compatibility. Library completion should not automatically submit an expensive 200K H200 training job without explicit user action. Config and paths must match between the two workflows.
- A **single config file FOR NEW LIBRARY + CONTINUAL OPERATIONS** should reference (read-only) the existing general ligand dir, pretrained checkpoint and `dict.txt`, and specify lipid chemistry options, independent H200 resource profiles, continual scientific flags, output dirs and Uni-Core version. Describe config precedence. **Do not redirect or change the existing general pretraining launcher.** Avoid hard-coded dependency on the *old clone path* for imports; new repo must be runnable after clean checkout.
- Preserve evaluation utilities/notebooks and add an evaluation hook for the continual checkpoint. Check correct architecture, stages, read-only source paths, and no T4 comparison requirement. Do not infer delivery or tissue specificity from embedding plots.
- Build **actual local synthetic integration tests**: 100-combination tiny library → validated LMDB → general-ligand fixture + lipid fixture → continual task batching → general checkpoint-compatible model load dry-run → simulated H200 launch → checkpoint/resume logic → read-only evaluation. Use stubs/mocks only where needed for non-HPC systems and say so.
- Docs must explain **the new GitHub repo's cloned HPC location** versus existing `heart-molecular-pretraining/` code and results. Original production data/checkpoint locations remain untouched and referenced by configuration. No destructive migration.

## 7. Overnight execution stages (do these in order, continue safely)

### Phase 1 — READ ONLY audit and clone full codebase

1. Record original HEAD SHA; clone the **complete original tracked repository** into a separate working directory, preserving all immutable general code, configs, model and notebooks byte-for-byte. Do not clone only lipid-related files or copy ignored run data. Create the initial protected-file SHA list before changes. **Skip review/refactoring of working general training internals except as needed to define an integration contract.**
2. Create `docs/CODE_AUDIT.md` and `docs/WORKFLOW_ARCHITECTURE.md` showing dependencies, outputs, and mandatory vs optional steps.
3. Create `docs/OVERNIGHT_PROGRESS.md`, note tasks/status/real vs mocked evidence; commit/push progress to separate destination repo/branch when authorized.

### Phase 2 — Bug investigation and robust library recovery

1. Inspect Stage 02 startup, array task 63, fingerprints/concurrency, and possible failure causes. If HPC logs absent, report `ROOT_CAUSE_NOT_CONFIRMED`. Add reproducible boundary tests (especially task 63); do not guess that one lipid caused `13:0`.
2. Improve safe resume: do not regenerate chunks with matching receipts/hashes; no silent overwrite; handle failed partial array tasks and recreate downstream SLURM dependencies without redoing finished stages.
3. Audit/optimize Stage 04/05 and their scientific/data-integrity contracts; choose to retain/combine stages based on evidence.

### Phase 3 — One configuration, both H200 job profiles

1. Refactor duplicate **lipid/continual** launchers and their `#SBATCH` defaults so the authoritative config yields exactly the intended resources for library Stage 04 and *independently* continual pretraining. **Leave existing general training launchers and shared baseline helpers unchanged.** Other stages must not accidentally reserve H200.
2. Implement `--dry-run`, `--status`, `--resume`, and explicit `--submit` operations with job-ID tracking, immutable config hashes and clear failure conditions.
3. Add mocked-SLURM tests that inspect **actual command arguments** and node/GRES choices for all entrypoints, not only YAML text.

### Phase 4 — HEART data and checkpoint integration

1. Ensure new repo contains **unchanged copies** of the general training/model/base-loader source and original evaluation notebooks alongside the optimized lipid generator, mixed-continual task/loader, initialization/resume/checkpoint tools and **new separate continual evaluation**. Repair stale imports/paths in **new or continual-specific files only**; prefer a new adapter rather than editing any protected general file.
2. Implement synthetic dataset schema + actual model/task loader/collator integration tests and the real-HPC read-only acceptance script.
3. Validate continual checkpoint initialization and resume state semantics; expose genuine `HEART_DRY_RUN` and isolated smoke options. No 200K job should launch automatically.

### Phase 5 — Reproducible docs, tests, GitHub publishing

1. Run `bash -n`, ShellCheck if available, pytest/unit/integration tests, mocked `sbatch` tests, directory-from-scratch install check, and security checks against accidental binary/data commits. Report missing runtime dependencies rather than claiming tests passed.
2. Create `README.md` with a **single project-level overview** (General pretraining [COMPLETED/UNCHANGED] → Lipid LMDB → Continual training → Evaluation), `docs/GENERAL_BASELINE_INTEGRITY.md`, `docs/HEART_GENERAL_TO_LIPID_COMPATIBILITY.md`, `docs/HPC_INSTALL_AND_RECOVERY.md`, `docs/UPSTREAM_DEPENDENCIES.md`, `docs/TEST_RESULTS.md`, and `docs/HANDOFF_FOR_CHATGPT.md`. Existing historical general-training docs should be preserved; correct outdated status in the *new top-level README* instead of rewriting protected general documents.
3. Push the full working codebase, docs, scripts, and tests to **`andypan0214/heart-molecular-pretraining-v2`** (or the explicitly reported private alternative) in incremental commits on a feature branch, then create a PR in THAT repository if supported. Do not push to or rewrite the original HEART repository. Report if authorization is blocked.
4. Handoff must state **repository URL, branch, latest commit SHA, PR URL (if any), completion status by phase, exact module paths, changed architecture, passed/failed/pending tests, the two different H200 job profiles, and next CMRI commands**. Keep repo accessible through the user's existing GitHub integration, subject to account permissions.

## 8. Safety / version control / unattended execution

- **Do not submit `sbatch` jobs on CMRI**, run 15M chemistry generation or 200K training unattended; do not claim overnight computational HPC jobs happened. Only source-code implementation, small local fixtures, mocks, docs, and permitted GitHub pushes are in scope.
- Do not overwrite or delete: original GitHub repo, old HPC checkout, previous enumeration chunks/receipts, current lipid production LMDB, original general ligand data, H200 general/continual checkpoints, notebooks, logs, conda environments, unrelated worktree changes. No `git push --force`, `git reset --hard`, or destructive cleanup of the existing HPC checkout.
- No `*.pt`, `*.lmdb`, full datasets, private Excel source sheets, personal/private HPC logs, tokens, secrets, output zips or enormous generated binary data in Git. Honor licensing of upstream components and do not relocate environment binaries. Keep `runs/` ignored.
- Use safe local working branches. User authorizes pushing **source code to the separate private HEART v2 repository**. If repository creation or write permission requires explicit interaction, prepare the complete git-ready code, document blocker and only ask for that one action; do not silently use the original repo.
- If a phase is blocked, still complete independent safe phases and publish progress. Do not claim a result was tested on H200 if you only ran local CPU or mocked tests.
- Never make architecture changes to general model/backbone, pretrained loss functions, general-data sampling in the original task, model weights or general checkpoint schema. For lipid-only geometry/chemistry or continual-specific changes, flag breaking changes and preserve the original behavior by default. New speculative research designs belong in an **optional proposal**, not an unannounced replacement.

## 9. Final acceptance checklist (do not skip)

- [ ] New repo includes **all original Git-tracked HEART source**; the **general pretraining part is byte-for-byte unchanged** against pinned upstream and only lipid/continual/integration features are changed or added.
- [ ] New lipid/continual workflows and integration run from a clean clone with pinned dependencies; historical general pretraining scripts remain unchanged and are NOT rerun or rewritten.
- [ ] General H200 checkpoint and ligand data remain read-only; protected general-training source/hash report shows zero modifications; strict model weight/dictionary compatibility and new continual optimizer reset are tested.
- [ ] Actual original general ligand reader / mixed-continual task can read synthetic general+lipid LMDB and form independent-view batches without schema or shape errors.
- [ ] Real-data read-only general/lipid compatibility command is provided; `PENDING_HPC` displayed until it truly runs on CMRI.
- [ ] Stage 02 `task 63` test included; cause is honestly labeled confirmed/unconfirmed; recovery preserves existing enumeration receipts.
- [ ] Stage 04 ETKDGv3/MMFF, 10 stored coordinates and `STORE_2D=0` remain intact; Stage 05 fails closed and produces valid disjoint splits.
- [ ] Library Stage 04 `gpu:h200:1`, `cmri-gpu04`, **250 logical CPUs / 500G**; continual pretraining `gpu:h200:1`, **16 CPUs / 200G**, batch 448, **200K updates**; actual SLURM commands checked in mocks.
- [ ] No T4 for production H200 tasks and no alternate launcher silently overrides resource arguments.
- [ ] Non-destructive `--dry-run`, `--status`, `--resume` and explicit `--submit` provided and documented. No production automatically submitted.
- [ ] Test results recorded (real vs synthetic vs mock), latest source pushed to separate HEART v2 repo, `docs/HANDOFF_FOR_CHATGPT.md` updated with URL + branch + commit SHA.
- [ ] Original HEART repo and all existing HPC data remain unchanged; no private datasets, checkpoints or logs in Git history.

## 10. Final report to user — concise, evidence-based

1. Independent **complete HEART v2 GitHub repository** URL / branch / latest SHA / PR link.
2. General pretraining status (**COMPLETED and UNCHANGED, hash integrity PASS/FAIL**), lipid generation status, continual integration status, separate continual evaluation status.
3. Which six library stages were retained/merged and why; Stage 02 failure hypothesis or confirmed cause, and non-destructive recovery steps.
4. Scientific compatibility results: exact LMDB keys/fields/slots/dictionary, loader+collator, checkpoint init/resume; real-HPC tests `PASS` versus `PENDING_HPC`.
5. The exact single config location and two independent H200 `sbatch` resource profiles; proof no contradictory arguments remain.
6. The few commands needed on CMRI to clone new repo, preview library and continual work, and safely resume partial production—without launching jobs now.
7. Status/risks/remaining approvals. Never claim general data, checkpoints or 15M molecules have been migrated to GitHub.

**SUCCESS = Tomorrow ChatGPT can open a single NEW GitHub HEART v2 repository, read `docs/HANDOFF_FOR_CHATGPT.md` and the complete code, and help the user resume the lipid pipeline and then start continual pretraining without manually patching SLURM arguments or losing the completed general H200 model.**
