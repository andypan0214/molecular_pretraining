"""Frozen-general-baseline integrity: protected files must equal upstream 73a5f9d byte for byte.

    bin/heart baseline            # verify (exit 1 on any modified/missing protected file)
    bin/heart baseline --generate # (maintainers) rebuild config/general_baseline_manifest.json from git

The manifest lists every file tracked at the pinned upstream commit EXCEPT the
lipid-library / continual-training files that v2 is allowed to change
(MODIFIABLE below). For each protected file it stores the git blob SHA-1, so
the check works on any checkout -- with or without git history -- by hashing
the working-tree bytes the same way git does.
"""
import fnmatch
import hashlib
import json
import os
import subprocess

from .config import REPO_ROOT

UPSTREAM_REPO = "https://github.com/andypan0214/heart-molecular-pretraining"
UPSTREAM_SHA = "73a5f9d4a624a37dfad0f943093187af06bae5e3"
MANIFEST = os.path.join(REPO_ROOT, "config", "general_baseline_manifest.json")

# Lipid / continual / integration files v2 may change (everything else is frozen).
MODIFIABLE = [
    "README.md",
    ".gitignore",
    "model/pretrain/lipid_library/*",
    "model/pretrain/scripts/lipid_library/*",
    "model/pretrain/scripts/continual_pretrain_heart-h200.sh",
    "model/pretrain/tools/check_continual_data.py",
    "model/pretrain/tools/check_continual_registry.py",
    "model/pretrain/tools/check_continual_stage.py",
    "model/pretrain/tools/init_continual_checkpoint.py",
    "model/pretrain/configs/continual_pretrain.yaml",
    "model/pretrain/README_CONTINUAL.md",
    "model/pretrain/CONTINUAL_PRETRAIN_CHANGE_REPORT.md",
    "model/unimol/tasks/unimol_contrastive_continual.py",
    "model/unimol/data/merged_sampling_dataset.py",
    "model/pretrain/tests/test_continual_loader.py",
    "model/pretrain/tests/test_continual_scripts.py",
    "model/pretrain/tests/test_lipid_pipeline.py",
    "model/pretrain/tests/test_ugi_reaction.py",
    "model/pretrain/tests/test_review_fixes.py",
    "model/pretrain/tests/test_v2_review_fixes.py",
    "model/pretrain/tests/lipid_fixtures.py",
]


def is_modifiable(path):
    return any(fnmatch.fnmatchcase(path, pat) for pat in MODIFIABLE)


def git_blob_sha(data):
    return hashlib.sha1(b"blob %d\0" % len(data) + data).hexdigest()


def generate(ref=UPSTREAM_SHA):
    out = subprocess.run(["git", "-C", REPO_ROOT, "ls-tree", "-r", ref], check=True,
                         capture_output=True, text=True).stdout
    files = {}
    for line in out.splitlines():
        meta, path = line.split("\t", 1)
        _mode, kind, sha = meta.split()
        if kind == "blob" and not is_modifiable(path):
            files[path] = sha
    manifest = {"upstream_repo": UPSTREAM_REPO, "upstream_sha": ref, "n_protected": len(files),
                "modifiable_patterns": MODIFIABLE, "protected": dict(sorted(files.items()))}
    with open(MANIFEST, "w", encoding="utf-8", newline="\n") as fh:
        json.dump(manifest, fh, indent=2)
        fh.write("\n")
    return manifest


def verify():
    """{"pass": bool, "n_protected": n, "modified": [...], "missing": [...], "eol_only": [...]}"""
    with open(MANIFEST, encoding="utf-8") as fh:
        manifest = json.load(fh)
    modified, missing, eol_only = [], [], []
    for path, sha in manifest["protected"].items():
        full = os.path.join(REPO_ROOT, path)
        if not os.path.isfile(full):
            missing.append(path)
            continue
        with open(full, "rb") as fh:
            data = fh.read()
        if git_blob_sha(data) == sha:
            continue
        if git_blob_sha(data.replace(b"\r\n", b"\n")) == sha:
            eol_only.append(path)          # Windows autocrlf checkout: same content
            continue
        modified.append(path)
    return {"pass": not modified and not missing, "upstream_sha": manifest["upstream_sha"],
            "n_protected": len(manifest["protected"]), "modified": modified, "missing": missing,
            "eol_only": eol_only}


def git_diff_names(ref=UPSTREAM_SHA):
    """Changed paths vs the pinned commit according to git (None if git/ref unavailable)."""
    try:
        out = subprocess.run(["git", "-C", REPO_ROOT, "diff", "--name-status", ref, "--"],
                             check=True, capture_output=True, text=True).stdout
    except (OSError, subprocess.CalledProcessError):
        return None
    rows = [line.split("\t") for line in out.splitlines() if line.strip()]
    return [(r[0], r[-1]) for r in rows]
