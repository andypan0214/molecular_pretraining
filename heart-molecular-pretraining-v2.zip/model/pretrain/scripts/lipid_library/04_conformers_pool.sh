#!/bin/bash
#SBATCH --partition=gpu
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=250
#SBATCH --mem=500G
#SBATCH --gres=gpu:h200:1
#SBATCH --nodelist=cmri-gpu04
#SBATCH --time=2-00:00:00
#SBATCH --signal=B:USR1@2700
#SBATCH --job-name=lipid-04-pool
#SBATCH --output=/home/ypan/heart_liver/model_train/lipid_library/logs/%x-%j.out
#SBATCH --error=/home/ypan/heart_liver/model_train/lipid_library/logs/%x-%j.err
# =============================================================================
# Stage 04 (v2, production): ETKDGv3 + MMFF conformers -> HEART shard LMDBs in
# ONE H200-node allocation (250 SLURM logical CPUs, 500G, 1 H200 GRES used only
# to land on the high-core-count node; RDKit does not use CUDA).
#
# The #SBATCH header above is a copy of slurm.profiles.lipid_04 in
# config/heart_v2.yaml (tests prove they are identical). Submit with
#   bin/heart library --dry-run | --submit | --resume --submit
# which renders the same flags on the sbatch command line. A start-up guard
# compares the real allocation with the profile and stops on any difference.
#
# Work: python -m lipid_library.stage04_pool -- a dynamic one-shard-per-process
# queue over the unchanged lmdb_writer.write_shard (same chemistry, same
# configuration fingerprint, same shard receipts as the array mode), reading
# only the stage-03b partition. Finished shards are re-verified (sha256) and
# skipped, so resubmitting this job resumes. The whole LMDB directory is locked
# exclusively (no second pool, no array task at the same time).
#   SIGUSR1 (45 min before the limit) / SIGTERM: no new shards start; running
#   shards finish if they can; exit 3 = incomplete, resubmit to continue.
#
# Settings come from bin/heart (config/heart_v2.yaml): LIPID_WORKERS (250),
# STORE_2D (0), RECORDS_PER_SHARD (5000), LIPID_ARRAY_SIZE (1000, the
# historical stride kept for resubmit lists), SEED_START (0), MAX_ATOMS (256).
# =============================================================================
set -eo pipefail
# v2: locate THIS checkout (sbatch runs a spooled copy); never fall back to the old clone.
here="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [ ! -f "$here/lipid_lib.sh" ]; then
    if [ -n "${HEART_REPO:-}" ]; then
        here="$HEART_REPO/model/pretrain/scripts/lipid_library"
    elif [ -n "${SLURM_JOB_ID:-}" ] && command -v scontrol >/dev/null 2>&1; then
        here="$(dirname "$(scontrol show job "$SLURM_JOB_ID" | sed -n 's/^ *Command=//p' | head -1 | cut -d' ' -f1)")"
    fi
fi
[ -f "$here/lipid_lib.sh" ] || { echo "ERROR: cannot locate scripts/lipid_library (set HEART_REPO)" >&2; exit 1; }
# shellcheck source=lipid_lib.sh
. "$here/lipid_lib.sh"
lipid_init "$here/04_conformers_pool.sh"
lipid_writer_args

[ -f "$LIPID_DEDUP/drop_combo_indexes.csv.gz" ] || die "run stage 03 first (drop list missing)"
[ -r "$LIPID_LMDB/shard_inputs/partition_index.json" ] || die "run stage 03b first (no shard-input partition)"
[ -r "$LIPID_DICT" ] || die "model dict.txt not readable: $LIPID_DICT"
[ "${STORE_2D:-}" = "0" ] || [ "${HEART_ALLOW_STORE_2D:-0}" = "1" ] \
    || die "STORE_2D=${STORE_2D:-unset}: the audited general ligand policy is STORE_2D=0"

# v2 hardening (mandatory, read-only): measure the REAL general ligand slot policy and refuse to
# generate shards that would not match it (also checked by bin/heart before submission).
mkdir -p "$LIPID_LMDB"
"$PY" -m lipid_library.general_policy "$DATA_PATH" --n-3d 10 --store-2d "$STORE_2D" \
    --lipid-dict "$LIPID_DICT" --sample "${LIPID_GENERAL_POLICY_SAMPLE:-256}" \
    --json-out "$LIPID_LMDB/general_policy_check.json" \
    || die "general ligand conformer policy does not match STORE_2D=$STORE_2D / 10 slots (see $LIPID_LMDB/general_policy_check.json)"

workers="${LIPID_WORKERS:-250}"
stride="${LIPID_ARRAY_SIZE:-1000}"
case "$workers$stride" in *[!0-9]*|'') die "bad LIPID_WORKERS/LIPID_ARRAY_SIZE" ;; esac
if [ -n "${SLURM_CPUS_PER_TASK:-}" ] && [ "$workers" -gt "$SLURM_CPUS_PER_TASK" ]; then
    die "LIPID_WORKERS=$workers > SLURM_CPUS_PER_TASK=$SLURM_CPUS_PER_TASK"
fi

# Deadline for the "do not start a shard that cannot finish" rule.
deadline_args=()
if [ -n "${SLURM_JOB_ID:-}" ] && command -v squeue >/dev/null 2>&1; then
    left="$(squeue -h -j "$SLURM_JOB_ID" -o %L 2>/dev/null | head -1)"
    secs="$("$PY" -c 'import sys
t = sys.argv[1].strip()
if not t or t in ("UNLIMITED", "NOT_SET", "INVALID"): sys.exit(1)
d, _, hms = t.rpartition("-")
p = [int(x) for x in hms.split(":")]
while len(p) < 3: p.insert(0, 0)
print(int(d or 0) * 86400 + p[0] * 3600 + p[1] * 60 + p[2])' "$left" 2>/dev/null || true)"
    if [ -n "$secs" ]; then
        deadline_args=(--deadline-epoch "$(( $(date +%s) + secs ))" --margin-min "${LIPID_DEADLINE_MARGIN_MIN:-45}")
        log "time left $left -> no shard starts that cannot finish ${LIPID_DEADLINE_MARGIN_MIN:-45} min before the limit"
    fi
fi
[ "${#deadline_args[@]}" -gt 0 ] || warn "SLURM time limit unknown: deadline gating disabled"

pool_args=(--workers "$workers" --stride "$stride" --map-size-gb "${LIPID_MAP_SIZE_GB:-16}"
    --commit-every 2000 --sec-per-molecule-hint "${SEC_PER_MOLECULE:-3.0}"
    --bytes-per-record "${LIPID_BYTES_PER_RECORD:-26000}" --min-free-factor "${LIPID_MIN_FREE_FACTOR:-1.15}")
[ "${LIPID_SKIP_DISK_CHECK:-0}" = "1" ] && pool_args+=(--skip-disk-check)

log "stage 04 pool: $workers workers on $(hostname), $(nproc 2>/dev/null || echo '?') CPUs visible, stride $stride"
"$PY" -m lipid_library.stage04_pool "$LIPID_ENUM" -o "$LIPID_LMDB" "${LIPID_WRITER_ARGS[@]}" \
    "${pool_args[@]}" --dry-run || die "stage 04 pre-flight failed"
[ "${HEART_DRY_RUN:-0}" = "1" ] && { log "HEART_DRY_RUN=1: pre-flight only"; exit 0; }

# Run in the background so SLURM's SIGUSR1/SIGTERM reach this shell; forward them.
"$PY" -m lipid_library.stage04_pool "$LIPID_ENUM" -o "$LIPID_LMDB" "${LIPID_WRITER_ARGS[@]}" \
    "${pool_args[@]}" "${deadline_args[@]}" &
pool_pid=$!
forward() { log "received SIG$1: asking the pool to stop starting shards"; kill -"$1" "$pool_pid" 2>/dev/null || true; }
trap 'forward USR1' USR1
trap 'forward TERM' TERM
set +e
while :; do
    wait "$pool_pid"; rc=$?
    kill -0 "$pool_pid" 2>/dev/null || break
done
set -e
trap - USR1 TERM
case "$rc" in
    0) log "stage 04 complete: stage 05 (finalize) can run" ;;
    3) warn "stage 04 stopped with shards left (deadline/signal): resubmit with bin/heart library --resume --submit" ;;
    *) warn "stage 04 exit $rc: see $LIPID_LMDB/stage04_progress.json and the log above" ;;
esac
exit "$rc"
