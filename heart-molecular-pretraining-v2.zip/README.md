# HEART v2 — molecular pretraining: general (frozen) → lipid library → continual

HEART pretrains a 3D-aware molecular encoder (Uni-Mol architecture, LUMI-lab objectives: masked atom
prediction, coordinate denoising, distance prediction, NT-Xent contrastive learning) with the Uni-Core
trainer. This repository (`heart-molecular-pretraining-v2`) is the complete successor of
[`heart-molecular-pretraining`](https://github.com/andypan0214/heart-molecular-pretraining) at upstream
commit `73a5f9d` (tag `upstream-baseline-73a5f9d`). It contains all of that code, with the general
pretraining kept byte for byte, plus the lipid-library and continual-training work.

| Phase | Status | Where |
|---|---|---|
| 1. General pretraining on the Uni-Mol ligand LMDB | **COMPLETED, FROZEN (unchanged in v2)**. H200 run `heart-h200-b448-v1`: 1,000,000 updates, batch 448, best valid loss ≈ 0.624; 192-ligand embedding evaluation done | `model/pretrain/scripts/pretrain_heart-h200.sh`, `model/unimol/`, [`README_HEART.md`](model/pretrain/README_HEART.md), [`docs/GENERAL_BASELINE_INTEGRITY.md`](docs/GENERAL_BASELINE_INTEGRITY.md) |
| 2. Ugi-4CR lipid virtual library → HEART LMDB | Code ready and tested locally. Production run on CMRI: stage 01 (job 1013342) completed; stage 02 array 1013343 task 63 FAILED `13:0` (cause not yet confirmed), the other tasks apparently completed (to be verified by `bin/heart library --status`); stages 03–05 were cancelled and have **not yet run** | `model/pretrain/lipid_library/`, `model/pretrain/scripts/lipid_library/`, `bin/heart library` |
| 3. General + lipid continual pretraining (200K updates) | Code ready and tested locally on CPU (tiny model). **Never run on H200** | `model/pretrain/scripts/continual_pretrain_heart-h200.sh`, `bin/heart continual` |
| 4. Evaluation | Historical general notebooks unchanged; read-only continual checkpoint comparison added | `model/*.ipynb`, `model/pretrain/tools/v2_compare_checkpoints.py`, `bin/heart evaluate --check` |

Start here: [`docs/HANDOFF_FOR_CHATGPT.md`](docs/HANDOFF_FOR_CHATGPT.md) (state, commits, pending HPC
checks) and [`docs/HPC_INSTALL_AND_RECOVERY.md`](docs/HPC_INSTALL_AND_RECOVERY.md) (CMRI commands).

## One configuration, two H200 job profiles

All NEW lipid and continual jobs take their paths and SLURM resources from
**[`config/heart_v2.yaml`](config/heart_v2.yaml)**. `bin/heart` renders every `sbatch` flag from it, the
`#SBATCH` headers of the job scripts are proven identical to it by tests, and every job checks its real
allocation against it at start-up. The general launcher is **not** governed by this file.

| Job | Partition | GRES | CPUs | RAM | Time | Node |
|---|---|---|---|---|---|---|
| Lipid stage 04 (RDKit conformers, 250 workers) | `gpu` | `gpu:h200:1` (node selection only, RDKit uses no CUDA) | 250 logical | 500G | 2-00:00:00 | `cmri-gpu04` |
| Continual pretraining | `gpu` | `gpu:h200:1` | 16 | 200G | 2-00:00:00 | scheduler (any H200) |
| Lipid stages 01, 02 (×64), 03, 03b | `gpu`, CPU-only | none | 1 | 4–16G | 0.5–12 h | any |
| Lipid stage 05 (finalize + QC) | `gpu`, CPU-only | none | 16 | 64G | 12 h | any |

## Commands (safe by default: nothing is submitted without `--submit`)

```bash
bin/heart check                      # config, #SBATCH == config, frozen-baseline hashes, paths
bin/heart library --status           # stage 01-05 progress from receipts (read-only)
bin/heart library --resume --dry-run # exact sbatch commands for ONLY the missing work
bin/heart library --resume --submit  # explicit
bin/heart continual --check          # read-only real-data + checkpoint preflight (needs a ready library)
bin/heart continual --dry-run        # exact 1-H200 / 16-CPU / 200G sbatch command
bin/heart continual --smoke --submit # isolated smoke run (own run name/output)
bin/heart continual --submit         # start or resume the 200K-update continual run
bin/heart evaluate --check           # read-only general-vs-continual checkpoint comparison
bash scripts/check_heart_hpc_readonly.sh   # CMRI acceptance gates G0-G7 (read-only)
```

## Layout on CMRI (`/home/ypan/heart_liver/model_train/`)

```text
heart-molecular-pretraining/        historical general checkout + its runs/ (read-only reference, untouched)
  runs/h200/full/heart-h200-b448-v1/checkpoint_best.pt   <- read-only input of continual training
heart-molecular-pretraining-v2/     THIS repository (clone here); continual runs go to its runs/h200/continual/
UniMolReference/ligand_data/ligands/ train.lmdb, valid.lmdb, dict.txt (read-only, never copied)
lipid_library/                      lipid stage outputs (bb/ enum/ dedup/ lmdb/ logs/ jobs/), never in Git
third_party/Uni-Core/               pinned trainer @ ace6fae
```

No data, LMDBs, checkpoints, logs, Excel source sheets or environments are in Git.

## Sources and licences

| Component | Source | Licence |
|---|---|---|
| `model/unimol/tasks`, `models`, `losses` | [LUMI-lab](https://github.com/bowenli-lab/LUMI-lab) @ `611e02b` (modified; derived from Uni-Mol) | GPL-3.0 |
| `model/unimol/data` | [Uni-Mol](https://github.com/deepmodeling/Uni-Mol) @ `90f52c4` (patches P1, P2, P5, P6) | MIT |
| Trainer (dependency, not included) | [Uni-Core](https://github.com/dptech-corp/Uni-Core) @ `ace6fae` | MIT |
| Scripts, tools, tests, lipid library, `heart_v2/`, `bin/`, `config/`, `docs/` | HEART | not yet chosen |

The licence texts and notices are kept in `model/unimol/` (`LICENSE.LUMI-lab`, `LICENSE.Uni-Mol`,
`THIRD_PARTY_NOTICES.md`); see [`docs/UPSTREAM_DEPENDENCIES.md`](docs/UPSTREAM_DEPENDENCIES.md). Please cite
Uni-Mol (Zhou et al., ICLR 2023) and LUMI-lab when using this work.
