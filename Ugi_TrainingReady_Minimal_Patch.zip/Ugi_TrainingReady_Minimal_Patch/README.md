# Ugi-4CR 3D-aware Training-Ready — minimal patch

This patch **updates six existing files**, adds no HPC .sbatch/Python modules, and makes no change to the completed Stage-04 LMDBs, existing `splits.json`, old `quality_report.json`, or existing sidecar index.

Current completed data:
- `/project/yli4/ypan/lipid_library/lmdb/` (3,049 shards; 15,182,715 records)
- `/project/yli4/ypan/lipid_library/lmdb/splits.json` (existing train/valid assignments)
- `/project/yli4/ypan/audits/ugi_3d_final_view/final_dataset_view.json` (verified per-record 3D prefix metadata)

## One-time install (no Git)

Upload ZIP to `/home/ypan`, then:

```bash
cd /home/ypan
unzip -q Ugi_TrainingReady_Minimal_Patch.zip
python Ugi_TrainingReady_Minimal_Patch/install.py --check
python Ugi_TrainingReady_Minimal_Patch/install.py --apply
cd /home/ypan/heart_liver/model_train/heart-molecular-pretraining
bin/heart baseline
bin/heart check
```

**If `--check` says REFUSED, do not force the patch:** the HPC file differs from the supplied file/baseline. Backups for applied changes are stored outside the repo under `/home/ypan/ugi_training_ready_backups/`.

## One-time Stage 06: integrity, existing split and actual 3D-aware loader

The existing `05_finalize.sh` is already guarded and does NOT need rerunning. `05_prepare_3d_view.sbatch` and `prepare_3d_view.py` were used to produce the existing sidecar, and do not need to run again.

```bash
cd /home/ypan/heart_liver/model_train/heart-molecular-pretraining
HEART_CONFIRM_LIPID=1 HEART_V2_ALLOW_DIRECT=1 sbatch --export=ALL model/pretrain/scripts/lipid_library/06_verify_library.sh
```

The existing `heart_v2.guard` requires `HEART_V2_ALLOW_DIRECT=1` for direct `sbatch`; it still enforces matching Slurm resources. If the readiness receipt already exists and remains valid, Step 06 exits without repeating the full hash. When Slurm finishes, confirm `COMPLETED` / exit `0:0`, then:

```bash
PYTHONPATH=model/pretrain python -m lipid_library.ready verify-3d /project/yli4/ypan/lipid_library/lmdb \
  --view /project/yli4/ypan/audits/ugi_3d_final_view/final_dataset_view.json
```

The command is written for execution from the repository root. Successful Stage 06 publishes `/project/yli4/ypan/lipid_library/lmdb/library_3d_ready.json` and retains the original Stage 05 QC FAIL unchanged. `library_3d_ready.json` attests full manifest SHA256 (once), all sidecar hashes, read-only real mixed LMDB loader smoke on train and valid, and pins source/index sizes+mtimes for later quick checks. Subsequent training does NOT repeat full LMDB hashes.

## Ready check / training smoke

From repo root:

```bash
bin/heart continual --check
bin/heart continual --smoke --submit
```

After successful H200 smoke, production continual may be submitted with `bin/heart continual --submit` at the user's discretion. It automatically uses the original `splits.json` and the pinned 3D view when `library_3d_ready.json` exists.

No LNPDB integration required for this Ugi-only readiness. Original UniMolReference is unchanged. Train/valid remain **sharded** rather than duplicated as massive train.lmdb / valid.lmdb files.

## Verification scope and limitations

Local: `py_compile` and `bash -n` PASS; synthetic metadata/readiness and stubbed LMDB loader PASS; baseline verification PASS. The full HPC LMDB/Uni-Core tests cannot run here due to unavailable `lmdb` and `unicore` packages and Project data. Stage 06 is the one-time real-cluster gate.
