#!/usr/bin/env python
"""The single "this lipid library may be used for continual training" receipt (v2).

    python -m lipid_library.ready write  LMDB_DIR [--allow-smoke]                  # last step of stage 05
    python -m lipid_library.ready verify LMDB_DIR [--allow-smoke] [--max-age-days D]     # quick (default)
    python -m lipid_library.ready verify LMDB_DIR --full [--workers 16]             # full re-hash (job)

`library_ready.json` is written ONLY when manifest.json (fail-closed finalize), splits.json,
validation.json and quality_report.json all exist, agree (hash chain) and passed.

Shard integrity (v2 hardening). Metadata hashes alone cannot detect a shard LMDB that was
truncated, overwritten or bit-rotted after stage 05, so `write` also records, per shard, in
`library_integrity.json`: size, mtime_ns and a SAMPLED digest (sha256 of the size plus four 256 KiB
blocks: head, tail and two interior blocks at offsets derived from the shard path), i.e. 1 MiB read
per shard, ~3 GB for ~3,050 shards. Verification levels:

  quick (every `bin/heart continual` call and every continual job start): metadata hash chain +
      every shard present, same size, same sampled digest. A changed mtime with unchanged content
      samples is still refused ("modified after stage 05: run full verification").
  full  (stage 05 itself -- finalize recomputes every shard's sha256 -- or `--full`, run as the
      lipid_verify CPU job): sha256 of every shard (~0.4 TB, parallel threads) == manifest.json.
      Success refreshes the integrity table and writes `library_verified.json`.

A production continual submission additionally requires the last FULL verification to be younger
than `continual.full_verify_max_age_days` (bin/heart passes --max-age-days).
"""
import argparse
import hashlib
import json
import os
import sys
import time

from . import FORMAT_VERSION, io_utils

READY = "library_ready.json"
INTEGRITY = "library_integrity.json"
VERIFIED = "library_verified.json"
READY_3D = "library_3d_ready.json"
BLOCK = 256 * 1024
N_INTERIOR = 2


def _load(path):
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


def _tail(path):
    """`shard-NNNNN/train.lmdb` of a path (independent of where the library directory lives)."""
    parts = os.path.normpath(path).replace("\\", "/").split("/")
    return "/".join(parts[-2:])


# --------------------------------------------------------------------------- shard integrity
def sample_offsets(rel, size, block=None):
    block = block or BLOCK
    span = max(1, size - block)
    offsets = [0, max(0, size - block)]
    for i in range(N_INTERIOR):
        seed = hashlib.sha256("{}:{}:{}".format(rel, size, i).encode("utf-8")).hexdigest()
        offsets.append(int(seed[:16], 16) % span)
    return offsets


def sampled_digest(path, rel, block=None):
    """sha256 over the size and 4 x 256 KiB blocks (head, tail, 2 path-seeded interior blocks)."""
    block = block or BLOCK
    size = os.path.getsize(path)
    offsets = sample_offsets(rel, size, block)
    h = hashlib.sha256(str(size).encode("ascii"))
    with open(path, "rb") as fh:
        for off in offsets:
            fh.seek(off)
            h.update(fh.read(block))
    return h.hexdigest()


def _stat_entry(lmdb_dir, rel):
    p = os.path.join(lmdb_dir, rel)
    st = os.stat(p)
    return {"lmdb": rel, "size": st.st_size, "mtime_ns": st.st_mtime_ns, "sample_sha256": sampled_digest(p, rel)}


def _pmap(fn, items, workers):
    if workers and workers > 1 and len(items) > 1:
        from concurrent.futures import ThreadPoolExecutor

        with ThreadPoolExecutor(max_workers=workers) as pool:
            return list(pool.map(fn, items))
    return [fn(i) for i in items]


def integrity_table(lmdb_dir, manifest, workers=8):
    rels = [s["lmdb"] for s in manifest["shards"]]
    return {"block_bytes": BLOCK, "n_interior_blocks": N_INTERIOR, "created_epoch": time.time(),
            "shards": _pmap(lambda r: _stat_entry(lmdb_dir, r), rels, workers)}


def quick_integrity(lmdb_dir, table, workers=8):
    """Problems from size / sampled-digest / mtime comparison of every shard."""
    def one(e):
        p = os.path.join(lmdb_dir, e["lmdb"])
        if not os.path.isfile(p):
            return "{}: missing".format(e["lmdb"])
        st = os.stat(p)
        if st.st_size != e["size"]:
            return "{}: size {} != {} recorded at stage 05 (truncated/rewritten)".format(e["lmdb"], st.st_size, e["size"])
        if sampled_digest(p, e["lmdb"], table.get("block_bytes")) != e["sample_sha256"]:
            return "{}: sampled content digest changed (corrupted/overwritten)".format(e["lmdb"])
        if st.st_mtime_ns != e["mtime_ns"]:
            return "{}: modified after stage 05 (mtime changed): run full verification".format(e["lmdb"])
        return None
    return [p for p in _pmap(one, table["shards"], workers) if p]


def full_verify(lmdb_dir, workers=16):
    """sha256 of every shard == manifest.json. Returns (problems, seconds)."""
    manifest = _load(os.path.join(lmdb_dir, "manifest.json"))
    t0 = time.time()

    def one(s):
        p = os.path.join(lmdb_dir, s["lmdb"])
        if not os.path.isfile(p):
            return "{}: missing".format(s["lmdb"])
        if io_utils.sha256_file(p) != s["lmdb_sha256"]:
            return "{}: sha256 differs from manifest.json".format(s["lmdb"])
        return None
    problems = [p for p in _pmap(one, manifest["shards"], workers) if p]
    return problems, time.time() - t0


def last_full_verification(lmdb_dir, record):
    """Epoch of the latest full verification that belongs to this ready receipt (or None)."""
    epochs = []
    fv = (record or {}).get("full_verification") or {}
    if fv.get("epoch"):
        epochs.append(float(fv["epoch"]))
    vp = os.path.join(lmdb_dir, VERIFIED)
    if os.path.isfile(vp):
        v = _load(vp)
        if v.get("passed") and v.get("manifest_sha256") == (record or {}).get("manifest_sha256"):
            epochs.append(float(v["epoch"]))
    return max(epochs) if epochs else None


# --------------------------------------------------------------------------- receipt
def check(lmdb_dir, allow_smoke=False):
    """(facts dict, problems list) without writing anything (metadata hash chain + QC verdicts)."""
    problems, facts = [], {}
    paths = {k: os.path.join(lmdb_dir, k + ".json") for k in ("manifest", "splits", "validation",
                                                              "finalize_report", "quality_report")}
    for k, p in paths.items():
        if not os.path.isfile(p):
            problems.append("missing {}".format(p))
    if problems:
        return facts, problems
    manifest, splits = _load(paths["manifest"]), _load(paths["splits"])
    validation, report = _load(paths["validation"]), _load(paths["finalize_report"])
    quality = _load(paths["quality_report"])
    facts.update({
        "manifest_sha256": io_utils.sha256_file(paths["manifest"]),
        "splits_sha256": io_utils.sha256_file(paths["splits"]),
        "validation_sha256": io_utils.sha256_file(paths["validation"]),
        "quality_report_sha256": io_utils.sha256_file(paths["quality_report"]),
        "smoke": bool(manifest.get("smoke") or splits.get("smoke")),
        "n_shards": manifest.get("n_shards"), "n_records": manifest.get("n_records"),
        "n_records_split": splits.get("n_records"),
        "coordinate_slots_per_record": manifest.get("coordinate_slots_per_record"),
        "stored_2d_conformer": manifest.get("stored_2d_conformer"),
        "config_fingerprint": manifest.get("config_fingerprint"),
    })
    if manifest.get("complete") is not True or report.get("complete") is not True:
        problems.append("manifest/finalize_report is not complete")
    if report.get("config_fingerprint") != manifest.get("config_fingerprint"):
        problems.append("finalize_report.json belongs to another finalize run than manifest.json")
    if splits.get("manifest_sha256") != facts["manifest_sha256"]:
        problems.append("splits.json was made from another manifest.json (re-run stage 05)")
    if splits.get("complete") is not True or not splits.get("valid") or not splits.get("train"):
        problems.append("splits.json is incomplete or has an empty split")
    if set(splits.get("train", [])) & set(splits.get("valid", [])):
        problems.append("train and valid splits share LMDBs")
    if validation.get("n_problems") != 0 or validation.get("passed") is False:
        problems.append("validation.json reports {} problem(s)".format(validation.get("n_problems")))
    checked = {_tail(r.get("lmdb", "")) for r in validation.get("results", [])}
    expected = {_tail(s["lmdb"]) for s in manifest.get("shards", [])}
    if expected - checked:
        problems.append("validation.json did not check {} manifest shard(s)".format(len(expected - checked)))
    if quality.get("manifest_sha256") != facts["manifest_sha256"]:
        problems.append("quality_report.json belongs to another manifest.json")
    if quality.get("passed") is not True:
        problems.append("quality_report.json: production-quality criteria not met: {}".format(
            "; ".join(quality.get("failures", []))[:500]))
    if facts["smoke"] and not allow_smoke:
        problems.append("SMOKE library (--limit / partial enumeration): not usable for production training")
    return facts, problems


def write(lmdb_dir, allow_smoke=False, workers=8):
    path = os.path.join(lmdb_dir, READY)
    for name in (READY, INTEGRITY, VERIFIED):
        if os.path.exists(os.path.join(lmdb_dir, name)):
            os.remove(os.path.join(lmdb_dir, name))      # never leave an old receipt beside new artefacts
    facts, problems = check(lmdb_dir, allow_smoke)
    if problems:
        return None, problems
    manifest = _load(os.path.join(lmdb_dir, "manifest.json"))
    report = _load(os.path.join(lmdb_dir, "finalize_report.json"))
    table = integrity_table(lmdb_dir, manifest, workers)
    io_utils.atomic_write_json(os.path.join(lmdb_dir, INTEGRITY), table)
    full = None
    if report.get("lmdb_sha256_verified") and report.get("finished_epoch"):
        full = {"epoch": report["finished_epoch"], "source": "stage-05 finalize (sha256 of every shard)"}
    record = dict(facts, format_version=FORMAT_VERSION, ready=True,
                  created=time.strftime("%Y-%m-%d %H:%M:%S"), lmdb_dir=os.path.abspath(lmdb_dir),
                  integrity_sha256=io_utils.sha256_file(os.path.join(lmdb_dir, INTEGRITY)),
                  full_verification=full)
    io_utils.atomic_write_json(path, record)
    return record, []


def verify(lmdb_dir, allow_smoke=False, full=False, workers=8, max_age_days=None, check_shards=True):
    """(record or None, problems): the receipt exists, still matches the artefacts AND the shards."""
    path = os.path.join(lmdb_dir, READY)
    # Prefer a verified 3D-prefix view whenever present; its sampler policy is
    # stricter than the historical uniform ten-slot path.
    if os.path.isfile(os.path.join(lmdb_dir, READY_3D)):
        return verify_3d(lmdb_dir)
    if not os.path.isfile(path):
        return None, ["no {} (stage 05 has not completed successfully)".format(path)]
    record = _load(path)
    facts, problems = check(lmdb_dir, allow_smoke)
    for k in ("manifest_sha256", "splits_sha256", "validation_sha256", "quality_report_sha256"):
        if facts.get(k) and record.get(k) != facts[k]:
            problems.append("{} changed after library_ready.json was written".format(k))
    ipath = os.path.join(lmdb_dir, INTEGRITY)
    if not os.path.isfile(ipath) or io_utils.sha256_file(ipath) != record.get("integrity_sha256"):
        problems.append("library_integrity.json missing or changed: re-run stage 05")
        return None, problems
    if problems:
        return None, problems
    if full:
        fproblems, seconds = full_verify(lmdb_dir, workers)
        problems += fproblems
        result = {"passed": not fproblems, "epoch": time.time(), "time": time.strftime("%Y-%m-%d %H:%M:%S"),
                  "seconds": round(seconds, 1), "n_shards": record.get("n_shards"),
                  "manifest_sha256": record.get("manifest_sha256"), "problems": fproblems[:100]}
        if not fproblems:
            # content proven == manifest: refresh the quick-check table (e.g. after a copy changed mtimes)
            table = integrity_table(lmdb_dir, _load(os.path.join(lmdb_dir, "manifest.json")), workers)
            io_utils.atomic_write_json(ipath, table)
            record["integrity_sha256"] = io_utils.sha256_file(ipath)
            io_utils.atomic_write_json(path, record)
        io_utils.atomic_write_json(os.path.join(lmdb_dir, VERIFIED), result)
    elif check_shards:
        problems += quick_integrity(lmdb_dir, _load(ipath), workers)
    if max_age_days is not None and not problems:
        last = last_full_verification(lmdb_dir, record)
        if last is None:
            problems.append("no full shard verification on record: run `bin/heart library --verify-full --submit`")
        elif (time.time() - last) / 86400.0 > float(max_age_days):
            problems.append("last full shard verification is {:.1f} days old (> {} days): run "
                            "`bin/heart library --verify-full --submit`".format((time.time() - last) / 86400.0,
                                                                                max_age_days))
    return (record if not problems else None), problems


# ------------------------------------------------------------------- Ugi 3D-aware readiness
# This is independent of the original Stage-05 QC result and never rewrites it.
def _checked_3d_view(lmdb_dir, view_file, hash_indexes=False):
    from pathlib import Path
    base = Path(lmdb_dir).resolve(strict=True)
    view_file = Path(view_file).resolve(strict=True)
    view = _load(str(view_file))
    if view.get("kind") != "existing_Ugi_3d_prefix_index" or view.get("data_index_validated") is not True:
        raise ValueError("3D-view index was not validated")
    if not view.get("all_molecules_with_ge_1_3d_kept") or view.get("production_continual_training_ready") is True:
        raise ValueError("unexpected view provenance or readiness status")
    if Path(view.get("source_lmdb_dir", "/INVALID")).resolve() != base:
        raise ValueError("3D view references a different LMDB root")
    for file, field in (("manifest.json", "source_manifest_sha256"),
                        ("splits.json", "source_splits_sha256"),
                        ("quality_report.json", "source_quality_report_sha256")):
        if io_utils.sha256_file(str(base / file)) != view.get(field):
            raise ValueError("3D view source identity differs for " + file)
    facts, problems = check(str(base))
    qc = _load(str(base / "quality_report.json"))
    # Only the TWO known stored-fallback limits may be excepted. No generic QC bypass.
    prefixes = ("records with a 2D fill-in ", "2D fill-in slot fraction ")
    failures = qc.get("failures") or []
    if not failures or any(not str(f).startswith(prefixes) for f in failures):
        raise ValueError("original QC failures are not limited to known 2D-fill thresholds")
    exceptional = [p for p in problems if p.startswith("quality_report.json: production-quality criteria not met:")]
    if len(exceptional) != 1 or len(problems) != 1:
        raise ValueError("additional original QC/manifest problem(s): " + repr(problems))
    manifest = _load(str(base / "manifest.json"))
    splits = _load(str(base / "splits.json"))
    rels = set(splits["train"]) | set(splits["valid"])
    if set(splits["train"]) & set(splits["valid"]):
        raise ValueError("train/valid shard overlap")
    rows = view.get("shards") or []
    if (len(rows) != len(rels) or len(rows) != view.get("shard_count")
            or len(rows) != manifest.get("n_shards")):
        raise ValueError("view does not cover exactly the train and valid shards")
    by_rel = {r["lmdb"]:r for r in rows}
    if set(by_rel) != rels or len(by_rel) != len(rows):
        raise ValueError("view shard paths do not match train/valid splits")
    total = three_d = fallback = 0
    signatures = []
    for rel in sorted(rels):
        row = by_rel[rel]
        relative = Path(row["index"])
        if relative.is_absolute() or ".." in relative.parts or not relative.parts:
            raise ValueError("unsafe sidecar index path")
        index = (view_file.parent / relative).resolve(strict=True)
        if view_file.parent not in index.parents:
            raise ValueError("sidecar index escapes view directory")
        n = index.stat().st_size
        if n != int(row["n_records"]):
            raise ValueError("sidecar byte length differs: " + str(index))
        if hash_indexes:
            contents = index.read_bytes()
            if io_utils.sha256_file(str(index)) != row["index_sha256"]:
                raise ValueError("sidecar index hash differs: " + str(index))
            if any(x < 1 or x > 10 for x in contents):
                raise ValueError("invalid 3D slot count in " + str(index))
            three_d += sum(contents)
            fallback += sum(x < 10 for x in contents)
        signatures.append((str(index), n, index.stat().st_mtime_ns))
        total += n
    if total != view.get("stored_records") or total != manifest.get("n_records"):
        raise ValueError("view record count does not equal source manifest")
    if hash_indexes and (three_d != view.get("success_3d_slots_total") or
                         fallback != view.get("fallback_containing_records_preserved")):
        raise ValueError("sidecar records fail global 3D/2D accounting")
    return view, view_file, signatures, facts


def _smoke_3d_loader(lmdb_dir, view_file, view):
    """One-time real mixed LMDB loader smoke; no model training and no data writes."""
    import sys
    from pathlib import Path
    import numpy as np
    model_dir = str(Path(__file__).resolve().parents[2])
    if model_dir not in sys.path:
        sys.path.insert(0, model_dir)
    from unimol.data.merged_sampling_dataset import MergedSampledLMDBDataset
    src = Path(lmdb_dir)
    general = src.parent.parent / "UniMolReference/ligand_data/ligands"
    splits = _load(str(src / "splits.json"))
    by_rel = {row["lmdb"]: row for row in view["shards"]}
    for split in ("train", "valid"):
        # Prefer a record with both valid 3D and stored 2D fallback.
        chosen = None
        for rel in splits[split]:
            row = by_rel[rel]
            data = (Path(view_file).parent / row["index"]).read_bytes()
            key = next((i for i,n in enumerate(data) if n < 10), None)
            if key is not None:
                chosen = (rel, key, data[key])
                break
        if chosen is None:
            raise ValueError("No fallback-containing record available in " + split)
        rel, key, expected = chosen
        gen = general / (split + ".lmdb")
        import lmdb
        env = lmdb.open(str(gen), subdir=False, readonly=True, lock=False, readahead=False)
        try:
            with env.begin() as txn:
                n_gen = txn.stat()["entries"]
        finally:
            env.close()
        ds = MergedSampledLMDBDataset(
            [str(gen), str(src / rel)], [min(1.0, 2.0 / n_gen), 1.0],
            max_open_envs=2, lipid_3d_view=view_file,
            lipid_splits=str(src / "splits.json"))
        try:
            record = ds[ds.cumulative_length[1] + key]
            if len(record["coordinates"]) != expected or not 1 <= expected < 10:
                raise ValueError("3D-aware loader did not mask 2D fallback in " + rel)
            if len(ds[0]["coordinates"]) != 10:
                raise ValueError("general reference conformers were changed")
        finally:
            ds.close()


def write_3d(lmdb_dir, view_file, workers=16):
    """One-time full LMDB+sidecar verification, then an immutable 3D-aware receipt."""
    view, view_file, index_stats, facts = _checked_3d_view(lmdb_dir, view_file, hash_indexes=True)
    problems, seconds = full_verify(lmdb_dir, workers)
    if problems:
        return None, problems
    _smoke_3d_loader(lmdb_dir, str(view_file), view)
    manifest = _load(os.path.join(lmdb_dir, "manifest.json"))
    # Fast subsequent checks use size+mtime only (full SHA was done here).
    shard_stats = []
    for entry in manifest["shards"]:
        p = os.path.join(lmdb_dir, entry["lmdb"])
        st = os.stat(p)
        shard_stats.append([entry["lmdb"], st.st_size, st.st_mtime_ns])
    rec = dict(facts, ready=True, smoke=False, n_records=view["stored_records"],
               n_shards=view["shard_count"], policy="verified_3d_prefix",
               view_file=str(view_file), view_sha256=io_utils.sha256_file(str(view_file)),
               original_quality_passed=False, full_verification={"epoch":time.time(),
               "source":"one-time complete Stage-06 manifest SHA256", "seconds":seconds},
               shard_stats=shard_stats, index_stats=index_stats, loader_smoke_passed=True)
    io_utils.atomic_write_json(os.path.join(lmdb_dir, READY_3D), rec)
    return rec, []


def verify_3d(lmdb_dir, view_file=None):
    """Fast check of pinned identity, all shard sizes/mtimes and 3D sidecar existence."""
    path = os.path.join(lmdb_dir, READY_3D)
    if not os.path.isfile(path):
        return None, ["no independently verified 3D view receipt: " + path]
    try:
        rec = _load(path)
        if rec.get("policy") != "verified_3d_prefix" or not rec.get("ready"):
            raise ValueError("invalid 3D-view readiness policy")
        view_file = view_file or rec.get("view_file")
        if not view_file or str(os.path.realpath(view_file)) != str(os.path.realpath(rec.get("view_file", ""))):
            raise ValueError("requested 3D view differs from receipt")
        if io_utils.sha256_file(view_file) != rec.get("view_sha256"):
            raise ValueError("3D view JSON changed")
        view, _, _, facts = _checked_3d_view(lmdb_dir, view_file, hash_indexes=False)
        for field in ("manifest_sha256", "splits_sha256", "quality_report_sha256"):
            if rec.get(field) != facts.get(field):
                raise ValueError("source metadata changed: " + field)
        if view["stored_records"] != rec.get("n_records") or view["shard_count"] != rec.get("n_shards"):
            raise ValueError("view counts differ from readiness receipt")
        if not rec.get("loader_smoke_passed"):
            raise ValueError("3D-view loader smoke not attested")
        for index, size, mtime_ns in rec.get("index_stats", []):
            st = os.stat(index)
            if st.st_size != size or st.st_mtime_ns != mtime_ns:
                raise ValueError("3D index file changed since verification: " + index)
        if len(rec.get("index_stats", [])) != view["shard_count"]:
            raise ValueError("incomplete sidecar stats in readiness receipt")
        for rel, size, mtime_ns in rec.get("shard_stats", []):
            st = os.stat(os.path.join(lmdb_dir, rel))
            if st.st_size != size or st.st_mtime_ns != mtime_ns:
                raise ValueError("LMDB file changed since full verification: " + rel)
        if len(rec.get("shard_stats", [])) != view["shard_count"]:
            raise ValueError("incomplete shard stats in readiness receipt")
        return rec, []
    except Exception as exc:
        return None, ["3D view invalid or source changed: " + str(exc)]


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("action", choices=("write", "verify", "write-3d", "verify-3d"))
    ap.add_argument("lmdb_dir")
    ap.add_argument("--allow-smoke", action="store_true")
    ap.add_argument("--view", help="validated 3D-prefix final_dataset_view.json")
    ap.add_argument("--full", action="store_true", help="verify: recompute the sha256 of every shard")
    ap.add_argument("--workers", type=int, default=8)
    ap.add_argument("--max-age-days", type=float, default=None,
                    help="verify: also require a full verification younger than this")
    ap.add_argument("--json", action="store_true")
    ns = ap.parse_args(argv)
    if ns.action == "write":
        record, problems = write(ns.lmdb_dir, ns.allow_smoke, ns.workers)
    elif ns.action == "write-3d":
        if not ns.view:
            ap.error("write-3d requires --view")
        record, problems = write_3d(ns.lmdb_dir, ns.view, ns.workers)
    elif ns.action == "verify-3d":
        record, problems = verify_3d(ns.lmdb_dir, ns.view)
    else:
        record, problems = verify(ns.lmdb_dir, ns.allow_smoke, ns.full, ns.workers, ns.max_age_days)
    if ns.json:
        print(json.dumps({"ready": record is not None, "problems": problems, "record": record}, indent=2))
    for p in problems[:50]:
        print("NOT READY: {}".format(p), file=sys.stderr)
    if len(problems) > 50:
        print("NOT READY: ... and {} more".format(len(problems) - 50), file=sys.stderr)
    if record is not None and not ns.json:
        print("library ready ({} check): {} shards, {} records{} ({})".format(
            "full" if ns.full else "quick", record["n_shards"], record["n_records"],
            " [SMOKE]" if record["smoke"] else "", os.path.join(ns.lmdb_dir,
                READY_3D if record.get("policy") == "verified_3d_prefix" else READY)))
    return 0 if record is not None else 1


if __name__ == "__main__":
    sys.exit(main())
