#!/usr/bin/env python3
"""Safe minimal Stage-06/3D-loader patch; no Git required and no HPC job submitted."""
import argparse,hashlib,json,os,shutil,sys,time
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=Path('/home/ypan/heart_liver/model_train/heart-molecular-pretraining')
SHA=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    p=argparse.ArgumentParser()
    opts=p.add_mutually_exclusive_group(required=True)
    opts.add_argument('--check',action='store_true')
    opts.add_argument('--apply',action='store_true')
    p.add_argument('--root',default=str(ROOT),help='Home checkout root (default: production path)')
    args=p.parse_args()
    root=Path(args.root).resolve()
    data=json.loads((HERE/'expected_sha256.json').read_text())
    failures=[]
    for rel,info in data.items():
        path=root/rel
        if not path.is_file():
            failures.append('MISSING '+rel);continue
        got=SHA(path)
        if got == info['new_sha256']:
            print('ALREADY PATCHED '+rel)
        elif got == info['before_sha256']:
            print('MATCH '+rel)
        else:
            failures.append('UNEXPECTED CURRENT VERSION '+rel)
        if SHA(HERE/'files'/rel) != info['new_sha256']:
            failures.append('PATCH ZIP CORRUPTED '+rel)
    if failures:
        for msg in failures:print('REFUSED '+msg,file=sys.stderr)
        return 2
    if args.check:
        print('PASS: source hashes match the uploaded baseline; no files changed')
        return 0
    backup=Path('/home/ypan/ugi_training_ready_backups')/time.strftime('%Y%m%d_%H%M%S')
    for rel,info in data.items():
        dst=root/rel
        if SHA(dst)==info['new_sha256']:
            continue
        b=backup/rel;b.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(dst,b)
        tmp=dst.with_name(dst.name+'.ugi-ready-tmp')
        shutil.copy2(HERE/'files'/rel,tmp)
        os.chmod(tmp,dst.stat().st_mode)
        os.replace(tmp,dst)
        print('PATCHED '+rel)
    print('PASS: updated existing files only; backup:',backup)
    return 0
if __name__=='__main__':sys.exit(main())
