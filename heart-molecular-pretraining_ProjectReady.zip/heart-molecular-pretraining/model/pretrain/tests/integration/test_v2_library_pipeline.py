"""HEART v2 lipid library: stage 02 boundaries/race, stage 04 pool, stage 05 fail-closed + ready receipt.

Real stage code on a tiny 16-combination library (production slot policy:
10 stored 3D slots, STORE_2D=0). Nothing touches real data.
"""
import gzip
import json
import os
import pickle
import shutil
import sys
import time

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import v2_helpers as h  # noqa: E402
from v2_fixtures import v2_library  # noqa: E402,F401

pytest.importorskip("rdkit")
pytest.importorskip("lmdb")

from lipid_library import enumerate_library, provenance, ready  # noqa: E402

TOTAL, CHUNK, TASKS = 64 * 61 * 64 * 61, 50000, 64


# --------------------------------------------------------------------------- stage 02
def test_production_combination_count_and_task63_chunks():
    assert TOTAL == 15241216
    chunks = enumerate_library.chunk_bounds(TOTAL, CHUNK)
    assert len(chunks) == 305 and chunks[-1] == (15200000, 15241216)
    t63 = enumerate_library.chunk_bounds(TOTAL, CHUNK, shard=63, num_shards=TASKS)
    assert t63 == [(c * CHUNK, (c + 1) * CHUNK) for c in (63, 127, 191, 255)]
    seen = []
    for t in range(TASKS):
        seen += enumerate_library.chunk_bounds(TOTAL, CHUNK, shard=t, num_shards=TASKS)
    assert sorted(seen) == chunks                              # every chunk exactly once
    assert enumerate_library.chunk_bounds(TOTAL, CHUNK, shard=48, num_shards=TASKS)[-1] == (15200000, 15241216)


def test_a_task_with_no_chunks_succeeds_and_writes_nothing(tmp_path):
    """Zero-assigned array tasks (more tasks than chunks) must exit 0, not fail the array."""
    h.lf.build_building_blocks(str(tmp_path / "bb"))
    out = tmp_path / "enum"
    rc = enumerate_library.main([str(tmp_path / "bb"), "-o", str(out), "--chunk-size", "8",
                                 "--shard", "63", "--num-shards", "64"])
    assert rc == 0
    assert not (out / "products").exists() or not os.listdir(out / "products")


def test_resubmitting_one_task_keeps_the_other_receipts(tmp_path):
    bb, out = str(tmp_path / "bb"), str(tmp_path / "enum")
    h.lf.build_building_blocks(bb)
    for t in range(2):
        assert enumerate_library.main([bb, "-o", out, "--chunk-size", "8", "--shard", str(t), "--num-shards", "2"]) == 0
    receipt = os.path.join(out, "products", "products-0-8.done.json")
    before = os.path.getmtime(receipt)
    os.remove(os.path.join(out, "products", "products-8-16.done.json"))   # task 1 "failed"
    assert enumerate_library.main([bb, "-o", out, "--chunk-size", "8", "--check-complete"]) == 1
    time.sleep(0.05)
    assert enumerate_library.main([bb, "-o", out, "--chunk-size", "8", "--shard", "1", "--num-shards", "2"]) == 0
    assert os.path.getmtime(receipt) == before                # task 0's chunk was not regenerated
    assert enumerate_library.main([bb, "-o", out, "--chunk-size", "8", "--check-complete"]) == 0


LOCK_CHILD = """
import json, sys, time
sys.path.insert(0, sys.argv[1])
from lipid_library import provenance
out_dir, pad, start = sys.argv[2], sys.argv[3], float(sys.argv[4])
cfg = {"pad": pad * 200000, "stage": "enumeration"}
while time.time() < start:
    pass
try:
    provenance.lock_config(out_dir, "enumeration", cfg)
    print("ok")
except provenance.StaleOutputError:
    print("stale")
except Exception as exc:                      # the v1 race: JSONDecodeError on a half-written file
    print("{}: {}".format(type(exc).__name__, exc))
"""


def _race(out_dir, pad, n):
    import subprocess

    start = time.time() + 4.0
    procs = [subprocess.Popen([sys.executable, "-c", LOCK_CHILD, h.PRETRAIN_DIR, out_dir, pad, str(start)],
                              stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True) for _ in range(n)]
    return [p.communicate(timeout=120)[0].strip().splitlines()[-1] for p in procs]


def test_concurrent_config_lock_never_reads_a_half_written_file(tmp_path):
    """v1 created the lock with O_EXCL and wrote it afterwards: a concurrent task could
    json.load an empty file. Now the file appears complete (hard link). 8 processes
    released at the same instant, 3 rounds; then 4 with another configuration."""
    for rnd in range(3):
        d = str(tmp_path / "r{}".format(rnd))
        assert _race(d, "x", 8) == ["ok"] * 8
        assert _race(d, "y", 4) == ["stale"] * 4


def test_legacy_empty_lock_file_is_waited_for(tmp_path):
    import threading

    d = str(tmp_path)
    path = os.path.join(d, "enumeration_config.json")
    open(path, "w").close()                                   # legacy writer: created, not yet written
    cfg = {"a": 1}

    def late_write():
        time.sleep(0.5)
        with open(path, "w") as fh:
            json.dump({"stage": "enumeration", "fingerprint": provenance.fingerprint(cfg), "config": cfg}, fh)
    threading.Thread(target=late_write).start()
    assert provenance.lock_config(d, "enumeration", cfg) == provenance.fingerprint(cfg)


# --------------------------------------------------------------------------- stage 04 pool + stage 05
def _records(lmdb_path):
    import lmdb

    env = lmdb.open(lmdb_path, subdir=False, readonly=True, lock=False)
    with env.begin() as txn:
        out = [pickle.loads(v) for _, v in txn.cursor()]
    env.close()
    return out


def test_pool_library_is_complete_ready_and_production_shaped(v2_library):
    lmdb = os.path.join(v2_library, "lmdb")
    rec, problems = ready.verify(lmdb)
    assert problems == [] and rec["smoke"] is False
    m = json.load(open(os.path.join(lmdb, "manifest.json")))
    assert m["complete"] and m["stored_2d_conformer"] == [False] and m["coordinate_slots_per_record"] == [10]
    s = json.load(open(os.path.join(lmdb, "splits.json")))
    assert s["train"] and s["valid"] and not set(s["train"]) & set(s["valid"])
    v = json.load(open(os.path.join(lmdb, "validation.json")))
    assert v["passed"] and v["fallback_audit"] and v["totals"]["n_audited"] == m["n_records"]
    prog = json.load(open(os.path.join(lmdb, "stage04_progress.json")))
    assert prog["all_complete"] and prog["written"] == m["n_shards"] and not prog["failed"]
    for shard in m["shards"]:
        recs = _records(os.path.join(lmdb, shard["lmdb"]))
        assert all(set(r) == {"smi", "atoms", "coordinates"} and len(r["coordinates"]) == 10 for r in recs)


def test_pool_shards_are_identical_to_array_mode_shards(v2_library, tmp_path):
    """Same chemistry/receipts: an array-mode task (lmdb_writer --shard) gives the same records."""
    root = str(tmp_path / "arr")
    for d in ("bb", "enum", "dedup"):
        shutil.copytree(os.path.join(v2_library, d), os.path.join(root, d))
    h.build_partition(root)
    h.run_py(["-m", "lipid_library.lmdb_writer", os.path.join(root, "enum"), "-o", os.path.join(root, "lmdb")]
             + h.writer_args(root) + ["--shard", "0", "--num-shards", "1000"])
    a = _records(os.path.join(root, "lmdb", "shard-00000", "train.lmdb"))
    b = _records(os.path.join(v2_library, "lmdb", "shard-00000", "train.lmdb"))
    assert [r["smi"] for r in a] == [r["smi"] for r in b]
    import numpy as np
    for ra, rb in zip(a, b):
        assert ra["atoms"] == rb["atoms"]
        assert all(np.array_equal(x, y) for x, y in zip(ra["coordinates"], rb["coordinates"]))
    ra = json.load(open(os.path.join(root, "lmdb", "shard-00000", "shard.json")))
    rb = json.load(open(os.path.join(v2_library, "lmdb", "shard-00000", "shard.json")))
    assert ra["input_fingerprint"] == rb["input_fingerprint"]
    ca = json.load(open(os.path.join(root, "lmdb", "lmdb_writer_config.json")))["config"]
    cb = json.load(open(os.path.join(v2_library, "lmdb", "lmdb_writer_config.json")))["config"]
    assert {k for k in set(ca) | set(cb) if ca.get(k) != cb.get(k)} == {"drop_list"}   # only its path


def _posix(p):
    p = str(p).replace("\\", "/")
    if sys.platform == "win32" and len(p) > 1 and p[1] == ":":
        p = "/" + p[0].lower() + p[2:]
    return p


def _copy_lmdb(src, dst):
    """Copy only the LMDB directory: enum/ and dedup/ of the shared fixture stay where the
    writer configuration recorded them (the drop-list path is part of the fingerprint)."""
    shutil.copytree(os.path.join(src, "lmdb"), dst)
    for f in ("library_ready.json",):
        p = os.path.join(dst, f)
        if os.path.exists(p):
            os.remove(p)
    return dst


def test_pool_resume_rebuilds_only_broken_shards(v2_library, tmp_path):
    root, lmdb = v2_library, _copy_lmdb(v2_library, str(tmp_path / "lmdb"))
    keep = os.path.getmtime(os.path.join(lmdb, "shard-00000", "train.lmdb"))
    os.remove(os.path.join(lmdb, "shard-00001", "shard.json"))                 # crashed before its receipt
    with open(os.path.join(lmdb, "shard-00002", "train.lmdb"), "ab") as fh:   # corrupted LMDB
        fh.write(b"junk")
    h.run_pool(root, lmdb=lmdb)
    prog = json.load(open(os.path.join(lmdb, "stage04_progress.json")))
    assert prog["written"] == 2 and prog["verified"] == prog["n_shards"] - 2 and prog["all_complete"]
    assert os.path.getmtime(os.path.join(lmdb, "shard-00000", "train.lmdb")) == keep
    assert all(r.returncode == 0 for r in h.run_stage05(root, lmdb=lmdb))


def test_pool_refuses_while_another_writer_holds_the_directory(v2_library, tmp_path):
    from lipid_library.dirlock import DirLock

    lmdb = _copy_lmdb(v2_library, str(tmp_path / "lmdb"))
    with DirLock(lmdb):
        res = h.run_pool(v2_library, check=False, lmdb=lmdb)
    assert res.returncode != 0 and "locked by another stage-04 writer" in (res.stderr + res.stdout)


def test_pool_stops_at_the_deadline_and_reports_incomplete(v2_library, tmp_path):
    root, lmdb = v2_library, _copy_lmdb(v2_library, str(tmp_path / "lmdb"))
    for d in os.listdir(lmdb):
        if d.startswith("shard-0"):
            shutil.rmtree(os.path.join(lmdb, d))
    res = h.run_pool(root, check=False, lmdb=lmdb,
                     extra=["--deadline-epoch", str(time.time() + 60), "--margin-min", "5"])
    assert res.returncode == 3                                 # nothing could finish before the limit
    prog = json.load(open(os.path.join(lmdb, "stage04_progress.json")))
    assert prog["stopped"] == "deadline" and prog["written"] == 0
    # stage 05 after an incomplete stage 04 fails closed: no manifest, no ready receipt
    out = h.run_stage05(root, check=False, lmdb=lmdb)
    assert out[0].returncode == 1
    assert not os.path.exists(os.path.join(lmdb, "manifest.json"))
    rep = json.load(open(os.path.join(lmdb, "finalize_report.json")))
    assert rep["complete"] is False and len(rep["missing_shards"]) == rep["n_expected_shards"]
    assert rep["resubmit_array_tasks"] == sorted(rep["missing_shards"])
    assert ready.verify(lmdb)[0] is None


def test_fallback_audit_catches_a_2d_fill_counted_as_3d(v2_library, tmp_path):
    lmdb = _copy_lmdb(v2_library, str(tmp_path / "lmdb"))
    import lmdb as lmdb_mod
    import numpy as np

    path = os.path.join(lmdb, "shard-00000", "train.lmdb")
    env = lmdb_mod.open(path, subdir=False, map_size=1 << 28)
    with env.begin(write=True) as txn:
        rec = pickle.loads(txn.get(b"0"))
        flat = rec["coordinates"][0].copy()
        flat[:, 2] = 0.0                                      # a 2D fill-in posing as 3D slot 0
        rec["coordinates"][0] = flat.astype(np.float32)
        txn.put(b"0", pickle.dumps(rec, protocol=4))
    env.close()
    res = h.run_py(["-m", "lipid_library.validate_lmdb", "--manifest", os.path.join(lmdb, "manifest.json"),
                    "--dict", h.DICT, "--expect-slots", "10", "--audit-fallback", "--sample", "500"], check=False)
    assert res.returncode == 1 and "records.csv.gz says" in (res.stdout + res.stderr)


def test_ready_receipt_is_invalidated_by_changed_artifacts(v2_library, tmp_path):
    lmdb = _copy_lmdb(v2_library, str(tmp_path / "lmdb"))
    assert ready.write(lmdb)[1] == []
    assert ready.verify(lmdb)[1] == []
    s = json.load(open(os.path.join(lmdb, "splits.json")))
    s["split_seed"] = 2
    json.dump(s, open(os.path.join(lmdb, "splits.json"), "w"))
    assert any("splits_sha256 changed" in p for p in ready.verify(lmdb)[1])
    v = json.load(open(os.path.join(lmdb, "validation.json")))
    v["n_problems"], v["passed"] = 3, False
    json.dump(v, open(os.path.join(lmdb, "validation.json"), "w"))
    assert ready.write(lmdb)[0] is None and not os.path.exists(os.path.join(lmdb, "library_ready.json"))


def test_stage04_shell_script_dry_run_on_the_tiny_library(v2_library, tmp_path):
    """The real 04_conformers_pool.sh pre-flight path (bash, HEART_SKIP_ENV hook, no SLURM)."""
    import subprocess

    from conftest import find_bash

    root = v2_library                                          # read-only use: dry run writes nothing
    general = h.write_general_dir(str(tmp_path / "general"))    # audited policy: the mandatory gate passes
    env = {k: v for k, v in os.environ.items() if not k.startswith(("SLURM_", "HEART_", "LIPID_"))}
    env.update(HEART_SKIP_ENV="1", HEART_PYTHON=_posix(sys.executable), HEART_CONFIRM_LIPID="1",
               HEART_REPO=_posix(h.REPO_ROOT), LIPID_ROOT=_posix(root), LIPID_DICT=_posix(h.DICT), STORE_2D="0",
               RECORDS_PER_SHARD="4", LIPID_WORKERS="2", HEART_DRY_RUN="1", HEART_DATA_PATH=_posix(general),
               LIPID_MAP_SIZE_GB="0.25", PYTHONIOENCODING="utf-8")
    script = os.path.join(h.PRETRAIN_DIR, "scripts", "lipid_library", "04_conformers_pool.sh")
    res = subprocess.run([find_bash(), script], env=env, capture_output=True, text=True)
    assert res.returncode == 0, res.stdout[-2000:] + res.stderr[-2000:]
    assert '"dry_run": true' in res.stdout and "allocation not checked" in res.stdout
    assert "COMPATIBLE" in res.stdout and "INCOMPATIBLE" not in res.stdout
