"""HEART v2: the lipid library produced by the v2 stages feeds the ACTUAL continual task.

general-format stand-in LMDB + v2 library (pool-built, production slot policy)
-> unchanged general dict.txt -> MergedSampledLMDBDataset -> unimol_contrastive_continual
-> collater batch with two independent views; then `bin/heart continual` dry-run /
mocked submission against that ready library, and the read-only checkpoint
comparison tool. CPU only, tiny model; no real data or checkpoint.
"""
import json
import os
import sys

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import v2_helpers as h  # noqa: E402
from v2_fixtures import v2_library  # noqa: E402,F401

torch = pytest.importorskip("torch")
pytest.importorskip("unicore")

from conftest import TOOLS_DIR, task_args  # noqa: E402


@pytest.fixture(scope="module")
def general_dir(tmp_path_factory):
    d = str(tmp_path_factory.mktemp("general"))
    return h.write_general_dir(d)


def _task(unimol_pkg, general_dir, v2_library, split="train", **kw):
    from unimol.tasks.unimol_contrastive_continual import UniMolTaskContrastiveContinual

    args = task_args(general_dir, lipid_splits=os.path.join(v2_library, "lmdb", "splits.json"), lipid_lmdb=None,
                     general_data_weight=0.5, lipid_data_weight=1.0, mixture_report=None,
                     require_equal_coordinate_slots=True, allow_smoke_lipid_data=False,
                     invalid_smiles_policy="skip-2d", max_invalid_smiles_fraction=0.01, batch_size=4,
                     masked_token_loss=0.5, masked_coord_loss=1.0, masked_dist_loss=5.0, **kw)
    task = UniMolTaskContrastiveContinual.setup_task(args)
    task.load_dataset(split)
    ds = task.dataset(split)
    ds.set_epoch(1)
    return task, ds


def test_check_continual_data_accepts_general_plus_v2_library(general_dir, v2_library):
    """The same read-only preflight the HPC acceptance script runs on the real data."""
    res = h.run_py([os.path.join(TOOLS_DIR, "check_continual_data.py"), "--general", general_dir,
                    "--lipid-splits", os.path.join(v2_library, "lmdb", "splits.json"), "--sample", "8",
                    "--verify-hashes"], check=False)
    assert res.returncode == 0, res.stdout[-3000:] + res.stderr[-3000:]


def test_actual_continual_task_builds_independent_view_batches(unimol_pkg, general_dir, v2_library):
    task, ds = _task(unimol_pkg, general_dir, v2_library)
    assert len(ds) > 0
    sample = ds[0]
    v0, v1 = sample["view_0"], sample["view_1"]
    assert v0["target.smi_name"] == v1["target.smi_name"]
    assert (not torch.equal(v0["net_input.src_coord"], v1["net_input.src_coord"])
            or not torch.equal(v0["net_input.src_tokens"], v1["net_input.src_tokens"]))
    batch = ds.collater([ds[i] for i in range(len(ds))])
    ni = batch["net_input"]
    b, n = ni["src_tokens"].shape
    assert b == 2 * len(ds)
    assert ni["src_coord"].shape == (b, n, 3) and ni["src_distance"].shape == (b, n, n)
    assert ni["src_edge_type"].shape == (b, n, n)
    vocab = len(task.dictionary)
    assert int(ni["src_tokens"].max()) < vocab                 # no out-of-vocabulary token
    lipid_smiles = set()
    from lipid_library import io_utils

    lmdb = os.path.join(v2_library, "lmdb")
    for d in os.listdir(lmdb):
        if d.startswith("shard-"):
            lipid_smiles |= {r["smi"] for r in io_utils.read_gz_csv(os.path.join(lmdb, d, "records.csv.gz"))}
    smis = batch["target"]["smi_name"]
    assert any(s in lipid_smiles for s in smis) and any(s not in lipid_smiles for s in smis)


def test_valid_split_reads_only_lipid_valid_shards(unimol_pkg, general_dir, v2_library):
    splits = json.load(open(os.path.join(v2_library, "lmdb", "splits.json")))
    train_smis, valid_smis = set(), set()
    from lipid_library import io_utils

    for key, bag in (("train", train_smis), ("valid", valid_smis)):
        for rel in splits[key]:
            p = os.path.join(v2_library, "lmdb", os.path.dirname(rel), "records.csv.gz")
            bag |= {r["smi"] for r in io_utils.read_gz_csv(p)}
    assert not (train_smis & valid_smis)                      # no lipid leakage train -> valid
    _, ds = _task(unimol_pkg, general_dir, v2_library, split="valid")
    batch = ds.collater([ds[i] for i in range(len(ds))])
    lipid_in_valid = {s for s in batch["target"]["smi_name"] if s in train_smis | valid_smis}
    assert lipid_in_valid and lipid_in_valid <= valid_smis


def test_one_step_with_v2_library_has_finite_loss(unimol_pkg, general_dir, v2_library):
    import copy

    from unimol.losses.unimol_contrastive import UniMolLossContrastive
    from unimol.models.unimol_contrastive import UniMolModelContrastive

    task, ds = _task(unimol_pkg, general_dir, v2_library)
    batch = ds.collater([ds[i] for i in range(min(4, len(ds)))])
    torch.manual_seed(0)
    model = UniMolModelContrastive(copy.deepcopy(task.args), task.dictionary).train()
    loss, _, logs = UniMolLossContrastive(task)(model, batch)
    assert torch.isfinite(loss)
    for k in ("masked_token_loss", "masked_coord_loss", "masked_dist_loss", "contrastive_loss"):
        assert torch.isfinite(torch.as_tensor(logs[k])), k
    loss.backward()
    assert all(torch.isfinite(p.grad).all() for p in model.parameters() if p.grad is not None)


# --------------------------------------------------------------------------- bin/heart continual
def _cli(args, monkeypatch, tmp_path):
    from heart_v2 import cli

    script = tmp_path / "fake_sbatch.py"
    script.write_text("import json,sys,os\nopen(os.environ['FAKE_LOG'],'a').write(json.dumps(sys.argv[1:])+'\\n')\n"
                      "print('2000001')\n")
    monkeypatch.setenv("HEART_V2_SBATCH_JSON", json.dumps([sys.executable, str(script)]))
    monkeypatch.setenv("FAKE_LOG", str(tmp_path / "calls.jsonl"))
    monkeypatch.setattr(cli, "_running_jobs", lambda names: [])
    out = []
    rc = cli.main(args, out=out.append)
    calls = [json.loads(l) for l in open(tmp_path / "calls.jsonl")] if (tmp_path / "calls.jsonl").exists() else []
    return rc, "\n".join(out), calls


def test_continual_submission_uses_the_continual_profile_and_ready_library(v2_library, tmp_path, monkeypatch):
    ck = tmp_path / "checkpoint_best.pt"
    ck.write_bytes(b"not a real checkpoint")                 # only existence/readability is gated here
    out_root = str(tmp_path / "runs").replace("\\", "/")
    base = ["--set", "paths.lipid_root=" + v2_library.replace("\\", "/"), "--set",
            "paths.general_checkpoint=" + str(ck).replace("\\", "/"), "--set", "paths.continual_output_root=" + out_root]
    rc, out, calls = _cli(base + ["continual", "--dry-run"], monkeypatch, tmp_path)
    assert rc == 0 and "READY" in out and "NEW stage" in out and calls == []
    rc, out, calls = _cli(base + ["continual", "--submit"], monkeypatch, tmp_path)
    assert rc == 0, out
    assert len(calls) == 1
    argv = calls[0]
    flags = dict(a.split("=", 1) for a in argv if a.startswith("--") and "=" in a)
    assert (flags["--gres"], flags["--cpus-per-task"], flags["--mem"], flags["--partition"]) == (
        "gpu:h200:1", "16", "200G", "gpu")
    assert flags["--job-name"] == "heart-h200-continual" and "--nodelist" not in flags
    exp = dict(kv.split("=", 1) for kv in flags["--export"].split(",")[1:])
    assert exp["BATCH_SIZE"] == "448" and exp["MAX_STEPS"] == "200000" and exp["NUM_WORKERS"] == "4"
    assert exp["GENERAL_DATA_WEIGHT"] == "0.5" and exp["LIPID_DATA_WEIGHT"] == "1.0"
    assert exp["HEART_LIPID_SPLITS"].endswith("/lmdb/splits.json") and exp["HEART_REQUIRE_LIBRARY_READY"] == "1"
    assert exp["HEART_OUTPUT_ROOT"] == out_root and "runs/h200/full" not in exp["HEART_OUTPUT_ROOT"]
    assert "HEART_CONTINUAL_SMOKE_UPDATES" not in exp
    rc, out, calls = _cli(base + ["continual", "--smoke", "--submit"], monkeypatch, tmp_path)
    exp = dict(kv.split("=", 1) for kv in [a for a in calls[-1] if a.startswith("--export=")][0][9:].split(",")[1:])
    assert rc == 0 and exp["RUN_NAME"] == "heart-lipid-continual-smoke" and exp["HEART_CONTINUAL_SMOKE_UPDATES"] == "200"


def test_compare_checkpoints_tool_is_read_only_and_strict(tmp_path):
    import hashlib

    g = {"model": {"encoder.layers.0.w": torch.ones(3, 3), "embed_tokens.weight": torch.ones(5, 2)},
         "optimizer_history": [{"num_updates": 1000000}]}
    c = {"model": {"encoder.layers.0.w": torch.ones(3, 3) * 1.1, "embed_tokens.weight": torch.ones(5, 2)},
         "optimizer_history": [{"num_updates": 200}]}
    gp, cp = tmp_path / "g.pt", tmp_path / "c.pt"
    torch.save(g, gp)
    torch.save(c, cp)
    before = hashlib.sha256(gp.read_bytes()).hexdigest()
    res = h.run_py([os.path.join(TOOLS_DIR, "v2_compare_checkpoints.py"), str(gp), str(cp), "--json-out",
                    str(tmp_path / "r.json")])
    assert hashlib.sha256(gp.read_bytes()).hexdigest() == before
    r = json.load(open(tmp_path / "r.json"))
    assert r["compatible"] and abs(r["relative_drift_by_group"]["encoder.layer00"] - 0.1) < 1e-6
    assert r["relative_drift_by_group"]["embed_tokens"] == 0.0
    c["model"]["embed_tokens.weight"] = torch.ones(6, 2)   # dictionary size changed
    torch.save(c, cp)
    assert h.run_py([os.path.join(TOOLS_DIR, "v2_compare_checkpoints.py"), str(gp), str(cp)], check=False).returncode == 1
