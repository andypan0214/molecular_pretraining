"""Tiny, production-shaped lipid library built through the REAL stage code (v2 tests).

full 16-combination enumeration (not smoke) -> dedup -> 03b partition ->
stage04_pool (spawned workers) -> finalize -> splits -> validate --audit-fallback
-> library_ready.json. Production slot policy: 10 stored 3D slots, STORE_2D=0,
the fixture dict.txt standing in for the general vocabulary.
"""
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
TESTS_DIR = os.path.dirname(HERE)
PRETRAIN_DIR = os.path.dirname(TESTS_DIR)
MODEL_ROOT = os.path.dirname(PRETRAIN_DIR)
REPO_ROOT = os.path.dirname(MODEL_ROOT)
for p in (PRETRAIN_DIR, TESTS_DIR):
    if p not in sys.path:
        sys.path.insert(0, p)

import lipid_fixtures as lf  # noqa: E402

DICT = lf.DICT_FIXTURE


def writer_args(root, records_per_shard=4):
    return ["--records-per-shard", str(records_per_shard), "--n-3d", "10", "--max-try", "15",
            "--max-iterations", "4000", "--seed-start", "0", "--max-atoms", "256", "--only-polar", "0",
            "--no-store-2d", "--dict", DICT, "--drop-list", os.path.join(root, "dedup", "drop_combo_indexes.csv.gz"),
            "--map-size-gb", "0.25"]


def run_py(args, cwd=PRETRAIN_DIR, check=True, env=None):
    res = subprocess.run([sys.executable] + args, cwd=cwd, capture_output=True, text=True, env=env)
    if check and res.returncode != 0:
        raise AssertionError("{} failed ({}):\n{}\n{}".format(args[:3], res.returncode, res.stdout[-3000:],
                                                             res.stderr[-3000:]))
    return res


def build_upstream(root):
    """Stages 01-03 on the mini sheet (in-process, real code)."""
    from lipid_library import dedup, enumerate_library

    lf.build_building_blocks(os.path.join(root, "bb"))
    assert enumerate_library.main([os.path.join(root, "bb"), "-o", os.path.join(root, "enum"),
                                   "--chunk-size", "8"]) == 0
    dedup.run(os.path.join(root, "enum"), os.path.join(root, "dedup"), require_complete=True)
    return root


def build_partition(root, records_per_shard=4, lmdb=None):
    run_py(["-m", "lipid_library.lmdb_writer", os.path.join(root, "enum"), "-o", lmdb or os.path.join(root, "lmdb")]
           + writer_args(root, records_per_shard) + ["--partition"])


def run_pool(root, workers=2, extra=(), check=True, records_per_shard=4, lmdb=None):
    """`root` holds enum/ and dedup/ (read-only here); shards go to `lmdb` (default root/lmdb)."""
    return run_py(["-m", "lipid_library.stage04_pool", os.path.join(root, "enum"), "-o", lmdb or os.path.join(root, "lmdb"),
                   "--workers", str(workers), "--stride", "1000", "--progress-sec", "0"]
                  + writer_args(root, records_per_shard) + list(extra), check=check)


def run_stage05(root, records_per_shard=4, check=True, lmdb=None, criteria=None):
    lmdb = lmdb or os.path.join(root, "lmdb")
    out = [run_py(["-m", "lipid_library.lmdb_writer", os.path.join(root, "enum"), "-o", lmdb]
                  + writer_args(root, records_per_shard) + ["--finalize", "--array-size", "1000", "--workers", "2"],
                  check=check)]
    if out[-1].returncode != 0:
        return out
    out.append(run_py(["-m", "lipid_library.splits", lmdb, "--valid-fraction", "0.002", "--split-seed", "1"],
                      check=check))
    out.append(run_py(["-m", "lipid_library.validate_lmdb", "--manifest", os.path.join(lmdb, "manifest.json"),
                       "--dict", DICT, "--expect-slots", "10", "--max-atoms", "256", "--only-polar", "0",
                       "--sample", "500", "--audit-fallback", "--workers", "2",
                       "--json-out", os.path.join(lmdb, "validation.json")], check=check))
    if out[-1].returncode != 0:
        return out
    out.append(run_py(["-m", "lipid_library.quality", lmdb, "--enum-dir", os.path.join(root, "enum"),
                       "--dedup-dir", os.path.join(root, "dedup"), "--workers", "2"]
                      + (["--criteria-json", criteria] if criteria else []), check=check))
    if out[-1].returncode != 0:
        return out
    out.append(run_py(["-m", "lipid_library.ready", "write", lmdb], check=check))
    return out


def build_library(root, workers=2):
    build_upstream(root)
    build_partition(root)
    run_pool(root, workers)
    run_stage05(root)
    return os.path.join(root, "lmdb")


GENERAL_SMILES = [  # small drug-like CHNO ligands that embed 10 distinct 3D conformers
    "CC(=O)Oc1ccccc1C(=O)O", "CN1C=NC2=C1C(=O)N(C(=O)N2C)C", "CC(C)Cc1ccc(cc1)C(C)C(=O)O",
    "CC(=O)Nc1ccc(O)cc1", "OC(=O)CCc1ccccc1", "CCN(CC)CCOC(=O)c1ccc(N)cc1", "COc1ccc(CCN)cc1",
    "CC(C)NCC(O)COc1cccc2ccccc12", "O=C(O)c1ccccc1O", "NC(Cc1ccccc1)C(=O)O",
]


def write_general_dir(out_dir, n_train=7):
    """General-format stand-in with the audited policy (10 stored 3D slots, STORE_2D=0)."""
    import pickle
    import shutil

    import lmdb

    from lipid_library.conformers import smi2coords_pretrain

    os.makedirs(out_dir, exist_ok=True)
    recs = []
    for smi in GENERAL_SMILES:
        rec, st = smi2coords_pretrain(smi, n_3d=10, store_2d=False, max_try=15, max_iteration=4000)
        assert st["n_2d_filled"] == 0, smi
        recs.append(rec)
    for split, items in (("train", recs[:n_train]), ("valid", recs[n_train:])):
        env = lmdb.open(os.path.join(out_dir, split + ".lmdb"), map_size=1 << 27, subdir=False)
        with env.begin(write=True) as txn:
            for i, r in enumerate(items):
                txn.put(str(i).encode("ascii"), pickle.dumps(r, protocol=4))
        env.close()
    shutil.copyfile(DICT, os.path.join(out_dir, "dict.txt"))
    return out_dir
