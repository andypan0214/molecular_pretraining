#!/bin/bash
#SBATCH --partition=gpu
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=4G
#SBATCH --time=00:30:00
#SBATCH --job-name=lipid-01-bb
#SBATCH --output=/project/yli4/ypan/lipid_library/logs/%x-%j.out
#SBATCH --error=/project/yli4/ypan/lipid_library/logs/%x-%j.err
# =============================================================================
# Stage 01 (CPU, minutes): parse + validate the LUMI building-block sheet and
# write the chemistry review sheet (one product per reagent + stratified
# assumption groups, with core/formula/LUMI-assembly checks and drawings).
# v2: resources come from config/heart_v2.yaml (profile lipid_01, CPU-only on
# partition gpu, which CMRI accepted for jobs 1013342+); submit with bin/heart.
#
#   mkdir -p /project/yli4/ypan/lipid_library/{input,logs}
#   cp LUMI_virtual_library_training_lipidLike.xlsx /project/yli4/ypan/lipid_library/input/
#   HEART_CONFIRM_LIPID=1 sbatch --export=ALL scripts/lipid_library/01_building_blocks.sh
# =============================================================================
set -eo pipefail
# v2: locate THIS checkout (sbatch runs a spooled copy); never fall back to the old clone.
here="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [ ! -f "$here/lipid_lib.sh" ]; then
    if [ -n "${HEART_REPO:-}" ]; then
        here="$HEART_REPO/model/pretrain/scripts/lipid_library"
    elif [ -n "${SLURM_JOB_ID:-}" ] && command -v scontrol >/dev/null 2>&1; then
        here="$(dirname "$(scontrol show job "$SLURM_JOB_ID" | sed -n 's/^ *Command=//p' | head -1 | cut -d' ' -f1)")"
    fi
fi
[ -f "$here/lipid_lib.sh" ] || { echo "ERROR: cannot locate scripts/lipid_library (set HEART_REPO)" >&2; exit 1; }
# shellcheck source=lipid_lib.sh
. "$here/lipid_lib.sh"
lipid_init "$here/01_building_blocks.sh"

[ -r "$LIPID_INPUT" ] || die "building-block sheet not found: $LIPID_INPUT"
"$PY" -m lipid_library.building_blocks "$LIPID_INPUT" -o "$LIPID_BB"
"$PY" -m lipid_library.review_products "$LIPID_BB" -o "$LIPID_REVIEW" --every-reagent \
    || warn "chemistry review reported problems: inspect $LIPID_REVIEW/review.csv before enumerating"
log "done: $LIPID_BB/summary.json, $LIPID_REVIEW/review.csv, $LIPID_REVIEW/review.svg"
