#!/bin/bash
#SBATCH --partition=gpu
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=8G
#SBATCH --time=12:00:00
#SBATCH --job-name=lipid-03b-part
#SBATCH --output=/project/yli4/ypan/lipid_library/logs/%x-%j.out
#SBATCH --error=/project/yli4/ypan/lipid_library/logs/%x-%j.err
# =============================================================================
# Stage 03b (CPU, one job): shard-input partition (v2 review P1).
# Reads the deduplicated product stream ONCE and writes, per shard, the gz CSV
# of its input rows plus $LIPID_LMDB/shard_inputs/partition_index.json (row
# count, input fingerprint and sha256 per shard; locked to the enumeration,
# drop list, RECORDS_PER_SHARD and LIMIT). Stage 04 array tasks then read only
# their own shards' files instead of all ~15M rows each. Re-running with the
# same configuration reuses the partition; a different one is refused.
# Uses the SAME writer options as stages 04/05 (STORE_2D is required by the
# option parser but does not affect the partition).
#
#   HEART_CONFIRM_LIPID=1 STORE_2D=<0|1> sbatch --export=ALL \
#       --dependency=afterok:<03 job id> scripts/lipid_library/03b_partition.sh
# =============================================================================
set -eo pipefail
# v2: locate THIS checkout (sbatch runs a spooled copy); never fall back to the old clone.
here="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [ ! -f "$here/lipid_lib.sh" ]; then
    if [ -n "${HEART_REPO:-}" ]; then
        here="$HEART_REPO/model/pretrain/scripts/lipid_library"
    elif [ -n "${SLURM_JOB_ID:-}" ] && command -v scontrol >/dev/null 2>&1; then
        here="$(dirname "$(scontrol show job "$SLURM_JOB_ID" | sed -n 's/^ *Command=//p' | head -1 | cut -d' ' -f1)")"
    fi
fi
[ -f "$here/lipid_lib.sh" ] || { echo "ERROR: cannot locate scripts/lipid_library (set HEART_REPO)" >&2; exit 1; }
# shellcheck source=lipid_lib.sh
. "$here/lipid_lib.sh"
lipid_init "$here/03b_partition.sh"
[ -f "$LIPID_DEDUP/drop_combo_indexes.csv.gz" ] || die "run stage 03 first (drop list missing)"
lipid_writer_args
"$PY" -m lipid_library.lmdb_writer "$LIPID_ENUM" -o "$LIPID_LMDB" "${LIPID_WRITER_ARGS[@]}" --partition \
    || die "partition failed"
"$PY" -m lipid_library.lmdb_writer "$LIPID_ENUM" -o "$LIPID_LMDB" "${LIPID_WRITER_ARGS[@]}" --plan \
    --array-size "${LIPID_ARRAY_SIZE:-1000}"
log "partition ready: $LIPID_LMDB/shard_inputs (submit stage 04 with LIPID_ARRAY_SIZE=${LIPID_ARRAY_SIZE:-1000})"
