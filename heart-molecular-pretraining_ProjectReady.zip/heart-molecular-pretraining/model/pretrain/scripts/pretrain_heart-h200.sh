#!/bin/bash
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=16
#SBATCH --job-name=heart-h200-full
#SBATCH --mem=200G
#SBATCH --gres=gpu:h200:1
#SBATCH --partition=gpu
#SBATCH --time=2-00:00:00
#SBATCH --signal=B:USR1@1800
#SBATCH --output=/project/yli4/ypan/runs/h200/slurm/%x-%j.out
#SBATCH --error=/project/yli4/ypan/runs/h200/slurm/%x-%j.err
# =============================================================================
# HEART H200 FULL general molecular pretraining (completed historical stage; do NOT
# rerun as part of the storage migration). Random initialisation, Uni-Mol
# ligand LMDB, LUMI-lab objectives). Production launcher for H200; the
# engineering smoke test is scripts/pretrain_smoke.sh.
#
# Same Uni-Core workflow as LUMI-lab model/pretrain/pretrain.sh, with CMRI guards:
#   * requires HEART_CONFIRM_FULL=1; H200 micro-batch defaults to 448;
#     previous H200 smoke tests were completed manually; no smoke-result gate;
#   * verifies GPU memory, disk space, CPU allocation, and SLURM time left;
#   * H200 allocation: 1 H200 GPU, 16 CPUs, 200G RAM; default 4 DataLoader
#     workers, batch size 448, fp16 (from successful H200 smoke tests);
#   * early checkpoint: a new run first trains to EARLY_CHECKPOINT_UPDATES
#     (default 1000), validates, writes checkpoint_last.pt, then resumes in
#     the same job. Learning-rate schedule and 10k save/validation cadence
#     remain unchanged; EARLY_CHECKPOINT_UPDATES=0 disables this safeguard;
#   * separate run directory runs/h200/full/<RUN_NAME>: resubmissions resume
#     checkpoint_last.pt (model, optimizer, LR schedule, fp16 scaler, and data
#     position), refusing incompatible changes in scientific settings;
#   * stops before SLURM time limit using cumulative --stop-time-hours;
#     SIGUSR1 and SIGTERM handling is unchanged from the original launcher.
#
# This script does not change or stop the existing T4 training.
# H200 outputs and Slurm logs use /project/yli4/ypan/runs/h200, regardless of stale
# terminal HEART_OUTPUT_ROOT values. Uni-Core code remains under Home;
# read-only general ligand LMDBs are in /project/yli4/ypan/UniMolReference/ligand_data/ligands.
#
# Submit H200 full training (no HEART_SMOKE_RUN variable required):
#   cd /home/ypan/heart_liver/model_train/heart-molecular-pretraining/model/pretrain
#   mkdir -p /project/yli4/ypan/runs/h200/slurm
#   HEART_CONFIRM_FULL=1 sbatch --export=ALL scripts/pretrain_heart-h200.sh
# Resume after a time limit: submit the same command with the same RUN_NAME.
# Pre-flight only (no GPU training):
#   HEART_DRY_RUN=1 HEART_CONFIRM_FULL=1 bash scripts/pretrain_heart-h200.sh
#
# Optional overrides: RUN_NAME, BATCH_SIZE (default 448), UPDATE_FREQ,
#   NUM_WORKERS (default 4), MIN_GPU_MEM_GB (default 120), MIN_FREE_GB (50),
#   HEART_MEM_INTERVAL (60 seconds; 0 = off), STOP_MARGIN_MINUTES (30),
#   EARLY_CHECKPOINT_UPDATES (1000; 0 = off), N_GPU (1; >1 untested),
#   HEART_ALLOW_ARG_CHANGE=1 (resume despite changed settings), plus HEART_*
#   HEART_* settings used in heart_lib.sh. Repository, output, Uni-Core, and
#   ligand dataset paths are fixed to the Home-code / Project-data layout.
#   Local CPU testing hooks unchanged.
# =============================================================================
set -eo pipefail

# >>> H200 paths: Home code, Project data and outputs; ignore stale shell paths >>>
# Code loads from /home/ypan/heart_liver/model_train/heart-molecular-pretraining; all new checkpoints and Slurm logs go to /project/yli4/ypan/runs/h200.
# Do not inherit HEART_REPO or HEART_OUTPUT_ROOT from a stale session.
export HEART_REPO=/home/ypan/heart_liver/model_train/heart-molecular-pretraining
export HEART_OUTPUT_ROOT=/project/yli4/ypan/runs/h200
# Uni-Core source remains on Home; the existing ligand LMDB is read from Project.
# All paths are pinned to the chosen deployment roots for this H200 launcher.
export HEART_UNICORE_SRC=/home/ypan/heart_liver/model_train/third_party/Uni-Core
export HEART_DATA_PATH=/project/yli4/ypan/UniMolReference/ligand_data/ligands
export BATCH_SIZE="${BATCH_SIZE:-448}"

# >>> Locate the repository (sbatch runs a spooled copy of this file) >>>
script_path="${BASH_SOURCE[0]}"
if [ -z "${HEART_REPO:-}" ] && [ -n "${SLURM_JOB_ID:-}" ] && command -v scontrol >/dev/null 2>&1; then
    submitted="$(scontrol show job "$SLURM_JOB_ID" 2>/dev/null | sed -n 's/^ *Command=//p' | head -1)"
    submitted="${submitted%% *}"
    [ -n "$submitted" ] && [ -f "$submitted" ] && script_path="$submitted"
fi
lib="$(dirname "$script_path")/heart_lib.sh"
[ -f "$lib" ] || lib="${HEART_REPO:-/home/ypan/heart_liver/model_train/heart-molecular-pretraining}/model/pretrain/scripts/heart_lib.sh"
# shellcheck source=heart_lib.sh
. "$lib"
heart_find_repo "$script_path"
heart_paths

# >>> Explicit full-training confirmation (checked before anything else) >>>
[ "${HEART_CONFIRM_FULL:-0}" = "1" ] || die "full pretraining requires HEART_CONFIRM_FULL=1"
[ -n "${BATCH_SIZE:-}" ] || die "BATCH_SIZE is empty; expected 448 for H200"

# >>> Heart Slurm information >>>
heart_slurm_info
heart_print_paths

# >>> conda initialize (heart_gpu; this script never installs packages) >>>
heart_activate_env
heart_runtime_env

# >>> HEART full-pretraining parameters (LUMI-lab pretrain.sh reference values) >>>
run_name="${RUN_NAME:-heart-h200-b448-v1}"
n_gpu="${N_GPU:-1}"
num_workers="${NUM_WORKERS:-4}"        # H200 default; 4 workers passed smoke tests
lr=1e-5
wd=1e-4
batch_size="$BATCH_SIZE"               # H200 default: 448 molecules/GPU (2 views each); LUMI used 448
batch_size_valid="$batch_size"
update_freq="${UPDATE_FREQ:-1}"        # gradient accumulation steps
heads=64
masked_token_loss=1
masked_coord_loss=5
masked_dist_loss=10
x_norm_loss=0.01
delta_pair_repr_norm_loss=0.01
contrastive_loss=10.0
contrastive_view_mode=independent      # HEART P3 (same as the smoke test); LUMI stock data path == identical
invalid_smiles_policy=skip-2d          # HEART P6: bad SMILES -> stored 3D conformers only (logged)
max_invalid_smiles_fraction=0.01       # HEART P6: stop if more records than this lack a 2D conformer
mask_prob=0.15
only_polar=0
noise_type="uniform"
noise=1.0
max_atoms=256
seed=1
warmup_steps=10000
max_steps=1000000
log_interval=100
validate_interval_updates=10000
save_interval_updates=10000
keep_interval_updates=10               # + checkpoint_last.pt + checkpoint_best.pt
early_checkpoint_updates="${EARLY_CHECKPOINT_UPDATES:-1000}"  # first checkpoint of a new run (0 = off)
stop_margin_minutes="${STOP_MARGIN_MINUTES:-30}"
min_gpu_mem_gb="${MIN_GPU_MEM_GB:-120}"  # H200 memory pre-flight threshold
min_free_gb="${MIN_FREE_GB:-50}"

for v in batch_size update_freq n_gpu num_workers stop_margin_minutes min_free_gb early_checkpoint_updates; do
    case "${!v}" in ''|*[!0-9]*) die "$v must be a non-negative integer (got '${!v}')" ;; esac
done
case "$min_gpu_mem_gb" in ''|*[!0-9.]*|*.*.*) die "MIN_GPU_MEM_GB must be a non-negative number (got '$min_gpu_mem_gb')" ;; esac
log "DataLoader workers: $num_workers$([ "$num_workers" = 0 ] && echo ' (data loaded in the main process)') | GPU memory required: >= $min_gpu_mem_gb GiB"
[ "$batch_size" -ge 1 ] && [ "$update_freq" -ge 1 ] && [ "$n_gpu" -ge 1 ] || die "BATCH_SIZE, UPDATE_FREQ and N_GPU must be >= 1"
effective_batch=$(( batch_size * update_freq * n_gpu ))
log "micro-batch $batch_size x update-freq $update_freq x GPUs $n_gpu = effective $effective_batch molecules/update"
log "NT-Xent negatives come from one micro-batch per GPU (gathered across GPUs): $(( 2 * batch_size * n_gpu - 2 )) per positive pair"
[ "$update_freq" -gt 1 ] && warn "update-freq $update_freq: accumulation reproduces the effective batch for the reconstruction losses, not for the contrastive negatives"

precision_args=(--fp16 --fp16-init-scale 4 --fp16-scale-window 256)
USE_CPU=0
if [ "${HEART_LOCAL_CPU_TEST:-0}" = "1" ]; then
    precision_args=(--cpu)             # local CPU test suite only; never on CMRI
    USE_CPU=1
fi
read -r -a extra_args <<< "${HEART_EXTRA_ARGS:-}"
heart_reject_forbidden_args "${extra_args[@]}"

DRY_RUN="${HEART_DRY_RUN:-0}"
if [ -z "${SLURM_JOB_ID:-}" ] && [ "$DRY_RUN" != "1" ] && [ "$USE_CPU" != "1" ]; then
    die "full pretraining runs only under sbatch (use HEART_DRY_RUN=1 for a login-node pre-flight)"
fi

# >>> H200 smoke tests were completed manually; no repeated smoke-result gate >>>

# >>> Pre-flight: real dataset, opened read-only >>>
heart_check_data

# >>> Fixed run directory: resubmission resumes >>>
save_dir="$OUTPUT_ROOT/full/$run_name"
heart_check_save_dir "$save_dir"
mkdir -p "$OUTPUT_ROOT/full"
free_gb="$(df -Pk "$OUTPUT_ROOT/full" | awk 'NR==2 {print int($4/1048576)}')"
log "free disk under $OUTPUT_ROOT/full: ${free_gb} GiB (need >= $min_free_gb)"
[ "$free_gb" -ge "$min_free_gb" ] || die "less than $min_free_gb GiB free for checkpoints (~0.6-0.8 GB each, up to 12 kept)"
if [ -n "${SLURM_CPUS_PER_TASK:-}" ] && [ "$num_workers" -ge "$SLURM_CPUS_PER_TASK" ]; then
    die "NUM_WORKERS=$num_workers must be < SLURM_CPUS_PER_TASK=$SLURM_CPUS_PER_TASK"
fi

resume_from=""
if [ -f "$save_dir/checkpoint_last.pt" ]; then
    resume_from="$(heart_ckpt_updates "$save_dir/checkpoint_last.pt")" || die "cannot read $save_dir/checkpoint_last.pt"
    [ "$resume_from" -lt "$max_steps" ] || die "run already reached $resume_from updates (max $max_steps)"
    log "run dir    : $save_dir (RESUMING from checkpoint_last.pt @ $resume_from updates)"
else
    log "run dir    : $save_dir (new run, random initialisation)"
fi

# >>> Pre-flight: GPU / PyTorch / Uni-Core registry / time >>>
gpu_optional=0
[ "$DRY_RUN" = "1" ] && [ -z "${SLURM_JOB_ID:-}" ] && gpu_optional=1
heart_gpu_preflight "$USE_CPU" "$min_gpu_mem_gb" "$gpu_optional"
heart_registry_check
heart_train_entry
[ "$DRY_RUN" = "1" ] || mkdir -p "$save_dir"
heart_stop_time_args "$save_dir" "$stop_margin_minutes"
if [ -n "${SLURM_JOB_ID:-}" ] && [ "${#STOP_ARGS[@]}" -eq 0 ] && [ "$USE_CPU" != "1" ]; then
    die "could not derive --stop-time-hours from the SLURM time limit; refusing an unguarded full run"
fi

# >>> Training command >>>
cd "$MODEL_ROOT"
CMD=("${TRAIN_ENTRY[@]}" "$DATA_PATH" --user-dir ./unimol --train-subset train --valid-subset valid
    --num-workers "$num_workers" --data-buffer-size 20 --ddp-backend=c10d
    --task unimol_contrastive --loss unimol_contrastive --arch unimol_contrastive_base
    --encoder-attention-heads "$heads"
    --optimizer adam --adam-betas "(0.9, 0.99)" --adam-eps 1e-6 --clip-norm 1.0 --weight-decay "$wd"
    --lr-scheduler polynomial_decay --lr "$lr" --warmup-updates "$warmup_steps" --total-num-update "$max_steps"
    --update-freq "$update_freq" --seed "$seed"
    "${precision_args[@]}" --tensorboard-logdir "$save_dir/tsb"
    --max-update "$max_steps" --log-interval "$log_interval" --log-format simple
    --save-interval-updates "$save_interval_updates" --validate-interval-updates "$validate_interval_updates"
    --keep-interval-updates "$keep_interval_updates" --no-epoch-checkpoints
    --masked-token-loss "$masked_token_loss" --masked-coord-loss "$masked_coord_loss" --masked-dist-loss "$masked_dist_loss"
    --x-norm-loss "$x_norm_loss" --delta-pair-repr-norm-loss "$delta_pair_repr_norm_loss"
    --mask-prob "$mask_prob" --noise-type "$noise_type" --noise "$noise" --max-atoms "$max_atoms"
    --batch-size "$batch_size" --batch-size-valid "$batch_size_valid"
    --save-dir "$save_dir" --tmp-save-dir "$save_dir" --only-polar "$only_polar" --mode train
    --dict-name dict.txt --contrastive-loss "$contrastive_loss" --contrastive-view-mode "$contrastive_view_mode"
    --invalid-smiles-policy "$invalid_smiles_policy" --max-invalid-smiles-fraction "$max_invalid_smiles_fraction"
    "${STOP_ARGS[@]}" "${extra_args[@]}")
if [ "$n_gpu" -gt 1 ]; then
    # torchrun exports RANK/WORLD_SIZE/LOCAL_RANK, which Uni-Core reads
    # (torch>=2 torch.distributed.launch passes --local-rank, which Uni-Core rejects).
    CMD=(torchrun --standalone --nproc_per_node="$n_gpu" "${CMD[@]}")
fi

echo "=== Command ==="
printf '%q ' "${CMD[@]}"; echo
if [ -n "$resume_from" ]; then
    allow=(); [ "${HEART_ALLOW_ARG_CHANGE:-0}" = "1" ] && allow=(--allow-change)
    "$PY" "$PRETRAIN_DIR/tools/check_resume_args.py" "$save_dir/checkpoint_last.pt" "${allow[@]}" -- "${CMD[@]}" \
        || die "resume settings differ from the checkpoint (HEART_ALLOW_ARG_CHANGE=1 to override, and document why)"
fi
# Early checkpoint: segment 1 stops at early_checkpoint_updates (Uni-Core validates and
# writes checkpoint_last.pt there); segment 2 resumes it with the unchanged command.
# Only --max-update differs, which neither the LR schedule (--total-num-update) nor
# check_resume_args.py depends on. Appended flags win (argparse: last value).
target_update="$max_steps"
for i in "${!CMD[@]}"; do
    [ "${CMD[$i]}" = "--max-update" ] && target_update="${CMD[$((i + 1))]}"
done
early_segment=0
if [ "$early_checkpoint_updates" -gt 0 ] && [ "${resume_from:-0}" -lt "$early_checkpoint_updates" ] \
        && [ "$early_checkpoint_updates" -lt "$target_update" ]; then
    early_segment=1
    log "early checkpoint: segment 1 to $early_checkpoint_updates updates (validate + checkpoint_last.pt), then resume to $target_update in this job"
else
    log "early checkpoint: not needed (start ${resume_from:-0}, early $early_checkpoint_updates, target $target_update)"
fi
if [ "$DRY_RUN" = "1" ]; then
    log "HEART_DRY_RUN=1: pre-flight passed; would write to $save_dir; not training"
    exit 0
fi

heart_provenance "$save_dir" "$script_path" "${CMD[@]}"
train_log="$save_dir/train-${SLURM_JOB_ID:-local}.log"
log "training log: $train_log"

# >>> Run in the background so SLURM signals reach this shell >>>
train_pid=""
got_term=0
on_signal() {
    log "received SIG$1: Uni-Core stops itself at --stop-time-hours (validate + checkpoint_last.pt)"
    if [ "$1" = TERM ]; then
        got_term=1
        if [ -n "$train_pid" ] && kill -0 "$train_pid" 2>/dev/null; then
            log "SIGTERM: forwarding to training (pid $train_pid); resume from the last saved checkpoint"
            kill -TERM "$train_pid" 2>/dev/null || true
        fi
    fi
}
# $@ = training command; sets rc
run_training() {
    "$@" > >(tee -a "$train_log") 2>&1 &
    train_pid=$!
    rc=0
    while :; do
        wait "$train_pid"
        rc=$?
        # wait returns >128 when interrupted by a trapped signal; keep waiting
        kill -0 "$train_pid" 2>/dev/null || break
    done
    train_pid=""
}
heart_memory_limits
mem_log="$save_dir/memory-${SLURM_JOB_ID:-local}.tsv"
MEM_MON_PID=""
[ "${HEART_MEM_INTERVAL:-60}" != 0 ] && heart_mem_monitor_start "$mem_log" "${HEART_MEM_INTERVAL:-60}"
trap 'on_signal USR1' USR1
trap 'on_signal TERM' TERM
set +e
run_main=1
if [ "$early_segment" = 1 ]; then
    log "segment 1/2: training to the early checkpoint at $early_checkpoint_updates updates"
    run_training "${CMD[@]}" --max-update "$early_checkpoint_updates"
    early_now="$(heart_ckpt_updates "$save_dir/checkpoint_last.pt" 2>/dev/null)"
    if [ "$rc" -ne 0 ] || [ "$got_term" = 1 ] || [ "$early_now" != "$early_checkpoint_updates" ]; then
        log "segment 1 ended (exit $rc, checkpoint_last.pt @ ${early_now:-none}); not continuing in this job"
        run_main=0
    else
        log "early checkpoint written: checkpoint_last.pt @ $early_now updates"
        if "$PY" "$PRETRAIN_DIR/tools/check_resume_args.py" "$save_dir/checkpoint_last.pt" -- "${CMD[@]}"; then
            heart_stop_time_args "$save_dir" "$stop_margin_minutes"    # minus the time segment 1 used
            log "segment 2/2: resuming checkpoint_last.pt @ $early_now -> $target_update updates"
        else
            log "resume settings differ from the early checkpoint; not continuing"
            rc=1
            run_main=0
        fi
    fi
fi
[ "$run_main" = 1 ] && run_training "${CMD[@]}" "${STOP_ARGS[@]}"
trap - USR1 TERM
heart_mem_monitor_stop "$mem_log"

echo "=== Summary ==="
"$PY" "$PRETRAIN_DIR/tools/summarize_log.py" "$train_log" || log "summary reported FAIL items (see above)"
ls -lh "$save_dir"
if [ -f "$save_dir/checkpoint_last.pt" ]; then
    now="$(heart_ckpt_updates "$save_dir/checkpoint_last.pt" || echo '?')"
    log "checkpoint_last.pt @ $now / $max_steps updates"
    [ "$now" != "$max_steps" ] && log "not finished: resubmit the same command to resume from $now updates"
fi
log "training exit code: $rc"
exit "$rc"