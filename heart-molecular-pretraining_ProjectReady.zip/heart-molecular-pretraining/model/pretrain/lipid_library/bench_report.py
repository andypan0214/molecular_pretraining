#!/usr/bin/env python
"""Compare stage-04 CPU-scaling benchmark runs (bin/heart bench). Read-only.

    python -m lipid_library.bench_report DIR [DIR ...] [--json-out FILE]

Each DIR is an isolated benchmark LMDB directory holding stage04_run-<job>.json written by
lipid_library.stage04_pool. Per run: workers, molecules written, wall hours, throughput
(molecules/hour), CPU seconds per molecule per worker, parallel efficiency relative to the
smallest worker count (throughput per worker / that of the baseline), peak worker RSS.
Pick the worker count with the highest molecules/hour; per-worker slow-down beyond the physical
core count (~128 on cmri-gpu04) shows up as falling efficiency.
"""
import argparse
import glob
import json
import os
import sys


def load_run(d):
    runs = sorted(glob.glob(os.path.join(d, "stage04_run-*.json")), key=os.path.getmtime)
    if not runs:
        return {"dir": d, "error": "no stage04_run-*.json"}
    r = json.load(open(runs[-1], encoding="utf-8"))
    hours = r.get("elapsed_hours") or 0
    mols = r.get("molecules_written") or 0
    return {"dir": d, "job_id": r.get("job_id"), "host": r.get("host"), "workers": r.get("workers"),
            "cpus_usable": r.get("cpus_usable"), "shards_written": r.get("written"), "failed": len(r.get("failed") or []),
            "molecules": mols, "wall_hours": hours,
            "molecules_per_hour": (mols / hours) if hours else None,
            "cpu_sec_per_molecule": r.get("measured_sec_per_molecule_cpu"),
            "peak_worker_rss_mb": r.get("peak_worker_rss_mb"), "complete": r.get("all_complete")}


def compare(dirs):
    rows = [load_run(d) for d in dirs]
    ok = [r for r in rows if r.get("molecules_per_hour")]
    if ok:
        base = min(ok, key=lambda r: r["workers"])
        per_w = base["molecules_per_hour"] / base["workers"]
        for r in ok:
            r["parallel_efficiency"] = round((r["molecules_per_hour"] / r["workers"]) / per_w, 3)
        best = max(ok, key=lambda r: r["molecules_per_hour"])
        for r in ok:
            r["best"] = r is best
    return rows


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("dirs", nargs="+")
    ap.add_argument("--json-out", default=None)
    ap.add_argument("--full-library-molecules", type=int, default=15241216)
    ns = ap.parse_args(argv)
    rows = compare(ns.dirs)
    print("{:>7} {:>9} {:>9} {:>11} {:>10} {:>8} {:>9}  dir".format(
        "workers", "molecules", "wall_h", "mol/hour", "cpu_s/mol", "eff", "rss_MB"))
    for r in rows:
        if r.get("error"):
            print("   ERROR {}: {}".format(r["dir"], r["error"]))
            continue
        print("{:>7} {:>9} {:>9.3f} {:>11} {:>10} {:>8} {:>9}  {}{}".format(
            r["workers"], r["molecules"], r["wall_hours"],
            "{:.0f}".format(r["molecules_per_hour"]) if r["molecules_per_hour"] else "n/a",
            str(r["cpu_sec_per_molecule"]), str(r.get("parallel_efficiency", "n/a")), str(r["peak_worker_rss_mb"]), r["dir"],
            "   <- best" if r.get("best") else ""))
        if r["molecules_per_hour"]:
            r["projected_full_library_hours"] = round(ns.full_library_molecules / r["molecules_per_hour"], 1)
            print("        projected full library ({} molecules): {:.1f} h".format(
                ns.full_library_molecules, r["projected_full_library_hours"]))
    if ns.json_out:
        with open(ns.json_out, "w", encoding="utf-8") as fh:
            json.dump(rows, fh, indent=2)
    return 0 if all(not r.get("error") for r in rows) else 1


if __name__ == "__main__":
    sys.exit(main())
