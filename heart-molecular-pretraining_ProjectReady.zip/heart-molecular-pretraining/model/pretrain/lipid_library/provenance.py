"""Configuration fingerprints and output-directory locks (review fix P0-2).

Every stage that writes reusable outputs records the complete scientific
configuration it ran with (input-file hashes, reaction/conformer policy,
RDKit version, options) and its SHA-256 fingerprint:

  * once per output directory, in `<out>/<stage>_config.json`, created
    atomically and exclusively (safe for concurrent SLURM array tasks). A later
    run with a different fingerprint FAILS instead of reusing or mixing old
    outputs: use a new output directory for a new configuration;
  * in every chunk/shard receipt, so an individual output is only ever reused
    when its configuration and its exact inputs are unchanged.

Smoke runs (`--limit`, partial ranges) get a different fingerprint and are
marked `"smoke": true`, so they can never be finalised as a production
dataset (see lmdb_writer.finalize and splits.py).
"""
import hashlib
import json
import os
import platform

from . import FORMAT_VERSION


class StaleOutputError(RuntimeError):
    """Existing outputs were produced with a different configuration or input."""


def fingerprint(obj):
    return hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(",", ":"),
                                     default=str).encode("utf-8")).hexdigest()


def sha256_text(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def runtime_versions():
    import numpy
    import rdkit

    out = {"python": platform.python_version(), "rdkit": rdkit.__version__,
           "numpy": numpy.__version__, "format_version": FORMAT_VERSION}
    try:
        import lmdb

        out["lmdb"] = lmdb.__version__
    except ImportError:  # pragma: no cover
        pass
    return out


def lock_config(out_dir, stage, config):
    """Record `config` for `out_dir`, or verify it matches the recorded one.

    Returns the fingerprint. Raises StaleOutputError on a mismatch. The first
    writer wins atomically (O_EXCL), so concurrent array tasks cannot record
    two different configurations.
    """
    os.makedirs(out_dir, exist_ok=True)
    fp = fingerprint(config)
    path = os.path.join(out_dir, "{}_config.json".format(stage))
    payload = json.dumps({"stage": stage, "fingerprint": fp, "config": config},
                         indent=2, sort_keys=True, default=str) + "\n"
    # v2 (stage-02 start-up race): the old code created the file with O_EXCL and
    # wrote it afterwards, so a concurrent array task could read an EMPTY or
    # half-written file and die in json.load. The lock is now published complete:
    # the payload goes to a private temp file that is hard-linked into place
    # (link() is atomic and fails if the name exists, also on NFS).
    if not _publish_exclusive(path, payload):
        recorded = _read_lock(path)
        if recorded.get("fingerprint") != fp:
            changed = sorted(k for k in set(config) | set(recorded.get("config", {}))
                             if config.get(k) != recorded.get("config", {}).get(k))
            raise StaleOutputError(
                "{}: outputs in {} were produced with a different configuration "
                "(changed: {}). Refusing to reuse or mix them; use a new output "
                "directory.".format(stage, out_dir, ", ".join(changed) or "?"))
    return fp


def _publish_exclusive(path, payload):
    """Create `path` with `payload` atomically and exclusively. False if it already exists."""
    import socket

    tmp = "{}.tmp.{}.{}".format(path, socket.gethostname(), os.getpid())
    with open(tmp, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(payload)
        fh.flush()
        os.fsync(fh.fileno())
    try:
        os.link(tmp, path)
        return True
    except FileExistsError:
        return False
    except OSError:
        # filesystem without hard links: exclusive create, then content (old behaviour,
        # readers retry on an incomplete file in _read_lock)
        try:
            fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL)
        except FileExistsError:
            return False
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(payload)
        return True
    finally:
        try:
            os.remove(tmp)
        except OSError:
            pass


def _read_lock(path, attempts=50, delay=0.1):
    """Read a lock file, retrying while another process may still be writing it."""
    import time

    last = None
    for _ in range(attempts):
        try:
            with open(path, encoding="utf-8") as fh:
                return json.load(fh)
        except ValueError as exc:      # empty / partial (legacy writer or no-link filesystem)
            last = exc
            time.sleep(delay)
    raise StaleOutputError("{}: unreadable configuration lock ({})".format(path, last))


def read_config(out_dir, stage):
    path = os.path.join(out_dir, "{}_config.json".format(stage))
    if not os.path.isfile(path):
        return None
    return _read_lock(path)
