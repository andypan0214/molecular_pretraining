#!/usr/bin/env python
"""Mandatory READ-ONLY check: the general ligand LMDBs use the conformer-slot policy stage 04 will write.

    python -m lipid_library.general_policy GENERAL_DIR --n-3d 10 --store-2d 0 \
        [--lipid-dict DICT] [--sample 256] [--json-out FILE]

Why: the lipid shards must store exactly the general data's slot layout, otherwise the continual task
sees two different training-time views (e.g. P(2D) 1/11 vs 2/12). The YAML only *states* the policy
(10 stored 3D slots, STORE_2D=0); this check *measures* it on the real train.lmdb/valid.lmdb before
stage 04 is submitted (bin/heart) and again inside the stage-04 job, and refuses on any mismatch.

Measured per split (records spread evenly over the whole file, opened read-only, lock=False):
  * every sampled record stores exactly n_3d + store_2d coordinate slots;
  * the dominant "<stored>/<flat>" profile equals "<n_3d+store_2d>/<store_2d>" (flat = all z == 0,
    i.e. a 2D slot); records with extra flat slots are 2D fill-ins of failed embeddings and are
    reported (fraction), not treated as a different policy;
  * records keep exactly the fields smi / atoms / coordinates (a `target` field is tolerated);
  * --lipid-dict, if given, is byte-identical to GENERAL_DIR/dict.txt (no vocabulary change).
Exit 0 = compatible; 1 = incompatible or unreadable (fail closed). Nothing is written except --json-out.
"""
import argparse
import hashlib
import json
import os
import pickle
import sys


def _sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for b in iter(lambda: fh.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def _profile_split(path, sample):
    import lmdb

    from .validate_lmdb import is_flat

    env = lmdb.open(path, subdir=False, readonly=True, lock=False, readahead=False, meminit=False,
                    max_readers=4)
    out = {"lmdb": path, "n_records": 0, "n_checked": 0, "profiles": {}, "stored_slots": {}, "fields": {}}
    try:
        with env.begin() as txn:
            n = txn.stat()["entries"]
            out["n_records"] = n
            if n == 0:
                return out
            k = min(sample, n)
            for i in sorted({int(round(j * (n - 1) / max(1, k - 1))) for j in range(k)}):
                raw = txn.get(str(i).encode("ascii"))
                if raw is None:
                    out.setdefault("missing_keys", []).append(i)
                    continue
                rec = pickle.loads(raw)
                fields = ",".join(sorted(rec))
                out["fields"][fields] = out["fields"].get(fields, 0) + 1
                coords = rec.get("coordinates", [])
                key = "{}/{}".format(len(coords), sum(is_flat(c) for c in coords))
                out["profiles"][key] = out["profiles"].get(key, 0) + 1
                out["stored_slots"][str(len(coords))] = out["stored_slots"].get(str(len(coords)), 0) + 1
                out["n_checked"] += 1
    finally:
        env.close()
    return out


def check(general_dir, n_3d=10, store_2d=0, sample=256, lipid_dict=None):
    expected_slots = int(n_3d) + int(store_2d)
    expected = "{}/{}".format(expected_slots, int(store_2d))
    report = {"general_dir": os.path.abspath(general_dir), "expected_profile": expected,
              "expected_stored_slots": expected_slots, "sample_per_split": sample, "splits": {}, "problems": []}
    dict_path = os.path.join(general_dir, "dict.txt")
    if not os.path.isfile(dict_path):
        report["problems"].append("missing {}".format(dict_path))
    elif lipid_dict:
        same = os.path.isfile(lipid_dict) and _sha(lipid_dict) == _sha(dict_path)
        report["lipid_dict_identical"] = same
        if not same:
            report["problems"].append("lipid dict {} is not byte-identical to {}".format(lipid_dict, dict_path))
    for split in ("train", "valid"):
        path = os.path.join(general_dir, split + ".lmdb")
        if not os.path.isfile(path):
            report["problems"].append("missing {}".format(path))
            continue
        try:
            r = _profile_split(path, sample)
        except Exception as exc:                                  # noqa: BLE001 - fail closed
            report["problems"].append("{}: unreadable ({}: {})".format(path, type(exc).__name__, exc))
            continue
        report["splits"][split] = r
        if not r["n_checked"]:
            report["problems"].append("{}: no records could be sampled".format(path))
            continue
        if r.get("missing_keys"):
            report["problems"].append("{}: integer keys missing {}".format(path, r["missing_keys"][:5]))
        wrong_slots = {k: v for k, v in r["stored_slots"].items() if int(k) != expected_slots}
        if wrong_slots:
            report["problems"].append("{}: stored slot counts {} differ from the lipid policy ({} slots)".format(
                split, wrong_slots, expected_slots))
        dominant = max(sorted(r["profiles"]), key=lambda key: r["profiles"][key])
        r["dominant_profile"] = dominant
        r["dominant_fraction"] = round(r["profiles"][dominant] / float(r["n_checked"]), 4)
        r["fraction_with_extra_flat_slots"] = round(sum(
            v for key, v in r["profiles"].items() if int(key.split("/")[1]) > int(store_2d)) / float(r["n_checked"]), 4)
        if dominant != expected:
            report["problems"].append("{}: dominant profile {} != lipid policy {} (n_3d={}, STORE_2D={})".format(
                split, dominant, expected, n_3d, store_2d))
        bad_fields = [f for f in r["fields"] if f not in ("atoms,coordinates,smi", "atoms,coordinates,smi,target")]
        if bad_fields:
            report["problems"].append("{}: unexpected record fields {}".format(split, bad_fields))
    report["compatible"] = not report["problems"]
    return report


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("general_dir")
    ap.add_argument("--n-3d", type=int, default=10)
    ap.add_argument("--store-2d", type=int, choices=(0, 1), required=True)
    ap.add_argument("--sample", type=int, default=256)
    ap.add_argument("--lipid-dict", default=None)
    ap.add_argument("--json-out", default=None)
    ns = ap.parse_args(argv)
    r = check(ns.general_dir, ns.n_3d, ns.store_2d, ns.sample, ns.lipid_dict)
    for split, s in r["splits"].items():
        print("general {:<5} {} records, {} sampled, profiles {} (dominant {} = {:.1%}), extra-flat {:.2%}".format(
            split, s["n_records"], s["n_checked"], json.dumps(s["profiles"], sort_keys=True),
            s.get("dominant_profile"), s.get("dominant_fraction", 0), s.get("fraction_with_extra_flat_slots", 0)))
    print("lipid policy expected {}: {}".format(r["expected_profile"], "COMPATIBLE" if r["compatible"] else "INCOMPATIBLE"))
    for p in r["problems"]:
        print("  PROBLEM: {}".format(p))
    if ns.json_out:
        with open(ns.json_out, "w", encoding="utf-8") as fh:
            json.dump(r, fh, indent=2, sort_keys=True)
    return 0 if r["compatible"] else 1


if __name__ == "__main__":
    sys.exit(main())
