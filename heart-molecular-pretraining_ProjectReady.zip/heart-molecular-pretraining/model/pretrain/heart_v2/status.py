"""Read-only progress of a lipid library from its on-disk receipts.

Nothing here hashes large files or writes anything: it reads the small JSON
receipts every stage already writes, so `bin/heart library --status` is cheap
on a login node. The authoritative, hash-verifying checks remain inside the
stages themselves (02 --check-complete, 04 re-verification, 05 --finalize).
"""
import glob
import json
import os
import re

STAGES = ["01", "02", "03", "03b", "04", "05"]


def _json(path):
    try:
        with open(path, encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return None


def chunk_bounds(total, chunk_size):
    return [(s, min(s + chunk_size, total)) for s in range(0, total, chunk_size)]


def library_status(root, lmdb_dir=None, chunk_size=50000, enum_array_size=64, stage04_stride=1000,
                   expected_combinations=None):
    """{stage: {"state": done|partial|missing|failed, ...}} plus "next" (first stage not done)."""
    bb, enum, dedup = (os.path.join(root, d) for d in ("bb", "enum", "dedup"))
    lmdb = lmdb_dir or os.path.join(root, "lmdb")
    st = {}

    summary = _json(os.path.join(bb, "summary.json"))
    if summary and os.path.isfile(os.path.join(bb, "building_blocks.csv")):
        st["01"] = {"state": "done", "n_combinations": summary.get("n_combinations"),
                    "counts_per_role": summary.get("counts_per_role"), "qc_flags": summary.get("qc_flags")}
    else:
        st["01"] = {"state": "missing"}

    # 02: chunk receipts that carry the locked enumeration fingerprint
    ecfg = _json(os.path.join(enum, "enumeration_config.json"))
    total = None
    if ecfg:
        total = ecfg["config"]["range"][1]
        chunk_size = ecfg["config"]["chunk_size"]
    elif st["01"]["state"] == "done":
        total = st["01"]["n_combinations"]
    total = total or expected_combinations
    if total:
        chunks = chunk_bounds(total, chunk_size)
        done, stale, missing = [], [], []
        for ci, (lo, hi) in enumerate(chunks):
            r = _json(os.path.join(enum, "products", "products-{}-{}.done.json".format(lo, hi)))
            if r is None or not os.path.isfile(os.path.join(enum, "products", "products-{}-{}.csv.gz".format(lo, hi))):
                missing.append(ci)
            elif ecfg and r.get("config_fingerprint") != ecfg["fingerprint"]:
                stale.append(ci)
            else:
                done.append(ci)
        complete = _json(os.path.join(enum, "enumeration_complete.json"))
        tasks = sorted({c % enum_array_size for c in missing + stale})
        st["02"] = {"state": "done" if not missing and not stale else ("partial" if done else "missing"),
                    "n_chunks": len(chunks), "n_done": len(done), "missing_chunks": missing[:50],
                    "stale_chunks": stale[:50], "resubmit_array_tasks": tasks,
                    "enumeration_complete_json": bool(complete and complete.get("complete")),
                    "n_combinations": total, "chunk_size": chunk_size}
        if stale:
            st["02"]["state"] = "failed"
            st["02"]["note"] = "receipts from another configuration: use a new LIPID root, never mix"
    else:
        st["02"] = {"state": "missing", "note": "stage 01 not done"}

    dsum = _json(os.path.join(dedup, "summary.json"))
    complete = _json(os.path.join(enum, "enumeration_complete.json"))
    if dsum and complete and dsum.get("enumeration_fingerprint") == complete.get("config_fingerprint") \
            and os.path.isfile(os.path.join(dedup, "drop_combo_indexes.csv.gz")):
        st["03"] = {"state": "done", "n_unique_products": dsum.get("n_unique_products"),
                    "n_duplicate_rows": dsum.get("n_duplicate_rows")}
    elif dsum:
        st["03"] = {"state": "failed", "note": "dedup summary does not match enumeration_complete.json"}
    else:
        st["03"] = {"state": "missing"}

    pidx = _json(os.path.join(lmdb, "shard_inputs", "partition_index.json"))
    if pidx and pidx.get("complete") is True:
        st["03b"] = {"state": "done", "n_shards": pidx["n_shards"], "n_input_rows": pidx["n_input_rows"]}
    else:
        st["03b"] = {"state": "missing"}

    wcfg = _json(os.path.join(lmdb, "lmdb_writer_config.json"))
    if pidx and pidx.get("complete") is True:
        fp = wcfg["fingerprint"] if wcfg else None
        by_sid = {e["shard_id"]: e for e in pidx["shards"]}
        have, stale = [], []
        for d in glob.glob(os.path.join(lmdb, "shard-*")):
            m = re.match(r"shard-(\d+)$", os.path.basename(d))
            if not m:
                continue
            sid = int(m.group(1))
            r = _json(os.path.join(d, "shard.json"))
            if r is None or not os.path.isfile(os.path.join(d, "train.lmdb")) or sid not in by_sid:
                continue
            if r.get("config_fingerprint") != fp or r.get("input_fingerprint") != by_sid[sid]["input_fingerprint"]:
                stale.append(sid)
            else:
                have.append(sid)
        missing = sorted(set(by_sid) - set(have) - set(stale))
        prog = _json(os.path.join(lmdb, "stage04_progress.json"))
        st["04"] = {"state": "done" if not missing and not stale else ("partial" if have else "missing"),
                    "n_shards": len(by_sid), "n_receipts": len(have), "missing_shards": missing[:50],
                    "n_missing": len(missing), "stale_shards": stale[:50],
                    "resubmit_array_tasks_stride": sorted({s % stage04_stride for s in missing + stale})[:200],
                    "progress": prog, "note": "receipts only; hashes are verified by stage 04/05"}
        if stale:
            st["04"]["state"] = "failed"
    else:
        st["04"] = {"state": "missing"}

    from lipid_library import ready as ready_mod

    manifest = _json(os.path.join(lmdb, "manifest.json"))
    report = _json(os.path.join(lmdb, "finalize_report.json"))
    # metadata only here (cheap on a login node); shard integrity is checked by `ready verify`
    record, problems = (ready_mod.verify(lmdb, allow_smoke=True, check_shards=False) if os.path.isdir(lmdb)
                        else (None, ["no lmdb dir"]))
    if record is not None:
        st["05"] = {"state": "done", "smoke": record["smoke"], "n_records": record["n_records"],
                    "n_shards": record["n_shards"]}
    elif manifest or report:
        st["05"] = {"state": "failed", "problems": problems[:10],
                    "finalize_problems": (report or {}).get("problems", [])[:10]}
    else:
        st["05"] = {"state": "missing"}

    nxt = next((s for s in STAGES if st[s]["state"] != "done"), None)
    return {"root": root, "lmdb": lmdb, "stages": st, "next": nxt, "complete": nxt is None}


def format_status(status):
    lines = ["lipid library: {}".format(status["root"])]
    for s in STAGES:
        e = status["stages"][s]
        extra = ""
        if s == "02" and "n_chunks" in e:
            extra = "{}/{} chunks".format(e["n_done"], e["n_chunks"])
            if e.get("resubmit_array_tasks") and e["state"] in ("partial", "failed"):
                extra += "; resubmit --array={}".format(",".join(map(str, e["resubmit_array_tasks"])))
        elif s == "04" and "n_shards" in e:
            extra = "{}/{} shard receipts".format(e["n_receipts"], e["n_shards"])
            p = e.get("progress") or {}
            if p:
                extra += "; last pool run {} (job {}): written {}, failed {}, stopped {}".format(
                    p.get("updated"), p.get("job_id"), p.get("written"), len(p.get("failed") or []), p.get("stopped"))
        elif s == "05" and e["state"] == "done":
            extra = "{} records in {} shards{}".format(e["n_records"], e["n_shards"], " [SMOKE]" if e["smoke"] else "")
        elif e.get("problems"):
            extra = "; ".join(e["problems"][:3])
        elif e.get("note"):
            extra = e["note"]
        lines.append("  stage {:<3} {:<8} {}".format(s, e["state"].upper(), extra))
    lines.append("  next: {}".format(status["next"] or "nothing (library complete)"))
    return "\n".join(lines)
