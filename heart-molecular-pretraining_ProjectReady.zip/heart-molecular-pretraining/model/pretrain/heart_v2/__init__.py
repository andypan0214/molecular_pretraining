"""HEART v2 orchestration for NEW lipid-library and continual-pretraining jobs.

    bin/heart check | library ... | continual ... | evaluate ... | baseline | render <profile>

Everything here reads config/heart_v2.yaml (the single source of SLURM
resources and paths for lipid/continual work), renders sbatch commands,
reports progress from on-disk receipts and only submits with an explicit
`--submit`. The frozen general pretraining (scripts/pretrain_heart-h200.sh,
heart_lib.sh, unimol_contrastive, ...) is never configured or launched here.
"""

V2_VERSION = "heart-v2-orchestrator-1"
