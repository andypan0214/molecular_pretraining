"""Load, override and validate config/heart_v2.yaml (fail fast on contradictions)."""
import copy
import hashlib
import json
import os
import re

HERE = os.path.dirname(os.path.abspath(__file__))
PRETRAIN_DIR = os.path.dirname(HERE)
MODEL_ROOT = os.path.dirname(PRETRAIN_DIR)
REPO_ROOT = os.path.dirname(MODEL_ROOT)
DEFAULT_CONFIG = os.path.join(REPO_ROOT, "config", "heart_v2.yaml")

LIBRARY_PROFILES = ["lipid_01", "lipid_02", "lipid_03", "lipid_03b", "lipid_04", "lipid_05"]
OPTIONAL_PROFILES = ["lipid_04_array"]
CONTINUAL_PROFILE = "continual"
OPTIONAL_PROFILE_KEYS = {"gres", "nodelist", "constraint", "array", "signal", "ntasks", "ntasks_per_node"}
H200_GRES = re.compile(r"^gpu:h200:([1-9][0-9]*)$")
MEM_RE = re.compile(r"^([1-9][0-9]*)([MGT])$")
TIME_RE = re.compile(r"^(?:(\d+)-)?(\d{1,2}):(\d{2}):(\d{2})$")


class ConfigError(ValueError):
    """The configuration is inconsistent or would request the wrong resources."""


def _load_yaml(path):
    if str(path).endswith(".json"):
        # Job-side snapshots are JSON. PyYAML (YAML 1.1) reads JSON's `2e-05` as a STRING,
        # which changed the config hash between submission and job start (v2 hardening).
        with open(path, encoding="utf-8") as fh:
            return json.load(fh)
    try:
        import yaml
    except ImportError as exc:  # pragma: no cover - heart_gpu ships pyyaml
        raise ConfigError("PyYAML is required to read {} ({})".format(path, exc))
    with open(path, encoding="utf-8") as fh:
        return yaml.safe_load(fh)


def _coerce(text):
    """`--set` values: int, float, bool, null or string."""
    low = text.lower()
    if low in ("true", "false"):
        return low == "true"
    if low in ("null", "none"):
        return None
    for cast in (int, float):
        try:
            return cast(text)
        except ValueError:
            pass
    return text


def apply_overrides(cfg, overrides):
    """`overrides` = ["slurm.profiles.lipid_04.time=1-00:00:00", ...]; returns a new dict."""
    out = copy.deepcopy(cfg)
    for item in overrides or []:
        if "=" not in item:
            raise ConfigError("--set expects key.path=value, got {!r}".format(item))
        key, value = item.split("=", 1)
        parts = key.strip().split(".")
        node = out
        for p in parts[:-1]:
            if not isinstance(node.get(p), dict):
                raise ConfigError("--set {}: {!r} is not a section".format(key, p))
            node = node[p]
        optional = len(parts) == 4 and parts[:2] == ["slurm", "profiles"] and parts[3] in OPTIONAL_PROFILE_KEYS
        if parts[-1] not in node and not optional:
            raise ConfigError("--set {}: unknown key (typo?)".format(key))
        node[parts[-1]] = _coerce(value.strip())
    return out


def mem_mb(text):
    m = MEM_RE.match(str(text))
    if not m:
        raise ConfigError("memory {!r} must look like 500G / 16000M".format(text))
    return int(m.group(1)) * {"M": 1, "G": 1024, "T": 1024 * 1024}[m.group(2)]


def time_hours(text):
    m = TIME_RE.match(str(text))
    if not m:
        raise ConfigError("time {!r} must be [D-]HH:MM:SS".format(text))
    d, h, mi, s = (int(x or 0) for x in m.groups())
    return d * 24 + h + mi / 60.0 + s / 3600.0


def profile(cfg, name):
    """Defaults merged with one profile."""
    profiles = cfg["slurm"]["profiles"]
    if name not in profiles:
        raise ConfigError("unknown SLURM profile {!r} (have {})".format(name, sorted(profiles)))
    merged = dict(cfg["slurm"].get("defaults", {}))
    merged.update(profiles[name])
    return merged


def validate(cfg):
    """Raise ConfigError on any contradiction. Returns a list of warnings."""
    warnings = []
    for section in ("paths", "environment", "library", "continual", "slurm"):
        if section not in cfg:
            raise ConfigError("config has no {!r} section".format(section))
    profiles = cfg["slurm"].get("profiles", {})
    for name in LIBRARY_PROFILES + [CONTINUAL_PROFILE]:
        if name not in profiles:
            raise ConfigError("missing SLURM profile {!r}".format(name))
    for name in profiles:
        p = profile(cfg, name)
        for key in ("partition", "script", "job_name", "cpus_per_task", "mem", "time"):
            if p.get(key) in (None, ""):
                raise ConfigError("profile {}: {} is required".format(name, key))
        if not isinstance(p["cpus_per_task"], int) or p["cpus_per_task"] < 1:
            raise ConfigError("profile {}: cpus_per_task must be a positive integer".format(name))
        mem_mb(p["mem"])
        time_hours(p["time"])
        if not os.path.isfile(os.path.join(REPO_ROOT, p["script"])):
            raise ConfigError("profile {}: script {} does not exist".format(name, p["script"]))
        gres = p.get("gres")
        if name in ("lipid_04", CONTINUAL_PROFILE):
            if not gres or not H200_GRES.match(str(gres)):
                raise ConfigError("profile {}: gres must be gpu:h200:<n> (got {!r}); generic gpu:1, "
                                  "gpu:h200a:1 and T4 are refused".format(name, gres))
        elif gres:
            raise ConfigError("profile {}: CPU stage must not request a GPU (gres {!r})".format(name, gres))
        for key in ("nodelist", "constraint"):
            if p.get(key) and re.search(r"t4", str(p[key]), re.I):
                raise ConfigError("profile {}: {} {!r} targets a T4 node".format(name, key, p[key]))

    lib, cont = cfg["library"], cfg["continual"]
    p04, pc = profile(cfg, "lipid_04"), profile(cfg, CONTINUAL_PROFILE)
    if p04["cpus_per_task"] < 64:
        raise ConfigError("lipid_04: {} CPUs is not the production H200 profile (250)".format(p04["cpus_per_task"]))
    if lib["stage04_workers"] > p04["cpus_per_task"]:
        raise ConfigError("library.stage04_workers {} > lipid_04 cpus_per_task {}".format(
            lib["stage04_workers"], p04["cpus_per_task"]))
    if pc["cpus_per_task"] > 64 or mem_mb(pc["mem"]) > 256 * 1024:
        raise ConfigError("continual profile requests {} CPUs / {}: that is the stage-04 library profile, "
                          "not the continual one (16 CPUs / 200G)".format(pc["cpus_per_task"], pc["mem"]))
    n_gres = int(H200_GRES.match(pc["gres"]).group(1))
    if n_gres != int(cont["n_gpu"]):
        raise ConfigError("continual.n_gpu {} != GPUs in gres {}".format(cont["n_gpu"], pc["gres"]))
    if int(cont["num_workers"]) >= pc["cpus_per_task"]:
        raise ConfigError("continual.num_workers must be < continual cpus_per_task")
    if str(cont["max_open_lmdb_envs"]) != "auto" and int(cont["max_open_lmdb_envs"]) < 1:
        raise ConfigError("continual.max_open_lmdb_envs must be >= 1 or 'auto'")
    for k in ("general_data_weight", "lipid_data_weight"):
        if not 0 < float(cont[k]) <= 1:
            raise ConfigError("continual.{} must be in (0, 1]".format(k))
    if int(lib["store_2d"]) not in (0, 1):
        raise ConfigError("library.store_2d must be 0 or 1")
    if int(lib["store_2d"]) != 0 or int(lib["n_3d"]) != 10:
        warnings.append("library slot policy differs from the audited general ligand data "
                        "(10 stored 3D slots, STORE_2D=0)")
    if int(cont["max_steps"]) != 200000:
        warnings.append("continual.max_steps is {} (production plan: 200000)".format(cont["max_steps"]))
    if int(cont["batch_size"]) != 448:
        warnings.append("continual.batch_size is {} (proven H200 value: 448)".format(cont["batch_size"]))
    p02 = profile(cfg, "lipid_02")
    if p02.get("array") != "0-{}".format(int(lib["enum_array_size"]) - 1):
        raise ConfigError("lipid_02 array {!r} must be 0-{} (library.enum_array_size)".format(
            p02.get("array"), int(lib["enum_array_size"]) - 1))
    lipid_root = os.path.normpath(cfg["paths"]["lipid_root"])
    for key in ("general_data",):
        other = os.path.normpath(cfg["paths"][key])
        if lipid_root == other or lipid_root.startswith(other + os.sep) or lipid_root.startswith(other + "/"):
            raise ConfigError("paths.lipid_root must not be inside paths.{}".format(key))
    cont_root = str(cfg["paths"]["continual_output_root"])
    if "/runs/h200/full" in cont_root.replace("\\", "/"):
        raise ConfigError("paths.continual_output_root must not be the general H200 run tree")
    return warnings


def config_hash(cfg):
    return hashlib.sha256(json.dumps(cfg, sort_keys=True, separators=(",", ":"),
                                     default=str).encode("utf-8")).hexdigest()


def load(path=None, overrides=None):
    """(config dict, path used, warnings). HEART_V2_CONFIG overrides the default file."""
    path = path or os.environ.get("HEART_V2_CONFIG") or DEFAULT_CONFIG
    cfg = apply_overrides(_load_yaml(path), overrides)
    warnings = validate(cfg)
    return cfg, os.path.abspath(path), warnings
