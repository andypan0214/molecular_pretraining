"""Render sbatch flags from a config profile; parse and compare #SBATCH headers.

The profile is the single source of truth. render() is used for the real
sbatch command line; header_lines() is what the #SBATCH header of the job
script must contain (tests compare them byte for byte), so a direct
`sbatch script.sh` and `bin/heart ... --submit` request the same resources.
"""
import os
import re
import shlex

from .config import REPO_ROOT, profile

# Order of flags in both the header and the command line.
FIELDS = [
    ("partition", "--partition"), ("nodes", "--nodes"), ("ntasks", "--ntasks"),
    ("ntasks_per_node", "--ntasks-per-node"),
    ("cpus_per_task", "--cpus-per-task"), ("mem", "--mem"), ("gres", "--gres"),
    ("nodelist", "--nodelist"), ("constraint", "--constraint"), ("time", "--time"),
    ("array", "--array"), ("signal", "--signal"), ("job_name", "--job-name"),
]
RESOURCE_FLAGS = {"--partition", "--nodes", "--ntasks", "--ntasks-per-node", "--cpus-per-task", "--mem",
                  "--gres", "--gpus", "--gpus-per-node", "--nodelist", "-w", "--constraint", "--time",
                  "--array", "--signal", "--job-name", "--output", "--error", "-p", "-c", "-t", "-N", "-n"}


def log_paths(cfg, name, lipid_root=None):
    """(--output, --error) for a profile."""
    p = profile(cfg, name)
    if name.startswith("lipid"):
        base = os.path.join(lipid_root or cfg["paths"]["lipid_root"], "logs").replace("\\", "/")
    else:
        base = "{}/slurm".format(str(cfg["paths"]["continual_output_root"]).rstrip("/"))
    pattern = "%x-%A_%a" if p.get("array") else "%x-%j"
    return "{}/{}.out".format(base, pattern), "{}/{}.err".format(base, pattern)


def resource_pairs(cfg, name, lipid_root=None, array=None):
    p = profile(cfg, name)
    if array is not None:
        p["array"] = array
    pairs = []
    for key, flag in FIELDS:
        v = p.get(key)
        if v not in (None, ""):
            pairs.append((flag, str(v)))
    out, err = log_paths(cfg, name, lipid_root)
    if array is not None and not p.get("array"):
        out, err = out.replace("%j", "%A_%a"), err.replace("%j", "%A_%a")
    pairs += [("--output", out), ("--error", err)]
    return pairs


def header_lines(cfg, name):
    """#SBATCH lines the job script must carry (production paths)."""
    return ["#SBATCH {}={}".format(f, v) for f, v in resource_pairs(cfg, name)]


def script_path(cfg, name):
    return os.path.join(REPO_ROOT, profile(cfg, name)["script"]).replace("\\", "/")


def render(cfg, name, export=None, dependency=None, array=None, lipid_root=None, parsable=True,
           test_only=False):
    """Full sbatch argv for profile `name`."""
    argv = ["sbatch"]
    if parsable:
        argv.append("--parsable")
    if test_only:
        argv.append("--test-only")
    argv += ["{}={}".format(f, v) for f, v in resource_pairs(cfg, name, lipid_root, array)]
    if dependency:
        argv.append("--dependency={}".format(dependency))
    if export:
        bad = [k for k, v in export.items() if "," in str(v)]
        if bad:
            raise ValueError("--export values may not contain commas: {}".format(bad))
        argv.append("--export=ALL," + ",".join("{}={}".format(k, export[k]) for k in sorted(export)))
    argv.append(script_path(cfg, name))
    return argv


def shell_join(argv):
    return " ".join(shlex.quote(a) for a in argv)


_HDR = re.compile(r"^#SBATCH\s+(\S+?)(?:[=\s]\s*(.*?))?\s*$")


def parse_header(path):
    """[(flag, value)] from the #SBATCH lines at the top of a script."""
    out = []
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            if line.startswith("#SBATCH"):
                m = _HDR.match(line.rstrip("\n"))
                if m:
                    out.append((m.group(1), m.group(2) or ""))
            elif line.strip() and not line.startswith("#"):
                break
    return out


def header_mismatches(cfg, name):
    """Differences between a script's #SBATCH header and its profile ([] = identical)."""
    want = resource_pairs(cfg, name)
    have = parse_header(script_path(cfg, name))
    problems = []
    if have != want:
        wd, hd = dict(want), dict(have)
        for flag in sorted(set(wd) | set(hd)):
            if wd.get(flag) != hd.get(flag):
                problems.append("{}: header {!r} vs config {!r}".format(flag, hd.get(flag), wd.get(flag)))
        if not problems:
            problems.append("flag order or duplicates differ")
    return problems


# GPU type evidence that actually exists on a SLURM node (v2 hardening, CMRI-compatible):
#   * `scontrol show job -d $SLURM_JOB_ID`: AllocTRES=...,gres/gpu:h200=1 ; TresPerNode=gres/gpu:h200:1 ;
#     GRES=gpu:h200:1(IDX:0)   (typed GRES appears here; untyped requests show only gres/gpu=1)
#   * `nvidia-smi --query-gpu=name --format=csv,noheader` -> "NVIDIA H200" for the GPU(s) in this job's cgroup
# Count: SLURM_GPUS_ON_NODE (set by SLURM for any GPU GRES). There is no standard SLURM variable carrying
# the GPU *type* (SLURM_JOB_GPUS / CUDA_VISIBLE_DEVICES are indices), so the type is never read from env.
_GPU_TYPE = re.compile(r"gpu:([A-Za-z][A-Za-z0-9_.-]*?)(?=[:=(,]|$)")
_TRES_FIELDS = ("AllocTRES", "TresPerNode", "TresPerJob", "TresPerTask", "GRES", "Gres", "ReqTRES")


def _run_cmd(argv):
    import subprocess

    try:
        res = subprocess.run(argv, capture_output=True, text=True, timeout=60)
    except (OSError, subprocess.SubprocessError):
        return ""
    return res.stdout if res.returncode == 0 else ""


def gpu_type_evidence(env, run=None):
    """[(source, value)] positive evidence of the GPU type(s) allocated to this job."""
    run = run or _run_cmd
    out = []
    jid = env.get("SLURM_JOB_ID")
    if jid:
        text = run(["scontrol", "show", "job", "-d", str(jid)])
        for field in _TRES_FIELDS:
            for m in re.finditer(r"\b{}=(\S+)".format(field), text or ""):
                for t in _GPU_TYPE.findall(m.group(1)):
                    out.append(("scontrol " + field, t.lower()))
    for line in (run(["nvidia-smi", "--query-gpu=name", "--format=csv,noheader"]) or "").splitlines():
        if line.strip():
            out.append(("nvidia-smi", line.strip()))
    return out


def check_gpu_type(gres, evidence):
    """Problems for `gres` (gpu:<type>:<n>) given the evidence. [] = positively verified."""
    want = gres.split(":")[1].lower()
    problems, positive = [], False
    for source, value in evidence:
        v = value.lower()
        if source == "nvidia-smi":
            if want in v.replace(" ", "").replace("-", ""):
                positive = True
            else:
                problems.append("nvidia-smi reports GPU {!r}, not {} ({})".format(value, want.upper(), gres))
        elif v == want:
            positive = True
        else:
            problems.append("{} reports GPU type {!r}, not {!r} ({})".format(source, value, want, gres))
    if not problems and not positive:
        problems.append("GPU type unverifiable: no typed TRES in `scontrol show job -d` and no nvidia-smi "
                        "name (set HEART_V2_ALLOW_UNVERIFIED_GPU_TYPE=1 only after checking the node by hand)")
    return problems


def check_allocation(cfg, name, env, run=None):
    """Compare the real SLURM allocation (job environment + scontrol/nvidia-smi) with the profile. [] = OK.

    Variables used (all set by SLURM on CMRI-class clusters): SLURM_CPUS_PER_TASK, SLURM_MEM_PER_NODE
    (MB, set by --mem), SLURM_JOB_PARTITION, SLURM_GPUS_ON_NODE, SLURMD_NODENAME; GPU type from
    gpu_type_evidence(). The type check only runs inside a job (SLURM_JOB_ID set).
    """
    from .config import mem_mb

    p = profile(cfg, name)
    problems = []
    cpus = env.get("SLURM_CPUS_PER_TASK")
    if cpus is not None and int(cpus) != int(p["cpus_per_task"]):
        problems.append("SLURM_CPUS_PER_TASK={} but profile {} wants {}".format(cpus, name, p["cpus_per_task"]))
    mem = env.get("SLURM_MEM_PER_NODE")
    if mem is not None and mem.isdigit() and int(mem) != mem_mb(p["mem"]):
        problems.append("SLURM_MEM_PER_NODE={}M but profile {} wants {}".format(mem, name, p["mem"]))
    part = env.get("SLURM_JOB_PARTITION")
    if part is not None and part != p["partition"]:
        problems.append("partition {} but profile {} wants {}".format(part, name, p["partition"]))
    gres = p.get("gres")
    gpus_on_node = env.get("SLURM_GPUS_ON_NODE")
    if gres:
        want = int(gres.rsplit(":", 1)[1])
        if env.get("SLURM_JOB_ID") and (gpus_on_node is None or not gpus_on_node.isdigit()):
            problems.append("SLURM_GPUS_ON_NODE is not set: no GPU was allocated ({} wants {})".format(name, gres))
        elif gpus_on_node is not None and gpus_on_node.isdigit() and int(gpus_on_node) != want:
            problems.append("SLURM_GPUS_ON_NODE={} but profile {} wants {} ({})".format(
                gpus_on_node, name, want, gres))
        if env.get("SLURM_JOB_ID") and env.get("HEART_V2_ALLOW_UNVERIFIED_GPU_TYPE") != "1":
            problems += check_gpu_type(gres, gpu_type_evidence(env, run))
    elif gpus_on_node not in (None, "", "0"):
        problems.append("CPU stage {} was given {} GPU(s)".format(name, gpus_on_node))
    node = env.get("SLURMD_NODENAME")
    if p.get("nodelist") and node and node not in str(p["nodelist"]).split(","):
        problems.append("running on {} but profile {} pins {}".format(node, name, p["nodelist"]))
    return problems
