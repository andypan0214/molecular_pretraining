# Copyright (c) DP Technology.
# This source code is licensed under the MIT license found in the
# LICENSE file in the root directory of this source tree.
#
# HEART patch P6 (full job 1011523, see model/pretrain/IMPLEMENTATION_MAP.md):
#   Upstream assumed every record's SMILES parses with the installed RDKit and
#   that AddHs(MolFromSmiles(smi)) reproduces the record's atom list. Job
#   1011523 crashed after ~5,000 updates with AddHs(NoneType): a record whose
#   SMILES the installed RDKit rejects, although the record still carries
#   stored 3D conformers (generated when the dataset was built). Upstream's
#   alignment "assert" was also a no-op (a bare tuple expression), so a 2D
#   conformer with a different atom count or order would have been silently
#   paired with the record's atoms.
#
#   The 2D conformer is now added only when the SMILES is a non-empty string
#   that RDKit parses and sanitizes, and AddHs reproduces the record's atom
#   symbols in order. Otherwise (policy "skip-2d", the default) the record is
#   kept with its stored 3D conformers only: no coordinates are fabricated,
#   the dataset length and indexing are unchanged, and every case is logged
#   with its index and reason. Policy "error" raises instead. A record with
#   neither a usable 2D conformer nor stored 3D conformers always raises.
#   If skipped records exceed max_invalid_fraction of the records processed
#   (after min_checked), training stops: that indicates a systematic problem
#   (e.g. an RDKit version or data mismatch), not a few malformed records.

import logging
import os

import numpy as np
from functools import lru_cache
from unicore.data import BaseWrapperDataset
from rdkit import Chem
from rdkit.Chem import AllChem

logger = logging.getLogger(__name__)

SKIP_2D = "skip-2d"
ERROR = "error"
POLICIES = (SKIP_2D, ERROR)


class Invalid2DConformer(ValueError):
    """The SMILES of a record cannot give a 2D conformer aligned with its atoms."""


class _quiet_rdkit:
    """Suppress RDKit's own stderr messages; HEART logs a structured reason instead."""

    def __enter__(self):
        try:
            from rdkit.rdBase import BlockLogs

            self._block = BlockLogs()
        except ImportError:  # very old RDKit: messages stay visible
            self._block = None
        return self

    def __exit__(self, *exc):
        self._block = None
        return False


class Add2DConformerDataset(BaseWrapperDataset):
    def __init__(self, dataset, smi, atoms, coordinates, invalid_policy=SKIP_2D,
                 max_invalid_fraction=0.01, min_checked=10000, log_first=20):
        if invalid_policy not in POLICIES:
            raise ValueError("invalid_policy must be one of {}, got {!r}".format(POLICIES, invalid_policy))
        self.dataset = dataset
        self.smi = smi
        self.atoms = atoms
        self.coordinates = coordinates
        self.invalid_policy = invalid_policy
        self.max_invalid_fraction = max_invalid_fraction
        self.min_checked = min_checked
        self.log_first = log_first
        self.n_checked = 0
        self.n_skipped = 0
        self.set_epoch(None)

    def set_epoch(self, epoch, **unused):
        super().set_epoch(epoch)
        self.epoch = epoch

    @lru_cache(maxsize=16)
    def __cached_item__(self, index: int, epoch: int):
        atoms = np.array(self.dataset[index][self.atoms])
        assert len(atoms) > 0
        smi = self.dataset[index][self.smi]
        # HEART patch P2: upstream did `coordinates.append(coordinates_2d)`,
        # mutating the list held in LMDBDataset's LRU cache, so a record could
        # accumulate several copies of its 2D conformer when this cache evicts
        # before the LMDB cache does. Build a new list instead.
        coordinates = list(self.dataset[index][self.coordinates])
        self.n_checked += 1
        try:
            coordinates.append(smi2_2Dcoords(smi, atoms))
        except Invalid2DConformer as exc:
            self._skip_2d(index, smi, str(exc), n_3d=len(coordinates))
        return {"smi": smi, "atoms": atoms, "coordinates": coordinates}

    def _skip_2d(self, index, smi, reason, n_3d):
        where = "record {} (pid {})".format(index, os.getpid())
        if self.invalid_policy == ERROR:
            raise Invalid2DConformer("{}: {}; smi={!r} (--invalid-smiles-policy error)".format(where, reason, smi))
        if n_3d == 0:
            raise Invalid2DConformer("{}: {}; smi={!r}, and the record has no stored 3D conformer "
                                     "to fall back to".format(where, reason, smi))
        self.n_skipped += 1
        if self.n_skipped <= self.log_first:
            logger.warning("HEART 2D conformer skipped: %s: %s; smi=%r; using its %d stored 3D conformer(s)",
                           where, reason, _short(smi), n_3d)
        if self.n_skipped == self.log_first or _is_power_of_ten(self.n_skipped):
            logger.warning("HEART 2D conformer skipped for %d of %d records processed so far (pid %d)",
                           self.n_skipped, self.n_checked, os.getpid())
        if (self.n_checked >= self.min_checked
                and self.n_skipped > self.max_invalid_fraction * self.n_checked):
            raise Invalid2DConformer(
                "2D conformer unusable for {} of {} records processed (> {:g}); this looks like a "
                "systematic data/RDKit mismatch, not isolated malformed records. Scan the LMDB with "
                "pretrain/tools/scan_lmdb_smiles.py".format(self.n_skipped, self.n_checked,
                                                            self.max_invalid_fraction))

    def __getitem__(self, index: int):
        return self.__cached_item__(index, self.epoch)


def _short(smi, n=200):
    return smi if not isinstance(smi, str) or len(smi) <= n else smi[:n] + "..."


def _is_power_of_ten(n):
    while n >= 10 and n % 10 == 0:
        n //= 10
    return n == 1


def parse_smiles(smi):
    """Return (mol, None) if RDKit parses and sanitizes `smi`, else (None, reason)."""
    if not isinstance(smi, str):
        return None, "SMILES is {}, not a string".format(type(smi).__name__)
    if not smi.strip():
        return None, "SMILES is empty"
    with _quiet_rdkit():
        mol = Chem.MolFromSmiles(smi)
        if mol is not None:
            return mol, None
        raw = Chem.MolFromSmiles(smi, sanitize=False)
        if raw is None:
            return None, "SMILES syntax rejected by RDKit"
        problems = [p.Message() for p in Chem.DetectChemistryProblems(raw)]
    return None, "RDKit sanitization failed: {}".format("; ".join(problems) or "unknown reason")


def smi2_2Dcoords(smi, atoms=None):
    """RDKit 2D coordinates (with explicit H) of `smi`, as float32 (N, 3).

    Raises Invalid2DConformer when the SMILES cannot be used, or, if `atoms`
    is given, when AddHs does not reproduce those atom symbols in order (the
    coordinates would otherwise be paired with the wrong atoms).
    """
    mol, reason = parse_smiles(smi)
    if mol is None:
        raise Invalid2DConformer(reason)
    with _quiet_rdkit():
        mol = AllChem.AddHs(mol)
        AllChem.Compute2DCoords(mol)
    coordinates = mol.GetConformer().GetPositions().astype(np.float32)
    symbols = [a.GetSymbol() for a in mol.GetAtoms()]
    if coordinates.shape != (len(symbols), 3) or not np.isfinite(coordinates).all():
        raise Invalid2DConformer("RDKit 2D coordinates have shape {} or are not finite".format(coordinates.shape))
    if atoms is not None:
        atoms = [str(a) for a in atoms]
        if len(symbols) != len(atoms):
            raise Invalid2DConformer("2D molecule has {} atoms, record has {}".format(len(symbols), len(atoms)))
        if symbols != atoms:
            i = next(k for k, (a, b) in enumerate(zip(symbols, atoms)) if a != b)
            raise Invalid2DConformer("2D atom order differs from the record at atom {} ({} vs {})".format(
                i, symbols[i], atoms[i]))
    return coordinates
