# HEART v2 — test results (2026-11-07/08)

## Latest: hardening pass, ONE full run on the final committed code

| Commit | Working tree | Command | Result |
|---|---|---|---|
| `4d86ded0156ec137947eca0ba7c704282900f9a7` | clean (`git status --porcelain --untracked-files=no` empty) | `cd model && python -m pytest pretrain/tests -rfEs` (whole suite, nothing deselected) | **433 passed, 0 failed, 2 skipped** in 652 s |

* Skipped (2): `test_lmdb_workers.py:84` and `test_v2_review_fixes.py:271` need `fork()`, which Linux/CMRI has and Windows doesn't.
* The previous full run, on `305b6d1`, gave 432 passed, 1 failed, 2 skipped. The failure was `test_review_fixes.py::test_p1_h200_preflight_refuses_smoke_lipid_data_in_production`. That test emulates a SLURM job (`SLURM_JOB_ID=123`) without its GPU allocation, so the new guard check "SLURM_GPUS_ON_NODE not set" fired first. Commit `4d86ded` adds `SLURM_GPUS_ON_NODE=1` to the emulated job environment. No product code changed, and the full suite was then re-run as above.
* The 71 v2 integration tests are 43 from the first pass plus 28 in `test_v2_hardening.py`.
* Docs-only commits follow `4d86ded`. `git diff 4d86ded..HEAD --stat` shows `docs/` only.

## First pass (kept for the record)

Environment (local, NOT CMRI): Windows 11, Git Bash, Python 3.11.7 venv, numpy 1.26.4, lmdb 1.4.1,
RDKit 2024.9.6, scipy 1.13.1, torch 2.2.2+cpu, Uni-Core `ace6fae` source checkout on `PYTHONPATH`
(an editable `pip install` of Uni-Core was blocked by the session's permission policy; the upstream
`conftest.py` documents `PYTHONPATH` as supported). Command:
`cd model && python -m pytest pretrain/tests -q`.

| Run | Code | Result | Kind |
|---|---|---|---|
| Upstream baseline, in-repo | `73a5f9d` | 362 passed, 2 skipped | LOCAL |
| Upstream baseline, `git archive` export | `73a5f9d` | 359 passed, 2 failed, 3 skipped — the 2 failures + 1 skip need a `.git` directory (`git ls-files`), not code issues | LOCAL |
| Full v2 suite | `36c61db` + post-commit doc/script edits | 404 passed, 1 failed, 2 skipped (10 min) — the failure is `test_general_pretraining_sources_are_unmodified`, which by design requires a committed working tree | LOCAL |
| Re-run after committing (`bafd563`): that test, the lipid stage-script end-to-end test, the obsolete-path doc scans and all 43 v2 integration tests | `bafd563` | 47 passed | LOCAL |
| **Effective full-suite status at `bafd563`** | | **405 passed, 0 failed, 2 skipped** | LOCAL |

Skipped: 2 tests that need `fork()` (Linux/CMRI only).

## New v2 tests (`model/pretrain/tests/integration/`, 43)

| File | What it proves | Kind |
|---|---|---|
| `test_v2_slurm_config.py` (21) | every `#SBATCH` header == config profile; superseded launchers declare no SLURM directives; Stage 04 = `gpu:h200:1`/250/500G/`cmri-gpu04`, continual = `gpu:h200:1`/16/200G, CPU stages request no GPU; 12 contradictory overrides refused (generic/T4/h200a GRES, T4 node, continual 250 CPUs or 500G, GPU on a CPU stage, …); runtime allocation guard; hand-submitted jobs refused; full 6-job chain with real `afterok`/`afterany` ids from a fake `sbatch`; dry run submits nothing; existing outputs require `--resume`; task-63 resume resubmits only `--array=63` with stride 64; continual submit refused without a ready library | LOCAL + MOCK |
| `test_v2_library_pipeline.py` (14) | 15,241,216 combinations → 305 chunks, task 63 = chunks 63/127/191/255, every chunk exactly once; zero-chunk task exits 0; resubmitting one task keeps other receipts; 8-process config-lock race (3 rounds) never sees a partial file; legacy empty lock waited for; pool library complete/ready/production-shaped (10 slots, STORE_2D=0); pool shards record-identical to array-mode shards; resume rebuilds only broken shards; exclusive lock refuses a second writer; deadline stop → exit 3, stage 05 fails closed with resubmit list; fallback audit catches a 2D slot posing as 3D; ready receipt invalidated by changed artefacts; real `04_conformers_pool.sh` dry run | LOCAL |
| `test_v2_continual_integration.py` (6) | real `check_continual_data.py --verify-hashes` accepts general stand-in + v2 library; actual `unimol_contrastive_continual` + `MergedSampledLMDBDataset` + collater give 2B-sequence batches with independent views, correct coord/distance/edge shapes, no out-of-vocab tokens, mixed sources; valid split uses only lipid valid shards (no leakage); one forward/backward with finite losses; `bin/heart continual` dry run + mocked submit (exact flags/exports, smoke variant); checkpoint comparison tool read-only and strict | LOCAL + MOCK |
| `test_v2_general_baseline.py` (3) | protected manifest covers the general launcher/helpers/task/model/loss/notebooks; 69 files byte-identical to `73a5f9d`; `git diff 73a5f9d` touches no protected file | LOCAL |

Upstream tests adapted (continual-specific, allowed): `test_continual_scripts.py::test_cpu_scripts_request_no_gpu_and_need_confirmation`
(stage 05 now 16 CPUs) and `test_review_fixes.py::_launcher_env` (adds `HEART_V2_PROFILE=continual`, as `bin/heart` does).

## Static checks

| Check | Result |
|---|---|
| `bash -n` on all lipid/continual scripts, `bin/heart`, acceptance script | PASS |
| ShellCheck 0.10.0 (`-x -S warning`) | all v2/lipid scripts clean; continual runner has 1 warning (SC2034 `MEM_MON_PID`) identical to upstream |
| Clean clone of `v2/lipid-continual` from GitHub | `bin/heart check` PASS, `bin/heart baseline` PASS, `bin/heart` mode 100755 |
| Secret / binary scan of tracked files | no tokens/keys; no `.pt/.lmdb/.xlsx/.pkl/.npy/archives`; largest file 92 KB (notebook) |

## Not tested (PENDING_HPC)

Real general LMDBs and checkpoint, real lipid production data, SLURM itself (only mocked), H200/CUDA/fp16,
250-worker behaviour on `cmri-gpu04`, NFS locking semantics, the continual smoke and production runs.
