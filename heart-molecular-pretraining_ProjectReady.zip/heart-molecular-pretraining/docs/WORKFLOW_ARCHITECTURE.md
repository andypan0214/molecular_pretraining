# HEART v2 — workflow architecture

```text
 (FROZEN, done)                       (lipid library, CPU)                                  (H200)            (CPU, read-only)
 general pretraining ───────┐
 1M updates, H200            │   Excel ─01─> building blocks ─02 (x64)─> Ugi products ─03─> drop list
 checkpoint_best.pt ────────┤                                                    │
 ligand train/valid.lmdb ───┤                         03b: partition (1 read of the product stream)
 dict.txt ──────────────────┤                                                    │
                            │       04: one 250-CPU H200-node job, dynamic per-shard queue
                            │           (ETKDGv3 + MMFF, 10 3D slots, STORE_2D=0) -> ~3,050 shard LMDBs
                            │                                                    │ (afterany)
                            │       05: finalize (fail closed) -> splits -> validate (+fallback audit)
                            │           -> library_ready.json
                            │                                                    │
                            └──────> continual pretraining (1 H200, 16 CPUs, 200G) <── explicit user submit
                                     init: strict weights-only from checkpoint_best.pt (optimizer/LR/scaler/updates reset)
                                     200K updates, lr 2e-5, warmup 1000, wd 1e-4, data weights general 0.5 / lipid 1.0
                                     resume: ONLY from the continual run's checkpoint_last.pt
                                                     │
                                                     └──> evaluate --check: v2_compare_checkpoints.py (+ unchanged notebooks)
```

## Mandatory vs optional

| Step | Mandatory | Command | Gate before the next step |
|---|---|---|---|
| Clone v2 next to the old checkout | yes | `git clone … heart-molecular-pretraining-v2` | `bin/heart check` = PASS |
| Read-only acceptance | yes | `bash scripts/check_heart_hpc_readonly.sh` | G0–G4 no FAIL |
| Library 01→05 (or resume) | yes | `bin/heart library --resume --dry-run`, then `--submit` | `library_ready.json` valid (`bin/heart library --status` → stage 05 DONE, not SMOKE) |
| Pilot library (own dir) | optional | `bin/heart library --pilot 100 --dry-run` / `--submit` | pilot never usable for production (marked smoke) |
| Stage-04 CPU scaling benchmark | optional, recommended | see `HPC_INSTALL_AND_RECOVERY.md` §6 | decide `library.stage04_workers` |
| Real-data compatibility | yes | `bash scripts/check_heart_hpc_readonly.sh` (G5, G6) | PASS |
| Continual smoke (separate run dir) | strongly recommended | `bin/heart continual --smoke --submit` | smoke log: finite losses, checkpoint written, resume works |
| Continual production | yes | `bin/heart continual --submit` (repeat to resume) | `checkpoint_last.pt` reaches 200,000 updates |
| Evaluation | yes | `bin/heart evaluate --check` | names/shapes identical, nonzero drift |

## Which component owns what

| Concern | Single owner |
|---|---|
| SLURM resources, paths, library/continual settings | `config/heart_v2.yaml` |
| Rendering/submitting sbatch, dependencies, job-id log | `model/pretrain/heart_v2/{slurm,cli}.py` (`bin/heart`) |
| Allocation check inside every job | `model/pretrain/heart_v2/guard.py` |
| Chemistry, enumeration, dedup, conformers, LMDB format | `model/pretrain/lipid_library/` (unchanged science) |
| Stage-04 scheduling | `lipid_library/stage04_pool.py` (+ `dirlock.py`) |
| "Library usable for training" | `lipid_library/ready.py` (`library_ready.json`) |
| Continual training run | `scripts/continual_pretrain_heart-h200.sh` (+ continual tools) |
| Frozen general baseline | upstream files + `config/general_baseline_manifest.json` |

## Failure and restart semantics

* **02**: a failed array task leaves other chunks intact; `--resume` resubmits only the task ids of missing
  chunks (stride 64 kept); stage 03 refuses an incomplete enumeration.
* **04**: SIGUSR1 (45 min before the limit) or SIGTERM stops new shards; a killed shard leaves no receipt and is
  rebuilt; finished shards are hash-verified and skipped on the next submission (`--resume`). Exit 3 =
  incomplete.
* **05**: always runs after 04 (`afterany`); fails closed (no manifest/ready receipt) and writes
  `finalize_report.json` with the missing shards.
* **continual**: `--stop-time-hours` saves before the SLURM limit; resubmitting the same command resumes from
  the continual `checkpoint_last.pt` with optimizer/scheduler/update counters; changed science or lipid splits
  are refused.
