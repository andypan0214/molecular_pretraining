# General pretraining baseline integrity (FROZEN)

The completed general pretraining is copied unchanged from the upstream repository and is **not** a v2
development target. Every file tracked at the pinned upstream commit, except the lipid/continual files that v2
may change, is listed below with its git blob SHA-1 at that commit.

* Upstream: `https://github.com/andypan0214/heart-molecular-pretraining` @ `73a5f9d4a624a37dfad0f943093187af06bae5e3` (tag `upstream-baseline-73a5f9d` in this repository)
* Protected files: **69**; modifiable patterns: `README.md`, `.gitignore`, `model/pretrain/lipid_library/*`, `model/pretrain/scripts/lipid_library/*`, `model/pretrain/scripts/continual_pretrain_heart-h200.sh`, `model/pretrain/tools/check_continual_data.py`, `model/pretrain/tools/check_continual_registry.py`, `model/pretrain/tools/check_continual_stage.py`, `model/pretrain/tools/init_continual_checkpoint.py`, `model/pretrain/configs/continual_pretrain.yaml`, `model/pretrain/README_CONTINUAL.md`, `model/pretrain/CONTINUAL_PRETRAIN_CHANGE_REPORT.md`, `model/unimol/tasks/unimol_contrastive_continual.py`, `model/unimol/data/merged_sampling_dataset.py`, `model/pretrain/tests/test_continual_loader.py`, `model/pretrain/tests/test_continual_scripts.py`, `model/pretrain/tests/test_lipid_pipeline.py`, `model/pretrain/tests/test_ugi_reaction.py`, `model/pretrain/tests/test_review_fixes.py`, `model/pretrain/tests/test_v2_review_fixes.py`, `model/pretrain/tests/lipid_fixtures.py`
* Machine-readable manifest: [`config/general_baseline_manifest.json`](../config/general_baseline_manifest.json)
* Verify on any checkout (no git needed): `bin/heart baseline` (exit 1 on any difference); tests:
  `model/pretrain/tests/integration/test_v2_general_baseline.py` (also checks `git diff 73a5f9d` touches no protected file).

## Current production-directory migration (2026-11-16)

The previously completed general scientific training remains unchanged. To make
all *future* smoke/full/H200/general launchers use **Home code + Project data**, a
small set of baseline-protected files necessarily changed **paths, Slurm log
headers, related examples, and comments only**. The original upstream hashes
are retained in `config/general_baseline_manifest.json`.

`approved_path_migrations` contains separate SHA-1s of the exact new versions.
`bin/heart baseline` reports these files as `path_migrated`, **NOT** as
byte-identical upstream files. Any extra unexpected edit fails the verification.
The original architecture, loss, optimizer, noise, and training hyperparameters
were NOT changed; existing checkpoints are not touched.

The original blanket statements below describe the *pre-migration historical*
state (2026-11-07), not the current deployment. See the current README and
migration report for live paths and statuses.

## Latest verification

| Check | Result |
|---|---|
| Protected files byte-identical (git blob SHA-1) | **PASS** (69 files, 0 modified, 0 missing) |
| Files equal only after CRLF->LF (Windows checkout of files without an eol rule) | `.gitattributes`, `model/unimol/LICENSE.LUMI-lab`, `model/unimol/LICENSE.Uni-Mol` |
| Verified | 2026-11-07 on the v2 development checkout (Windows); re-run on CMRI with `bin/heart baseline` |

Nothing in the general training path was edited, optimised, re-run or re-configured: the general launcher,
`heart_lib.sh`, `unimol_contrastive` task/model/loss, shared data transforms, `dict.txt` handling, configs, general
tools/tests and the evaluation notebooks are byte-identical. New v2 code only *reads* them (e.g. `lipid_lib.sh`
sources `heart_lib.sh`; the continual task subclasses `unimol_contrastive`; the continual runner calls the
general `check_resume_args.py`). No `BLOCKED_GENERAL_FREEZE` issue arose.

## Protected files

| File | git blob SHA-1 @ 73a5f9d |
|---|---|
| `.gitattributes` | `51cbb123ba8175be2ef4756eb8ab44245c7049c8` |
| `model/HEART_H200_checkpoint_best_embedding_evaluation.ipynb` | `ea11aa2fbb051f7e7c858ddcd4f5b62f48dc2cb3` |
| `model/HEART_best_checkpoint_embedding_evaluation.ipynb` | `74fc1e1dc90f0c7f1a71b5e9080e88984e2237e7` |
| `model/pretrain/IMPLEMENTATION_MAP.md` | `d0051ea65b8c6049855888f2fcbf3d545fce23c6` |
| `model/pretrain/IMPLEMENTATION_REPORT.md` | `f14ead362a72838e32eea59962739765bede1f46` |
| `model/pretrain/README_HEART.md` | `c6849d921d35fb1471732fb588ad70be1e458739` |
| `model/pretrain/configs/full_pretrain.yaml` | `73465c30f3b0c7bdcaa0e16615107fcbc9adbafa` |
| `model/pretrain/configs/pilot.yaml` | `b63b8b432df8b27b23d5c52a13dc2344584a13cf` |
| `model/pretrain/notebooks/HEART_HPC_Validation.ipynb` | `27d94cb3aa766698b93676a52f5bd1d22fbfb705` |
| `model/pretrain/requirements-heart.txt` | `ae4a00763e604fe26a4f2126581a414dc368f900` |
| `model/pretrain/scripts/check_heart_env.sh` | `1268acefe8b156031e233da8b080e1bbab93abf0` |
| `model/pretrain/scripts/heart_lib.sh` | `66ca91bbf50144e2ec2009819c25bce24db84275` |
| `model/pretrain/scripts/pretrain_heart-h200.sh` | `e24acd3a7eb02899250241735f55d1c780035d74` |
| `model/pretrain/scripts/pretrain_heart.sh` | `9347d107bd99ba92dd1d5340bb1c173e20278d0c` |
| `model/pretrain/scripts/pretrain_smoke.sh` | `864fa9cce9da7fbaef8a1739265e701c22b59b47` |
| `model/pretrain/tests/conftest.py` | `6790c5b5eb76077b0ddf331396128da05fa43294` |
| `model/pretrain/tests/fixtures/dict.txt` | `4130c254b4da592338b43298b49120a561dfae60` |
| `model/pretrain/tests/run_notebook_cells.py` | `138d225409753d3e941fc7927427b8d097da21a8` |
| `model/pretrain/tests/test_add_2d_conformer.py` | `63f5bdb53a6f81245bec10d5dae929e5151ab8b1` |
| `model/pretrain/tests/test_data_pipeline.py` | `0f97111ac5c29491b997f864750ff208c8050fc8` |
| `model/pretrain/tests/test_env_tools.py` | `d680a23e1d535c7802ec2416cf38b72b3e73a1a0` |
| `model/pretrain/tests/test_fixture_data.py` | `ec960ac3a02a45211575696e25796a24e2132756` |
| `model/pretrain/tests/test_inspect_lmdb.py` | `6c39e16a35396ad786cdec934abd0d892bf474bd` |
| `model/pretrain/tests/test_launcher.py` | `5c2d76fc681028fc1301035750165c6198de6b3d` |
| `model/pretrain/tests/test_lmdb_workers.py` | `af515300497092de836ad9a0e2a08e22a56be929` |
| `model/pretrain/tests/test_model_loss.py` | `b8d04557ff5553fc5640453b9bd00a1e38216c5e` |
| `model/pretrain/tests/test_notebook.py` | `e13860d553e8cbaa970838a9c830b37268869e77` |
| `model/pretrain/tests/test_registry.py` | `4ede475b5b28de7c0705bfe27d9318008579b38a` |
| `model/pretrain/tests/test_scripts.py` | `a177f10b9b58242437f856ff74c43f18e1050172` |
| `model/pretrain/tests/test_unicore_train_e2e.py` | `e43c73a9c61cdf118db5f77b3000feeebaf86318` |
| `model/pretrain/tests/unicore_train_entry.py` | `513afee7954cf75be7c1f31d440498fcd2c13db8` |
| `model/pretrain/tools/check_registry.py` | `8753a1c9793d97b1b144a1b15bc58c1b9879ed10` |
| `model/pretrain/tools/check_resume_args.py` | `2227cc80061f7497f34754efa8815200f2a5a1d0` |
| `model/pretrain/tools/heart_env_check.py` | `fca7b3eb6e61c3a8d03f4ebc10ae69ee9c564556` |
| `model/pretrain/tools/inspect_real_lmdb.py` | `1f0d8f39116ac03e5e5029f475ee0e7e4f0e16c1` |
| `model/pretrain/tools/make_fixture_lmdb.py` | `b1d8f8edd3296692ff9668839e651af0bf6a800e` |
| `model/pretrain/tools/scan_lmdb_smiles.py` | `27e8ef07cb9d7225a94e5068cc9da8140363c9ce` |
| `model/pretrain/tools/stop_time_hours.py` | `14e894a0687e84cb465e7998dce890e4e42a4661` |
| `model/pretrain/tools/summarize_log.py` | `ccc00da2fa746768423bdf7b98a22a9ec83add43` |
| `model/pretrain/tools/verify_checkpoint.py` | `7e24c90d0a518d5a55b62467c2594ea961a1a5f8` |
| `model/pretrain/tools/yaml_to_env.py` | `73a5f2b702787ab161ccf5f2c24af92f5815aad0` |
| `model/unimol/LICENSE.LUMI-lab` | `f288702d2fa16d3cdf0035b15a9fcbc552cd88e7` |
| `model/unimol/LICENSE.Uni-Mol` | `1781bf281af9c1bef9beeb0a0c12072f741b3381` |
| `model/unimol/THIRD_PARTY_NOTICES.md` | `3bd337a3d82cd8ef2472a10c32427a830be89546` |
| `model/unimol/__init__.py` | `42035d8411a5a06aa074e457d5fc7538aeed6a0a` |
| `model/unimol/data/__init__.py` | `848d97825658cf04bb0ce89c295b4a0abc104149` |
| `model/unimol/data/add_2d_conformer_dataset.py` | `7da4a103596f79c130d78c64b7d1ebd2ce2784d1` |
| `model/unimol/data/atom_type_dataset.py` | `ee3c5d86a5a5b3fb945836f2aeedad4f89502a96` |
| `model/unimol/data/conformer_sample_dataset.py` | `804a18012a1394d953364e99ba8941724d4015aa` |
| `model/unimol/data/coord_pad_dataset.py` | `3cbfcc87925a89cd6860b7ff5ddb5b1afba0f582` |
| `model/unimol/data/cropping_dataset.py` | `511b30446556ce19a630bbac4d02eb83d1240de5` |
| `model/unimol/data/data_utils.py` | `53111b654c91785e5fa1e6e682f8020aef0aed5c` |
| `model/unimol/data/distance_dataset.py` | `adcefc08c27a9759026a4541721789f33d609173` |
| `model/unimol/data/from_str_dataset.py` | `bc72deb41a7dbeb52ea6e47f18fa35d305f12da5` |
| `model/unimol/data/key_dataset.py` | `c241374e474a7c0993f778e81d939ae794460677` |
| `model/unimol/data/lmdb_dataset.py` | `1abe7fc533826a72cbbbaa57695601370b09f88f` |
| `model/unimol/data/mask_points_dataset.py` | `c2399a80f5b54f9bc5bb939a264335c60e7c2694` |
| `model/unimol/data/normalize_dataset.py` | `836f77daf53ea8e061f61d67dfabae2ecda02165` |
| `model/unimol/data/prepend_and_append_2d_dataset.py` | `0fda0688ba7e623790ff4db0eed7726bd8e2d6f0` |
| `model/unimol/data/remove_hydrogen_dataset.py` | `787b9f1a38402ac96c74184f03d34dede1f4f97d` |
| `model/unimol/data/tta_dataset.py` | `a28c31e9dd9b959b1d64beefa95c2c6559c45cc0` |
| `model/unimol/losses/__init__.py` | `dcf6c62a83aedf027719b8930ca2cacff858f802` |
| `model/unimol/losses/unimol_contrastive.py` | `4606f14078f568f373cd5ce8d5c27a387dceada0` |
| `model/unimol/models/__init__.py` | `33c257701e8f1d8420d006cce15bb6b69dc0451e` |
| `model/unimol/models/transformer_encoder_with_pair.py` | `78f3852a068085941a3429fbe5d050a9dde5716c` |
| `model/unimol/models/unimol_contrastive.py` | `c2a5ebddc916b9ffc11ab71c4d6a6ac1d3e2bc87` |
| `model/unimol/tasks/__init__.py` | `646cddbea500fc206c103455a419886dcbc50014` |
| `model/unimol/tasks/unimol_contrastive.py` | `5e008fcdc29dde42fd8043e3d061d44cbfd3af4b` |
| `runs/slurm/.gitkeep` | `e69de29bb2d1d6434b8b29ae775ad8c2e48c5391` |
