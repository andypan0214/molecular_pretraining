# HPC deployment and safe recovery — Home code / Project data

**Current state (2026-11-16):** The previously built Ugi-4CR library has completed
Stages 01–04 (3,049 shards). Stage 05 generated manifests and split metadata but
**FAILED** its production quality gate (2D fallback criteria). No 3D filtering
policy is yet validated. Continual training has **not** begun.

## 1. Code and data directories

- **Home code (new production checkout)**: `/home/ypan/heart_liver/model_train/heart-molecular-pretraining`
- **Old `-v2` checkout**: preserve temporarily for rollback, no automatic deletion
- **General LMDBs**: `/project/yli4/ypan/UniMolReference/ligand_data/ligands`
- **Lipid library**: `/project/yli4/ypan/lipid_library`
- **General checkpoint**: `/project/yli4/ypan/runs/h200/full/heart-h200-b448-v1/checkpoint_best.pt`
- **Training outputs**: `/project/yli4/ypan/runs/h200/{smoke,full,continual}/`
- **Training Slurm logs**: `/project/yli4/ypan/runs/h200/slurm/`
- **Lipid stage logs (separate)**: `/project/yli4/ypan/lipid_library/logs/`
- **Conda environment**: `/home/ypan/.conda/envs/heart_gpu`
- **Uni-Core source**: `/home/ypan/heart_liver/model_train/third_party/Uni-Core`

The internal `heart_v2` package, `heart_v2.yaml`, `HEART_V2_*` environment
variables are historical software API identifiers. The directory itself is
`heart-molecular-pretraining` (no `-v2` suffix).

## 2. Install without GitHub (preserve rollback)

Upload `heart-molecular-pretraining_ProjectReady.zip` to your HPC Home directory.

```bash
cd /home/ypan/heart_liver/model_train
test ! -e heart-molecular-pretraining || { echo 'Destination exists. Stop, do not overwrite.'; exit 1; }
unzip ~/heart-molecular-pretraining_ProjectReady.zip
mkdir -p /project/yli4/ypan/runs/h200/slurm
cd heart-molecular-pretraining
```

## 3. Read-only acceptance checks

```bash
bin/heart baseline                 # protected upstream hashes with explicit path-only exceptions
bin/heart check                    # config, Slurm header/profile consistency, paths
bin/heart render continual         # print Slurm command; DO NOT submit
python scripts/verify_project_layout.py
```

The four-test Notebook is at
`model/pretrain/notebooks/Ugi_Conformer_4Tests_HomeCode_ProjectData.ipynb`.
The Notebook reads Home code and Project data; it does not run the completed
Stage 01–04 library generation.

## 4. Safeguards and pending science decisions

- **DO NOT** run `bin/heart library --resume --submit` to test the path migration.
  The library already has 3,049 completed shards. Do not regenerate them.
- The original Stage 05 `quality_report.json` remains **FAILED**. Do not simply
  lower quality standards or fabricate `library_ready.json`.
- **DO NOT** run `bin/heart continual --submit` until the four conformer tests
  validate a 3D-sampling/filtering policy and updated Stage 05/06 readiness.
- The `-v2` checkout is preserved until the new deployment passes acceptance.
- No existing LMDB, checkpoint, historical receipts, or lock fingerprints are
  altered by this directory migration. Path relocation does not cure QC failure.

## 5. Recovery

If any path/profile/baseline check fails, **stop**. Keep the `-v2` checkout and
all Project data intact. Restore only the new code directory after investigating;
never clean Project storage or resubmit Stage 04 for a path problem.

Completed old jobs are historical evidence. Their Slurm logs are not moved or
rewritten by this code package. Only *future* stdout/stderr uses the new log path.
