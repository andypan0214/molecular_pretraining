# HEART v2 — code audit (lipid library, continual training, integration)

Audited tree: upstream `andypan0214/heart-molecular-pretraining` **main @ `73a5f9d4a624a37dfad0f943093187af06bae5e3`**
(2026-11-07; 7 commits newer than the local checkout the user had). The general pretraining was **not**
reviewed for improvement (frozen by request); it was read only to define the integration contracts.
The unmerged upstream branch `perf/lipid-library-hpc-optimization` (`51c9f6a`, based on the older
`c871f59`) was inspected but **not merged** (see §6).

## 1. Scope classification

* **Frozen (69 files, byte-identical to upstream):** everything tracked at `73a5f9d` except the
  lipid/continual files listed in `model/pretrain/heart_v2/baseline.py::MODIFIABLE`. Includes
  `scripts/pretrain_heart-h200.sh`, `pretrain_heart.sh`, `pretrain_smoke.sh`, `heart_lib.sh`,
  `check_heart_env.sh`, `configs/{pilot,full_pretrain}.yaml`, all of `model/unimol/` except the continual
  task and the mixed dataset, the general tools (`check_resume_args.py`, `verify_checkpoint.py`,
  `stop_time_hours.py`, …), the general tests and `conftest.py`, both evaluation notebooks, licences/notices.
  Hashes: [`GENERAL_BASELINE_INTEGRITY.md`](GENERAL_BASELINE_INTEGRITY.md).
* **Modifiable:** `lipid_library/*`, `scripts/lipid_library/*`, `scripts/continual_pretrain_heart-h200.sh`,
  the four continual tools, `unimol/tasks/unimol_contrastive_continual.py`,
  `unimol/data/merged_sampling_dataset.py`, `configs/continual_pretrain.yaml`, continual READMEs,
  lipid/continual tests, top-level `README.md`, `.gitignore`.
* **New in v2:** `config/heart_v2.yaml`, `config/general_baseline_manifest.json`, `bin/heart`,
  `model/pretrain/heart_v2/`, `lipid_library/{stage04_pool,dirlock,ready}.py`,
  `scripts/lipid_library/04_conformers_pool.sh`, `tools/v2_compare_checkpoints.py`,
  `scripts/check_heart_hpc_readonly.sh`, `model/pretrain/tests/integration/`, `docs/`.

## 2. Import / execution dependency diagram (as implemented)

```text
bin/heart ──> python -m heart_v2 (cwd model/pretrain)
   heart_v2.config  <- config/heart_v2.yaml (+ --set, HEART_V2_CONFIG)
   heart_v2.slurm   -> sbatch argv (the ONLY resource source) ; parse/compare #SBATCH headers
   heart_v2.status  -> reads receipts of stages 01-05 (no hashing) ; lipid_library.ready.verify
   heart_v2.cli     -> sbatch --parsable ... <stage script>   (only with --submit; log -> <root>/jobs/)
   heart_v2.baseline-> config/general_baseline_manifest.json (git blob SHA-1 per frozen file)

SLURM job  scripts/lipid_library/0X_*.sh
   -> lipid_lib.sh  -> heart_lib.sh (FROZEN, used read-only: repo discovery, conda activation, die/log)
                    -> python -m heart_v2.guard --profile <p>   (allocation == config, else exit 1)
   01 -> lipid_library.building_blocks (io_utils.read_xlsx_rows, ugi) ; review_products
   02 -> lipid_library.enumerate_library (ugi, provenance.lock_config, io_utils.AtomicGzCsvWriter)
   03 -> enumerate_library --check-complete ; lipid_library.dedup (heapq merge of sorted chunks)
   03b-> lipid_library.lmdb_writer --partition (+ --plan)
   04 -> lipid_library.stage04_pool -> [spawned worker per shard] lmdb_writer.write_shard
                                        -> conformers.smi2coords_pretrain (RDKit ETKDGv3 + MMFF)
         (fallback: 04_conformers_array.sh -> lmdb_writer --shard i --num-shards 1000)
   05 -> lmdb_writer --finalize -> splits -> validate_lmdb --audit-fallback -> ready write

SLURM job  scripts/continual_pretrain_heart-h200.sh
   -> heart_lib.sh (FROZEN) ; heart_v2.guard --profile continual ; lipid_library.ready verify
   -> tools/check_continual_data.py (real general + lipid LMDBs, read-only)
   -> tools/init_continual_checkpoint.py (strict names/shapes/dict; weights-only init file)
   -> tools/check_resume_args.py (FROZEN general tool) + tools/check_continual_stage.py on resume
   -> unicore-train --user-dir ./unimol --task unimol_contrastive_continual
        unimol/tasks/unimol_contrastive_continual.py  (subclass of the FROZEN unimol_contrastive task)
        unimol/data/merged_sampling_dataset.py        (bounded LRU of LMDB envs)
        FROZEN: models/unimol_contrastive, losses/unimol_contrastive, data/* transforms, dict.txt
```

## 3. Data contracts

| Contract | General baseline (frozen) | Lipid library output | Continual training input |
|---|---|---|---|
| LMDB layout | `train.lmdb`, `valid.lmdb`, `subdir=False` | `shard-NNNNN/train.lmdb` (compacted), `subdir=False` | general `train/valid.lmdb` + lipid shards from `splits.json` |
| Keys | ASCII integers `b'0'..b'N-1'` | same, contiguous per shard (receipt `key_convention`) | `MergedSampledLMDBDataset` refuses non-integer keys |
| Record | pickle `{"smi","atoms","coordinates"}` | exactly those 3 fields; `atoms` = `AddHs` order; coordinates float32 `(n_atoms,3)` | read unchanged; 2D slot added at training time (`Add2DConformerDataset`) |
| Stored slots | 10 (audited policy: `STORE_2D=0`) | 10 3D slots, 2D fill-in only when <10 embeddings succeed (counted in `records.csv.gz`, audited in stage 05) | `--require-equal-coordinate-slots`; preflight compares slot profiles |
| Vocabulary | `dict.txt` of the general data | atoms outside it are skipped+reported, never mapped | the general `dict.txt` only |
| Atom limit | `--max-atoms 256` after `--only-polar 0` (heavy atoms) | records that would be cropped are skipped (reason recorded) | identical args |
| Completeness | n/a | `manifest.json` only after fail-closed finalize; `splits.json`; `validation.json`; **`library_ready.json`** (v2) | `bin/heart` and the runner (`HEART_REQUIRE_LIBRARY_READY=1`) require a valid ready receipt |
| Checkpoint | `checkpoint_best.pt` (task `unimol_contrastive`, 1M updates) — read-only | n/a | weights-only `continual_init.pt` (strict); resume only from the continual `checkpoint_last.pt` |
| Evaluation | historical notebooks (unchanged) | n/a | `tools/v2_compare_checkpoints.py` (read-only drift/shape report) |

## 4. Findings and dispositions

Severity: **P0** would run wrong code/resources or corrupt/mix outputs; **P1** correctness/robustness
risk; **P2** performance/usability; **I** information only.

| # | Sev | Finding (evidence) | Disposition |
|---|---|---|---|
| F1 | P0 | Every lipid stage script did `[ -f "$here/lipid_lib.sh" ] \|\| here=/home/ypan/.../heart-molecular-pretraining/...`. Under `sbatch` the script body runs from the SLURM spool copy, so `$here` is the spool dir and **every job ran the OLD clone's code** (a v2 clone would silently be ignored). | Fixed: `HEART_REPO` (exported by `bin/heart`) or the `scontrol show job` command path; refuses if neither resolves. |
| F2 | P0 | `continual_pretrain_heart-h200.sh` hard-coded `HEART_REPO=/home/ypan/.../heart-molecular-pretraining` (outside the local-test hook): the v2 runner would train with the old repository's task/data code and write into the old `runs/`. | Fixed: repo derived from the submitted script path; a different exported `HEART_REPO` is refused; output root from config (`.../heart-molecular-pretraining-v2/runs/h200`). |
| F3 | P0 | Competing resource sources: `04_conformers_250cpu.sbatch` header `--gres=gpu:1` (generic) vs `submit_lipid_library_production_now.sh` `--gres=gpu:h200:1` vs `submit_lipid_library_250cpu.sh` `--test-only ... --gres=gpu:1`; CPU/RAM duplicated in three files. | Replaced by `config/heart_v2.yaml` + `bin/heart`; the four v1 launchers are stubs with no `#SBATCH` (exit 2 with the new command). Headers == config is a test; jobs check their allocation (`heart_v2.guard`). |
| F4 | P1 | `provenance.lock_config` created the lock with `O_EXCL` and wrote the JSON afterwards; 64 stage-02 tasks start together, so a task could `json.load` an empty/partial file and die. | Fixed: payload written to a temp file and published with `os.link` (atomic, exclusive, NFS-safe); readers retry on legacy partial files. Regression test with 8 concurrent processes. **Not proven to be the task-63 cause** (that failure was exit 13, a JSON error would exit 1; §5). |
| F5 | P2 | v1 250-CPU stage 04: `seq 0 999 \| xargs -P 250 lmdb_writer --shard i` = 1000 work units of 3–4 shards; tail ≈ one task (3–4 × 5,000 molecules × measured s/molecule); every process re-did config/geometry locking. | `stage04_pool`: one shard per spawned process (`max_tasks_per_child=1`), unverified shards first, locks taken once, deadline gating, `USR1`/`TERM` handling, progress JSON, disk preflight. Same `write_shard`, same fingerprints, same receipts (test proves identical records vs array mode). |
| F6 | P2 | Each array task loaded the entire dedup drop set although only the partition needs it. | Not loaded in `--shard`/pool mode. |
| F7 | P1 | Stage 05 left a valid-looking `splits.json` when record validation failed afterwards; the runner keyed on `splits.json`. | `library_ready.json` (hash chain manifest → splits → validation, all passed); removed on any failure; required by `bin/heart continual` and by the runner. |
| F8 | P1 | Validation counted slots but could not tell a 2D fill-in from a real 3D conformer. | `validate_lmdb --audit-fallback`: flat-slot count of every checked record must equal `records.csv.gz` `n_2d_filled` (+1 if a stored 2D slot). |
| F9 | P2 | Finalize hashed ~0.3–0.4 TB of shard LMDBs single-threaded; validation single process. | Thread pool for sha256 (hashlib releases the GIL); process pool for validation (`stage05_workers: 16`). |
| F10 | P2 | Mixed loader keeps ≤ 64 LMDB envs (LRU) per process; with ~3,050 lipid shards and random sampling almost every lipid read re-opens an env. | `MAX_OPEN_LMDB_ENVS=auto` option (all shards if `ulimit -n` allows). Default stays 64 until an H200 throughput comparison is done (**PENDING_HPC**). |
| F11 | I | `conformers.py`: `MMFFOptimizeMolecule`'s non-convergence return value is not checked (default 200 iterations), and in the heavy-atom retry path the `EmbedMolecule` result is not checked (a failure is then counted as `mmff_failed`). Both match LUMI's reference behaviour; geometry is kept, not dropped. | Unchanged (would change the conformer policy fingerprint). Documented; a counter-only change is listed as optional. |
| F12 | P2 | No disk-space check for an output of order 10^11 bytes (15.2M records × ~26 kB assumed). | Pool preflight: measured bytes/record from finished shards (else the assumption) × 1.15 vs free space. |
| F13 | P1 | SLURM fails a job whose `--output` directory does not exist. | `bin/heart --submit` creates the log directories first. |
| F14 | I | `lipid_lib.sh` still reuses the frozen `heart_lib.sh` (activation, repo discovery). | Kept read-only; no edit to the shared helper. |

Not changed on purpose: Ugi chemistry/policy, enumeration indexing, chunk receipts, dedup policy (lowest
combination index kept), partition layout, conformer settings (ETKDGv3, MMFF, 10 slots, 15 tries,
`maxIterations` 4000, seed start 0), `STORE_2D=0`, split method, the continual task/loader science and all
continual hyperparameters (lr 2e-5, warmup 1000, wd 1e-4, 200K updates, weights 0.5/1.0, batch 448).

## 5. Stage 02 task 63 (`1013343_63`, `FAILED 13:0` after ~1 s)

Facts from the code: 15,241,216 combinations / 50,000 = **305 chunks** (last chunk 41,216 rows, owned by
task 48). Task 63 owns chunks 63, 127, 191, 255 — ordinary full chunks; there is no boundary at task 63.
Tasks with zero chunks would exit 0 (tested). An exit after ~1 s is earlier than an RDKit import plus a
single chunk would take, i.e. the failure happened in the shell prelude or at Python start-up.

Exit status 13 is not produced by any code path in the lipid scripts (`die` → 1, Python
`SystemExit("…")` → 1, uncaught exception → 1, argparse → 2). Candidate causes, **none confirmed**:
an environment/module/conda bootstrap failure on that node (sourcing `lmod.sh`/`conda.sh` under `set -e`
propagates their status), a file-system/permission error on the log or output path of that task, or a node
problem. The F4 race would have produced exit 1 with a `JSONDecodeError` traceback.

**Status: `ROOT_CAUSE_NOT_CONFIRMED`.** Needed evidence: `sacct -j 1013343_63 --format=JobID,State,ExitCode,NodeList,Start,End`
and `lipid_library/logs/lipid-02-enum-1013343_63.{out,err}` (G7 of `scripts/check_heart_hpc_readonly.sh`
prints both). Recovery does not depend on the cause: `bin/heart library --resume --dry-run` lists exactly the
missing chunks and resubmits `--array=63` with the original stride 64; completed chunks are verified and
skipped, never regenerated.

## 6. Stage boundaries — decision

All six stages are kept. Merging was rejected where it would cost evidence or resources:

* **03b stays separate** from 04: it is a single-threaded ~10^7-row stream read that would otherwise idle
  249 of the 250 reserved CPUs; its fingerprinted partition is what lets every stage-04 worker verify its
  inputs independently.
* **04** changed from a 1,000-task stride to an in-allocation dynamic queue (F5). The stride (1000) is still
  locked so the array-mode fallback and stage 05's resubmit lists remain valid.
* **05** keeps finalize → splits → validation and adds the ready receipt (F7). It is chained `afterany` on 04
  so an incomplete 04 still yields a missing-shard report; it can never mark missing output complete.

Upstream branch `perf/lipid-library-hpc-optimization` (`51c9f6a`) implements a cross-job shard queue
(claim files, heartbeats, stale takeover) plus a CMRI benchmark harness. Not merged: it is based on an older
commit, unvalidated on CMRI, and the claim/takeover machinery is unnecessary when one exclusive allocation
owns the directory (v2 uses a kernel `flock` that disappears with the job). Its benchmark idea is kept as the
plan in `HPC_INSTALL_AND_RECOVERY.md` §6.

## 7. Hardening pass (PR #1 review, 2026-11-08)

| # | Review item | Finding | Fix | Regression tests (`tests/integration/test_v2_hardening.py` unless noted) |
|---|---|---|---|---|
| H1 | P0-1 general policy only stated in YAML/docs | Stage 04 would generate 0.4 TB under an unverified assumption about the general LMDB slot layout | `lipid_library/general_policy.py` measures the real `train/valid.lmdb` (read-only). Mandatory in `bin/heart library --submit` (any plan with stage 04) and inside `04_conformers_pool.sh`. Fails closed on a mismatch, on unreadable data or on a different `dict.txt` | `test_general_policy_measures_the_real_files`, `test_stage04_submission_refused_*`, `test_pool_job_itself_refuses_a_policy_mismatch` |
| H2 | P0-2 readiness relied on metadata hashes | A truncated, overwritten or bit-rotted shard with unchanged `manifest.json`/`splits.json` passed `ready verify` | `library_integrity.json`: size, mtime and a sampled digest per shard. Quick check at every continual call and job start. Full sha256 verification (stage 05, or the new `lipid_verify` job `06_verify_library.sh`) required within `full_verify_max_age_days` for submission | `test_quick_check_detects_*`, `test_unsampled_corruption_passes_quick_but_fails_full_verification`, `test_touched_shard_needs_full_verification_*`, `test_full_verification_age_limit`, `test_continual_submission_requires_intact_shards` |
| H3 | P1-3 config drift only warned | **Real bug found:** the job snapshot is JSON, and PyYAML reads JSON's `2e-05` as a *string*, so every job's config hash differed from the submission's. As a warning this was invisible; as fail-closed it would have blocked every job | `.json` snapshots are loaded with `json`. Drift, a missing `HEART_V2_CONFIG_SHA` or an edited snapshot now fail (guard + submission). Snapshots are written atomically and read-only | `test_json_snapshot_round_trip_keeps_the_hash`, `test_guard_fails_closed_on_configuration_drift`, `test_tampered_snapshot_is_refused_at_submission` |
| H4 | P1-4 `continual --check` read-only? | The dry run called the frozen `heart_check_save_dir` (creates `OUTPUT_ROOT`, touch-tests a probe file) and `mkdir`-ed `runs/.../continual` | In dry-run mode the same policy is checked without writing (nearest existing parent must be writable); `PYTHONDONTWRITEBYTECODE=1`; `SLURM_JOB_ID` dropped for a check | `test_continual_scripts.py::test_launcher_dry_run_checks_the_checkpoint_and_writes_nothing` (full tree snapshots before/after) |
| H5 | P1-4 acceptance diagnostics | Only a 40-line tail of the task-63 log was printed; the summary file held only the gate lines | `scripts/check_heart_hpc_readonly.sh` writes `~/heart_v2_acceptance/<time>/`: `full.log` (everything), `summary.txt`, `general_policy.json`, `library_status.json`, and `task63/` with sacct (`--long`), seff and **complete** copies of every task log | manual (bash -n, ShellCheck) |
| H6 | P1-5 Stage-05 criteria | No explicit production criteria; conformer-attempt failures were not recorded | `lipid_library/quality.py` + `library.quality` thresholds (`docs/LIBRARY_QUALITY_CRITERIA.md`). Shard receipts now also count ETKDG/MMFF attempts and the 3D-success / distinct-3D histograms (counters only; geometry and fingerprints unchanged). `library_ready.json` requires `quality_report.json` passed | `test_quality_report_accounts_for_everything`, `test_production_library_failing_a_criterion_gets_no_ready_receipt`, `test_quality_criteria_come_from_the_config` |
| H7 | P2-7 slots vs distinct conformers | Seeds 0 and 1 embed identically in RDKit, so 10 slots normally hold ≤ 9 distinct 3D conformers | Settings kept (LUMI-faithful). Documented, measured and reported | `test_seed_start_0_gives_fewer_distinct_conformers_than_slots` |
| H8 | P2-8 benchmark | Only a written plan | `bin/heart bench [--submit]`: 64/128/250 workers, ≤ 100k molecules each, production Stage 04 allocation, runs serialised. `python -m lipid_library.bench_report` reports throughput, CPU s/molecule, parallel efficiency, peak worker RSS and a full-library projection | `test_bench_dry_run_and_mocked_submission`, `test_bench_report_compares_worker_counts` |
| H9 | P2-9 GPU type detection | The guard read `SLURM_JOB_GPUS_TYPE` (not a SLURM variable) and `SLURM_TRES_PER_*`, so in practice the GPU type was never verified | Type from `scontrol show job -d` (`AllocTRES`/`TresPerNode`/`GRES`, e.g. `gres/gpu:h200=1`, `GRES=gpu:h200:1(IDX:0)`) and `nvidia-smi --query-gpu=name`; count from `SLURM_GPUS_ON_NODE`. Fails closed when unverifiable (explicit override `HEART_V2_ALLOW_UNVERIFIED_GPU_TYPE=1`) | `test_gpu_type_detection` (9 cases), `test_allocation_check_uses_the_detected_gpu_type` |

Preserved: the 15,241,216-combination space, 10 stored slots, `STORE_2D=0`, ETKDGv3/MMFF settings and `seed_start=0`, stages 04/05, the writer/enumeration fingerprints, checkpoint compatibility, all 200K continual settings, and the frozen general baseline (69 files).
