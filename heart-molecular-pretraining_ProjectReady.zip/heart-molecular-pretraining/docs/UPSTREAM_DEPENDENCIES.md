# Upstream dependencies, pins and licences

| Dependency | Pin | Used for | Where pinned |
|---|---|---|---|
| HEART v1 repository | `andypan0214/heart-molecular-pretraining` @ `73a5f9d4a624a37dfad0f943093187af06bae5e3` | complete starting tree; frozen general pretraining | tag `upstream-baseline-73a5f9d`, `config/general_baseline_manifest.json` |
| Uni-Core | `ace6fae1c8479a9751f2bb1e1d6e4047427bc134` | trainer (`unicore-train`), task/model registries | `config/heart_v2.yaml` `environment.unicore_commit`, `scripts/heart_lib.sh` |
| Uni-Mol data transforms | `90f52c4` (patched P1, P2, P5, P6) | `model/unimol/data/` (frozen) | `model/unimol/THIRD_PARTY_NOTICES.md` |
| LUMI-lab | `611e02b` | task/model/loss (frozen); lipid conformer policy and continual hyperparameters reproduced | notices; `lipid_library/conformers.py` docstring |
| Python env `heart_gpu` | Python 3.11, torch 2.2.2+cu121, numpy 1.26.4, lmdb 1.4.1, RDKit 2024.9.6, scipy 1.13.1, PyYAML 6 | everything | `model/pretrain/requirements-heart.txt` (frozen) |

Local test environment of this session (not CMRI): Windows 11, Python 3.11.7 venv, numpy 1.26.4,
lmdb 1.4.1, rdkit 2024.9.6, scipy 1.13.1, tokenizers 0.20.3, tensorboardX 2.6.2.2, PyYAML 6.0.2, pytest
8.3.3, torch 2.2.2+cpu, Uni-Core `ace6fae` source checkout on `PYTHONPATH` (its CUDA extensions are not
built; Uni-Core falls back to PyTorch ops).

RDKit version is part of every lipid configuration fingerprint (`provenance.runtime_versions`): a library
must be continued with the RDKit it was started with, or written to a new directory.

## Licences

* LUMI-lab-derived files (`model/unimol/tasks`, `models`, `losses`): GPL-3.0 — `model/unimol/LICENSE.LUMI-lab`.
* Uni-Mol-derived files (`model/unimol/data`): MIT — `model/unimol/LICENSE.Uni-Mol`.
* Uni-Core: MIT (dependency, not vendored).
* HEART-original files: no licence chosen yet (pending institutional review). The v2 repository is private.
* The LUMI virtual-library Excel sheet is private input data: it is git-ignored (`*.xlsx`) and is copied to
  `lipid_library/input/` on CMRI by the user.
