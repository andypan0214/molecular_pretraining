# HEART v2 — overnight progress log (2026-11-07)

Evidence types: **LOCAL** = executed in this session on Windows/CPU; **MOCK** = SLURM replaced by a fake
`sbatch` that records argv; **DOC** = written analysis; **PENDING_HPC** = needs CMRI.

| Phase | Task | Status | Evidence |
|---|---|---|---|
| 1 | Pin upstream `73a5f9d` (origin/main was 7 commits ahead of the local checkout); full tracked tree as starting point | DONE | v2 `main` = `73a5f9d`; tag `upstream-baseline-73a5f9d` |
| 1 | Private repo `andypan0214/heart-molecular-pretraining-v2` | DONE | created with `gh repo create --private` |
| 1 | Baseline test run of the unmodified upstream tree | DONE (LOCAL) | 362 passed, 2 skipped (fork-only) in the repo; 359 passed + 2 git-dependent failures on a `git archive` export (no `.git`) |
| 1 | `CODE_AUDIT.md`, `WORKFLOW_ARCHITECTURE.md`, protected-file hashes | DONE (DOC) | `docs/` |
| 2 | Stage 02 task 63 investigation | DONE: `ROOT_CAUSE_NOT_CONFIRMED` | chunk/task arithmetic tested; exit 13 not producible by the lipid code; evidence commands in G7 |
| 2 | Stage 02 start-up race (config lock) | FIXED (LOCAL) | atomic hard-link publish; 8-process race test |
| 2 | Safe resume (02 failed tasks only, 04 broken shards only) | DONE (LOCAL+MOCK) | `--resume` plan tests; pool resume test |
| 2 | Stage 04 audit/optimisation | DONE (LOCAL) | `stage04_pool.py`; identical records vs array mode |
| 2 | Stage 05 fail-closed + ready receipt + fallback audit | DONE (LOCAL) | tests in `test_v2_library_pipeline.py` |
| 3 | One config, two H200 profiles, guards | DONE (LOCAL+MOCK) | `test_v2_slurm_config.py` (21 tests) |
| 3 | `--dry-run/--status/--resume/--submit`, job-id log, config snapshot | DONE (MOCK) | same |
| 4 | v2 path fixes (old clone used under sbatch; continual runner hard-coded old repo) | FIXED (LOCAL) | `CODE_AUDIT.md` F1, F2 |
| 4 | Library → actual continual task/collator batch; checkpoint init/resume | DONE (LOCAL) | `test_v2_continual_integration.py`; upstream continual tests |
| 4 | Real-data read-only acceptance script | WRITTEN; run PENDING_HPC | `scripts/check_heart_hpc_readonly.sh` |
| 4 | Post-continual evaluation hook | DONE (LOCAL) | `tools/v2_compare_checkpoints.py`, `bin/heart evaluate --check` |
| 5 | `bash -n`, ShellCheck (0.10.0 wheel), full pytest, clean-clone check, secret/binary scan | DONE (LOCAL) | `docs/TEST_RESULTS.md` |
| 5 | Push incremental commits, PR, handoff | DONE | `docs/HANDOFF_FOR_CHATGPT.md` |

Not done by design (needs the user/HPC): any `sbatch`, the stage-04 CPU benchmark, the continual smoke run,
real-data gates G1–G7, the decision whether to merge the PR into `main`.
