#!/usr/bin/env python3
"""Verify project path migration. READ ONLY: no creates, deletes, or submissions."""
import os
import pathlib
import sys

CODE = pathlib.Path('/home/ypan/heart_liver/model_train/heart-molecular-pretraining')
PROJECT = pathlib.Path('/project/yli4/ypan')
RUNS = PROJECT / 'runs/h200'
LIBRARY = PROJECT / 'lipid_library'
REF = PROJECT / 'UniMolReference/ligand_data/ligands'


def main():
    problems = []
    checks = {
        'active code checkout': CODE / 'bin/heart',
        'project reference training LMDB': REF / 'train.lmdb',
        'project reference validation LMDB': REF / 'valid.lmdb',
        'project reference dictionary': REF / 'dict.txt',
        'project lipid manifest': LIBRARY / 'lmdb/manifest.json',
        'project lipid splits': LIBRARY / 'lmdb/splits.json',
        'project original QC report': LIBRARY / 'lmdb/quality_report.json',
        'project general checkpoint': RUNS / 'full/heart-h200-b448-v1/checkpoint_best.pt',
        'project slurm log directory': RUNS / 'slurm',
    }
    for label, path in checks.items():
        valid = path.is_file() if label != 'project slurm log directory' else path.is_dir()
        print(('PASS' if valid else 'MISSING') + ' | ' + label + ' | ' + str(path))
        if not valid: problems.append(label)
    if (RUNS/'slurm').is_dir() and not os.access(RUNS/'slurm', os.W_OK):
        problems.append('slurm log dir is not writable')
        print('FAIL | slurm log directory is not writable')
    # This checks only inventory, not dataset byte-integrity. Shards are read-only.
    shards = list((LIBRARY/'lmdb').glob('shard-*/shard.json'))
    print('INFO | shard receipts detected:', len(shards))
    if len(shards) != 3049:problems.append('expected 3049 shard receipts')
    print('NOTE | This does NOT validate LMDB hashes or resolve Stage 05 QC failure.')
    print('NOTE | No job has been submitted, and no dataset has been changed.')
    if problems:
        print('FAIL:', ', '.join(problems));return 1
    print('PASS | Project layout preflight');return 0


if __name__ == '__main__':
    raise SystemExit(main())
