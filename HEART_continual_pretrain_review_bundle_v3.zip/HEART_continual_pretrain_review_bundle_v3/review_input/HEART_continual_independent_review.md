# HEART × LUMI continual pretraining — Independent review (2026-11-04)

**Scope:** Static review of the uploaded `HEART_continual_pretrain_review_bundle.zip` (30 new repository files). All 36 manifest entries passed SHA-256 and byte-size verification. I did **not** run the project’s Windows/Uni-Core or H200 training tests. The test totals in Claude’s report remain third-party claims, not independently reproduced results.

## Decision
**Changes requested before GitHub commit/push or any full-scale HPC generation or H200 training.** The architecture is substantially implemented, and original tracked general-pretraining files were not included as modifications, but the following material issues remain.

## Required fixes

### P0 — prevent incomplete 15M dataset from being declared ready
- `pretrain/lipid_library/lmdb_writer.py::update_manifest()` simply enumerates *available* `shard.json` receipts; it does not confirm that every expected shard exists. `pretrain/scripts/lipid_library/05_finalize.sh` immediately builds splits and validates these available shards. A partial or failed array could therefore produce apparently usable `manifest.json` and `splits.json` missing large portions of the enumerated library.
- **Fix:** Derive the expected shard IDs/counts from completed product enumeration, dedup settings, and records-per-shard. Before finalization, require each expected ID, verified receipt hash, matching input-identity/config metadata, and count reconciliation. Fail closed on missing/duplicate IDs and incorrect coverage. Add an interrupted-array test.

### P0 — prevent stale outputs when inputs or processing options change
- `enumerate_library.py::chunk_is_complete()` validates chunk range and the old output hash, but not the building-block content, reaction-template version, stereochemistry policy, or generation options.
- `lmdb_writer.py::shard_is_complete()` validates only format, shard ID, and *its own* file hash. If SMILES products, dedup decisions, dictionary, seed-start, conformer settings, `--limit`, or other options change, old shards can be silently reused.
- **Fix:** Record and check input-file hashes and complete scientific configuration fingerprints for each stage/shard; use separate output namespace or explicitly fail on mismatches. Make any `--limit` smoke output impossible to reuse as a production-complete shard. Test changing Excel, reaction policy, `--seed-start`, `--limit`, and `--no-store-2d`.

### P1 — resolve the 2D conformer policy against the real general LMDB
- `conformers.py::smi2coords_pretrain()` stores 10 3D slots **plus one 2D** by default. `unimol_contrastive_continual.py::load_dataset()` wraps **both** lipid and general records in HEART `Add2DConformerDataset`, adding *another* 2D at training time. This gives lipid records 12 slots (not 11), and the real general records’ slot count is not yet verified.
- `--require-equal-coordinate-slots` exists but the H200 launcher does **not** pass it, so mismatch merely warns. This is a scientific data-distribution mismatch, not necessarily a runtime error.
- **Fix:** Inspect the actual general `train.lmdb` and `valid.lmdb` (multiple representative records); explicitly choose the LUMI- and HEART-compatible scheme, preferably 10 stored 3D plus HEART-generated 2D **if** general records follow that convention. Make matching slot policy a hard launch preflight, and test that both sources produce the intended number and 3D/2D probabilities.

### P1 — correct 48-hour CPU-array job sizing
- `04_conformers_array.sh` defaults to `#SBATCH --array=0-99`, `RECORDS_PER_SHARD=20000`, and `--time=2-00:00:00`. At the script’s own estimate of 1.9 seconds/molecule, ~15.24M products /100 tasks ≈ 152K molecules per task = ~80 CPU hours per task, exceeding 48 hours. The script’s comment recommends using 200 tasks, but its default is 100.
- **Fix:** Choose defaults conservatively from a measured HPC pilot (e.g., more array tasks and/or a shorter per-task workload), calculate expected runtime and concurrency, and document resubmission of unfinished shards. Avoid claiming a 48-hour task will finish without a pilot.

### P1 — don't silently change the chemical design space
- Claude's report says B62 is an invalid SMILES (unclosed ring), reducing the enumerated space from 15,491,072 to 15,241,216 combinations. The Ugi reaction is independently reconstructed, and multi-reactive amines are reduced to lexicographically smallest product; 12 examples differ in E/Z handling from an upstream assembly comparison.
- **Fix:** Report the exact B62 source string, RDKit error, and a *proposed* correction separately (never silently alter source data). Flag affected reagents and alternative Ugi sites for chemist review. Provide 2D product renders and a table of representative mappings. Keep any assumptions documented; do not claim strict LUMI replication without original 15M enumeration code or reference structures.

### P1 — H200 production readiness
- The new H200 launcher uses the proven CMRI SLURM resources and contains a sensible separation between general-checkpoint **weight initialization** and continual-checkpoint **resume**, but real checkpoint loading and H200 FP16 mixed-batch execution have not been demonstrated.
- **Fix:** After code corrections, on CMRI run read-only dataset audits, general-checkpoint compatibility checks, dry run, and a short, uniquely named H200 smoke run with real general + lipid molecules (not the existing general-run output directory). Only then approve production. Confirm the checkpoint initialisation path actually uses `--finetune-from-model` correctly for the pinned Uni-Core version.

## Additional recommendations
- **Finalization safety:** Fail if the lipid `valid` split is empty, train/valid LMDBs overlap, or validation shards are generated from incomplete output. A single-shard smoke-test overlap should require an explicit smoke-only flag.
- **Per-shard reproducibility:** Record source product checksum and provenance, resolved RDKit version, original reagent-file hash, reaction SMARTS hash, and config in all receipts.
- **Chemistry:** Inspect reaction SMARTS with representative multifunctional amines, hydrazines and isocyanide B33. Report product-site choices rather than treating lexicographic choice as verified LUMI behavior.
- **Memory:** The mixed loader stores sampled index arrays (not raw molecules); this is more scalable than storing all LMDB keys, but benchmark memory and worker behavior on the real 15M+ datasets.
- **Regression:** Repeat original general-pretraining tests after any edits and ensure only new continual-specific files change.

## Suggested Claude Code instruction (paste from the project root)

> Read `HEART_continual_independent_review.md` and inspect the current local implementation. Address **all P0 issues**, then P1 issues that can be resolved locally, without rewriting the existing general model or training launchers. Add regression tests reproducing each defect. Do not use the full 15M dataset locally. For requirements that depend on the real CMRI general LMDB/H200 checkpoint, add read-only preflight commands and fail-closed guards, and report them as unverified rather than guessing. Re-run feasible tests; update `CONTINUAL_PRETRAIN_CHANGE_REPORT.md`; generate a **new** `HEART_continual_pretrain_review_bundle_v2.zip` with every added/modified file and SHA-256 manifest. **Do not commit, push, pull, or submit production jobs.**

## Status
**Good foundation; not yet approved for production.** This is a code-review finding, not a claim that the entire pipeline is broken. The reported 130 new and 229 combined test passes are encouraging but do not cover the identified full-scale failure modes.
