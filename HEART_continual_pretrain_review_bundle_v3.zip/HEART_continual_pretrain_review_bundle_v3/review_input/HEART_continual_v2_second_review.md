# HEART × LUMI continual pretraining — v2 independent code review

**Review status: CHANGES REQUESTED before 15M production or H200 production training.**

## Evidence and verification

Reviewed the uploaded `HEART_continual_pretrain_review_bundle_v2.zip` directly, including all delivered source files, scripts, and tests. Verified all **40 file entries** against the ZIP's SHA-256 manifest and byte counts; Python files pass `compileall`, and the included Bash scripts pass `bash -n`. The bundle reports zero tracked-file changes at HEAD `ff40a14`, but that is a report of the local checkout, not a live check of the user's PC. Claude's Windows test totals are **reported, not independently reproduced** here: the review environment does not have the project's pinned Uni-Core and `lmdb` dependency.

The v1 P0 safety measures are present in source code: `lmdb_writer.finalize()` reconstructs expected shards and reconciles checksums/counts; configuration fingerprints and per-shard input hashes protect against stale reuse; `check_continual_data.py` plus the launcher check 2D/slot policies; there is an isolated H200 smoke mode and distinct weight-only-init versus continual-resume paths. This is substantial progress.

## New findings requiring fixes

### P0 — LMDB file descriptor exhaustion on the full dataset

**Files:** `model/unimol/data/merged_sampling_dataset.py`, `model/unimol/tasks/unimol_contrastive_continual.py`.

`MergedSampledLMDBDataset._get_env()` adds each accessed LMDB environment to `env_list` and **never closes it until process exit**. With `RECORDS_PER_SHARD=5000`, around 15.24M lipid products become ~3,049 shards, with ~3,047 train LMDBs plus general ligand LMDB. As training shuffles across shards, each worker may eventually hold thousands of environments and file descriptors; typical Linux per-process `ulimit -n` can be much lower. `_coordinate_slot_check()` already probes up to eight items **from every shard**, so even dataset initialization can accumulate all open handles in the parent before DataLoader worker creation (problematic with fork). These issues may not surface in tiny CPU tests.

**Required:** Implement a bounded, PID-aware LRU cache of *open LMDB environments* (not just the existing 16-record item cache), explicitly close on eviction, and close/drop any parent environment handles before fork/spawn. Provide a configurable max-open-env count (e.g. 32 or 64), stress-test with many synthetic LMDB shards, show open-FD count stays bounded, and preserve correct read behavior after eviction, worker fork/spawn, and resume. Do not change the existing general pretraining LMDB reader.

### P1 — Every SLURM array task re-parses the entire 15M product stream

**Files:** `model/pretrain/lipid_library/lmdb_writer.py`, `model/pretrain/scripts/lipid_library/04_conformers_array.sh`.

`lmdb_writer.main()` runs `for shard_id, batch in iter_shard_batches(...)` on **all** product rows and filters only afterwards with `if shard_id % ns.num_shards != ns.shard: continue`. With `--array=0-999%200`, every one of the 1,000 tasks parses all ~15M product records (around **15 billion row visits total**), merely retaining ~1/1000 of the shards. This adds major redundant gzip reads, Python parsing, shared-filesystem I/O and unpredictable runtimes, undermining the 24-hour sizing calculation (which counts only conformer processing).

**Required:** Materialize a stable, fingerprinted per-shard input index or physical product partitions once, then have each array task read only assigned shard inputs. Do not rely on reading-and-discarding all 15M rows in each task. Keep existing input hashes, safe resubmission, and final reconciliation. Test that total records read across all array tasks scales approximately with the actual dataset size rather than array_size × dataset size. Include input-read overhead in `--plan`.

### P1 — Biased lipid validation split by combination order

**File:** `model/pretrain/lipid_library/splits.py`.

Default `valid_shards=2` takes the **last two shard IDs** from a sequential, mixed-radix Ugi enumeration. Those shards are concentrated at the end of the chemical combinatorial order (e.g. late amine/isocyanide IDs), rather than a representative sample of the 15M library. The reported lipid validation loss may therefore be biased; the two shards represent only about 10,000 of ~15M candidate structures.

**Required:** Make deterministic random/stratified selection of complete validation shards with explicit seed and configurable fraction or count; avoid simply taking the last contiguous shards. Report selected reagent ID distribution by split and the validation fraction. Preserve disjoint split and provenance checks. Consider a scientifically justified scaffold or reagent-holdout split if the goal changes; do not silently claim a random split is a scaffold split. Add tests confirming reproducibility and dispersion across combination-index space.

### P1 — Data preflight samples only the first 64 lipid shards

**File:** `model/pretrain/tools/check_continual_data.py`.

`paths[:64]` samples only the first 64 shards within each lipid split, not records spread across the whole source. As a diagnostic it can miss late-shard variation or damage. The mixed task does a more extensive per-shard check but is susceptible to the LMDB-handle problem above.

**Required:** Perform reproducible, distributed sampling across all shard IDs and use final manifest metadata to enforce declared slot policy consistently; fail on missing/corrupt/contradictory shard metadata. Preserve bounded file handles and reasonable I/O.

## Scientific decisions still open (not coding bugs)

1. **B62:** the submitted SMILES has an unclosed ring; Claude rejected it and reduced the theoretical library from 15,491,072 to 15,241,216. A proposed chemical correction is not equivalent to author-confirmed source data. Preserve the original and require an explicit owner decision before claiming the original 15M reproduction.
2. **Ugi reaction site/chemistry:** the enumeration template is reconstructed. Multi-site amines, hydrazines, N-isocyanide B33, and stereo handling require chemical sign-off before full production.
3. **Conformer seed:** keep LUMI's seed-0 behavior for strict methodology or use seed-start-1 as a documented scientific deviation; neither is automatically the correct choice.
4. **CMRI-only readiness:** audit real general-ligand 2D/slot profile; verify pretrained H200 checkpoint strict initialization, fp16/batch-448 memory, SLURM resource/time-limit behavior and real CPU pilot speed. No claims of having tested these on CMRI should be made.

## Local next steps for Claude

Implement the above P0 and P1 changes **in the local checkout only**, plus focused regression and scale tests. Run feasible tests, update `CONTINUAL_PRETRAIN_CHANGE_REPORT.md`, and create `HEART_continual_pretrain_review_bundle_v3.zip` containing all new or modified files, SHA-256 manifest, and test results. **Do not commit, push, pull, submit jobs, modify existing general-pretraining code or checkpoints, or run the full 15M pipeline.**

Before ending, independently review the final source code for matching SLURM array parameters, worker FD usage, finite/safe mixed-data operation and checkpoint resume. Separate observed tests from projected performance.
