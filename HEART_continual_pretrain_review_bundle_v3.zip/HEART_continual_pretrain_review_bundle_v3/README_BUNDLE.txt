HEART x LUMI continual pretraining review bundle v3: revision 3, responds to
review_input/HEART_continual_v2_second_review.md (2026-11-04)
repo/         : every new file, at its path relative to the Git root C:/XuLab/Heart_liverPorject/pretrain/heart-molecular-pretraining
                (no tracked file was modified; git/tracked_changes.diff is empty)
git/          : original HEAD, tracked diff/status, untracked inventory
test_results/ : raw pytest output of the final local runs + local measurements (laptop, not CMRI)
CONTINUAL_PRETRAIN_CHANGE_REPORT.md : the change report (outside the Git root, in the project folder)
Excluded: .git, credentials, the user Excel, checkpoints, LMDBs, conda/venv, generated outputs, unrelated docs.
Start with CONTINUAL_PRETRAIN_CHANGE_REPORT.md section 2, then repo/model/pretrain/README_CONTINUAL.md.
