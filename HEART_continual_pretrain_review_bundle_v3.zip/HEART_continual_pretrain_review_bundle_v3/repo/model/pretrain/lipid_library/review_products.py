#!/usr/bin/env python
"""Chemistry review sheet: representative Ugi products with independent checks and drawings.

    python -m lipid_library.review_products BB_DIR -o REVIEW_DIR [--products-dir ENUM_DIR] [--per-group 4]

The enumeration template is a reconstruction (see ugi.py assumptions A1-A4),
so its products need human review. This tool picks a small, deterministic,
stratified sample of enumerated products -- every multi-site amine
(assumption A1), every non-aliphatic amine (A3), reagents carrying stereo
bonds/centres (A2), plus the first products of each role -- and for each one
records:

  * the four reagent IDs and SMILES and the product SMILES;
  * `core_ok`: the alpha-acylamino amide core R-C(=O)-N(R)-CH(R)-C(=O)-NH-R is present;
  * `formula_ok`: product formula == sum of the reagents - H2O;
  * `lumi_assembly`: whether LUMI's own core-attachment assembly
    (data_generate.ipynb) gives the identical canonical SMILES;
  * `n_unique_products`: >1 means assumption A1 chose one of several products.

Outputs (REVIEW_DIR): review.csv, review.svg (grid drawing, legend = combo
ID), summary.json. The combinations are built directly from the
combination space with the same `ugi.product_smiles` code as the
enumeration (no 15M-row scan); with --products-dir the first products are
also compared with the enumeration output.
"""
import argparse
import csv
import json
import logging
import os
import sys

from . import io_utils, ugi
from .building_blocks import ROLE_ORDER, load_building_blocks
from .lmdb_writer import product_chunks

logger = logging.getLogger(__name__)

# Amide N substituents may be C or N: hydrazine "amines" (A34, A41, A48 in the
# real sheet; assumption A3) and the N-isocyanide B33 give N-N bonds.
CORE_SMARTS = "[CX3](=O)[NX3]([#6,#7])[CX4;H1]([#6])[CX3](=O)[NX3;H1][#6,#7]"
FIELDS = ["group", "combo_index", "combo_id", "amine_smiles", "isocyanide_smiles",
          "aldehyde_smiles", "acid_smiles", "product_smiles", "core_ok", "formula_ok",
          "lumi_assembly", "n_unique_products", "alternative_products", "mol_wt", "num_heavy_atoms"]


def _formula(mol):
    from rdkit.Chem import AllChem

    out = {}
    for a in AllChem.AddHs(mol).GetAtoms():
        out[a.GetSymbol()] = out.get(a.GetSymbol(), 0) + 1
    return out


def _flat(smiles):
    from rdkit import Chem

    return Chem.MolToSmiles(Chem.MolFromSmiles(smiles), isomericSmiles=False)


def check_product(reagents, product_smiles, alternatives=()):
    """Independent checks of one product. `reagents` maps role -> SMILES."""
    from rdkit import Chem
    from rdkit.Chem import Descriptors

    prod = Chem.MolFromSmiles(product_smiles)
    if prod is None:
        return {"core_ok": False, "formula_ok": False, "lumi_assembly": "product unparsable"}
    core_ok = bool(prod.GetSubstructMatches(Chem.MolFromSmarts(CORE_SMARTS)))
    total = {}
    for smi in reagents.values():
        for k, v in _formula(Chem.MolFromSmiles(smi)).items():
            total[k] = total.get(k, 0) + v
    total["H"] -= 2
    total["O"] -= 1
    formula_ok = _formula(prod) == {k: v for k, v in total.items() if v}
    try:
        lumi = ugi.lumi_core_product_smiles(reagents)
        if lumi == product_smiles:
            lumi_status = "identical"
        elif lumi in alternatives:
            # LUMI's assembly attaches at the FIRST matching group (input atom
            # order); the template keeps the lexicographically smallest product
            # (A1). Both are valid Ugi adducts at different sites: chemist review.
            lumi_status = "other_site_A1: " + lumi
        elif _flat(lumi) == _flat(product_smiles):
            # LUMI's CXSMILES core assembly loses E/Z next to the attachment
            # point (e.g. an alpha,beta-unsaturated acid); the template keeps it.
            lumi_status = "identical_except_stereo: " + lumi
        else:
            lumi_status = "DIFFERENT: " + lumi
    except ugi.UgiError as exc:
        lumi_status = "not comparable: {}".format(exc)
    return {"core_ok": core_ok, "formula_ok": formula_ok, "lumi_assembly": lumi_status,
            "mol_wt": round(Descriptors.MolWt(prod), 2), "num_heavy_atoms": prod.GetNumHeavyAtoms()}


def _has_nn(smiles):
    from rdkit import Chem

    return bool(Chem.MolFromSmiles(smiles).GetSubstructMatches(
        Chem.MolFromSmarts("[CX3](=O)[NX3](N)[CX4;H1]")))


def _has_nhn(smiles):
    from rdkit import Chem

    return bool(Chem.MolFromSmiles(smiles).GetSubstructMatches(
        Chem.MolFromSmarts("[CX4;H1][CX3](=O)[NX3;H1][NX3]")))


def _groups(by_role):
    """Reagent IDs of interest per review group."""
    groups = {}
    for row in by_role["amine"]:
        if row["n_sites"] > 1:
            groups.setdefault("A1_multi_site_amine", set()).add(row["id"])
        if row["site_tier"] == "other_primary":
            groups.setdefault("A3_non_aliphatic_amine", set()).add(row["id"])
    for role in ROLE_ORDER:
        for row in by_role[role]:
            if int(row.get("n_stereo_bonds") or 0) or int(row.get("n_specified_stereocentres") or 0):
                groups.setdefault("A2_reagent_stereo", set()).add(row["id"])
    return groups


def select(by_role, per_group=4, n_first=8, every_reagent=False):
    """Deterministic stratified combinations, built from the combination space.

    For each review group, up to `per_group` member reagents are taken in
    role_index order; reagent k of a group is combined with partner reagents
    chosen by rotating index (k * 7 + j) mod n, so different partners appear.
    The first `n_first` combinations (indexes 0..n_first-1) are always included
    so they can be compared with the enumeration output byte for byte.
    """
    from .enumerate_library import CombinationSpace

    space = CombinationSpace(by_role)
    picked = [("first_products", i) for i in range(min(n_first, space.total))]
    groups = sorted(_groups(by_role).items())
    if every_reagent:
        groups.append(("every_reagent", {r["id"] for role in ROLE_ORDER for r in by_role[role]}))
    for g, members in groups:
        rows = [(role, r) for role in ROLE_ORDER for r in by_role[role] if r["id"] in members]
        limit = len(rows) if g == "every_reagent" else per_group
        for k, (role, r) in enumerate(rows[:limit]):
            idx = []
            for j, other in enumerate(ROLE_ORDER):
                n = len(by_role[other])
                idx.append(r["role_index"] if other == role else (k * 7 + j) % n)
            picked.append((g, space.encode(idx)))
    return picked, space


def write_markdown(path, rows, summary, bb_dir):
    """Human-readable mapping table for chemist review (review fix P1 chemistry)."""
    lines = ["# Ugi-4CR product review (template reconstruction; NOT verified LUMI output)", "",
             "Reaction SMARTS: `{}`".format(summary["ugi_reaction_smarts"]), "",
             "Checks: core {n_core_ok}/{n}, formula {n_formula_ok}/{n}, LUMI assembly identical "
             "{n_lumi_identical}, identical except stereo {n_lumi_identical_except_stereo}, different "
             "{n_lumi_different}, other Ugi site (A1 choice differs from LUMI's first-match assembly) "
             "{n_lumi_other_site_A1}; combinations with alternative products (A1) "
             "{n_multi_product_combinations}.".format(n=summary["n_reviewed"], **summary), ""]
    issues = os.path.join(bb_dir, "reagent_issues.csv")
    if os.path.isfile(issues):
        with open(issues, newline="", encoding="utf-8") as fh:
            bad = list(csv.DictReader(fh))
        if bad:
            lines += ["## Rejected reagents (source data NOT modified)", "",
                      "| ID | category | source SMILES | reason | proposed corrections (not applied) |",
                      "|---|---|---|---|---|"]
            for b in bad:
                cands = json.loads(b.get("proposed_corrections") or "[]")
                prop = "<br>".join("`{}` ({}, {})".format(c["canonical"], c["formula"], c["edit"]) for c in cands)
                lines.append("| {} | {} | `{}` | {} | {} |".format(
                    b["id"], b["category"], b["input_smiles"], b["reason"].replace("|", "/"), prop or "none"))
            lines.append("")
    lines += ["## Representative mappings", "",
              "| group | combination | amine | isocyanide | aldehyde | acid | product | core | formula | LUMI assembly | alternatives (A1) |",
              "|---|---|---|---|---|---|---|---|---|---|---|"]
    for r in rows:
        lines.append("| {group} | {combo_id} | `{amine_smiles}` | `{isocyanide_smiles}` | `{aldehyde_smiles}` | "
                     "`{acid_smiles}` | `{product_smiles}` | {core_ok} | {formula_ok} | {lumi} | {alts} |".format(
                         lumi=r["lumi_assembly"].split(":")[0], alts=(r.get("alternative_products") or "").replace("|", "<br>"),
                         **r))
    io_utils.atomic_write_text(path, chr(10).join(lines) + chr(10))


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("bb_dir")
    ap.add_argument("-o", "--out-dir", required=True)
    ap.add_argument("--products-dir", default=None,
                    help="enumerate_library output: the first products are compared with it")
    ap.add_argument("--per-group", type=int, default=4)
    ap.add_argument("--first", type=int, default=8)
    ap.add_argument("--every-reagent", action="store_true",
                    help="also build one product per accepted reagent (every reagent must react)")
    ap.add_argument("--no-svg", action="store_true")
    ns = ap.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(message)s")

    from rdkit import Chem, RDLogger
    from rdkit.Chem import Draw

    RDLogger.DisableLog("rdApp.*")
    by_role = load_building_blocks(os.path.join(ns.bb_dir, "building_blocks.csv"))
    smiles_of = {r["id"]: r["canonical_smiles"] for role in ROLE_ORDER for r in by_role[role]}
    picked, space = select(by_role, ns.per_group, ns.first, ns.every_reagent)
    counts = {}
    for g, _ in picked:
        counts[g] = counts.get(g, 0) + 1
    enumerated = {}
    if ns.products_dir:
        wanted = {i for _, i in picked}
        for path in product_chunks(ns.products_dir):
            for prow in io_utils.read_gz_csv(path):
                if int(prow["combo_index"]) in wanted:
                    enumerated[int(prow["combo_index"])] = prow["product_smiles"]
            break                                   # the first chunk holds the first products
    mols_by_id = {i: Chem.MolFromSmiles(s) for i, s in smiles_of.items()}

    os.makedirs(ns.out_dir, exist_ok=True)
    rows, mols, legends = [], [], []
    n_enum_match = n_enum_compared = 0
    failures = []
    for group, index in picked:
        am, iso, ald, acid = space.decode(index)
        row = {"combo_index": index, "combo_id": "-".join(r["id"] for r in (am, iso, ald, acid)),
               "amine_id": am["id"], "isocyanide_id": iso["id"], "aldehyde_id": ald["id"],
               "acid_id": acid["id"]}
        try:
            row["product_smiles"], info = ugi.product_smiles(
                mols_by_id[acid["id"]], mols_by_id[am["id"]], mols_by_id[ald["id"]], mols_by_id[iso["id"]])
            row["n_unique_products"] = info["n_unique_products"]
            # A1: every product the template allows; the first is the one enumerated
            alts = sorted({Chem.MolToSmiles(Chem.MolFromSmiles(a)) for a in info["alternative_products"]})
            row["alternative_products"] = " | ".join(alts) if len(alts) > 1 else ""
        except ugi.UgiError as exc:
            logger.warning("%s: no product (%s)", row["combo_id"], exc)
            failures.append({"combo_id": row["combo_id"], "reason": str(exc)})
            continue
        if index in enumerated:
            n_enum_compared += 1
            n_enum_match += int(enumerated[index] == row["product_smiles"])
        reagents = {"amine": smiles_of[row["amine_id"]], "isocyanide": smiles_of[row["isocyanide_id"]],
                    "aldehyde": smiles_of[row["aldehyde_id"]], "acid": smiles_of[row["acid_id"]]}
        alts_all = [a for a in (row.get("alternative_products") or "").split(" | ") if a]
        checks = check_product(reagents, row["product_smiles"], alts_all)
        rows.append({"group": group, "combo_index": row["combo_index"], "combo_id": row["combo_id"],
                     "amine_smiles": reagents["amine"], "isocyanide_smiles": reagents["isocyanide"],
                     "aldehyde_smiles": reagents["aldehyde"], "acid_smiles": reagents["acid"],
                     "product_smiles": row["product_smiles"],
                     "n_unique_products": row["n_unique_products"],
                     "alternative_products": row.get("alternative_products", ""), **checks})
        mols.append(Chem.MolFromSmiles(row["product_smiles"]))
        legends.append("{} [{}]".format(row["combo_id"], group.split("_")[0]))

    with open(os.path.join(ns.out_dir, "review.csv"), "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=FIELDS, extrasaction="ignore", lineterminator="\n")
        w.writeheader()
        w.writerows(rows)
    if mols and not ns.no_svg:
        svg = Draw.MolsToGridImage(mols, molsPerRow=3, subImgSize=(420, 320), legends=legends,
                                   useSVG=True)
        with open(os.path.join(ns.out_dir, "review.svg"), "w", encoding="utf-8") as fh:
            fh.write(svg if isinstance(svg, str) else svg.data)
    summary = {
        "n_reviewed": len(rows), "per_group": counts, "failures": failures,
        "enumeration_output_compared": n_enum_compared,
        "enumeration_output_identical": n_enum_match,
        "n_core_ok": sum(bool(r["core_ok"]) for r in rows),
        "n_formula_ok": sum(bool(r["formula_ok"]) for r in rows),
        "n_lumi_identical": sum(r["lumi_assembly"] == "identical" for r in rows),
        "n_lumi_identical_except_stereo": sum(
            r["lumi_assembly"].startswith("identical_except_stereo") for r in rows),
        "n_lumi_different": sum(r["lumi_assembly"].startswith("DIFFERENT") for r in rows),
        "n_lumi_other_site_A1": sum(r["lumi_assembly"].startswith("other_site_A1") for r in rows),
        "n_hydrazine_amide_n": sum(_has_nn(r["product_smiles"]) for r in rows),
        "n_n_isocyanide_nh_n": sum(_has_nhn(r["product_smiles"]) for r in rows),
        "n_multi_product_combinations": sum(int(r["n_unique_products"]) > 1 for r in rows),
        "ugi_reaction_smarts": ugi.UGI_SMARTS,
        "note": "manual review required: the Ugi template is a reconstruction (assumptions A1-A4)",
    }
    io_utils.atomic_write_json(os.path.join(ns.out_dir, "summary.json"), summary)
    write_markdown(os.path.join(ns.out_dir, "review.md"), rows, summary, ns.bb_dir)
    logger.info("reviewed %d products (%s): core %d/%d, formula %d/%d, LUMI-identical %d/%d",
                len(rows), json.dumps(counts), summary["n_core_ok"], len(rows),
                summary["n_formula_ok"], len(rows), summary["n_lumi_identical"], len(rows))
    logger.info("wrote %s", ns.out_dir)
    ok = summary["n_core_ok"] == summary["n_formula_ok"] == len(rows) and n_enum_match == n_enum_compared         and summary["n_lumi_different"] == 0 and not failures
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
