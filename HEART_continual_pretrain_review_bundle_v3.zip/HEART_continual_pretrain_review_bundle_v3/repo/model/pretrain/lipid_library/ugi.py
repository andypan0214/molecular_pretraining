"""Ugi four-component product construction for the LUMI-style virtual lipid library.

Connectivity built here (virtual enumeration only; no laboratory procedure):

    acid R_D-COOH + amine R_A-NH2 + aldehyde R_C-CHO + isocyanide R_B-NC
        -> R_D-C(=O)-N(R_A)-CH(R_C)-C(=O)-NH-R_B      (water is eliminated)

Atom bookkeeping used by the reaction template below: the aldehyde oxygen is
the one lost as water, and the acid hydroxyl oxygen becomes the carbonyl
oxygen of the amide formed at the isocyanide carbon. The resulting skeleton
`C(=O)N-C-C(=O)N` is the same alpha-acylamino-amide core that LUMI-lab's
`model/data_process/data_generate.ipynb` assembles for its 220k library
(core SMILES `C(=O)NCC(=O)N`), which `tests/test_ugi_reaction.py` uses as an
independent cross-check of this template.

ASSUMPTIONS (documented, not verified against LUMI's own 15M-library code,
which is not published in LUMI-lab @ 611e02b):
  A1. One reaction site per reagent; a single mono-Ugi product per
      combination. If a reagent carries several eligible groups (e.g. the
      di/tri-amines A1, A5, A40), RDKit returns one product per group and the
      pipeline keeps the lexicographically smallest canonical product SMILES.
      That rule is deterministic and restartable (it does not depend on
      iteration order); `n_unique_products` in the enumeration output records
      how many distinct products the combination could have given, so
      multi-site reagents stay visible rather than silently collapsed.
  A2. The new stereocentre at the aldehyde-derived carbon is left
      unspecified (racemic); stereochemistry present in the reagents is
      carried over unchanged.
  A3. Aromatic/heteroaryl primary amines and hydrazines are accepted but
      flagged (`amine_tier`), since they are not classic Ugi partners.
  A4. Side-chain nucleophiles (alcohols, secondary amines, esters) are not
      acylated: only the four groups selected below react.
"""
import logging

from rdkit import Chem
from rdkit.Chem import AllChem, rdChemReactions

logger = logging.getLogger(__name__)

# --------------------------------------------------------------------------- group SMARTS
# Acid: carboxylic acid, not an ester (esters are present in many D reagents).
ACID_SMARTS = "[CX3;!$(C[O;H0])](=[OX1])[OX2;H1]"
# Aldehyde: carbon with exactly one H, double-bonded O, attached to carbon.
ALDEHYDE_SMARTS = "[CX3;H1](=[OX1])[#6]"
# Isocyanide: terminal divalent carbon, written [C-]#[N+]R in the input sheet.
ISOCYANIDE_SMARTS = "[CX1;$([C-]#[N+]),$([C]#[N])]#[NX2,NX2+]"
# Amine tiers: aliphatic primary amine first, then any other primary NH2
# (aromatic amines, hydrazines), which is accepted but flagged.
AMINE_SMARTS_PRIMARY = "[NX3;H2;!$(NC=O);!$(N-a);!$(N-[!#6]);!$(N#*)]"
AMINE_SMARTS_ANY = "[NX3;H2;!$(NC=O)]"

# Reaction template. Reactant order: acid, amine, aldehyde, isocyanide.
#   :3  acid hydroxyl O  -> carbonyl O of the new secondary amide
#   the aldehyde O is left unmapped, so RDKit drops it (it leaves as water)
UGI_SMARTS = (
    "[CX3;!$(C[O;H0]):1](=[OX1:2])[OX2;H1:3]"
    ".[NX3;H2:4]"
    ".[CX3;H1:5](=[OX1])[#6:9]"
    ".[CX1:7]#[NX2,NX2+:8]"
    ">>"
    "[C:1](=[O:2])[N;H0;+0:4][C;H1:5]([#6:9])[C;+0:7](=[O;H0:3])[N;H1;+0:8]"
)


# Everything that decides which product a combination gives. It is part of the
# enumeration fingerprint (provenance.py): changing any of it invalidates old
# product chunks instead of silently reusing them. Bump POLICY_VERSION when the
# behaviour of build_product/product_smiles changes.
POLICY_VERSION = "ugi-policy-v1"


def policy():
    return {
        "policy_version": POLICY_VERSION,
        "reaction_smarts": UGI_SMARTS,
        "acid_smarts": ACID_SMARTS,
        "aldehyde_smarts": ALDEHYDE_SMARTS,
        "isocyanide_smarts": ISOCYANIDE_SMARTS,
        "amine_smarts_primary": AMINE_SMARTS_PRIMARY,
        "amine_smarts_any": AMINE_SMARTS_ANY,
        "A1_multi_site": "lexicographically smallest canonical isomeric product SMILES",
        "A2_stereo": "new alpha stereocentre unspecified; reagent stereo kept",
        "A3_amines": "aliphatic primary first; any other primary NH2 (aryl, hydrazine) accepted+flagged",
        "A4_side_reactions": "none modelled",
        "smiles": "RDKit canonical isomeric, round-trip stable",
    }


class UgiError(ValueError):
    """A combination cannot be turned into a single valid Ugi product."""


def _compile():
    rxn = rdChemReactions.ReactionFromSmarts(UGI_SMARTS)
    if rxn is None:
        raise RuntimeError("the Ugi reaction SMARTS failed to compile")
    rxn.Initialize()
    return rxn


_RXN = None
_PATTERNS = None


def reaction():
    """The compiled Ugi reaction (built once per process)."""
    global _RXN
    if _RXN is None:
        _RXN = _compile()
    return _RXN


def patterns():
    """Compiled functional-group patterns, keyed by name."""
    global _PATTERNS
    if _PATTERNS is None:
        _PATTERNS = {
            "acid": Chem.MolFromSmarts(ACID_SMARTS),
            "aldehyde": Chem.MolFromSmarts(ALDEHYDE_SMARTS),
            "isocyanide": Chem.MolFromSmarts(ISOCYANIDE_SMARTS),
            "amine_primary": Chem.MolFromSmarts(AMINE_SMARTS_PRIMARY),
            "amine_any": Chem.MolFromSmarts(AMINE_SMARTS_ANY),
        }
        for k, v in _PATTERNS.items():
            if v is None:
                raise RuntimeError("SMARTS for {} failed to compile".format(k))
    return _PATTERNS


# --------------------------------------------------------------------------- role eligibility
ROLE_GROUP = {"amine": "amine", "isocyanide": "isocyanide", "aldehyde": "aldehyde", "acid": "acid"}


def site_count(mol, role):
    """Number of eligible reacting groups of `role` in `mol` (and the tier used)."""
    pats = patterns()
    if role == "amine":
        n = len(mol.GetSubstructMatches(pats["amine_primary"]))
        if n:
            return n, "aliphatic_primary"
        return len(mol.GetSubstructMatches(pats["amine_any"])), "other_primary"
    return len(mol.GetSubstructMatches(pats[ROLE_GROUP[role]])), ROLE_GROUP[role]


def check_eligibility(mol, role):
    """Return (ok, n_sites, tier, reason)."""
    n, tier = site_count(mol, role)
    if n == 0:
        return False, 0, tier, "no {} group found".format(role)
    return True, n, tier, ""


def _first_site(mol, role):
    """The lowest-index eligible group match in `mol`, for reporting only."""
    pats = patterns()
    key = "amine_primary" if role == "amine" else ROLE_GROUP[role]
    matches = mol.GetSubstructMatches(pats[key])
    if not matches and role == "amine":
        matches = mol.GetSubstructMatches(pats["amine_any"])
    return matches[0] if matches else None


def build_product(acid, amine, aldehyde, isocyanide, sanitize=True):
    """Build the Ugi product of four RDKit mols.

    Returns (product_mol, info). `info` records the number of raw products
    RDKit produced, the number of distinct canonical products, and the
    reacting-site match used for each reagent. Raises UgiError if no valid
    product can be built.
    """
    rxn = reaction()
    try:
        raw = rxn.RunReactants((acid, amine, aldehyde, isocyanide))
    except Exception as exc:  # pragma: no cover - RDKit internal failure
        raise UgiError("RunReactants failed: {}".format(exc))
    if not raw:
        raise UgiError("the Ugi template did not match these four reagents")

    smiles_to_mol = {}
    for tup in raw:
        prod = tup[0]
        prod.UpdatePropertyCache(strict=False)
        if sanitize:
            problems = Chem.SanitizeMol(prod, catchErrors=True)
            if problems != Chem.SanitizeFlags.SANITIZE_NONE:
                continue
        try:
            smi = Chem.MolToSmiles(prod)
        except Exception:
            continue
        if smi and smi not in smiles_to_mol:
            smiles_to_mol[smi] = prod
    if not smiles_to_mol:
        raise UgiError("every raw Ugi product failed RDKit sanitization")

    # Assumption A1: deterministic choice when a reagent has several sites.
    chosen_smi = sorted(smiles_to_mol)[0]
    info = {
        "n_raw_products": len(raw),
        "n_unique_products": len(smiles_to_mol),
        # every distinct product the template allows (for chemist review of A1)
        "alternative_products": sorted(smiles_to_mol),
        "sites": {
            "acid": _first_site(acid, "acid"),
            "amine": _first_site(amine, "amine"),
            "aldehyde": _first_site(aldehyde, "aldehyde"),
            "isocyanide": _first_site(isocyanide, "isocyanide"),
        },
    }
    return smiles_to_mol[chosen_smi], info


def product_smiles(acid, amine, aldehyde, isocyanide):
    """Canonical isomeric SMILES of the Ugi product, plus the info dict."""
    mol, info = build_product(acid, amine, aldehyde, isocyanide)
    # Re-parse so the stored SMILES is one RDKit can read back unchanged.
    smi = Chem.MolToSmiles(mol, isomericSmiles=True)
    back = Chem.MolFromSmiles(smi)
    if back is None:
        raise UgiError("the product SMILES does not round-trip: {}".format(smi))
    canonical = Chem.MolToSmiles(back, isomericSmiles=True)
    if canonical != smi:
        raise UgiError("the product SMILES is not canonical-stable: {} -> {}".format(smi, canonical))
    info["num_heavy_atoms"] = back.GetNumHeavyAtoms()
    info["num_atoms_with_h"] = AllChem.AddHs(back).GetNumAtoms()
    info["formal_charge"] = Chem.GetFormalCharge(back)
    return canonical, info


# --------------------------------------------------------------------------- LUMI cross-check
LUMI_CORE_SMILES = "C(=O)NCC(=O)N"  # LUMI data_generate.ipynb core; C0 N2 C3 N6
LUMI_CORE_POS = {"amine": 2, "isocyanide": 6, "aldehyde": 3, "acid": 0}
LUMI_TRIM = {
    "amine": "[NH2]",
    "isocyanide": "N#C",
    "aldehyde": "[CX3H1](=O)",
    "acid": "[CX3](=O)[OX2H1]",
}


def lumi_core_product_smiles(reagent_smiles_by_role):
    """Independent re-implementation of LUMI's core-attachment assembly.

    `reagent_smiles_by_role` maps 'amine'/'isocyanide'/'aldehyde'/'acid' to the
    reagent SMILES. Returns the canonical product SMILES, or raises UgiError.
    This is used only to cross-check `product_smiles`; the pipeline itself
    uses the reaction template above.
    """
    from rdkit.Chem import rdMolEnumerator

    core = Chem.MolFromSmiles(LUMI_CORE_SMILES)
    if core is None:
        raise UgiError("the LUMI core SMILES failed to parse")
    frag_smiles = {}
    for role, smi in reagent_smiles_by_role.items():
        mol = Chem.MolFromSmiles(smi)
        if mol is None:
            raise UgiError("reagent SMILES failed to parse: {!r}".format(smi))
        patt = Chem.MolFromSmarts(LUMI_TRIM[role])
        if not mol.GetSubstructMatches(patt):
            raise UgiError("no {} group in {!r}".format(role, smi))
        trimmed = Chem.ReplaceSubstructs(mol, patt, Chem.MolFromSmiles("*"))[0]
        Chem.SanitizeMol(trimmed)
        frag = Chem.MolToSmiles(trimmed)
        if not frag.startswith("*"):
            raise UgiError("the trimmed {} does not start with the attachment point: {}".format(role, frag))
        frag_smiles[role] = (frag, trimmed.GetNumAtoms())

    order = ["amine", "isocyanide", "aldehyde", "acid"]
    offset = core.GetNumAtoms()
    links = []
    parts = [LUMI_CORE_SMILES]
    for role in order:
        frag, n_atoms = frag_smiles[role]
        links.append("{}:{}".format(offset, LUMI_CORE_POS[role]))
        offset += n_atoms
        parts.append(frag)
    cxsmiles = "{} |m:{}|".format(".".join(parts), ",".join(links))
    combined = Chem.MolFromSmiles(cxsmiles)
    if combined is None:
        raise UgiError("the LUMI CXSMILES assembly failed to parse")
    enumerated = rdMolEnumerator.Enumerate(combined)
    if len(enumerated) != 1:
        raise UgiError("the LUMI assembly enumerated {} molecules".format(len(enumerated)))
    product = enumerated[0]
    Chem.SanitizeMol(product)
    return Chem.MolToSmiles(product, isomericSmiles=True)
