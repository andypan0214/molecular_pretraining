"""Small dependency-free I/O helpers: atomic writes, gz CSV, minimal .xlsx reader.

The .xlsx reader uses only the standard library (zipfile + xml), so the
pipeline does not need pandas/openpyxl in heart_gpu. If openpyxl is
installed it is not required; both give the same cell strings for the
plain-text ID/SMILES/Category sheet used here.
"""
import csv
import gzip
import hashlib
import io
import json
import os
import re
import zipfile
import xml.etree.ElementTree as ET

_NS = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
_REL_NS = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"


def sha256_file(path, chunk=1 << 20):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        while True:
            b = fh.read(chunk)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def atomic_write_text(path, text):
    tmp = "{}.tmp.{}".format(path, os.getpid())
    with open(tmp, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(text)
        fh.flush()
        os.fsync(fh.fileno())
    os.replace(tmp, path)


def atomic_write_json(path, obj):
    atomic_write_text(path, json.dumps(obj, indent=2, sort_keys=True, default=_json_default) + "\n")


def _json_default(o):
    try:
        import numpy as np

        if isinstance(o, np.integer):
            return int(o)
        if isinstance(o, np.floating):
            return float(o)
        if isinstance(o, np.ndarray):
            return o.tolist()
    except ImportError:  # pragma: no cover
        pass
    raise TypeError("not JSON serialisable: {!r}".format(type(o)))


class AtomicGzCsvWriter:
    """gzip CSV written to <path>.partial and renamed on close(commit=True)."""

    def __init__(self, path, header):
        self.path = path
        self.tmp = path + ".partial"
        self._raw = open(self.tmp, "wb")
        # mtime=0 -> byte-identical output for identical content (determinism checks)
        self._gz = gzip.GzipFile(fileobj=self._raw, mode="wb", mtime=0)
        self._txt = io.TextIOWrapper(self._gz, encoding="utf-8", newline="")
        self._w = csv.writer(self._txt, lineterminator="\n")
        self._w.writerow(header)
        self.n = 0

    def writerow(self, row):
        self._w.writerow(row)
        self.n += 1

    def close(self, commit=True):
        self._txt.flush()
        self._txt.close()        # closes the TextIOWrapper and the GzipFile
        self._raw.flush()
        os.fsync(self._raw.fileno())
        self._raw.close()        # GzipFile(fileobj=...) does not close it for us
        if commit:
            os.replace(self.tmp, self.path)
        else:
            os.remove(self.tmp)


def read_gz_csv(path):
    with gzip.open(path, "rt", encoding="utf-8", newline="") as fh:
        for row in csv.DictReader(fh):
            yield row


def _col_index(ref):
    letters = re.match(r"([A-Z]+)", ref).group(1)
    n = 0
    for ch in letters:
        n = n * 26 + (ord(ch) - 64)
    return n - 1


def read_xlsx_rows(path, sheet=None):
    """Return (sheet_names, sheet_name_used, rows) with every cell as a string.

    Only shared strings, inline strings and numbers are supported (all that a
    plain ID/SMILES/Category sheet contains). Formulas are returned as their
    cached value.
    """
    with zipfile.ZipFile(path) as z:
        wb = ET.fromstring(z.read("xl/workbook.xml"))
        rels = ET.fromstring(z.read("xl/_rels/workbook.xml.rels"))
        rel_target = {r.get("Id"): r.get("Target") for r in rels}
        sheets = []
        for s in wb.find("m:sheets", _NS):
            target = rel_target[s.get(_REL_NS + "id")]
            target = target.lstrip("/")
            if not target.startswith("xl/"):
                target = "xl/" + target
            sheets.append((s.get("name"), target))
        names = [n for n, _ in sheets]
        if sheet is None:
            name, target = sheets[0]
        else:
            matches = [(n, t) for n, t in sheets if n == sheet]
            if not matches:
                raise KeyError("sheet {!r} not in {}".format(sheet, names))
            name, target = matches[0]
        shared = []
        if "xl/sharedStrings.xml" in z.namelist():
            sst = ET.fromstring(z.read("xl/sharedStrings.xml"))
            for si in sst.findall("m:si", _NS):
                shared.append("".join(t.text or "" for t in si.iter("{%s}t" % _NS["m"])))
        ws = ET.fromstring(z.read(target))
        rows = []
        for r in ws.find("m:sheetData", _NS).findall("m:row", _NS):
            cells = {}
            for c in r.findall("m:c", _NS):
                t = c.get("t")
                v = c.find("m:v", _NS)
                if t == "s":
                    val = shared[int(v.text)] if v is not None else ""
                elif t == "inlineStr":
                    is_ = c.find("m:is", _NS)
                    val = "".join(x.text or "" for x in is_.iter("{%s}t" % _NS["m"])) if is_ is not None else ""
                else:
                    val = v.text if v is not None and v.text is not None else ""
                cells[_col_index(c.get("r"))] = val
            if cells:
                width = max(cells) + 1
                rows.append([cells.get(i, "") for i in range(width)])
            else:
                rows.append([])
    return names, name, rows
