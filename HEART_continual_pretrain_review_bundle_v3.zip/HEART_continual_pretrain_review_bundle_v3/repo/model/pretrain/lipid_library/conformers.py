"""RDKit conformer generation for lipid records, following LUMI's pretraining path.

Scientific reference: LUMI-lab `model/molecule_library/
vector_rdkit_conformer_gen_customized_conformer.py` @ 611e02b, functions
`smi2_2Dcoords`, `smi2_3Dcoords` and `smi2coords_pretrain`:

  * ETKDGv3 embedding, one attempt per changing fixed seed (seed = attempt
    number, so the result is reproducible), MMFF optimisation of each
    accepted embedding;
  * the pretraining path asks for 10 3D conformers with at most 15 attempts
    and `maxIterations=4000`, then appends one 2D conformer;
  * a molecule with more than 400 atoms skips 3D entirely and stores the 2D
    conformer in all slots;
  * any 3D slot that could not be filled is filled with the 2D conformer.

Differences from LUMI, all of them bookkeeping rather than chemistry:

  D1. LUMI reuses one `mol` object across attempts, so `EmbedMolecule`
      overwrites the previous conformer and `MMFFOptimizeMolecule` relaxes
      whichever conformer is current. The same is done here (same geometry
      sequence), but every accepted conformer is copied out immediately, so a
      later attempt cannot silently alter an earlier result.
  D2. LUMI's bare `except: continue` hides the reason. Here each failure is
      counted by category (embed_failed, mmff_failed, exception) and reported.
  D3. LUMI does not report how many slots are 2D fallbacks. Every record
      produced here carries `n_3d_success`, `n_2d_filled` and
      `is_3d` (one flag per coordinate slot), so training and QC can tell a
      real 3D geometry from a 2D fill-in.
  D4. LUMI's `len(...) == len(coordinates)` alignment check is a bare
      expression (a no-op). Here the atom/coordinate alignment, the (N, 3)
      shape and finiteness are asserted for every conformer.
  D5. 3D conformers are not assumed to be geometrically distinct: identical
      seeds can converge to the same minimum. `n_distinct_3d` reports how
      many are distinct to 1e-3 A RMS of their coordinate arrays.
  D6. Seeds. LUMI uses randomSeed = attempt number starting at 0. In RDKit
      (verified with 2024.09.6) ETKDG randomSeed=0 produces the SAME
      embedding as randomSeed=1, so LUMI's first two 3D slots are normally
      identical (observed locally: 9 distinct of 10 for real Ugi lipids).
      `seed_start=0` (default) reproduces LUMI exactly; `seed_start=1` uses
      seeds 1..15 and avoids the duplicate. The choice is a reviewer decision
      and is recorded in every shard receipt.
"""
import logging

import numpy as np

logger = logging.getLogger(__name__)

# Part of the lmdb_writer configuration fingerprint: bump when the geometry
# produced for a given (SMILES, options) changes.
CONFORMER_POLICY_VERSION = "lumi-smi2coords-pretrain-v1 (ETKDGv3 fast-then-retry, MMFF, D1-D6)"

N_3D_SLOTS = 10          # LUMI: cnt = 10
MAX_TRY = 15             # LUMI smi2coords_pretrain: MAX_TRY = 15
MAX_ITERATIONS = 4000    # LUMI smi2coords_pretrain: max_iteration = 4000
MAX_ATOMS_FOR_3D = 400   # LUMI: atom num > 400 -> 2D only


class ConformerError(ValueError):
    """No usable coordinates could be produced for a SMILES."""


def _quiet():
    from rdkit import RDLogger

    RDLogger.DisableLog("rdApp.*")


def smi2_2Dcoords(smi):
    """2D coordinates with explicit H, float32 (N, 3). LUMI `smi2_2Dcoords` + D4."""
    from rdkit import Chem
    from rdkit.Chem import AllChem

    mol = Chem.MolFromSmiles(smi)
    if mol is None:
        raise ConformerError("RDKit cannot parse/sanitize SMILES: {!r}".format(smi))
    mol = AllChem.AddHs(mol)
    AllChem.Compute2DCoords(mol)
    coords = mol.GetConformer().GetPositions().astype(np.float32)
    n = mol.GetNumAtoms()
    if coords.shape != (n, 3):
        raise ConformerError("2D coordinates have shape {}, expected ({}, 3)".format(coords.shape, n))
    if not np.isfinite(coords).all():
        raise ConformerError("2D coordinates are not finite")
    return coords


def smi2_3Dcoords(smi, cnt=N_3D_SLOTS, max_try=MAX_TRY, max_iteration=MAX_ITERATIONS, seed_start=0):
    """Up to `cnt` MMFF-relaxed ETKDGv3 conformers. Returns (list, stats).

    Follows LUMI `smi2_3Dcoords`: attempt i uses randomSeed = i, the fast
    parameter set first, and on an embedding failure (-1) a retry that embeds
    the heavy-atom molecule and adds hydrogens with coordinates. Unlike LUMI,
    the fallback 2D filling is left to the caller so it can be accounted for.
    """
    from rdkit import Chem
    from rdkit.Chem import AllChem

    mol = Chem.MolFromSmiles(smi)
    if mol is None:
        raise ConformerError("RDKit cannot parse/sanitize SMILES: {!r}".format(smi))
    mol = AllChem.AddHs(mol)
    n_atoms = mol.GetNumAtoms()

    ps = AllChem.ETKDGv3()
    ps.maxIterations = max_iteration
    ps_fast = AllChem.ETKDGv3()

    out = []
    stats = {"attempts": 0, "embed_failed": 0, "mmff_failed": 0, "exceptions": 0,
             "retry_heavy_then_addhs": 0}
    try_num = 0
    while len(out) < cnt and try_num < max_try:
        seed = seed_start + try_num        # LUMI: seed = try_num (seed_start 0, see D6)
        try_num += 1
        stats["attempts"] += 1
        ps.randomSeed = seed
        ps_fast.randomSeed = seed
        coords = None
        try:
            res = AllChem.EmbedMolecule(mol, ps_fast)
            if res == 0:
                try:
                    AllChem.MMFFOptimizeMolecule(mol)
                    coords = mol.GetConformer().GetPositions()
                except Exception:
                    stats["mmff_failed"] += 1
                    continue
            elif res == -1:
                stats["retry_heavy_then_addhs"] += 1
                mol_tmp = Chem.MolFromSmiles(smi)
                AllChem.EmbedMolecule(mol_tmp, ps)
                mol_tmp = AllChem.AddHs(mol_tmp, addCoords=True)
                try:
                    AllChem.MMFFOptimizeMolecule(mol_tmp)
                    coords = mol_tmp.GetConformer().GetPositions()
                except Exception:
                    stats["mmff_failed"] += 1
                    continue
            else:
                stats["embed_failed"] += 1
                continue
        except Exception:
            stats["exceptions"] += 1
            continue
        if coords is None:
            stats["embed_failed"] += 1
            continue
        coords = np.asarray(coords, dtype=np.float32)
        if coords.shape != (n_atoms, 3) or not np.isfinite(coords).all():
            stats["embed_failed"] += 1
            continue
        out.append(coords.copy())      # D1: copy out before the next attempt
    stats["n_3d_success"] = len(out)
    return out, stats


def n_distinct(coord_list, tol=1e-3):
    """How many arrays in `coord_list` are distinct within `tol` (RMS)."""
    kept = []
    for c in coord_list:
        if not any(c.shape == k.shape and float(np.sqrt(((c - k) ** 2).mean())) <= tol for k in kept):
            kept.append(c)
    return len(kept)


def smi2coords_pretrain(smi, n_3d=N_3D_SLOTS, store_2d=True, max_try=MAX_TRY,
                        max_iteration=MAX_ITERATIONS, max_atoms_for_3d=MAX_ATOMS_FOR_3D,
                        seed_start=0):
    """Build one HEART/LUMI pretraining record for `smi`.

    Returns (record, stats). The record is
        {"smi": smi, "atoms": [symbols with H], "coordinates": [ (N,3) float32 ]}
    with `n_3d` 3D slots (2D-filled when 3D failed) plus, if `store_2d`, one
    trailing stored 2D conformer, exactly like LUMI's `smi2coords_pretrain`.
    `stats` records the 3D/2D accounting of D3.
    """
    from rdkit import Chem
    from rdkit.Chem import AllChem

    _quiet()
    mol = Chem.MolFromSmiles(smi)
    if mol is None:
        raise ConformerError("RDKit cannot parse/sanitize SMILES: {!r}".format(smi))
    mol_h = AllChem.AddHs(mol)
    atoms = [a.GetSymbol() for a in mol_h.GetAtoms()]
    n_atoms = len(atoms)

    stats = {"n_atoms": n_atoms, "n_heavy_atoms": mol.GetNumHeavyAtoms(),
             "oversized": n_atoms > max_atoms_for_3d}
    if n_atoms > max_atoms_for_3d:
        twod = smi2_2Dcoords(smi)
        coords = [twod.copy() for _ in range(n_3d + (1 if store_2d else 0))]
        is_3d = [False] * len(coords)
        stats.update({"attempts": 0, "embed_failed": 0, "mmff_failed": 0, "exceptions": 0,
                      "retry_heavy_then_addhs": 0, "n_3d_success": 0,
                      "n_2d_filled": n_3d, "n_distinct_3d": 0})
    else:
        coords, s = smi2_3Dcoords(smi, n_3d, max_try, max_iteration, seed_start)
        stats.update(s)
        stats["n_distinct_3d"] = n_distinct(coords)
        is_3d = [True] * len(coords)
        n_missing = n_3d - len(coords)
        if n_missing > 0:
            twod = smi2_2Dcoords(smi)
            coords.extend(twod.copy() for _ in range(n_missing))
            is_3d.extend([False] * n_missing)
        stats["n_2d_filled"] = n_missing
        if store_2d:
            coords.append(smi2_2Dcoords(smi))
            is_3d.append(False)

    expected = n_3d + (1 if store_2d else 0)
    if len(coords) != expected:
        raise ConformerError("built {} coordinate slots, expected {}".format(len(coords), expected))
    for i, c in enumerate(coords):           # D4
        if c.shape != (n_atoms, 3):
            raise ConformerError("conformer {} has shape {}, expected ({}, 3)".format(i, c.shape, n_atoms))
        if c.dtype != np.float32:
            raise ConformerError("conformer {} has dtype {}, expected float32".format(i, c.dtype))
        if not np.isfinite(c).all():
            raise ConformerError("conformer {} is not finite".format(i))

    stats["n_coordinate_slots"] = len(coords)
    stats["stored_2d"] = bool(store_2d)
    stats["is_3d"] = is_3d
    record = {"smi": smi, "atoms": atoms, "coordinates": coords}
    return record, stats
