#!/usr/bin/env python
"""Assign whole lipid shards to the train and valid splits.

    python -m lipid_library.splits LMDB_DIR [--valid-fraction 0.002 | --valid-shards K |
                                   --valid-shard-ids 3,7] [--split-seed 1]
                                   [--split-method stratified-random|random|last]
                                   [--reagent-report all|valid|none]
                                   [--allow-smoke] [--allow-smoke-overlap]

Whole shards are assigned, never individual records, so no molecule can
appear in both splits. The result is LMDB_DIR/splits.json with LMDB_DIR-relative
paths, which the continual task resolves against the directory holding it,
plus LMDB_DIR/split_report.json (validation fraction, combination-index
dispersion and reagent-ID distribution per split).

v2 review P1 (representative validation). Shards are cut from the enumeration
in mixed-radix combination order with the AMINE as the most significant digit,
so the last shards contain only the last amines. Revision 2 took the last
`--valid-shards` shards, i.e. a biased validation set. Now:

  * `stratified-random` (default): the shard list (combination order) is cut
    into K contiguous strata of near-equal size and ONE shard is drawn from
    each stratum. The validation shards are therefore spread over the whole
    combination-index range (every amine block region), and the selection
    is reproducible from `--split-seed`;
  * `random`: K shards drawn uniformly without stratification;
  * `last`: revision-2 behaviour, kept only for comparison; marked
    `"representative": false`.

The draw uses sha256("<seed>:<shard id>") ranks, not Python's RNG, so it is
identical on every Python/NumPy version. K = --valid-shards, or
round(--valid-fraction x n_shards) (at least 1, at most n_shards - 1).

What this split is NOT: a scaffold or reagent hold-out. Validation molecules
share building blocks with training molecules (split_report.json shows how
much); it measures fit to the library distribution, not generalisation to
unseen reagents. A reagent hold-out would be a different scientific choice.

Fail-closed rules (review fixes P0-1 and "finalization safety"):
  * manifest.json must exist and say `"complete": true` (only a successful
    `lmdb_writer --finalize` writes it);
  * a smoke dataset (--limit or partial enumeration) is refused unless
    --allow-smoke, and the split is then marked `"smoke": true`;
  * the validation split must not be empty;
  * train and valid must be disjoint (LMDB paths and combination-index ranges);
  * a single shard (which would have to serve as both train and valid) is
    refused unless --allow-smoke-overlap, and such a split is always smoke.
"""
import argparse
import hashlib
import json
import logging
import os
import sys

from . import FORMAT_VERSION, io_utils
from .building_blocks import ROLE_ORDER

logger = logging.getLogger(__name__)

DEFAULT_VALID_FRACTION = 0.002          # ~6 of ~3,050 shards, ~30k records for the full library
SPLIT_METHODS = ("stratified-random", "random", "last")
SPLIT_KIND_NOTE = ("random whole-shard split (stratified over combination-index order); NOT a "
                   "scaffold or reagent hold-out: validation molecules share building blocks "
                   "with training molecules")


class SplitError(ValueError):
    pass


def _rank(seed, shard_id):
    return hashlib.sha256("{}:{}".format(seed, shard_id).encode("ascii")).hexdigest()


def _strata(items, k):
    """`items` cut into k contiguous, near-equal groups (like numpy.array_split)."""
    n = len(items)
    q, r = divmod(n, k)
    out, start = [], 0
    for i in range(k):
        size = q + (1 if i < r else 0)
        out.append(items[start:start + size])
        start += size
    return out


def select_valid_shards(ids, k, seed=1, method="stratified-random"):
    """Deterministic choice of k validation shard ids out of `ids` (combination order)."""
    if method not in SPLIT_METHODS:
        raise SplitError("unknown --split-method {!r} (one of {})".format(method, SPLIT_METHODS))
    ids = list(ids)
    if not 0 < k < len(ids):
        raise SplitError("cannot choose {} validation shard(s) out of {}".format(k, len(ids)))
    if method == "last":
        return sorted(ids[len(ids) - k:])
    if method == "random":
        return sorted(sorted(ids, key=lambda i: _rank(seed, i))[:k])
    return sorted(min(group, key=lambda i: _rank(seed, i)) for group in _strata(ids, k))


def _n_valid(n_shards, valid_shards, valid_fraction):
    if valid_shards is not None:
        k = int(valid_shards)
    else:
        if not 0.0 < float(valid_fraction) < 1.0:
            raise SplitError("--valid-fraction must be in (0, 1), got {}".format(valid_fraction))
        k = int(round(float(valid_fraction) * n_shards))
        k = max(1, k)
    return min(k, n_shards - 1)


def reagent_distribution(lmdb_dir, shards):
    """{role: {reagent id: n records}} over the records.csv.gz of `shards`."""
    counts = {role: {} for role in ROLE_ORDER}
    unparsed = 0
    for s in shards:
        path = os.path.join(lmdb_dir, s["dir"], "records.csv.gz")
        for row in io_utils.read_gz_csv(path):
            parts = row["combo_id"].split("-")
            if len(parts) != len(ROLE_ORDER):
                unparsed += 1
                continue
            for role, rid in zip(ROLE_ORDER, parts):
                counts[role][rid] = counts[role].get(rid, 0) + 1
    return counts, unparsed


def _quantiles(values, qs=(0.0, 0.25, 0.5, 0.75, 1.0)):
    v = sorted(values)
    if not v:
        return {}
    return {str(q): v[min(len(v) - 1, int(round(q * (len(v) - 1))))] for q in qs}


def split_report(lmdb_dir, manifest, by_id, train_ids, valid_ids, reagents="all"):
    """Validation fraction, dispersion over combination-index space, reagent coverage."""
    all_first = [s["first_combo_index"] for s in manifest["shards"] if s.get("first_combo_index") is not None]
    all_last = [s["last_combo_index"] for s in manifest["shards"] if s.get("last_combo_index") is not None]
    lo, hi = (min(all_first), max(all_last)) if all_first and all_last else (None, None)

    def position(i):
        s = by_id[i]
        if lo is None or hi == lo or s.get("first_combo_index") is None:
            return None
        mid = 0.5 * (s["first_combo_index"] + s["last_combo_index"])
        return round((mid - lo) / float(hi - lo), 6)

    n_train = sum(by_id[i]["n_records"] for i in train_ids)
    n_valid = sum(by_id[i]["n_records"] for i in valid_ids)
    positions = [p for p in (position(i) for i in valid_ids) if p is not None]
    report = {
        "n_shards": {"train": len(train_ids), "valid": len(valid_ids)},
        "n_records": {"train": n_train, "valid": n_valid},
        "valid_fraction_records": round(n_valid / float(n_train + n_valid), 6) if n_train + n_valid else None,
        "valid_fraction_shards": round(len(valid_ids) / float(len(train_ids) + len(valid_ids)), 6),
        "valid_combo_index_positions": positions,
        "valid_combo_index_position_quantiles": _quantiles(positions),
        "valid_combo_index_ranges": [[by_id[i]["first_combo_index"], by_id[i]["last_combo_index"]]
                                     for i in valid_ids],
        "reagents": None,
    }
    if reagents == "none":
        return report
    sets = {"valid": valid_ids} if reagents == "valid" else {"train": train_ids, "valid": valid_ids}
    dist, unparsed = {}, 0
    for name, ids in sets.items():
        dist[name], u = reagent_distribution(lmdb_dir, [by_id[i] for i in ids])
        unparsed += u
    summary = {}
    for role in ROLE_ORDER:
        entry = {}
        for name in sets:
            counts = dist[name][role]
            total = sum(counts.values())
            entry[name] = {"n_distinct": len(counts),
                           "max_share": round(max(counts.values()) / float(total), 6) if total else None,
                           "counts": dict(sorted(counts.items()))}
        if "train" in sets:
            valid_ids_seen = set(dist["valid"][role])
            train_ids_seen = set(dist["train"][role])
            entry["valid_reagents_also_in_train"] = len(valid_ids_seen & train_ids_seen)
            entry["valid_reagents_not_in_train"] = sorted(valid_ids_seen - train_ids_seen)
            entry["fraction_of_train_reagents_seen_in_valid"] = (
                round(len(valid_ids_seen & train_ids_seen) / float(len(train_ids_seen)), 6)
                if train_ids_seen else None)
        summary[role] = entry
    report["reagents"] = summary
    report["n_unparsed_combo_ids"] = unparsed
    return report


def build_splits(lmdb_dir, valid_shards=None, valid_shard_ids=None, allow_smoke=False,
                 allow_smoke_overlap=False, valid_fraction=DEFAULT_VALID_FRACTION, split_seed=1,
                 split_method="stratified-random", with_report=False, reagents="all"):
    path = os.path.join(lmdb_dir, "manifest.json")
    if not os.path.isfile(path):
        raise SplitError("{}: no manifest.json; run `lmdb_writer --finalize` (it writes the manifest "
                         "only when every expected shard is present and verified)".format(lmdb_dir))
    with open(path, encoding="utf-8") as fh:
        manifest = json.load(fh)
    if manifest.get("complete") is not True:
        raise SplitError("{}: manifest is not complete".format(path))
    smoke = bool(manifest.get("smoke"))
    if smoke and not allow_smoke:
        raise SplitError("{}: this is a SMOKE dataset (--limit or a partial enumeration); pass "
                         "--allow-smoke for a local test, never for production".format(path))
    shards = sorted(manifest["shards"], key=lambda s: s["shard_id"])
    if not shards:
        raise SplitError("{}: the manifest lists no shards".format(lmdb_dir))
    ids = [s["shard_id"] for s in shards]
    if len(ids) != len(set(ids)):
        raise SplitError("{}: duplicate shard ids in the manifest".format(path))
    if valid_shards is not None and int(valid_shards) < 1:
        raise SplitError("the validation split is empty (--valid-shards {})".format(valid_shards))
    warnings = []
    method = split_method
    if len(shards) == 1:
        if not allow_smoke_overlap:
            raise SplitError("only one shard: train and valid would overlap; pass "
                             "--allow-smoke-overlap for a smoke test only")
        warnings.append("single shard used for train AND valid (smoke test only)")
        smoke = True
        method = "single-shard-overlap"
        train_ids, valid_ids = list(ids), list(ids)
    else:
        if valid_shard_ids is not None:
            unknown = sorted(set(valid_shard_ids) - set(ids))
            if unknown:
                raise SplitError("unknown shard id(s): {}".format(unknown))
            valid_ids = sorted(set(valid_shard_ids))
            method = "explicit"
        else:
            k = _n_valid(len(ids), valid_shards, valid_fraction)
            valid_ids = select_valid_shards(ids, k, split_seed, split_method)
        if method == "last":
            warnings.append("--split-method last: the validation shards are the end of the "
                            "combination order (last amines only), NOT representative")
        train_ids = [i for i in ids if i not in set(valid_ids)]
    by_id = {s["shard_id"]: s for s in shards}
    n_valid = sum(by_id[i]["n_records"] for i in valid_ids)
    if not valid_ids or n_valid == 0:
        raise SplitError("the validation split is empty")
    if not train_ids or sum(by_id[i]["n_records"] for i in train_ids) == 0:
        raise SplitError("the training split is empty")
    if len(shards) > 1:
        if set(train_ids) & set(valid_ids):
            raise SplitError("train and valid share shards {}".format(sorted(set(train_ids) & set(valid_ids))))
        ranges = {i: (by_id[i]["first_combo_index"], by_id[i]["last_combo_index"]) for i in ids}
        for v in valid_ids:
            for t in train_ids:
                a, b = ranges[v], ranges[t]
                if None not in a + b and not (a[1] < b[0] or b[1] < a[0]):
                    raise SplitError("shards {} (valid) and {} (train) overlap in combination "
                                     "indexes".format(v, t))
    n_train = sum(by_id[i]["n_records"] for i in train_ids)
    splits = {
        "format_version": FORMAT_VERSION,
        "complete": True,
        "smoke": smoke,
        "manifest_sha256": io_utils.sha256_file(path),
        "config_fingerprint": manifest.get("config_fingerprint"),
        "lmdb_dir": os.path.abspath(lmdb_dir),
        "coordinate_slots_per_record": manifest["coordinate_slots_per_record"],
        "stored_2d_conformer": manifest["stored_2d_conformer"],
        "train": [by_id[i]["lmdb"] for i in train_ids],
        "valid": [by_id[i]["lmdb"] for i in valid_ids],
        "n_records": {"train": n_train, "valid": n_valid},
        "shard_ids": {"train": train_ids, "valid": valid_ids},
        "split_method": method,
        "split_seed": split_seed if method in ("stratified-random", "random") else None,
        "representative": method in ("stratified-random", "random", "explicit"),
        "split_kind": SPLIT_KIND_NOTE,
        "valid_fraction_records": round(n_valid / float(n_train + n_valid), 6) if len(shards) > 1 else None,
        "warnings": warnings,
    }
    if not with_report:
        return splits
    return splits, split_report(lmdb_dir, manifest, by_id, train_ids, valid_ids, reagents)


def load_splits(path, split):
    """Absolute LMDB paths of `split` from a splits.json file."""
    with open(path, encoding="utf-8") as fh:
        splits = json.load(fh)
    if split not in splits:
        raise KeyError("{}: no {!r} split (have {})".format(
            path, split, [k for k in ("train", "valid") if k in splits]))
    base = os.path.dirname(os.path.abspath(path))
    out = [os.path.normpath(os.path.join(base, rel)) for rel in splits[split]]
    missing = [p for p in out if not os.path.isfile(p)]
    if missing:
        raise FileNotFoundError("{}: missing LMDB file(s): {}".format(path, missing))
    return out, splits


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("lmdb_dir")
    size = ap.add_mutually_exclusive_group()
    size.add_argument("--valid-fraction", type=float, default=DEFAULT_VALID_FRACTION,
                      help="fraction of shards for validation (default %(default)s; >= 1 shard)")
    size.add_argument("--valid-shards", type=int, default=None, help="number of validation shards")
    size.add_argument("--valid-shard-ids", default=None, help="explicit comma-separated shard ids")
    ap.add_argument("--split-seed", type=int, default=1)
    ap.add_argument("--split-method", choices=SPLIT_METHODS, default="stratified-random")
    ap.add_argument("--reagent-report", choices=("all", "valid", "none"), default="all",
                    help="reagent-ID distribution in split_report.json: 'all' reads every shard's "
                         "records.csv.gz once (~15M rows for the full library)")
    ap.add_argument("--allow-smoke", action="store_true", help="accept a smoke (limited) dataset")
    ap.add_argument("--allow-smoke-overlap", action="store_true",
                    help="accept a single shard used for train and valid (smoke only)")
    ns = ap.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    ids = None
    if ns.valid_shard_ids:
        ids = [int(x) for x in ns.valid_shard_ids.split(",") if x.strip()]
    path = os.path.join(ns.lmdb_dir, "splits.json")
    report_path = os.path.join(ns.lmdb_dir, "split_report.json")
    try:
        splits, report = build_splits(ns.lmdb_dir, ns.valid_shards, ids, ns.allow_smoke,
                                      ns.allow_smoke_overlap, ns.valid_fraction, ns.split_seed,
                                      ns.split_method, with_report=True, reagents=ns.reagent_report)
    except SplitError as exc:
        for p in (path, report_path):
            if os.path.exists(p):
                os.remove(p)
        raise SystemExit("ERROR: {}".format(exc))
    report.update({"split_method": splits["split_method"], "split_seed": splits["split_seed"],
                   "split_kind": splits["split_kind"], "manifest_sha256": splits["manifest_sha256"]})
    io_utils.atomic_write_json(report_path, report)
    io_utils.atomic_write_json(path, splits)
    logger.info("split       : %s (seed %s) -- %s", splits["split_method"], splits["split_seed"],
                splits["split_kind"])
    logger.info("train: %d shards, %d records", len(splits["train"]), splits["n_records"]["train"])
    logger.info("valid: %d shards, %d records (%.4f%% of records), shard ids %s",
                len(splits["valid"]), splits["n_records"]["valid"],
                100.0 * (report["valid_fraction_records"] or 0), splits["shard_ids"]["valid"])
    logger.info("valid positions in combination order (0..1): %s", report["valid_combo_index_positions"])
    if report.get("reagents"):
        for role, entry in report["reagents"].items():
            logger.info("   %-10s valid uses %d distinct reagent(s)%s", role, entry["valid"]["n_distinct"],
                        "" if "train" not in entry else ", train {}".format(entry["train"]["n_distinct"]))
    for w in splits["warnings"]:
        logger.warning("WARNING: %s", w)
    logger.info("wrote %s and %s%s", path, report_path, " [SMOKE]" if splits["smoke"] else "")
    return 0


if __name__ == "__main__":
    sys.exit(main())
