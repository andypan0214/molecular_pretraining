#!/usr/bin/env python
"""Record-level QC of lipid (or general) pretraining LMDBs. Read-only.

    python -m lipid_library.validate_lmdb LMDB [LMDB ...] [--dict dict.txt]
    python -m lipid_library.validate_lmdb --splits LMDB_DIR/splits.json --split train
    python -m lipid_library.validate_lmdb --manifest LMDB_DIR/manifest.json --sample 200

Checks, per LMDB (on `--sample` records per file, or all of them with
`--all`):

  key convention   every key b'0'..b'N-1' present, nothing else, which is
                   what HEART's LMDBDataset requires
  record keys      `smi`, `atoms`, `coordinates` present; `target` reported
                   if present (HEART's pretraining loader ignores it)
  alignment        every conformer is (n_atoms, 3), float32 and finite
  SMILES           parses and sanitizes; `AddHs` reproduces `atoms` in order,
                   which is what the training-time 2D conformer relies on
  vocabulary       every atom symbol is in dict.txt
  atom count       atoms left after the --only-polar hydrogen policy (heavy
                   atoms for 0, the HEART/LUMI setting) against --max-atoms
  2D policy        the number of stored coordinate slots per record, and the
                   count after the training-time 2D conformer is added

Exit code 0 only if every check passed. Nothing is written unless --json-out
is given.
"""
import argparse
import collections
import json
import logging
import os
import pickle
import sys

logger = logging.getLogger(__name__)


def _dict_symbols(path):
    out = set()
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            tok = line.split()
            if tok:
                out.add(tok[0])
    return out


def check_lmdb(path, dict_symbols=None, sample=200, check_all=False, max_atoms=256,
               expect_slots=None, only_polar=0):
    """QC one LMDB. `max_atoms` is compared with the atom count that survives the
    training hydrogen policy, exactly like lmdb_writer: --only-polar 0 removes
    every H before CroppingDataset (heavy atoms counted), -1 keeps all atoms,
    1 keeps polar H (counted conservatively as all atoms)."""
    import lmdb
    import numpy as np
    from rdkit import Chem, RDLogger
    from rdkit.Chem import AllChem

    RDLogger.DisableLog("rdApp.*")
    out = {"lmdb": path, "problems": [], "n_records": 0, "n_checked": 0,
           "slot_counts": {}, "elements": {}, "max_n_atoms": 0,
           "n_smiles_unparsable": 0, "n_addhs_mismatch": 0, "n_has_target": 0,
           "n_3d_like": 0, "n_flat": 0}
    env = lmdb.open(path, subdir=False, readonly=True, lock=False, readahead=False,
                    meminit=False, max_readers=16)
    try:
        with env.begin() as txn:
            n = txn.stat()["entries"]
            out["n_records"] = n
            if n == 0:
                out["problems"].append("the LMDB is empty")
                return out
            # key convention: HEART reads key f"{idx}" for idx in 0..N-1
            missing = [i for i in (0, n - 1) if txn.get(str(i).encode("ascii")) is None]
            if missing:
                out["problems"].append("key(s) {} missing: keys are not the contiguous "
                                       "ASCII integers 0..{}".format(missing, n - 1))
            if check_all or n <= sample:
                indexes = range(n)
            else:
                step = max(1, n // sample)
                indexes = list(range(0, n, step))[:sample]
            non_integer = 0
            if check_all:
                for key in txn.cursor().iternext(values=False):
                    try:
                        k = int(key.decode("ascii"))
                    except (ValueError, UnicodeDecodeError):
                        non_integer += 1
                        continue
                    if not 0 <= k < n:
                        non_integer += 1
                if non_integer:
                    out["problems"].append("{} key(s) are not ASCII integers in 0..{}".format(
                        non_integer, n - 1))
            for i in indexes:
                raw = txn.get(str(i).encode("ascii"))
                if raw is None:
                    out["problems"].append("key b'{}' missing".format(i))
                    continue
                rec = pickle.loads(raw)
                out["n_checked"] += 1
                for field in ("smi", "atoms", "coordinates"):
                    if field not in rec:
                        out["problems"].append("record {}: missing field {!r}".format(i, field))
                if not {"smi", "atoms", "coordinates"} <= set(rec):
                    continue
                if "target" in rec:
                    out["n_has_target"] += 1
                atoms = list(rec["atoms"])
                coords = rec["coordinates"]
                out["max_n_atoms"] = max(out["max_n_atoms"], len(atoms))
                n_policy = sum(a != "H" for a in atoms) if only_polar == 0 else len(atoms)
                out["max_n_atoms_after_h_policy"] = max(out.get("max_n_atoms_after_h_policy", 0), n_policy)
                if max_atoms and n_policy > max_atoms:
                    out["problems"].append(
                        "record {}: {} atoms after the --only-polar {} hydrogen policy exceeds "
                        "--max-atoms {} (training would crop it)".format(i, n_policy, only_polar, max_atoms))
                slots = len(coords)
                out["slot_counts"][str(slots)] = out["slot_counts"].get(str(slots), 0) + 1
                for j, c in enumerate(coords):
                    c = np.asarray(c)
                    if c.shape != (len(atoms), 3):
                        out["problems"].append("record {} conformer {}: shape {} != ({}, 3)".format(
                            i, j, c.shape, len(atoms)))
                        continue
                    if c.dtype != np.float32:
                        out["problems"].append("record {} conformer {}: dtype {} != float32".format(
                            i, j, c.dtype))
                    if not np.isfinite(c).all():
                        out["problems"].append("record {} conformer {}: not finite".format(i, j))
                    if float(np.abs(c[:, 2]).max()) < 1e-6:
                        out["n_flat"] += 1
                    else:
                        out["n_3d_like"] += 1
                for a in atoms:
                    out["elements"][a] = out["elements"].get(a, 0) + 1
                if dict_symbols is not None:
                    unsupported = sorted({a for a in atoms if a not in dict_symbols})
                    if unsupported:
                        out["problems"].append("record {}: atom symbol(s) not in dict.txt: {}".format(
                            i, ",".join(unsupported)))
                mol = Chem.MolFromSmiles(rec["smi"]) if isinstance(rec["smi"], str) else None
                if mol is None:
                    out["n_smiles_unparsable"] += 1
                    out["problems"].append("record {}: RDKit cannot parse/sanitize its SMILES".format(i))
                else:
                    symbols = [a.GetSymbol() for a in AllChem.AddHs(mol).GetAtoms()]
                    if symbols != atoms:
                        out["n_addhs_mismatch"] += 1
                        out["problems"].append(
                            "record {}: AddHs(SMILES) atoms differ from the record "
                            "({} vs {} atoms)".format(i, len(symbols), len(atoms)))
    finally:
        env.close()
    if expect_slots is not None:
        wrong = {k: v for k, v in out["slot_counts"].items() if int(k) != expect_slots}
        if wrong:
            out["problems"].append("stored coordinate slots {} differ from the expected {}".format(
                wrong, expect_slots))
    out["slots_at_training_time"] = {str(int(k) + 1): v for k, v in out["slot_counts"].items()}
    return out


def is_flat(coords, tol=1e-6):
    """A coordinate slot is 2D-like when every z coordinate is (numerically) zero."""
    import numpy as np

    c = np.asarray(coords)
    return bool(c.size) and float(np.abs(c[:, 2]).max()) < tol


def slot_profile(path, sample=64):
    """Read-only conformer-slot profile of an integer-keyed LMDB.

    Returns {"n_records", "n_checked", "profiles": {"<stored>/<flat>": count}},
    where <stored> is len(coordinates) and <flat> the number of 2D-like slots,
    from `sample` records spread evenly over the whole LMDB (first, last and
    in between, so a 150 GB file costs `sample` random reads).
    """
    import lmdb

    env = lmdb.open(path, subdir=False, readonly=True, lock=False, readahead=False,
                    meminit=False, max_readers=16)
    out = {"lmdb": path, "n_records": 0, "n_checked": 0, "profiles": {}}
    try:
        with env.begin() as txn:
            n = txn.stat()["entries"]
            out["n_records"] = n
            if n == 0:
                return out
            k = min(sample, n)
            idx = sorted({int(round(i * (n - 1) / max(1, k - 1))) for i in range(k)})
            for i in idx:
                raw = txn.get(str(i).encode("ascii"))
                if raw is None:
                    raise ValueError("{}: key b'{}' missing (not integer-keyed?)".format(path, i))
                coords = pickle.loads(raw)["coordinates"]
                key = "{}/{}".format(len(coords), sum(is_flat(c) for c in coords))
                out["profiles"][key] = out["profiles"].get(key, 0) + 1
                out["n_checked"] += 1
    finally:
        env.close()
    return out


def runtime_view(profile_key, runtime_2d=True):
    """(slots, P(2D)) a record sees in training after HEART's Add2DConformerDataset."""
    stored, flat = (int(x) for x in profile_key.split("/"))
    slots = stored + (1 if runtime_2d else 0)
    flat += 1 if runtime_2d else 0
    return slots, flat / slots


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("lmdb", nargs="*", help="LMDB file(s) to check")
    ap.add_argument("--splits", default=None, help="splits.json written by lipid_library.splits")
    ap.add_argument("--split", default="train")
    ap.add_argument("--manifest", default=None, help="manifest.json written by lipid_library.lmdb_writer")
    ap.add_argument("--dict", dest="dict_path", default=None)
    ap.add_argument("--sample", type=int, default=200, help="records per LMDB (default 200)")
    ap.add_argument("--all", action="store_true", help="check every record and every key")
    ap.add_argument("--max-atoms", type=int, default=256)
    ap.add_argument("--only-polar", type=int, default=0, choices=[-1, 0, 1],
                    help="training hydrogen policy used for the --max-atoms check (HEART/LUMI: 0)")
    ap.add_argument("--expect-slots", type=int, default=None,
                    help="required number of stored coordinate slots per record")
    ap.add_argument("--json-out", default=None)
    ns = ap.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(message)s")

    paths = list(ns.lmdb)
    if ns.splits:
        from .splits import load_splits

        more, meta = load_splits(ns.splits, ns.split)
        paths.extend(more)
        logger.info("splits      : %s split %r -> %d LMDB(s)", ns.splits, ns.split, len(more))
    if ns.manifest:
        with open(ns.manifest, encoding="utf-8") as fh:
            manifest = json.load(fh)
        base = os.path.dirname(os.path.abspath(ns.manifest))
        paths.extend(os.path.normpath(os.path.join(base, s["lmdb"])) for s in manifest["shards"])
    if not paths:
        raise SystemExit("no LMDB given (pass files, --splits or --manifest)")

    dict_symbols = _dict_symbols(ns.dict_path) if ns.dict_path else None
    results, n_problems = [], 0
    totals = collections.Counter()
    for p in paths:
        r = check_lmdb(p, dict_symbols, ns.sample, ns.all, ns.max_atoms, ns.expect_slots, ns.only_polar)
        results.append(r)
        n_problems += len(r["problems"])
        totals["n_records"] += r["n_records"]
        totals["n_checked"] += r["n_checked"]
        verdict = "PASS" if not r["problems"] else "FAIL"
        logger.info("%s %s: %d records, %d checked, slots %s, max atoms %d",
                    verdict, os.path.basename(os.path.dirname(p)) + "/" + os.path.basename(p),
                    r["n_records"], r["n_checked"], json.dumps(r["slot_counts"]), r["max_n_atoms"])
        for problem in r["problems"][:10]:
            logger.info("   %s", problem)
        if len(r["problems"]) > 10:
            logger.info("   ... and %d more", len(r["problems"]) - 10)

    logger.info("total: %d LMDB(s), %d records, %d checked, %d problem(s)",
                len(paths), totals["n_records"], totals["n_checked"], n_problems)
    if ns.json_out:
        from . import io_utils

        io_utils.atomic_write_json(ns.json_out, {"results": results, "n_problems": n_problems})
        logger.info("wrote %s", ns.json_out)
    return 0 if n_problems == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
