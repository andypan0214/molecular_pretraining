#!/usr/bin/env python
"""Global duplicate detection over every enumerated product chunk.

    python -m lipid_library.dedup PRODUCTS_DIR -o DEDUP_DIR

The combination count and the number of distinct products are not the same
number: two different reagent quadruples can give the same product (symmetric
reagents, or assumption A1 collapsing a multi-site reagent). This tool finds
those groups without holding the whole library in memory:

  pass 1  each product chunk is read, sorted by (product SMILES, combo_index)
          and written to a temporary gzip file (chunk-sized memory only);
  pass 2  the sorted chunks are merged with heapq.merge, so equal SMILES meet
          as neighbours and duplicate groups are detected in one streaming
          pass.

Outputs (all gzip CSV, deterministic):

    DEDUP_DIR/duplicates.csv.gz           kept_combo_index, dropped_combo_index, smiles
    DEDUP_DIR/drop_combo_indexes.csv.gz   combo_index to skip, ascending
    DEDUP_DIR/summary.json                counts

The lowest combination index of each group is kept, so the result does not
depend on chunk order or on how the work was sharded.
"""
import argparse
import csv
import gzip
import heapq
import json
import logging
import os
import sys
import tempfile

from . import io_utils
from .lmdb_writer import product_chunks

logger = logging.getLogger(__name__)


def _sorted_chunk_file(path, tmp_dir, i):
    rows = []
    for row in io_utils.read_gz_csv(path):
        rows.append((row["product_smiles"], int(row["combo_index"])))
    rows.sort()
    out = os.path.join(tmp_dir, "sorted-{:06d}.csv.gz".format(i))
    with gzip.open(out, "wt", encoding="utf-8", newline="") as fh:
        w = csv.writer(fh, lineterminator="\n")
        for smi, idx in rows:
            w.writerow([smi, idx])
    return out, len(rows)


def _iter_sorted(path):
    with gzip.open(path, "rt", encoding="utf-8", newline="") as fh:
        for smi, idx in csv.reader(fh):
            yield smi, int(idx)


def run(products_dir, out_dir, tmp_dir=None, require_complete=False):
    """Detect duplicates. With `require_complete` (the SLURM stage), the enumeration
    must have a verified enumeration_complete.json (review fix P0-1)."""
    os.makedirs(out_dir, exist_ok=True)
    enum_fp = None
    complete_path = os.path.join(products_dir, "enumeration_complete.json")
    if require_complete or os.path.isfile(complete_path):
        from .enumerate_library import load_complete

        enum_fp = load_complete(products_dir)["config_fingerprint"]
    chunks = product_chunks(products_dir)
    if not chunks:
        raise SystemExit("no products-*.csv.gz found under {}".format(products_dir))
    owned_tmp = tmp_dir is None
    tmp_dir = tmp_dir or tempfile.mkdtemp(prefix="lipid-dedup-")
    sorted_files, n_total = [], 0
    try:
        for i, path in enumerate(chunks):
            f, n = _sorted_chunk_file(path, tmp_dir, i)
            sorted_files.append(f)
            n_total += n
        logger.info("pass 1: %d chunks, %d products", len(chunks), n_total)

        dup_writer = io_utils.AtomicGzCsvWriter(
            os.path.join(out_dir, "duplicates.csv.gz"),
            ["kept_combo_index", "dropped_combo_index", "smiles"])
        drop_writer = io_utils.AtomicGzCsvWriter(
            os.path.join(out_dir, "drop_combo_indexes.csv.gz"), ["combo_index"])
        drops = []
        n_unique, n_groups = 0, 0
        try:
            current_smi, kept_index, group_n = None, None, 0
            for smi, idx in heapq.merge(*(_iter_sorted(f) for f in sorted_files)):
                if smi != current_smi:
                    if group_n > 1:
                        n_groups += 1
                    current_smi, kept_index, group_n = smi, idx, 1
                    n_unique += 1
                    continue
                group_n += 1
                dup_writer.writerow([kept_index, idx, smi])
                drops.append(idx)
            if group_n > 1:
                n_groups += 1
            for idx in sorted(drops):
                drop_writer.writerow([idx])
        except BaseException:
            dup_writer.close(commit=False)
            drop_writer.close(commit=False)
            raise
        n_dropped = dup_writer.n
        dup_writer.close()
        drop_writer.close()
    finally:
        if owned_tmp:
            for f in sorted_files:
                try:
                    os.remove(f)
                except OSError:
                    pass
            try:
                os.rmdir(tmp_dir)
            except OSError:
                pass

    summary = {
        "n_product_rows": n_total,
        "n_unique_products": n_unique,
        "n_duplicate_rows": n_dropped,
        "n_duplicate_groups": n_groups,
        "n_chunks": len(chunks),
    }
    provenance_info = {
        "enumeration_fingerprint": enum_fp,
        "drop_list_sha256": io_utils.sha256_file(os.path.join(out_dir, "drop_combo_indexes.csv.gz")),
    }
    io_utils.atomic_write_json(os.path.join(out_dir, "summary.json"), {**summary, **provenance_info})
    return summary


def load_drop_set(path):
    """Read drop_combo_indexes.csv.gz as a sorted list of combination indexes."""
    out = [int(row["combo_index"]) for row in io_utils.read_gz_csv(path)]
    out.sort()
    return out


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("products_dir")
    ap.add_argument("-o", "--out-dir", required=True)
    ap.add_argument("--tmp-dir", default=None, help="where to put the sorted scratch files")
    ap.add_argument("--require-complete", action="store_true",
                    help="fail unless the enumeration has a verified enumeration_complete.json")
    ns = ap.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    try:
        summary = run(ns.products_dir, ns.out_dir, ns.tmp_dir, ns.require_complete)
    except Exception as exc:
        from .provenance import StaleOutputError

        if isinstance(exc, StaleOutputError):
            raise SystemExit("ERROR: {}".format(exc))
        raise
    logger.info("products %d | distinct %d | duplicate rows %d in %d groups",
                summary["n_product_rows"], summary["n_unique_products"],
                summary["n_duplicate_rows"], summary["n_duplicate_groups"])
    logger.info("wrote %s", json.dumps(sorted(os.listdir(ns.out_dir))))
    return 0


if __name__ == "__main__":
    sys.exit(main())
