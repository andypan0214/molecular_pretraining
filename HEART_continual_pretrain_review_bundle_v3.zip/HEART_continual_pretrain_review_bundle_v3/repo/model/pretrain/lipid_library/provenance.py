"""Configuration fingerprints and output-directory locks (review fix P0-2).

Every stage that writes reusable outputs records the complete scientific
configuration it ran with (input-file hashes, reaction/conformer policy,
RDKit version, options) and its SHA-256 fingerprint:

  * once per output directory, in `<out>/<stage>_config.json`, created
    atomically and exclusively (safe for concurrent SLURM array tasks). A later
    run with a different fingerprint FAILS instead of reusing or mixing old
    outputs: use a new output directory for a new configuration;
  * in every chunk/shard receipt, so an individual output is only ever reused
    when its configuration and its exact inputs are unchanged.

Smoke runs (`--limit`, partial ranges) get a different fingerprint and are
marked `"smoke": true`, so they can never be finalised as a production
dataset (see lmdb_writer.finalize and splits.py).
"""
import hashlib
import json
import os
import platform

from . import FORMAT_VERSION


class StaleOutputError(RuntimeError):
    """Existing outputs were produced with a different configuration or input."""


def fingerprint(obj):
    return hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(",", ":"),
                                     default=str).encode("utf-8")).hexdigest()


def sha256_text(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def runtime_versions():
    import numpy
    import rdkit

    out = {"python": platform.python_version(), "rdkit": rdkit.__version__,
           "numpy": numpy.__version__, "format_version": FORMAT_VERSION}
    try:
        import lmdb

        out["lmdb"] = lmdb.__version__
    except ImportError:  # pragma: no cover
        pass
    return out


def lock_config(out_dir, stage, config):
    """Record `config` for `out_dir`, or verify it matches the recorded one.

    Returns the fingerprint. Raises StaleOutputError on a mismatch. The first
    writer wins atomically (O_EXCL), so concurrent array tasks cannot record
    two different configurations.
    """
    os.makedirs(out_dir, exist_ok=True)
    fp = fingerprint(config)
    path = os.path.join(out_dir, "{}_config.json".format(stage))
    payload = json.dumps({"stage": stage, "fingerprint": fp, "config": config},
                         indent=2, sort_keys=True, default=str) + "\n"
    try:
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL)
    except FileExistsError:
        with open(path, encoding="utf-8") as fh:
            recorded = json.load(fh)
        if recorded.get("fingerprint") != fp:
            changed = sorted(k for k in set(config) | set(recorded.get("config", {}))
                             if config.get(k) != recorded.get("config", {}).get(k))
            raise StaleOutputError(
                "{}: outputs in {} were produced with a different configuration "
                "(changed: {}). Refusing to reuse or mix them; use a new output "
                "directory.".format(stage, out_dir, ", ".join(changed) or "?"))
        return fp
    with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(payload)
    return fp


def read_config(out_dir, stage):
    path = os.path.join(out_dir, "{}_config.json".format(stage))
    if not os.path.isfile(path):
        return None
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)
