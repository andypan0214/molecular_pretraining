#!/usr/bin/env python
"""Parse and validate the LUMI lipid building-block sheet.

    python -m lipid_library.building_blocks INPUT.xlsx -o OUT_DIR [--sheet Sheet1]

Reads the ID/SMILES/Category sheet, validates every reagent with RDKit,
assigns each category a Ugi role, and writes:

    OUT_DIR/building_blocks.csv   one row per accepted reagent (role, canonical
                                  SMILES, n_sites, amine tier, atom counts)
    OUT_DIR/rejected.csv          every rejected reagent with its reason
    OUT_DIR/summary.json          counts per role, combination count, QC flags

The role order is fixed (amine, isocyanide, aldehyde, acid) and reagents are
sorted by (role, numeric suffix of ID) so the combination index is stable
across machines and runs. Nothing is written outside OUT_DIR.
"""
import argparse
import csv
import json
import logging
import os
import sys

from . import io_utils, ugi

logger = logging.getLogger(__name__)

# Category label in the sheet -> Ugi role. Matching is case-insensitive and
# ignores surrounding whitespace; unknown categories are a hard error.
CATEGORY_ROLE = {
    "amines": "amine",
    "amine": "amine",
    "isocyanides": "isocyanide",
    "isocyanide": "isocyanide",
    "lipid aldehydes": "aldehyde",
    "aldehydes": "aldehyde",
    "lipid carboxylic acids": "acid",
    "carboxylic acids": "acid",
}
ROLE_ORDER = ["amine", "isocyanide", "aldehyde", "acid"]
# LUMI-style ID prefix per role (A=amine, B=isocyanide, C=aldehyde, D=acid).
ROLE_PREFIX = {"amine": "A", "isocyanide": "B", "aldehyde": "C", "acid": "D"}
# Expected counts from the task specification; a mismatch is reported, not fatal.
EXPECTED_COUNTS = {"amine": 64, "isocyanide": 62, "aldehyde": 64, "acid": 61}

BB_FIELDS = [
    "role", "role_index", "id", "id_prefix", "id_number", "category",
    "input_smiles", "canonical_smiles", "n_sites", "site_tier",
    "num_heavy_atoms", "num_atoms_with_h", "formal_charge", "elements",
    "n_unspecified_stereocentres", "n_specified_stereocentres", "n_stereo_bonds",
]
REJECT_FIELDS = ["row", "id", "category", "input_smiles", "reason"]


def _id_number(reagent_id):
    digits = "".join(ch for ch in reagent_id if ch.isdigit())
    return int(digits) if digits else -1


def read_table(path, sheet=None):
    """Return (rows, meta) where rows are dicts with ID/SMILES/Category keys."""
    ext = os.path.splitext(path)[1].lower()
    if ext in (".xlsx", ".xlsm"):
        sheet_names, used, raw = io_utils.read_xlsx_rows(path, sheet)
        if not raw:
            raise SystemExit("{}: sheet {!r} is empty".format(path, used))
        header = [c.strip() for c in raw[0]]
        rows = []
        for i, r in enumerate(raw[1:], start=2):
            if not any(str(c).strip() for c in r):
                continue
            padded = list(r) + [""] * (len(header) - len(r))
            rows.append({"__row__": i, **{header[j]: padded[j] for j in range(len(header))}})
        meta = {"source": os.path.abspath(path), "sheet_names": sheet_names, "sheet_used": used,
                "columns": header, "n_data_rows": len(rows),
                "source_sha256": io_utils.sha256_file(path)}
    elif ext == ".csv":
        with open(path, newline="", encoding="utf-8-sig") as fh:
            reader = csv.DictReader(fh)
            header = reader.fieldnames or []
            rows = [{"__row__": i, **r} for i, r in enumerate(reader, start=2)]
        meta = {"source": os.path.abspath(path), "sheet_names": [], "sheet_used": "",
                "columns": header, "n_data_rows": len(rows),
                "source_sha256": io_utils.sha256_file(path)}
    else:
        raise SystemExit("unsupported input extension: {}".format(ext))

    missing = [c for c in ("ID", "SMILES", "Category") if c not in meta["columns"]]
    if missing:
        raise SystemExit("{}: missing required column(s) {} (found {})".format(
            path, ", ".join(missing), meta["columns"]))
    return rows, meta


def rdkit_error(smi):
    """The exact RDKit parser/sanitizer message for a SMILES that fails to parse."""
    import contextlib
    import io

    from rdkit import Chem, RDLogger, rdBase

    RDLogger.EnableLog("rdApp.error")
    rdBase.LogToPythonStderr()
    buf = io.StringIO()
    try:
        with contextlib.redirect_stderr(buf):
            Chem.MolFromSmiles(smi)
    finally:
        RDLogger.DisableLog("rdApp.*")
    lines = [line.split("]", 1)[-1].strip() if line.startswith("[") else line.strip()
             for line in buf.getvalue().splitlines() if line.strip()]
    return " | ".join(lines) or "no RDKit message"


def correction_candidates(smi, error):
    """PROPOSED corrections for a SMILES with unclosed ring(s). Never applied.

    For each unclosed ring label d, the two minimal edits are tried: close it on
    the last atom ("...d") or on one appended carbon ("...Cd"). Every candidate
    that parses is returned with its formula, so a chemist can choose (or reject
    all of them). Other error types get no automatic proposal.
    """
    import re

    from rdkit import Chem
    from rdkit.Chem.rdMolDescriptors import CalcMolFormula

    if "unclosed ring" not in error:
        return []
    body = re.sub(r"\[[^\]]*\]", "", smi)                 # ignore digits inside brackets
    open_labels = [d for d in sorted(set(re.findall(r"%\d\d|\d", body))) if body.count(d) % 2 == 1]
    out = []
    for d in open_labels:
        for suffix in (d, "C" + d):
            cand = smi + suffix
            mol = Chem.MolFromSmiles(cand)
            if mol is not None:
                out.append({"candidate": cand, "canonical": Chem.MolToSmiles(mol),
                            "formula": CalcMolFormula(mol), "edit": "append '{}'".format(suffix)})
    return out


def reagent_issues(rejected):
    """Rows for reagent_issues.csv: every rejected reagent and any proposed corrections."""
    issues = []
    for r in rejected:
        cands = []
        if "cannot parse" in r["reason"]:
            cands = correction_candidates(r["input_smiles"], r["reason"])
        issues.append({**r, "proposed_corrections": json.dumps(cands),
                       "status": "REJECTED; source data not modified; corrections are proposals "
                                 "for the data owner"})
    return issues


def _stereo_counts(mol):
    from rdkit import Chem

    centres = Chem.FindMolChiralCenters(mol, includeUnassigned=True, useLegacyImplementation=False)
    unspecified = sum(1 for _, tag in centres if tag == "?")
    stereo_bonds = sum(1 for b in mol.GetBonds() if b.GetStereo() != Chem.BondStereo.STEREONONE)
    return unspecified, len(centres) - unspecified, stereo_bonds


def validate_rows(rows):
    """Return (accepted, rejected). Accepted rows carry full QC metadata."""
    from rdkit import Chem, RDLogger

    RDLogger.DisableLog("rdApp.*")  # invalid reagents are expected and reported
    accepted, rejected = [], []
    seen_ids, seen_canonical = {}, {}
    for r in rows:
        rid = str(r.get("ID", "")).strip()
        smi = str(r.get("SMILES", "")).strip()
        cat = str(r.get("Category", "")).strip()
        row_no = r.get("__row__")

        def reject(reason):
            rejected.append({"row": row_no, "id": rid, "category": cat,
                             "input_smiles": smi, "reason": reason})

        if not rid:
            reject("empty ID")
            continue
        if not smi:
            reject("empty SMILES")
            continue
        role = CATEGORY_ROLE.get(cat.lower())
        if role is None:
            reject("unknown Category {!r} (known: {})".format(cat, sorted(set(CATEGORY_ROLE))))
            continue
        if rid in seen_ids:
            reject("duplicate ID (first seen on row {})".format(seen_ids[rid]))
            continue
        mol = Chem.MolFromSmiles(smi)
        if mol is None:
            reject("RDKit cannot parse/sanitize this SMILES: {}".format(rdkit_error(smi)))
            continue
        ok, n_sites, tier, why = ugi.check_eligibility(mol, role)
        if not ok:
            reject("not eligible as {}: {}".format(role, why))
            continue
        canonical = Chem.MolToSmiles(mol, isomericSmiles=True)
        if canonical in seen_canonical:
            reject("duplicate structure: same canonical SMILES as {}".format(seen_canonical[canonical]))
            continue
        seen_ids[rid] = row_no
        seen_canonical[canonical] = rid
        unspec, spec, bonds = _stereo_counts(mol)
        accepted.append({
            "role": role, "role_index": -1, "id": rid,
            "id_prefix": rid[:1], "id_number": _id_number(rid), "category": cat,
            "input_smiles": smi, "canonical_smiles": canonical,
            "n_sites": n_sites, "site_tier": tier,
            "num_heavy_atoms": mol.GetNumHeavyAtoms(),
            "num_atoms_with_h": Chem.AddHs(mol).GetNumAtoms(),
            "formal_charge": Chem.GetFormalCharge(mol),
            "elements": "".join(sorted({a.GetSymbol() for a in mol.GetAtoms()})),
            "n_unspecified_stereocentres": unspec,
            "n_specified_stereocentres": spec,
            "n_stereo_bonds": bonds,
        })

    accepted.sort(key=lambda a: (ROLE_ORDER.index(a["role"]), a["id_number"], a["id"]))
    per_role = {}
    for a in accepted:
        a["role_index"] = per_role.get(a["role"], 0)
        per_role[a["role"]] = a["role_index"] + 1
    return accepted, rejected


def build_summary(accepted, rejected, meta):
    counts = {role: sum(1 for a in accepted if a["role"] == role) for role in ROLE_ORDER}
    combos = 1
    for role in ROLE_ORDER:
        combos *= counts[role]
    flags = []
    for role in ROLE_ORDER:
        if counts[role] != EXPECTED_COUNTS[role]:
            flags.append("{}: {} accepted, specification expects {}".format(
                role, counts[role], EXPECTED_COUNTS[role]))
    expected_combos = 1
    for v in EXPECTED_COUNTS.values():
        expected_combos *= v
    if combos != expected_combos:
        flags.append("combinations: {} (specification expects {})".format(combos, expected_combos))
    for a in accepted:
        if a["n_sites"] > 1:
            flags.append("{} has {} eligible {} groups (assumption A1 applies)".format(
                a["id"], a["n_sites"], a["role"]))
        if a["site_tier"] == "other_primary":
            flags.append("{} reacts through a non-aliphatic primary amine (assumption A3)".format(a["id"]))
    prefix_mismatch = [a["id"] for a in accepted if a["id_prefix"] != ROLE_PREFIX[a["role"]]]
    if prefix_mismatch:
        flags.append("ID prefix does not match the role for: {}".format(", ".join(prefix_mismatch)))
    return {
        "input": meta,
        "counts_per_role": counts,
        "expected_counts_per_role": EXPECTED_COUNTS,
        "n_accepted": len(accepted),
        "n_rejected": len(rejected),
        "n_combinations": combos,
        "expected_n_combinations": expected_combos,
        "role_order": ROLE_ORDER,
        "rejected": rejected,
        "qc_flags": flags,
        "ugi_reaction_smarts": ugi.UGI_SMARTS,
    }


def write_outputs(out_dir, accepted, rejected, summary):
    os.makedirs(out_dir, exist_ok=True)
    bb_path = os.path.join(out_dir, "building_blocks.csv")
    lines = [",".join(BB_FIELDS)]
    for a in accepted:
        lines.append(",".join(_csv_cell(a[f]) for f in BB_FIELDS))
    io_utils.atomic_write_text(bb_path, "\n".join(lines) + "\n")
    rej_path = os.path.join(out_dir, "rejected.csv")
    lines = [",".join(REJECT_FIELDS)]
    for r in rejected:
        lines.append(",".join(_csv_cell(r.get(f, "")) for f in REJECT_FIELDS))
    io_utils.atomic_write_text(rej_path, "\n".join(lines) + "\n")
    issues_path = os.path.join(out_dir, "reagent_issues.csv")
    fields = REJECT_FIELDS + ["proposed_corrections", "status"]
    lines = [",".join(fields)]
    for r in reagent_issues(rejected):
        lines.append(",".join(_csv_cell(r.get(f, "")) for f in fields))
    io_utils.atomic_write_text(issues_path, "\n".join(lines) + "\n")
    sum_path = os.path.join(out_dir, "summary.json")
    io_utils.atomic_write_json(sum_path, summary)
    return {"building_blocks": bb_path, "rejected": rej_path, "reagent_issues": issues_path,
            "summary": sum_path}


def _csv_cell(value):
    s = "" if value is None else str(value)
    if any(c in s for c in ',"\n'):
        return '"' + s.replace('"', '""') + '"'
    return s


def load_building_blocks(path):
    """Read building_blocks.csv back into {role: [row, ...]} in role_index order."""
    by_role = {role: [] for role in ROLE_ORDER}
    with open(path, newline="", encoding="utf-8") as fh:
        for row in csv.DictReader(fh):
            row["role_index"] = int(row["role_index"])
            row["n_sites"] = int(row["n_sites"])
            by_role[row["role"]].append(row)
    for role in ROLE_ORDER:
        by_role[role].sort(key=lambda r: r["role_index"])
        for i, r in enumerate(by_role[role]):
            if r["role_index"] != i:
                raise ValueError("{}: {} role_index values are not 0..N-1".format(path, role))
    return by_role


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("input", help="building-block .xlsx or .csv with ID/SMILES/Category")
    ap.add_argument("-o", "--out-dir", required=True)
    ap.add_argument("--sheet", default=None, help="sheet name (default: the first sheet)")
    ap.add_argument("--quiet", action="store_true")
    ns = ap.parse_args(argv)
    logging.basicConfig(level=logging.WARNING if ns.quiet else logging.INFO, format="%(message)s")

    rows, meta = read_table(ns.input, ns.sheet)
    accepted, rejected = validate_rows(rows)
    summary = build_summary(accepted, rejected, meta)
    paths = write_outputs(ns.out_dir, accepted, rejected, summary)

    logger.info("input      : %s (sheet %s, %d data rows)", meta["source"], meta["sheet_used"] or "-",
                meta["n_data_rows"])
    for role in ROLE_ORDER:
        logger.info("%-11s: %d accepted (specification: %d)", role,
                    summary["counts_per_role"][role], EXPECTED_COUNTS[role])
    logger.info("rejected   : %d", len(rejected))
    for r in rejected:
        logger.info("   row %s %s: %s", r["row"], r["id"], r["reason"])
    logger.info("combinations: %d (specification: %d)", summary["n_combinations"],
                summary["expected_n_combinations"])
    for f in summary["qc_flags"]:
        logger.info("QC FLAG    : %s", f)
    for k, v in sorted(paths.items()):
        logger.info("wrote %-16s %s", k, v)
    return 0


if __name__ == "__main__":
    sys.exit(main())
