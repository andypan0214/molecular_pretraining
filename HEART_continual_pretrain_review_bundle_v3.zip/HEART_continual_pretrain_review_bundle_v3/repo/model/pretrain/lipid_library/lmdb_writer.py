#!/usr/bin/env python
"""Conformer generation and HEART-compatible LMDB writing for enumerated lipid products.

    python -m lipid_library.lmdb_writer ENUM_DIR -o LMDB_DIR (--store-2d | --no-store-2d) [options]
    python -m lipid_library.lmdb_writer ENUM_DIR -o LMDB_DIR ... --partition              (once, before the array)
    python -m lipid_library.lmdb_writer ENUM_DIR -o LMDB_DIR ... --shard i --num-shards N   (array task)
    python -m lipid_library.lmdb_writer ENUM_DIR -o LMDB_DIR ... --finalize               (after the array)
    python -m lipid_library.lmdb_writer ENUM_DIR -o LMDB_DIR ... --plan                   (sizing only)

Reads ONLY the product chunks listed in ENUM_DIR/enumeration_complete.json,
removes the dedup drop list, cuts the stream into shards of
`--records-per-shard` rows, generates conformers (conformers.py) and writes:

    LMDB_DIR/lmdb_writer_config.json         configuration lock (provenance.py)
    LMDB_DIR/shard_inputs/input-00000.csv.gz the input rows of shard 0 (written once by --partition)
    LMDB_DIR/shard_inputs/partition_index.json  per-shard row count, input fingerprint, sha256
    LMDB_DIR/array_geometry_config.json      the --num-shards of the array (lock)
    LMDB_DIR/shard-00000/train.lmdb          records under keys b'0'..b'N-1' (compacted)
    LMDB_DIR/shard-00000/shard.json          receipt: config + input fingerprints, counts, sha256
    LMDB_DIR/shard-00000/records.csv.gz      key -> combo_id/SMILES/3D accounting
    LMDB_DIR/manifest.json                   ONLY written by a successful --finalize
    LMDB_DIR/finalize_report.json            every --finalize, with what is missing

HEART compatibility (why this is not LUMI's `write_lmdb_extended_lipid`,
which uses SMILES keys): contiguous ASCII integer keys per LMDB; records with
exactly `smi`, `atoms`, `coordinates`; `--max-atoms` on the atoms left after
the training hydrogen policy (`--only-polar 0`: heavy atoms), so no molecule
is cropped silently; atoms outside the model dict.txt are reported, never mapped.

Review fix P0-2 (staleness). Every scientific option, the dict.txt hash, the
drop-list hash, the enumeration fingerprint, `--limit` and the versions form
the writer configuration; LMDB_DIR is locked to it. Each shard receipt also
stores an input fingerprint (sha256 of the shard's combo indexes and product
SMILES). A shard is reused only if both fingerprints and its LMDB sha256
match; a receipt with another fingerprint is an error, never reused.

v2 review P1 (array I/O). The product stream is read ONCE, by `--partition`
(stage 03b, one CPU job), which writes one small gz CSV of input rows per shard
plus a fingerprinted index (the partition configuration: enumeration and
drop-list identity, --records-per-shard, --limit). An array task opens only the
input files of its own shards, verifies each file's sha256 and recomputes its
input fingerprint before use, so 1,000 tasks read ~1x the library instead of
1,000x. A single-process run (no --shard) builds the partition itself. The
array stride --num-shards is locked on the first task, so a resubmission with
another stride (two tasks writing one shard) is refused.

Review fix P0-1 (completeness). `--finalize` recomputes the expected shards
from the enumeration record, the drop list and `--records-per-shard`, and
requires every expected shard (no missing, extra or duplicate IDs), matching
fingerprints, verified LMDB hashes and exact count reconciliation
(records + skipped == input rows per shard; the inputs sum to the products
minus the dropped duplicates). Only then is manifest.json written, with
`"complete": true`. On any failure it removes manifest.json and splits.json,
writes finalize_report.json and exits 1.
"""
import argparse
import glob
import hashlib
import json
import logging
import os
import pickle
import re
import sys
import time

from . import FORMAT_VERSION, io_utils, provenance
from .conformers import CONFORMER_POLICY_VERSION, ConformerError, smi2coords_pretrain

logger = logging.getLogger(__name__)

RECORD_FIELDS = [
    "key", "combo_index", "combo_id", "smi", "n_atoms", "n_heavy_atoms",
    "n_coordinate_slots", "n_3d_success", "n_2d_filled", "n_distinct_3d", "oversized",
]
SKIP_FIELDS = ["combo_index", "combo_id", "smi", "reason"]
PARTITION_DIR = "shard_inputs"
PARTITION_INDEX = "partition_index.json"
INPUT_FIELDS = ["combo_index", "combo_id", "product_smiles"]
# rows parsed per source in this process (scale tests and the --plan read estimate)
ROWS_READ = {"products": 0, "shard_inputs": 0}
# assumed gz-CSV parse cost when no partition has been measured yet (projection only)
DEFAULT_READ_SEC_PER_ROW = 1e-4      # laptop measured 6.6e-5 incl. writing the partition

SCIENTIFIC_OPTIONS = ["n_3d", "store_2d", "max_try", "max_iterations", "seed_start", "max_atoms",
                      "only_polar", "allow_2d_only", "records_per_shard", "limit"]


# --------------------------------------------------------------------------- product stream
def product_chunks(products_dir):
    """Product chunk files in start order.

    If ENUM_DIR has enumeration_complete.json, exactly the chunks listed there
    are returned (a directory glob could also pick up stale --limit chunks).
    Without it (unit tests and ad-hoc use) all products-*.csv.gz are globbed.
    """
    complete = os.path.join(products_dir, "enumeration_complete.json")
    if os.path.isfile(complete):
        with open(complete, encoding="utf-8") as fh:
            record = json.load(fh)
        return [os.path.join(products_dir, c["products_file"]) for c in record["chunks"]]
    pattern = os.path.join(products_dir, "products", "products-*.csv.gz")
    files = [f for f in glob.glob(pattern) if not f.endswith(".partial")]
    if not files:
        pattern = os.path.join(products_dir, "products-*.csv.gz")
        files = [f for f in glob.glob(pattern) if not f.endswith(".partial")]

    def start_of(path):
        m = re.search(r"products-(\d+)-(\d+)\.csv\.gz$", os.path.basename(path))
        return (int(m.group(1)), int(m.group(2))) if m else (1 << 62, 0)

    return sorted(files, key=start_of)


def iter_products(products_dir, drop_indexes=None):
    """Product rows in deterministic combination-index order, minus `drop_indexes`."""
    for path in product_chunks(products_dir):
        for row in io_utils.read_gz_csv(path):
            ROWS_READ["products"] += 1
            row["combo_index"] = int(row["combo_index"])
            if drop_indexes and row["combo_index"] in drop_indexes:
                continue
            yield row


def _batched(iterable, n):
    batch = []
    for item in iterable:
        batch.append(item)
        if len(batch) == n:
            yield batch
            batch = []
    if batch:
        yield batch


def iter_shard_batches(products_dir, drop_indexes, records_per_shard, limit=None):
    """(shard_id, rows) for the deterministic shard layout, honouring --limit."""
    n_seen = 0
    for shard_id, batch in enumerate(_batched(iter_products(products_dir, drop_indexes), records_per_shard)):
        if limit is not None:
            if n_seen >= limit:
                return
            batch = batch[: max(0, limit - n_seen)]
        n_seen += len(batch)
        yield shard_id, batch


def input_fingerprint(rows):
    """sha256 of the shard's inputs: combo index and product SMILES, in order."""
    h = hashlib.sha256()
    for row in rows:
        h.update("{}\t{}\n".format(row["combo_index"], row["product_smiles"]).encode("utf-8"))
    return h.hexdigest()


# --------------------------------------------------------------------------- shard-input partition
class PartitionError(RuntimeError):
    """The shard-input partition is missing or does not belong to this configuration."""


def partition_config(opts, products_dir):
    """Everything that determines which rows go into which shard (and nothing else)."""
    enum_identity = _enumeration_identity(products_dir)
    return {"stage": "partition", "format_version": FORMAT_VERSION, **enum_identity,
            **_drop_identity(opts.drop_list, enum_identity),
            "records_per_shard": opts.records_per_shard, "limit": opts.limit}


def _partition_dir(out_dir):
    return os.path.join(out_dir, PARTITION_DIR)


def _input_name(shard_id):
    return "input-{:05d}.csv.gz".format(shard_id)


def build_partition(products_dir, out_dir, opts):
    """Read the product stream once and write one input file per shard. Returns the index.

    Idempotent: an existing complete index for the same configuration is reused
    (after checking its files exist); another configuration raises StaleOutputError.
    """
    pdir = _partition_dir(out_dir)
    cfg = partition_config(opts, products_dir)
    fp = provenance.lock_config(pdir, "partition", cfg)
    index_path = os.path.join(pdir, PARTITION_INDEX)
    if os.path.isfile(index_path):
        with open(index_path, encoding="utf-8") as fh:
            index = json.load(fh)
        if (index.get("config_fingerprint") == fp and index.get("complete") is True
                and all(os.path.isfile(os.path.join(pdir, e["file"])) for e in index["shards"])):
            logger.info("partition   : reusing %s (%d shards)", index_path, index["n_shards"])
            return index
        os.remove(index_path)
    t0 = time.time()
    n_read0 = ROWS_READ["products"]
    shards, n_rows = [], 0
    for shard_id, rows in iter_shard_batches(products_dir, _drop_set(opts.drop_list),
                                             opts.records_per_shard, opts.limit):
        name = _input_name(shard_id)
        w = io_utils.AtomicGzCsvWriter(os.path.join(pdir, name), INPUT_FIELDS)
        for row in rows:
            w.writerow([row["combo_index"], row["combo_id"], row["product_smiles"]])
        w.close()
        shards.append({"shard_id": shard_id, "file": name, "n_input_rows": len(rows),
                       "input_fingerprint": input_fingerprint(rows),
                       "sha256": io_utils.sha256_file(os.path.join(pdir, name)),
                       "first_combo_index": rows[0]["combo_index"],
                       "last_combo_index": rows[-1]["combo_index"]})
        n_rows += len(rows)
    seconds = time.time() - t0
    n_read = ROWS_READ["products"] - n_read0
    index = {"format_version": FORMAT_VERSION, "complete": True, "config_fingerprint": fp,
             "records_per_shard": opts.records_per_shard, "n_shards": len(shards),
             "n_input_rows": n_rows, "n_product_rows_read": n_read, "seconds": round(seconds, 3),
             "measured_read_sec_per_row": (seconds / n_read) if n_read else None,
             "shards": shards}
    io_utils.atomic_write_json(index_path, index)
    logger.info("partition   : %d shards, %d rows from %d product rows in %.1fs -> %s",
                len(shards), n_rows, n_read, seconds, index_path)
    return index


def load_partition(out_dir, opts, products_dir):
    """The partition index for THIS configuration, or PartitionError/StaleOutputError."""
    pdir = _partition_dir(out_dir)
    index_path = os.path.join(pdir, PARTITION_INDEX)
    if not os.path.isfile(index_path):
        raise PartitionError("no shard-input partition in {}: run `lmdb_writer ... --partition` "
                             "(stage 03b) once before the array".format(pdir))
    with open(index_path, encoding="utf-8") as fh:
        index = json.load(fh)
    fp = provenance.fingerprint(partition_config(opts, products_dir))
    if index.get("complete") is not True or index.get("config_fingerprint") != fp:
        raise provenance.StaleOutputError(
            "the shard-input partition {} was made for another configuration (products, drop "
            "list, --records-per-shard or --limit changed): use a new output directory".format(pdir))
    return index


def read_shard_input(out_dir, entry, verify_hash=True):
    """The input rows of one shard, verified against the partition index."""
    path = os.path.join(_partition_dir(out_dir), entry["file"])
    if verify_hash and io_utils.sha256_file(path) != entry["sha256"]:
        raise provenance.StaleOutputError("{}: sha256 differs from the partition index".format(path))
    rows = []
    for row in io_utils.read_gz_csv(path):
        ROWS_READ["shard_inputs"] += 1
        row["combo_index"] = int(row["combo_index"])
        rows.append(row)
    if len(rows) != entry["n_input_rows"] or input_fingerprint(rows) != entry["input_fingerprint"]:
        raise provenance.StaleOutputError("{}: rows do not match the partition index".format(path))
    return rows


def lock_array_geometry(out_dir, num_shards):
    """One stride per output directory: tasks of different strides would write the same shard."""
    return provenance.lock_config(out_dir, "array_geometry", {"num_shards": int(num_shards)})


def load_dictionary_symbols(dict_path):
    """Atom symbols in a Uni-Core dict.txt (one `symbol count` per line)."""
    symbols = set()
    with open(dict_path, encoding="utf-8") as fh:
        for line in fh:
            tok = line.split()
            if tok:
                symbols.add(tok[0])
    return symbols


# --------------------------------------------------------------------------- configuration
def _enumeration_identity(products_dir):
    complete = os.path.join(products_dir, "enumeration_complete.json")
    if os.path.isfile(complete):
        with open(complete, encoding="utf-8") as fh:
            r = json.load(fh)
        return {"enumeration_fingerprint": r["config_fingerprint"], "enumeration_smoke": r["smoke"],
                "enumeration_complete_sha256": io_utils.sha256_file(complete),
                "n_products": r["n_products"]}
    # ad-hoc product directories (unit tests): identify by content hash of the chunks
    h = hashlib.sha256()
    n = 0
    for path in product_chunks(products_dir):
        h.update(io_utils.sha256_file(path).encode("ascii"))
        n += 1
    return {"enumeration_fingerprint": None, "enumeration_smoke": True,
            "enumeration_complete_sha256": None, "products_content_sha256": h.hexdigest(),
            "n_product_chunks": n}


def _drop_identity(drop_list, enum_identity):
    if not drop_list:
        return {"drop_list": None, "drop_list_sha256": None, "dedup_enumeration_fingerprint": None}
    summary_path = os.path.join(os.path.dirname(os.path.abspath(drop_list)), "summary.json")
    dedup_fp = None
    if os.path.isfile(summary_path):
        with open(summary_path, encoding="utf-8") as fh:
            dedup_fp = json.load(fh).get("enumeration_fingerprint")
    if enum_identity.get("enumeration_fingerprint") and dedup_fp != enum_identity["enumeration_fingerprint"]:
        raise provenance.StaleOutputError(
            "the drop list {} was made from enumeration {} but the products are enumeration {}: "
            "re-run dedup".format(drop_list, dedup_fp, enum_identity["enumeration_fingerprint"]))
    return {"drop_list": os.path.abspath(drop_list), "drop_list_sha256": io_utils.sha256_file(drop_list),
            "dedup_enumeration_fingerprint": dedup_fp}


def writer_config(opts, products_dir):
    enum_identity = _enumeration_identity(products_dir)
    config = {
        "stage": "lmdb_writer",
        "conformer_policy": CONFORMER_POLICY_VERSION,
        "versions": provenance.runtime_versions(),
        "dict_sha256": io_utils.sha256_file(opts.dict_path) if opts.dict_path else None,
        **enum_identity,
        **_drop_identity(opts.drop_list, enum_identity),
        **{k: getattr(opts, k) for k in SCIENTIFIC_OPTIONS},
    }
    config["smoke"] = bool(opts.limit is not None or enum_identity["enumeration_smoke"])
    return config


# --------------------------------------------------------------------------- shards
def _shard_dir(out_dir, shard_id):
    return os.path.join(out_dir, "shard-{:05d}".format(shard_id))


def read_receipt(out_dir, shard_id):
    rp = os.path.join(_shard_dir(out_dir, shard_id), "shard.json")
    if not os.path.isfile(rp):
        return None
    try:
        with open(rp, encoding="utf-8") as fh:
            return json.load(fh)
    except (ValueError, OSError):
        return None


def shard_is_complete(out_dir, shard_id, verify_hash=True, config_fingerprint=None, input_fp=None):
    """True if the shard has a receipt for this configuration and these inputs.

    A receipt with a different configuration or input fingerprint raises
    provenance.StaleOutputError (fail closed). A missing/corrupt LMDB returns
    False so the shard is rebuilt.
    """
    receipt = read_receipt(out_dir, shard_id)
    lp = os.path.join(_shard_dir(out_dir, shard_id), "train.lmdb")
    if receipt is None or not os.path.isfile(lp):
        return False
    if receipt.get("format_version") != FORMAT_VERSION or receipt.get("shard_id") != shard_id:
        return False
    if config_fingerprint is not None and receipt.get("config_fingerprint") != config_fingerprint:
        raise provenance.StaleOutputError(
            "shard {} in {} was written with configuration {} (current {})".format(
                shard_id, out_dir, receipt.get("config_fingerprint"), config_fingerprint))
    if input_fp is not None and receipt.get("input_fingerprint") != input_fp:
        raise provenance.StaleOutputError(
            "shard {} in {} was written from different input rows (products or drop list "
            "changed)".format(shard_id, out_dir))
    if verify_hash and receipt.get("lmdb_sha256") != io_utils.sha256_file(lp):
        logger.warning("shard %d: train.lmdb sha256 does not match its receipt", shard_id)
        return False
    return True


def write_shard(rows, out_dir, shard_id, opts, config_fingerprint=None):
    """Build one shard LMDB from `rows` (a list of product rows). Returns the receipt."""
    import lmdb

    d = _shard_dir(out_dir, shard_id)
    os.makedirs(d, exist_ok=True)
    receipt_path = os.path.join(d, "shard.json")
    if os.path.exists(receipt_path):
        os.remove(receipt_path)        # never pair an old receipt with a new LMDB
    lmdb_path = os.path.join(d, "train.lmdb")
    tmp_path = lmdb_path + ".partial"
    for p in (tmp_path, tmp_path + "-lock"):
        if os.path.exists(p):
            os.remove(p)
    rec_writer = io_utils.AtomicGzCsvWriter(os.path.join(d, "records.csv.gz"), RECORD_FIELDS)
    skip_writer = io_utils.AtomicGzCsvWriter(os.path.join(d, "skipped.csv.gz"), SKIP_FIELDS)

    stats = {
        "n_records": 0, "n_skipped": 0, "n_oversized": 0,
        "n_records_with_2d_fill": 0, "n_3d_slots_total": 0, "n_2d_filled_total": 0,
        "n_distinct_3d_total": 0, "skip_reasons": {}, "unsupported_atoms": {},
        "coordinate_slot_counts": {}, "max_n_atoms": 0, "max_n_heavy_atoms": 0,
    }
    t0 = time.time()
    env = lmdb.open(tmp_path, subdir=False, readonly=False, lock=True, readahead=False,
                    meminit=False, max_readers=1, map_size=int(opts.map_size_gb * (1 << 30)))
    try:
        txn = env.begin(write=True)
        key = 0
        for row in rows:
            smi = row["product_smiles"]

            def skip(reason):
                stats["n_skipped"] += 1
                stats["skip_reasons"][reason] = stats["skip_reasons"].get(reason, 0) + 1
                skip_writer.writerow([row["combo_index"], row["combo_id"], smi, reason])

            try:
                record, s = smi2coords_pretrain(
                    smi, n_3d=opts.n_3d, store_2d=opts.store_2d,
                    max_try=opts.max_try, max_iteration=opts.max_iterations,
                    seed_start=getattr(opts, "seed_start", 0))
            except ConformerError as exc:
                skip("conformer generation failed: {}".format(exc))
                continue
            except Exception as exc:
                skip("{}: {}".format(type(exc).__name__, exc))
                continue

            n_after_h = s["n_heavy_atoms"] if opts.only_polar == 0 else s["n_atoms"]
            if opts.max_atoms and n_after_h > opts.max_atoms:
                skip("{} atoms after the --only-polar {} hydrogen policy ({} with hydrogens) "
                     "exceeds --max-atoms {}: training would crop this molecule".format(
                         n_after_h, opts.only_polar, s["n_atoms"], opts.max_atoms))
                continue
            stats["max_n_atoms_after_h_policy"] = max(
                stats.get("max_n_atoms_after_h_policy", 0), n_after_h)
            if opts.dict_symbols is not None:
                unsupported = sorted({a for a in record["atoms"] if a not in opts.dict_symbols})
                if unsupported:
                    for a in unsupported:
                        stats["unsupported_atoms"][a] = stats["unsupported_atoms"].get(a, 0) + 1
                    skip("atom symbol(s) not in dict.txt: {}".format(",".join(unsupported)))
                    continue
            if s["n_3d_success"] == 0 and not opts.allow_2d_only:
                skip("no 3D conformer could be embedded (use --allow-2d-only to keep it)")
                continue

            txn.put("{}".format(key).encode("ascii"), pickle.dumps(record, protocol=4))
            rec_writer.writerow([key, row["combo_index"], row["combo_id"], smi, s["n_atoms"],
                                 s["n_heavy_atoms"], s["n_coordinate_slots"], s["n_3d_success"],
                                 s["n_2d_filled"], s["n_distinct_3d"], int(bool(s["oversized"]))])
            key += 1
            stats["n_records"] += 1
            stats["n_3d_slots_total"] += s["n_3d_success"]
            stats["n_2d_filled_total"] += s["n_2d_filled"]
            stats["n_distinct_3d_total"] += s["n_distinct_3d"]
            stats["n_oversized"] += int(bool(s["oversized"]))
            stats["n_records_with_2d_fill"] += int(s["n_2d_filled"] > 0)
            stats["max_n_atoms"] = max(stats["max_n_atoms"], s["n_atoms"])
            stats["max_n_heavy_atoms"] = max(stats["max_n_heavy_atoms"], s["n_heavy_atoms"])
            slot_key = str(s["n_coordinate_slots"])
            stats["coordinate_slot_counts"][slot_key] = stats["coordinate_slot_counts"].get(slot_key, 0) + 1
            if key % opts.commit_every == 0:
                txn.commit()
                txn = env.begin(write=True)
        txn.commit()
    except BaseException:
        env.close()
        rec_writer.close(commit=False)
        skip_writer.close(commit=False)
        raise
    # Compact copy: only used pages, so the sha256 receipt reads real data only.
    compact_path = lmdb_path + ".compact"
    if os.path.exists(compact_path):
        os.remove(compact_path)
    env.copy(compact_path, compact=True)
    env.close()
    rec_writer.close()
    skip_writer.close()
    for p in (tmp_path, tmp_path + "-lock"):
        if os.path.exists(p):
            os.remove(p)
    os.replace(compact_path, lmdb_path)

    receipt = {
        "format_version": FORMAT_VERSION,
        "shard_id": shard_id,
        "lmdb": "train.lmdb",
        "lmdb_sha256": io_utils.sha256_file(lmdb_path),
        "config_fingerprint": config_fingerprint,
        "input_fingerprint": input_fingerprint(rows),
        "n_input_rows": len(rows),
        "first_combo_index": rows[0]["combo_index"] if rows else None,
        "last_combo_index": rows[-1]["combo_index"] if rows else None,
        "records_csv_sha256": io_utils.sha256_file(os.path.join(d, "records.csv.gz")),
        "key_convention": "contiguous ASCII integers 0..N-1",
        "record_keys": ["smi", "atoms", "coordinates"],
        "n_3d_slots_per_record": opts.n_3d,
        "stored_2d_conformer": bool(opts.store_2d),
        "coordinate_slots_per_record": opts.n_3d + (1 if opts.store_2d else 0),
        "max_atoms_filter": opts.max_atoms,
        "only_polar": opts.only_polar,
        "dict_checked": opts.dict_path,
        "conformer_seed_start": getattr(opts, "seed_start", 0),
        "max_try": opts.max_try,
        "max_iterations": opts.max_iterations,
        "versions": provenance.runtime_versions(),
        "seconds": round(time.time() - t0, 3),
        **stats,
    }
    io_utils.atomic_write_json(receipt_path, receipt)
    return receipt


# --------------------------------------------------------------------------- finalize
def _drop_set(drop_list):
    if not drop_list:
        return None
    from .dedup import load_drop_set

    return set(load_drop_set(drop_list))


def finalize(products_dir, out_dir, opts, verify_hash=True, array_size=None):
    """Fail-closed completeness check; writes manifest.json only when everything reconciles."""
    locked = provenance.read_config(out_dir, "lmdb_writer")
    problems = []
    config = writer_config(opts, products_dir)
    fp = provenance.fingerprint(config)
    if locked is None:
        problems.append("no lmdb_writer_config.json in {}: no shard was written".format(out_dir))
    elif locked["fingerprint"] != fp:
        problems.append("the finalize options differ from the configuration the shards were written "
                        "with (pass the same options as stage 04)")
    drops = _drop_set(opts.drop_list)

    expected, n_rows = [], 0
    for shard_id, rows in iter_shard_batches(products_dir, drops, opts.records_per_shard, opts.limit):
        expected.append({"shard_id": shard_id, "n_input_rows": len(rows),
                         "input_fingerprint": input_fingerprint(rows)})
        n_rows += len(rows)
    expected_ids = [e["shard_id"] for e in expected]
    try:
        index = load_partition(out_dir, opts, products_dir)
        by_sid = {e["shard_id"]: e for e in index["shards"]}
        if sorted(by_sid) != expected_ids or any(
                by_sid[e["shard_id"]]["input_fingerprint"] != e["input_fingerprint"] for e in expected):
            problems.append("the shard-input partition does not match the product stream")
    except (PartitionError, provenance.StaleOutputError) as exc:
        problems.append(str(exc))
    present = sorted(int(m.group(1)) for m in (re.match(r"shard-(\d+)$", os.path.basename(p))
                                               for p in glob.glob(os.path.join(out_dir, "shard-*")))
                     if m)
    extra = sorted(set(present) - set(expected_ids))
    if extra:
        problems.append("shard directories not in the expected layout: {}".format(extra[:20]))
    if len(present) != len(set(present)):
        problems.append("duplicate shard ids")

    shards, missing, stale = [], [], []
    seconds = 0.0
    for e in expected:
        sid = e["shard_id"]
        try:
            ok = shard_is_complete(out_dir, sid, verify_hash, fp, e["input_fingerprint"])
        except provenance.StaleOutputError as exc:
            stale.append(sid)
            problems.append(str(exc))
            continue
        if not ok:
            missing.append(sid)
            continue
        r = read_receipt(out_dir, sid)
        seconds += float(r.get("seconds") or 0.0)
        if r["n_records"] + r["n_skipped"] != e["n_input_rows"] or r["n_input_rows"] != e["n_input_rows"]:
            problems.append("shard {}: records {} + skipped {} != input rows {}".format(
                sid, r["n_records"], r["n_skipped"], e["n_input_rows"]))
        shards.append({
            "shard_id": sid, "dir": os.path.basename(_shard_dir(out_dir, sid)),
            "lmdb": "{}/{}".format(os.path.basename(_shard_dir(out_dir, sid)), r["lmdb"]),
            "n_records": r["n_records"], "n_skipped": r["n_skipped"], "n_input_rows": r["n_input_rows"],
            "lmdb_sha256": r["lmdb_sha256"], "input_fingerprint": r["input_fingerprint"],
            "first_combo_index": r["first_combo_index"], "last_combo_index": r["last_combo_index"],
            "coordinate_slots_per_record": r["coordinate_slots_per_record"],
            "stored_2d_conformer": r["stored_2d_conformer"],
            "n_3d_slots_per_record": r["n_3d_slots_per_record"],
            "n_2d_filled_total": r.get("n_2d_filled_total"),
        })
    if missing:
        problems.append("{} expected shard(s) missing or corrupt: {}".format(len(missing), missing[:50]))

    enum = _enumeration_identity(products_dir)
    expected_rows = None
    if enum.get("n_products") is not None:
        n_dropped = len(drops) if drops else 0
        expected_rows = enum["n_products"] - n_dropped
        if opts.limit is not None:
            expected_rows = min(expected_rows, opts.limit)
        if expected_rows != n_rows:
            problems.append("products {} - dropped {} = {} but the shard stream has {} rows (drop "
                            "list not a subset of these products?)".format(
                                enum["n_products"], n_dropped, expected_rows, n_rows))
    if shards and sum(s["n_input_rows"] for s in shards) != n_rows and not missing and not stale:
        problems.append("shard inputs do not sum to the product stream")
    if not expected:
        problems.append("the product stream is empty")

    report = {
        "complete": not problems, "config_fingerprint": fp, "smoke": config["smoke"],
        "n_expected_shards": len(expected), "n_complete_shards": len(shards),
        "missing_shards": missing, "stale_shards": stale, "extra_shards": extra,
        "n_input_rows": n_rows, "expected_input_rows": expected_rows,
        "measured_sec_per_molecule": (round(seconds / sum(s["n_input_rows"] for s in shards), 4)
                                      if shards and sum(s["n_input_rows"] for s in shards) else None),
        "problems": problems,
    }
    if array_size:
        report["resubmit_array_tasks"] = sorted({s % array_size for s in missing + stale})
    io_utils.atomic_write_json(os.path.join(out_dir, "finalize_report.json"), report)
    if problems:
        for name in ("manifest.json", "splits.json"):
            p = os.path.join(out_dir, name)
            if os.path.exists(p):
                os.remove(p)
        return None, report
    manifest = {
        "format_version": FORMAT_VERSION,
        "complete": True,
        "smoke": config["smoke"],
        "config_fingerprint": fp,
        "writer_config": config,
        "key_convention": "contiguous ASCII integers 0..N-1 within each shard LMDB",
        "record_keys": ["smi", "atoms", "coordinates"],
        "n_shards": len(shards),
        "n_input_rows": n_rows,
        "n_records": sum(s["n_records"] for s in shards),
        "n_skipped": sum(s["n_skipped"] for s in shards),
        "coordinate_slots_per_record": sorted({s["coordinate_slots_per_record"] for s in shards}),
        "stored_2d_conformer": sorted({bool(s["stored_2d_conformer"]) for s in shards}),
        "shards": shards,
    }
    io_utils.atomic_write_json(os.path.join(out_dir, "manifest.json"), manifest)
    return manifest, report


def plan(products_dir, opts, sec_per_molecule=None, array_size=None, out_dir=None):
    """Shard layout and per-task cost from the enumeration record and drop list, without streaming.

    The per-task estimate includes input reading (v2 review P1): a task reads
    only its own shards' input rows (max_shards_per_task * records_per_shard),
    at the read rate the partition measured (or DEFAULT_READ_SEC_PER_ROW,
    flagged as assumed, before the partition exists).
    """
    enum = _enumeration_identity(products_dir)
    if enum.get("n_products") is None:
        raise SystemExit("--plan needs ENUM_DIR/enumeration_complete.json")
    drops = _drop_set(opts.drop_list)
    n_rows = enum["n_products"] - (len(drops) if drops else 0)
    if opts.limit is not None:
        n_rows = min(n_rows, opts.limit)
    n_shards = -(-n_rows // opts.records_per_shard)
    out = {"n_rows": n_rows, "records_per_shard": opts.records_per_shard, "n_shards": n_shards,
           "n_product_rows": enum["n_products"]}
    read_rate, source = DEFAULT_READ_SEC_PER_ROW, "assumed"
    out["partition"] = "missing"
    if out_dir:
        try:
            index = load_partition(out_dir, opts, products_dir)
            out["partition"] = "matches"
            if index.get("n_shards") != n_shards:
                out["partition"] = "stale"
            if index.get("measured_read_sec_per_row"):
                read_rate, source = float(index["measured_read_sec_per_row"]), "measured by --partition"
        except PartitionError:
            pass
        except provenance.StaleOutputError:
            out["partition"] = "stale"
    out.update({"read_sec_per_row": read_rate, "read_rate_source": source,
                "est_partition_hours": round(enum["n_products"] * read_rate / 3600.0, 3)})
    if array_size:
        per_task = -(-n_shards // array_size)
        rows_per_task = per_task * opts.records_per_shard
        out.update({"array_size": array_size, "max_shards_per_task": per_task,
                    "input_rows_read_per_task": rows_per_task,
                    "input_rows_read_all_tasks": n_rows,
                    "input_rows_read_if_every_task_streamed": n_rows * array_size,
                    "est_input_read_hours_per_task": round(rows_per_task * read_rate / 3600.0, 4)})
        if sec_per_molecule:
            out.update({"sec_per_molecule": sec_per_molecule,
                        "est_hours_per_task": round(rows_per_task * (sec_per_molecule + read_rate) / 3600.0, 2),
                        "est_cpu_hours_total": round(n_rows * sec_per_molecule / 3600.0, 1)})
    return out


# --------------------------------------------------------------------------- CLI
def build_parser():
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("products_dir", help="enumerate_library output directory")
    ap.add_argument("-o", "--out-dir", required=True)
    ap.add_argument("--records-per-shard", type=int, default=5000)
    ap.add_argument("--n-3d", type=int, default=10, help="3D conformer slots (LUMI: 10)")
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--store-2d", dest="store_2d", action="store_true",
                   help="store LUMI's trailing 2D conformer (11 stored slots)")
    g.add_argument("--no-store-2d", dest="store_2d", action="store_false",
                   help="store 3D slots only; HEART adds the 2D conformer at training time "
                        "(choose the convention the general LMDB uses: README_CONTINUAL.md 2D policy)")
    ap.add_argument("--max-try", type=int, default=15, help="embedding attempts (LUMI pretraining: 15)")
    ap.add_argument("--max-iterations", type=int, default=4000, help="ETKDGv3 maxIterations (LUMI: 4000)")
    ap.add_argument("--seed-start", type=int, default=0,
                    help="first ETKDG seed (LUMI: 0). RDKit seed 0 == seed 1, so 0 duplicates the "
                         "first two 3D slots; 1 avoids it (see conformers.py D6)")
    ap.add_argument("--max-atoms", type=int, default=256,
                    help="reject records the training CroppingDataset would crop (atoms after the "
                         "--only-polar hydrogen policy)")
    ap.add_argument("--only-polar", type=int, default=0, choices=[-1, 0, 1],
                    help="training --only-polar value: 0 removes every H before cropping (HEART/LUMI)")
    ap.add_argument("--dict", dest="dict_path", default=None,
                    help="model dict.txt; atom symbols outside it are reported and the record is skipped")
    ap.add_argument("--allow-2d-only", action="store_true",
                    help="keep records for which no 3D conformer could be embedded")
    ap.add_argument("--map-size-gb", type=float, default=64.0)
    ap.add_argument("--commit-every", type=int, default=2000)
    ap.add_argument("--drop-list", default=None,
                    help="dedup drop_combo_indexes.csv.gz (its summary.json must match the enumeration)")
    ap.add_argument("--limit", type=int, default=None,
                    help="smoke mode: only this many products (marks the output as smoke)")
    ap.add_argument("--shard", type=int, default=None, help="only shards i where i %% num_shards == shard")
    ap.add_argument("--num-shards", type=int, default=1)
    ap.add_argument("--force", action="store_true", help="rebuild shards (same configuration only)")
    ap.add_argument("--no-verify-hash", action="store_true")
    ap.add_argument("--finalize", "--manifest-only", dest="finalize", action="store_true",
                    help="generate nothing; verify every expected shard and write manifest.json")
    ap.add_argument("--array-size", type=int, default=None,
                    help="with --finalize/--plan: the stage-04 array size (resubmit list / sizing)")
    ap.add_argument("--plan", action="store_true", help="print the shard layout and exit")
    ap.add_argument("--partition", action="store_true",
                    help="read the product stream once and write the per-shard input files "
                         "(stage 03b; required before --shard array tasks)")
    ap.add_argument("--sec-per-molecule", type=float, default=None, help="with --plan: runtime estimate")
    return ap


def main(argv=None):
    ns = build_parser().parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    ns.dict_symbols = load_dictionary_symbols(ns.dict_path) if ns.dict_path else None
    try:
        if ns.plan:
            print(json.dumps(plan(ns.products_dir, ns, ns.sec_per_molecule, ns.array_size, ns.out_dir),
                             indent=2))
            return 0
        if ns.partition:
            index = build_partition(ns.products_dir, ns.out_dir, ns)
            print(json.dumps({k: v for k, v in index.items() if k != "shards"}, indent=2))
            return 0
        if ns.finalize:
            manifest, report = finalize(ns.products_dir, ns.out_dir, ns, not ns.no_verify_hash, ns.array_size)
            return _report_finalize(manifest, report, ns.out_dir)
        config = writer_config(ns, ns.products_dir)
        fp = provenance.lock_config(ns.out_dir, "lmdb_writer", config)
    except provenance.StaleOutputError as exc:
        raise SystemExit("ERROR: {}".format(exc))

    if ns.dict_symbols is not None:
        logger.info("dict.txt    : %s (%d symbols)", ns.dict_path, len(ns.dict_symbols))
    logger.info("config      : %s%s", fp, " (SMOKE: not a production dataset)" if config["smoke"] else "")
    drops = _drop_set(ns.drop_list)
    if drops is not None:
        logger.info("drop list   : %s (%d duplicate combinations)", ns.drop_list, len(drops))

    try:
        if ns.shard is not None:
            if not 0 <= ns.shard < ns.num_shards:
                raise SystemExit("ERROR: --shard {} outside 0..{}".format(ns.shard, ns.num_shards - 1))
            lock_array_geometry(ns.out_dir, ns.num_shards)
            index = load_partition(ns.out_dir, ns, ns.products_dir)
        else:
            index = build_partition(ns.products_dir, ns.out_dir, ns)
    except (PartitionError, provenance.StaleOutputError) as exc:
        raise SystemExit("ERROR: {}".format(exc))

    totals = {"n_records": 0, "n_skipped": 0, "shards_written": 0, "shards_skipped": 0}
    for entry in index["shards"]:
        shard_id = entry["shard_id"]
        if ns.shard is not None and shard_id % ns.num_shards != ns.shard:
            continue                    # nothing of another task's shards is read
        try:
            done = not ns.force and shard_is_complete(ns.out_dir, shard_id, not ns.no_verify_hash,
                                                      fp, entry["input_fingerprint"])
            if done:
                logger.info("shard %d: already complete, skipped", shard_id)
                totals["shards_skipped"] += 1
                continue
            batch = read_shard_input(ns.out_dir, entry, not ns.no_verify_hash)
        except provenance.StaleOutputError as exc:
            raise SystemExit("ERROR: {}".format(exc))
        r = write_shard(batch, ns.out_dir, shard_id, ns, fp)
        logger.info("shard %d: %d records, %d skipped, 3D slots %d, 2D fills %d, %.1fs",
                    shard_id, r["n_records"], r["n_skipped"], r["n_3d_slots_total"],
                    r["n_2d_filled_total"], r["seconds"])
        for reason, n in sorted(r["skip_reasons"].items(), key=lambda kv: -kv[1])[:5]:
            logger.info("   skipped %dx: %s", n, reason)
        if r["unsupported_atoms"]:
            logger.warning("   unsupported atom symbols: %s", json.dumps(r["unsupported_atoms"]))
        totals["n_records"] += r["n_records"]
        totals["n_skipped"] += r["n_skipped"]
        totals["shards_written"] += 1
    totals["rows_read"] = dict(ROWS_READ)
    logger.info("done: %s", json.dumps(totals))
    if ns.shard is not None:
        logger.info("array task %d/%d: run --finalize once every task has finished", ns.shard, ns.num_shards)
        return 0
    manifest, report = finalize(ns.products_dir, ns.out_dir, ns, not ns.no_verify_hash)
    return _report_finalize(manifest, report, ns.out_dir)


def _report_finalize(manifest, report, out_dir):
    if manifest is None:
        logger.error("FINALIZE FAILED (%d problem(s)); manifest.json not written:", len(report["problems"]))
        for p in report["problems"][:20]:
            logger.error("   %s", p)
        if report.get("resubmit_array_tasks"):
            logger.error("   resubmit stage 04 with --array=%s",
                         ",".join(str(t) for t in report["resubmit_array_tasks"]))
        return 1
    logger.info("manifest    : complete, %d shards, %d records (%d skipped) from %d input rows%s -> %s",
                manifest["n_shards"], manifest["n_records"], manifest["n_skipped"], manifest["n_input_rows"],
                " [SMOKE]" if manifest["smoke"] else "", os.path.join(out_dir, "manifest.json"))
    return 0


if __name__ == "__main__":
    sys.exit(main())
