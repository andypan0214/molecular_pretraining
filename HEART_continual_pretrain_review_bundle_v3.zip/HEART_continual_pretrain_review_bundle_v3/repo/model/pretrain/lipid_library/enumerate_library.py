#!/usr/bin/env python
"""Deterministic, restartable Ugi-4CR product enumeration over a combination index range.

    python -m lipid_library.enumerate_library BB_DIR -o OUT_DIR [--limit N]
    python -m lipid_library.enumerate_library BB_DIR -o OUT_DIR --shard 3 --num-shards 64
    python -m lipid_library.enumerate_library BB_DIR -o OUT_DIR --check-complete

The combination space is the mixed-radix product of the four roles in the
fixed order (amine, isocyanide, aldehyde, acid), so combination index i maps
to exactly one quadruple on every machine, and any index range can be
regenerated on its own. Work is written in chunks of `--chunk-size`
combinations:

    OUT_DIR/products/products-<start>-<end>.csv.gz     accepted products
    OUT_DIR/products/products-<start>-<end>.done.json  chunk receipt
    OUT_DIR/failures/failures-<start>-<end>.csv.gz     one row per failed combination
    OUT_DIR/enumeration_config.json                    the configuration lock
    OUT_DIR/enumeration_complete.json                  written by --check-complete

Staleness (review fix P0-2). The configuration -- building_blocks.csv and its
source-sheet hashes, the full Ugi policy (ugi.policy()), RDKit/format
versions, chunk size and the enumerated range (so a --limit smoke run is a
different configuration) -- is fingerprinted. OUT_DIR is locked to the first
fingerprint; a run with another configuration fails. A chunk is reused only
if its receipt carries the same fingerprint and its CSV matches the recorded
sha256; a receipt with a different fingerprint is an error, never reused.

Completeness (review fix P0-1). `--check-complete` verifies every chunk of
the configured range and writes enumeration_complete.json with the exact
chunk list, counts and hashes. Downstream stages read ONLY the chunks listed
there, never a directory glob.
"""
import argparse
import json
import logging
import os
import sys
import time

from . import io_utils, provenance, ugi
from .building_blocks import ROLE_ORDER, load_building_blocks

logger = logging.getLogger(__name__)

PRODUCT_FIELDS = [
    "combo_index", "combo_id", "amine_id", "isocyanide_id", "aldehyde_id", "acid_id",
    "product_smiles", "num_heavy_atoms", "num_atoms_with_h", "formal_charge",
    "n_unique_products",
]
FAILURE_FIELDS = ["combo_index", "combo_id", "reason"]
COMPLETE_FILE = "enumeration_complete.json"


class CombinationSpace:
    """Mixed-radix index <-> (amine, isocyanide, aldehyde, acid) reagent rows."""

    def __init__(self, by_role):
        self.by_role = by_role
        self.sizes = [len(by_role[r]) for r in ROLE_ORDER]
        for role, n in zip(ROLE_ORDER, self.sizes):
            if n == 0:
                raise ValueError("no accepted {} reagents".format(role))
        self.total = 1
        for n in self.sizes:
            self.total *= n
        # radix weights, last role varying fastest
        self.weights = [1] * len(self.sizes)
        for i in range(len(self.sizes) - 2, -1, -1):
            self.weights[i] = self.weights[i + 1] * self.sizes[i + 1]

    def decode(self, index):
        if not 0 <= index < self.total:
            raise IndexError("combination index {} outside 0..{}".format(index, self.total - 1))
        out = []
        for role, w, n in zip(ROLE_ORDER, self.weights, self.sizes):
            out.append(self.by_role[role][(index // w) % n])
        return out

    def encode(self, role_indices):
        return sum(i * w for i, w in zip(role_indices, self.weights))


def chunk_bounds(total, chunk_size, start=0, end=None, shard=None, num_shards=1):
    """Yield (chunk_start, chunk_end) ranges, optionally only this shard's chunks."""
    end = total if end is None else min(end, total)
    chunks = []
    s = start
    while s < end:
        chunks.append((s, min(s + chunk_size, end)))
        s += chunk_size
    if shard is None:
        return chunks
    return [c for i, c in enumerate(chunks) if i % num_shards == shard]


def enumeration_config(bb_dir, total, chunk_size, start, end):
    """Everything that determines the content of the product chunks."""
    bb_csv = os.path.join(bb_dir, "building_blocks.csv")
    summary_path = os.path.join(bb_dir, "summary.json")
    source_sha = None
    if os.path.isfile(summary_path):
        with open(summary_path, encoding="utf-8") as fh:
            source_sha = json.load(fh).get("input", {}).get("source_sha256")
    return {
        "stage": "enumeration",
        "building_blocks_sha256": io_utils.sha256_file(bb_csv),
        "source_sheet_sha256": source_sha,
        "ugi_policy": ugi.policy(),
        "versions": provenance.runtime_versions(),
        "n_combinations_total": total,
        "chunk_size": chunk_size,
        "range": [start, end],
        "smoke": not (start == 0 and end == total),
    }


def _receipt_path(out_dir, lo, hi):
    return os.path.join(out_dir, "products", "products-{}-{}.done.json".format(lo, hi))


def _product_path(out_dir, lo, hi):
    return os.path.join(out_dir, "products", "products-{}-{}.csv.gz".format(lo, hi))


def _failure_path(out_dir, lo, hi):
    return os.path.join(out_dir, "failures", "failures-{}-{}.csv.gz".format(lo, hi))


def chunk_is_complete(out_dir, lo, hi, verify_hash=True, config_fingerprint=None):
    """True if this chunk has a valid receipt for this configuration.

    Raises provenance.StaleOutputError if the receipt was written with another
    configuration (it must not be reused, and silently overwriting it would
    hide that the directory mixes configurations).
    """
    rp = _receipt_path(out_dir, lo, hi)
    if not os.path.isfile(rp):
        return False
    try:
        with open(rp, encoding="utf-8") as fh:
            receipt = json.load(fh)
    except (ValueError, OSError):
        return False
    if config_fingerprint is not None and receipt.get("config_fingerprint") != config_fingerprint:
        raise provenance.StaleOutputError(
            "chunk {}-{} in {} was produced with configuration {} (current {}); use a new "
            "output directory".format(lo, hi, out_dir, receipt.get("config_fingerprint"),
                                      config_fingerprint))
    pp = _product_path(out_dir, lo, hi)
    if not os.path.isfile(pp):
        return False
    if receipt.get("start") != lo or receipt.get("end") != hi:
        return False
    if verify_hash and receipt.get("products_sha256") != io_utils.sha256_file(pp):
        logger.warning("chunk %d-%d: sha256 mismatch, regenerating", lo, hi)
        return False
    return True


def enumerate_chunk(space, mols, out_dir, lo, hi, config_fingerprint=None):
    """Enumerate [lo, hi) and write the product/failure files plus the receipt."""
    from rdkit import RDLogger

    RDLogger.DisableLog("rdApp.*")
    os.makedirs(os.path.join(out_dir, "products"), exist_ok=True)
    os.makedirs(os.path.join(out_dir, "failures"), exist_ok=True)
    pw = io_utils.AtomicGzCsvWriter(_product_path(out_dir, lo, hi), PRODUCT_FIELDS)
    fw = io_utils.AtomicGzCsvWriter(_failure_path(out_dir, lo, hi), FAILURE_FIELDS)
    reasons = {}
    n_multi = 0
    t0 = time.time()
    try:
        for index in range(lo, hi):
            rows = space.decode(index)
            combo_id = "-".join(r["id"] for r in rows)
            amine, iso, ald, acid = rows
            try:
                smi, info = ugi.product_smiles(
                    mols[acid["id"]], mols[amine["id"]], mols[ald["id"]], mols[iso["id"]])
            except ugi.UgiError as exc:
                reason = str(exc)
                reasons[reason] = reasons.get(reason, 0) + 1
                fw.writerow([index, combo_id, reason])
                continue
            except Exception as exc:  # unexpected RDKit failure: recorded, never fatal
                reason = "{}: {}".format(type(exc).__name__, exc)
                reasons[reason] = reasons.get(reason, 0) + 1
                fw.writerow([index, combo_id, reason])
                continue
            n_multi += int(info["n_unique_products"] > 1)
            pw.writerow([index, combo_id, amine["id"], iso["id"], ald["id"], acid["id"],
                         smi, info["num_heavy_atoms"], info["num_atoms_with_h"],
                         info["formal_charge"], info["n_unique_products"]])
    except BaseException:
        pw.close(commit=False)
        fw.close(commit=False)
        raise
    n_products, n_failures = pw.n, fw.n
    pw.close()
    fw.close()
    receipt = {
        "start": lo, "end": hi, "n_combinations": hi - lo,
        "n_products": n_products, "n_failures": n_failures,
        "n_multi_product_combinations": n_multi,
        "failure_reasons": reasons,
        "products_sha256": io_utils.sha256_file(_product_path(out_dir, lo, hi)),
        "failures_sha256": io_utils.sha256_file(_failure_path(out_dir, lo, hi)),
        "seconds": round(time.time() - t0, 3),
        "ugi_reaction_smarts": ugi.UGI_SMARTS,
        "config_fingerprint": config_fingerprint,
    }
    io_utils.atomic_write_json(_receipt_path(out_dir, lo, hi), receipt)
    return receipt


def check_complete(out_dir, chunks, config, fp, verify_hash=True):
    """Verify every chunk; write enumeration_complete.json if all present. Returns (ok, record)."""
    missing, records = [], []
    for lo, hi in chunks:
        if not chunk_is_complete(out_dir, lo, hi, verify_hash, fp):
            missing.append([lo, hi])
            continue
        with open(_receipt_path(out_dir, lo, hi), encoding="utf-8") as fh:
            r = json.load(fh)
        records.append({"start": lo, "end": hi, "n_products": r["n_products"],
                        "n_failures": r["n_failures"],
                        "products_file": os.path.relpath(_product_path(out_dir, lo, hi), out_dir).replace("\\", "/"),
                        "products_sha256": r["products_sha256"]})
    record = {
        "complete": not missing,
        "config_fingerprint": fp,
        "smoke": config["smoke"],
        "range": config["range"],
        "n_chunks_expected": len(chunks),
        "n_chunks_complete": len(records),
        "missing_chunks": missing,
        "n_combinations": sum(c[1] - c[0] for c in chunks),
        "n_products": sum(r["n_products"] for r in records),
        "n_failures": sum(r["n_failures"] for r in records),
        "chunks": records,
    }
    path = os.path.join(out_dir, COMPLETE_FILE)
    if missing:
        if os.path.exists(path):
            os.remove(path)            # never leave a stale "complete" record behind
        return False, record
    record["n_products_plus_failures_equals_combinations"] = (
        record["n_products"] + record["n_failures"] == record["n_combinations"])
    if not record["n_products_plus_failures_equals_combinations"]:
        record["complete"] = False
        return False, record
    io_utils.atomic_write_json(path, record)
    return True, record


def load_complete(enum_dir):
    """Read and re-verify enumeration_complete.json. Raises if absent or inconsistent."""
    path = os.path.join(enum_dir, COMPLETE_FILE)
    if not os.path.isfile(path):
        raise provenance.StaleOutputError(
            "{} not found: run `enumerate_library ... --check-complete` after every enumeration "
            "task has finished".format(path))
    with open(path, encoding="utf-8") as fh:
        record = json.load(fh)
    locked = provenance.read_config(enum_dir, "enumeration")
    if not record.get("complete") or locked is None or locked["fingerprint"] != record["config_fingerprint"]:
        raise provenance.StaleOutputError("{}: not a complete enumeration for the locked "
                                          "configuration".format(path))
    return record


def load_mols(by_role):
    from rdkit import Chem

    mols = {}
    for role in ROLE_ORDER:
        for row in by_role[role]:
            mol = Chem.MolFromSmiles(row["canonical_smiles"])
            if mol is None:
                raise ValueError("{}: canonical SMILES no longer parses".format(row["id"]))
            mols[row["id"]] = mol
    return mols


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("bb_dir", help="directory holding building_blocks.csv")
    ap.add_argument("-o", "--out-dir", required=True)
    ap.add_argument("--chunk-size", type=int, default=50000)
    ap.add_argument("--start", type=int, default=0)
    ap.add_argument("--end", type=int, default=None)
    ap.add_argument("--limit", type=int, default=None,
                    help="smoke mode: enumerate only the first N combinations of the range "
                         "(a different configuration: never usable as the production library)")
    ap.add_argument("--shard", type=int, default=None, help="process only chunks i where i %% num_shards == shard")
    ap.add_argument("--num-shards", type=int, default=1)
    ap.add_argument("--force", action="store_true",
                    help="re-enumerate chunks that already have a receipt (same configuration only)")
    ap.add_argument("--no-verify-hash", action="store_true", help="trust receipts without re-hashing the CSV")
    ap.add_argument("--check-complete", action="store_true",
                    help="enumerate nothing; verify every chunk and write enumeration_complete.json "
                         "(exit 1 if any chunk is missing)")
    ns = ap.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(message)s")

    by_role = load_building_blocks(os.path.join(ns.bb_dir, "building_blocks.csv"))
    space = CombinationSpace(by_role)
    end = space.total if ns.end is None else min(ns.end, space.total)
    if ns.limit is not None:
        end = min(end, ns.start + ns.limit)
    if ns.shard is not None and not 0 <= ns.shard < ns.num_shards:
        raise SystemExit("--shard must be in 0..num_shards-1")
    config = enumeration_config(ns.bb_dir, space.total, ns.chunk_size, ns.start, end)
    try:
        fp = provenance.lock_config(ns.out_dir, "enumeration", config)
    except provenance.StaleOutputError as exc:
        raise SystemExit("ERROR: {}".format(exc))

    logger.info("reagents    : %s", ", ".join("{} {}".format(n, r) for r, n in zip(ROLE_ORDER, space.sizes)))
    logger.info("combinations: %d total; range %d..%d%s", space.total, ns.start, end,
                " (SMOKE: not a production library)" if config["smoke"] else "")
    logger.info("config      : %s", fp)

    if ns.check_complete:
        try:
            ok, record = check_complete(ns.out_dir, chunk_bounds(space.total, ns.chunk_size, ns.start, end),
                                        config, fp, not ns.no_verify_hash)
        except provenance.StaleOutputError as exc:
            raise SystemExit("ERROR: {}".format(exc))
        logger.info("complete: %d of %d chunks; %d products, %d failures; missing %s",
                    record["n_chunks_complete"], record["n_chunks_expected"], record["n_products"],
                    record["n_failures"], record["missing_chunks"][:10])
        return 0 if ok else 1

    chunks = chunk_bounds(space.total, ns.chunk_size, ns.start, end, ns.shard, ns.num_shards)
    logger.info("chunks      : %d of size %d%s", len(chunks), ns.chunk_size,
                "" if ns.shard is None else " (shard {}/{})".format(ns.shard, ns.num_shards))
    mols = load_mols(by_role)
    totals = {"n_combinations": 0, "n_products": 0, "n_failures": 0, "skipped_chunks": 0}
    for lo, hi in chunks:
        try:
            done = not ns.force and chunk_is_complete(ns.out_dir, lo, hi, not ns.no_verify_hash, fp)
        except provenance.StaleOutputError as exc:
            raise SystemExit("ERROR: {}".format(exc))
        if done:
            logger.info("chunk %d-%d: already complete, skipped", lo, hi)
            totals["skipped_chunks"] += 1
            continue
        r = enumerate_chunk(space, mols, ns.out_dir, lo, hi, fp)
        logger.info("chunk %d-%d: %d products, %d failures, %.1fs",
                    lo, hi, r["n_products"], r["n_failures"], r["seconds"])
        for k in ("n_combinations", "n_products", "n_failures"):
            totals[k] += r[k]
    logger.info("done: %s", json.dumps(totals))
    if ns.shard is None:
        ok, record = check_complete(ns.out_dir, chunk_bounds(space.total, ns.chunk_size, ns.start, end),
                                    config, fp, not ns.no_verify_hash)
        logger.info("enumeration_complete.json: %s", "written" if ok else "NOT written (incomplete)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
