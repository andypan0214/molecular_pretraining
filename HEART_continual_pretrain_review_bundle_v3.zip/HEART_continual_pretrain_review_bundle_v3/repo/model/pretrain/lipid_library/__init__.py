"""HEART x LUMI lipid library: Ugi-4CR virtual products -> conformers -> HEART LMDB.

Pipeline (each stage is a restartable CLI, see README_CONTINUAL.md):

  building_blocks   Excel/CSV reagents -> validated building_blocks.csv + QC
  enumerate_library combination index range -> Ugi-4CR products (chunked, gz CSV)
  dedup             global duplicate detection over all enumeration chunks
  lmdb_writer       product shard -> ETKDGv3/MMFF conformers -> shard LMDBs
  pack              shard LMDBs -> HEART-compatible pack LMDBs + manifest.json
  validate_lmdb     record-level QC of pack/shard LMDBs against dict.txt

Nothing here touches the general-pretraining code path.
"""

FORMAT_VERSION = "heart-lipid-lmdb-v1"
