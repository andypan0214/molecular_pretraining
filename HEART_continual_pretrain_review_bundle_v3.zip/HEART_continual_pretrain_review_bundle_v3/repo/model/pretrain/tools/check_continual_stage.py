#!/usr/bin/env python
"""Verify that a checkpoint belongs to the continual stage before resuming it.

    python pretrain/tools/check_continual_stage.py <run>/checkpoint_last.pt \
        --expect-task unimol_contrastive_continual --expect-total-num-update 200000 \
        [--stage-file <run>/continual_stage.json] [--expect-min-updates 1]

A resume must not silently turn into something else. This tool refuses a
checkpoint that

  * was written by a different task (e.g. the general `unimol_contrastive`
    checkpoint copied into the continual run directory),
  * carries a different `--total-num-update`, which would mean the
    polynomial-decay schedule of the stored optimizer state does not match
    the schedule of the resumed command,
  * has no optimizer state, no LR-scheduler state or no update counter, so a
    resume would quietly restart with a fresh optimizer,
  * disagrees with the stage marker written when the continual stage started
    (the general checkpoint it came from, the learning rate, the warmup, the
    data weights).

Exit code 0 only if every check passes. The checkpoint is opened read-only.
"""
import argparse
import json
import os
import sys


def load(path):
    import torch

    try:
        return torch.load(path, map_location="cpu", weights_only=False)
    except TypeError:  # torch < 1.13
        return torch.load(path, map_location="cpu")


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("checkpoint")
    ap.add_argument("--expect-task", default="unimol_contrastive_continual")
    ap.add_argument("--expect-total-num-update", type=int, default=None)
    ap.add_argument("--expect-min-updates", type=int, default=1)
    ap.add_argument("--stage-file", default=None)
    ns = ap.parse_args(argv)

    if not os.path.isfile(ns.checkpoint):
        print("FAIL  checkpoint not found: {}".format(ns.checkpoint))
        return 1
    ck = load(ns.checkpoint)
    args = ck.get("args")
    history = ck.get("optimizer_history") or []
    last = history[-1] if history else {}
    updates = last.get("num_updates")
    checks = []

    checks.append(("checkpoint has model weights", bool(ck.get("model"))))
    checks.append(("checkpoint has args", args is not None))
    task = getattr(args, "task", None)
    checks.append(("task is {} (got {})".format(ns.expect_task, task), task == ns.expect_task))
    checks.append(("optimizer state present (a resume would otherwise restart the optimizer)",
                   ck.get("last_optimizer_state") is not None))
    checks.append(("LR-scheduler state present", bool(last.get("lr_scheduler_state"))))
    checks.append(("update counter present", isinstance(updates, int)))
    if isinstance(updates, int):
        checks.append(("update counter {} >= {}".format(updates, ns.expect_min_updates),
                       updates >= ns.expect_min_updates))
    if ns.expect_total_num_update is not None:
        stored = getattr(args, "total_num_update", None)
        checks.append(("total-num-update is {} (got {})".format(ns.expect_total_num_update, stored),
                       stored == ns.expect_total_num_update))
    extra = ck.get("extra_state") or {}
    prev_hours = float(extra.get("previous_training_time", 0.0)) / 3600.0
    print("checkpoint : {}".format(ns.checkpoint))
    print("task       : {}".format(task))
    print("updates    : {} / total-num-update {}".format(updates, getattr(args, "total_num_update", None)))
    print("lr / warmup: {} / {}".format(getattr(args, "lr", None), getattr(args, "warmup_updates", None)))
    print("recorded training time: {:.2f} h".format(prev_hours))

    if ns.stage_file and os.path.isfile(ns.stage_file):
        with open(ns.stage_file, encoding="utf-8") as fh:
            stage = json.load(fh)
        print("stage file : {} (from {})".format(ns.stage_file, stage.get("general_checkpoint")))
        checks.append(("stage file says stage=continual", stage.get("stage") == "continual"))
        checks.append(("stage file task matches the checkpoint",
                       stage.get("task") == task))
        for key, attr in (("total_num_update", "total_num_update"), ("lr", "lr"),
                          ("warmup_updates", "warmup_updates"),
                          ("general_data_weight", "general_data_weight"),
                          ("lipid_data_weight", "lipid_data_weight")):
            if key in stage:
                got = getattr(args, attr, None)
                if isinstance(got, (list, tuple)) and len(got) == 1:   # Uni-Core stores lr as [lr]
                    got = got[0]
                try:
                    same = float(stage[key]) == float(got)
                except (TypeError, ValueError):
                    same = stage[key] == got
                checks.append(("stage file {} {} matches the checkpoint ({})".format(
                    key, stage[key], got), same))
    elif ns.stage_file:
        print("stage file : {} (absent; not compared)".format(ns.stage_file))

    ok = True
    for name, passed in checks:
        print("{}  {}".format("PASS" if passed else "FAIL", name))
        ok &= bool(passed)
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
