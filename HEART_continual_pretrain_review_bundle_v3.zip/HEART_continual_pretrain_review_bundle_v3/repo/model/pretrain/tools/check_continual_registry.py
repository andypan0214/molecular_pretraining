#!/usr/bin/env python
"""Verify that Uni-Core discovers the HEART continual registrations via --user-dir.

Run from the model root (the directory that contains `unimol/` and `pretrain/`):
    cd /home/ypan/heart_liver/model_train/heart-molecular-pretraining/model
    python pretrain/tools/check_continual_registry.py --user-dir ./unimol

Exit code 0 only if the continual task is registered next to the unchanged
general task, model, architecture and loss, if `unimol` resolves to the
directory passed with --user-dir, and if the continual task's own options are
present on the parser.
"""
import argparse
import os
import sys
from types import SimpleNamespace

EXPECTED = {
    "general_task": "unimol_contrastive",
    "continual_task": "unimol_contrastive_continual",
    "model": "unimol_contrastive",
    "arch": "unimol_contrastive_base",
    "loss": "unimol_contrastive",
}
CONTINUAL_OPTIONS = [
    "--lipid-splits", "--lipid-lmdb", "--general-data-weight", "--lipid-data-weight",
    "--mixture-report", "--contrastive-view-mode", "--invalid-smiles-policy",
]


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--user-dir", default="./unimol")
    ns = parser.parse_args(argv)

    import unicore
    from unicore import utils
    from unicore.losses import CRITERION_REGISTRY as LOSS_REGISTRY
    from unicore.models import ARCH_MODEL_REGISTRY, MODEL_REGISTRY
    from unicore.tasks import TASK_REGISTRY

    user_dir = os.path.abspath(ns.user_dir)
    print("cwd        :", os.getcwd())
    print("user-dir   :", user_dir)
    print("unicore    :", unicore.__file__)
    utils.import_user_module(SimpleNamespace(user_dir=ns.user_dir))
    unimol = sys.modules.get("unimol")
    unimol_dir = os.path.dirname(os.path.abspath(unimol.__file__)) if unimol else None
    print("unimol     :", unimol_dir)

    checks = [
        ("unimol package resolves to --user-dir", unimol_dir == user_dir),
        ("task  " + EXPECTED["general_task"] + " (unchanged)", EXPECTED["general_task"] in TASK_REGISTRY),
        ("task  " + EXPECTED["continual_task"], EXPECTED["continual_task"] in TASK_REGISTRY),
        ("model " + EXPECTED["model"], EXPECTED["model"] in MODEL_REGISTRY),
        ("arch  " + EXPECTED["arch"], EXPECTED["arch"] in ARCH_MODEL_REGISTRY),
        ("loss  " + EXPECTED["loss"], EXPECTED["loss"] in LOSS_REGISTRY),
    ]
    if EXPECTED["continual_task"] in TASK_REGISTRY:
        ap = argparse.ArgumentParser(add_help=False)
        TASK_REGISTRY[EXPECTED["continual_task"]].add_args(ap)
        known = {s for a in ap._actions for s in a.option_strings}
        for opt in CONTINUAL_OPTIONS:
            checks.append(("option " + opt, opt in known))
        cls = TASK_REGISTRY[EXPECTED["continual_task"]]
        general = TASK_REGISTRY.get(EXPECTED["general_task"])
        checks.append(("the continual task reuses the general task class",
                       general is not None and issubclass(cls, general)))

    ok = True
    for name, passed in checks:
        print("{}  {}".format("PASS" if passed else "FAIL", name))
        ok &= bool(passed)
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
