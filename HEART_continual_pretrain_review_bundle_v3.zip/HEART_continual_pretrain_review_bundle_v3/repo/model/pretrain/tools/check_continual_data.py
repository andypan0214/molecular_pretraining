#!/usr/bin/env python
"""Read-only preflight of the continual training data. Exit 0 only if it is safe to train.

    python pretrain/tools/check_continual_data.py --general <ligand dir> \
        --lipid-splits <lipid lmdb>/splits.json [--sample 64] [--lipid-shards 256] \
        [--records-per-shard 4] [--seed 1] [--verify-hashes] [--allow-smoke] [--json-out f]

Checks (review fixes P1 "2D policy" and P0-1 "incomplete dataset", extended
for the v2 review P1 "preflight samples only the first 64 lipid shards"):

  1. lipid splits.json says complete, is not smoke (unless --allow-smoke),
     has a non-empty valid split, and its manifest.json still has the hash
     recorded in splits.json (the manifest was not regenerated underneath it);
  2. METADATA OF EVERY SHARD (no sampling): each shard in splits.json is in
     the manifest exactly once and in one split only; every manifest shard is
     in a split; its LMDB exists, its receipt (shard.json) exists and agrees
     with the manifest (sha256, record count, slot policy); the LMDB's entry
     count equals the manifest count (one short-lived open per shard, so at
     most ONE LMDB handle is open at any time); every shard declares the same
     coordinate-slot count and stored-2D flag as the manifest. With
     --verify-hashes the sha256 of every LMDB is recomputed (slow: reads all data);
  3. RECORDS SAMPLED ACROSS ALL SHARD IDS: the shard list of each split is cut
     into --lipid-shards contiguous strata and one shard is drawn from each
     (sha256(seed:shard id) rank, reproducible); --records-per-shard records
     spread over each drawn shard are read. Every sampled lipid record must
     store exactly the declared number of slots, and, if the manifest declares
     a stored 2D conformer, have at least one flat slot;
  4. the conformer-slot profile -- stored slots / 2D-like (flat) slots -- of
     the general train.lmdb and valid.lmdb and of the lipid splits; the
     dominant profile of every source must be identical (otherwise P(2D)
     differs at training time, e.g. 1/11 vs 2/12). The fix is to rebuild the
     lipid shards with the general convention, never to edit the general data.

The training-time view (slots after the runtime 2D conformer, P(2D)) is
printed for both sources. Nothing is written except --json-out.
"""
import argparse
import hashlib
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))   # model/pretrain -> lipid_library


def dominant(profiles):
    if not profiles:
        return None, 0.0
    key = max(sorted(profiles), key=lambda k: profiles[k])
    return key, profiles[key] / float(sum(profiles.values()))


def stratified_sample(ids, k, seed):
    """One id per contiguous stratum (k strata) by sha256 rank; all ids when k >= len(ids)."""
    ids = list(ids)
    if k <= 0 or not ids:
        return []
    if k >= len(ids):
        return ids
    q, r = divmod(len(ids), k)
    out, start = [], 0
    for i in range(k):
        size = q + (1 if i < r else 0)
        group = ids[start:start + size]
        start += size
        out.append(min(group, key=lambda x: hashlib.sha256("{}:{}".format(seed, x).encode()).hexdigest()))
    return out


def lmdb_entries(path):
    import lmdb

    env = lmdb.open(path, subdir=False, readonly=True, lock=False, readahead=False,
                    meminit=False, max_readers=4)
    try:
        with env.begin() as txn:
            return txn.stat()["entries"]
    finally:
        env.close()


def check_lipid_metadata(splits_path, meta, verify_hashes=False):
    """Every shard's metadata (no sampling). Returns (problems, manifest, {split: [shard dict]})."""
    from lipid_library import io_utils

    problems = []
    lmdb_dir = os.path.dirname(os.path.abspath(splits_path))
    manifest_path = os.path.join(lmdb_dir, "manifest.json")
    if not os.path.isfile(manifest_path):
        return ["lipid manifest.json missing next to splits.json"], None, {}
    try:
        with open(manifest_path, encoding="utf-8") as fh:
            manifest = json.load(fh)
    except ValueError as exc:
        return ["lipid manifest.json is corrupt: {}".format(exc)], None, {}
    if manifest.get("complete") is not True:
        problems.append("lipid manifest.json is not complete")
    declared_slots = manifest.get("coordinate_slots_per_record")
    declared_2d = manifest.get("stored_2d_conformer")
    if not isinstance(declared_slots, list) or len(declared_slots) != 1:
        problems.append("the manifest must declare exactly one coordinate-slot count, got {}".format(declared_slots))
    if not isinstance(declared_2d, list) or len(declared_2d) != 1:
        problems.append("the manifest must declare exactly one stored-2D policy, got {}".format(declared_2d))
    if meta.get("coordinate_slots_per_record") != declared_slots or meta.get("stored_2d_conformer") != declared_2d:
        problems.append("splits.json and manifest.json declare different slot policies")
    shards = manifest.get("shards") or []
    by_lmdb = {}
    for s in shards:
        if s.get("lmdb") in by_lmdb:
            problems.append("manifest lists {} twice".format(s.get("lmdb")))
        by_lmdb[s.get("lmdb")] = s
    if manifest.get("n_shards") != len(shards):
        problems.append("manifest n_shards {} != {} shard entries".format(manifest.get("n_shards"), len(shards)))
    if sum(s.get("n_records", 0) for s in shards) != manifest.get("n_records"):
        problems.append("manifest n_records does not equal the sum over its shards")

    per_split, seen = {}, {}
    for split in ("train", "valid"):
        per_split[split] = []
        for rel in meta.get(split) or []:
            if rel not in by_lmdb:
                problems.append("{} shard {} is not in the manifest".format(split, rel))
                continue
            seen.setdefault(rel, []).append(split)
            per_split[split].append(by_lmdb[rel])
    single_overlap = len(shards) == 1 and meta.get("smoke")
    for rel, where in seen.items():
        if len(where) > 1 and not single_overlap:
            problems.append("shard {} is in more than one split: {}".format(rel, where))
    unassigned = sorted(set(by_lmdb) - set(seen))
    if unassigned:
        problems.append("{} manifest shard(s) in no split: {}".format(len(unassigned), unassigned[:10]))

    n_bad = 0
    for s in shards:
        rel = s.get("lmdb")
        path = os.path.join(lmdb_dir, rel or "")
        bad = []
        if s.get("coordinate_slots_per_record") not in (declared_slots or []):
            bad.append("declares {} slots".format(s.get("coordinate_slots_per_record")))
        if bool(s.get("stored_2d_conformer")) not in (declared_2d or []):
            bad.append("declares stored 2D {}".format(s.get("stored_2d_conformer")))
        if not rel or not os.path.isfile(path):
            bad.append("LMDB missing")
        else:
            receipt_path = os.path.join(lmdb_dir, s.get("dir", os.path.dirname(rel)), "shard.json")
            try:
                with open(receipt_path, encoding="utf-8") as fh:
                    receipt = json.load(fh)
            except (OSError, ValueError):
                receipt = None
                bad.append("receipt shard.json missing or corrupt")
            if receipt is not None:
                for key in ("lmdb_sha256", "n_records", "coordinate_slots_per_record", "stored_2d_conformer"):
                    if receipt.get(key) != s.get(key):
                        bad.append("receipt {} {} != manifest {}".format(key, receipt.get(key), s.get(key)))
            try:
                n = lmdb_entries(path)
                if n != s.get("n_records"):
                    bad.append("LMDB has {} entries, manifest says {}".format(n, s.get("n_records")))
            except Exception as exc:          # corrupt / unreadable LMDB
                bad.append("LMDB unreadable: {}: {}".format(type(exc).__name__, exc))
            if verify_hashes and not bad and io_utils.sha256_file(path) != s.get("lmdb_sha256"):
                bad.append("sha256 differs from the manifest")
        if bad:
            n_bad += 1
            if n_bad <= 20:
                problems.append("lipid shard {}: {}".format(rel, "; ".join(bad)))
    if n_bad > 20:
        problems.append("... {} lipid shards with metadata problems in total".format(n_bad))
    return problems, manifest, per_split


def main(argv=None):
    from lipid_library import io_utils
    from lipid_library.splits import load_splits
    from lipid_library.validate_lmdb import runtime_view, slot_profile

    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--general", required=True, help="general ligand dir (train.lmdb, valid.lmdb)")
    ap.add_argument("--lipid-splits", default=None)
    ap.add_argument("--lipid-lmdb", default=None, help="comma-separated LMDBs (smoke hook)")
    ap.add_argument("--sample", type=int, default=64, help="records per general LMDB")
    ap.add_argument("--lipid-shards", type=int, default=256,
                    help="lipid shards sampled per split, one per stratum over ALL shard ids")
    ap.add_argument("--records-per-shard", type=int, default=4, help="records read per sampled lipid shard")
    ap.add_argument("--seed", type=int, default=1, help="shard-sampling seed (reproducible)")
    ap.add_argument("--verify-hashes", action="store_true", help="recompute every lipid LMDB sha256 (slow)")
    ap.add_argument("--allow-smoke", action="store_true")
    ap.add_argument("--min-dominant-fraction", type=float, default=0.95,
                    help="the dominant slot profile must cover at least this fraction of the sample")
    ap.add_argument("--json-out", default=None)
    ns = ap.parse_args(argv)

    problems, sources, sampled = [], {}, {}
    for split in ("train", "valid"):
        p = os.path.join(ns.general, split + ".lmdb")
        if not os.path.isfile(p):
            problems.append("general {} missing: {}".format(split, p))
            continue
        sources["general:" + split] = [slot_profile(p, ns.sample)]

    lipid_paths, declared_slots, declared_2d, metadata = {}, None, None, None
    if ns.lipid_splits:
        with open(ns.lipid_splits, encoding="utf-8") as fh:
            meta = json.load(fh)
        if meta.get("complete") is not True:
            problems.append("lipid splits.json is not from a complete, finalised dataset")
        if meta.get("smoke") and not ns.allow_smoke:
            problems.append("lipid splits.json is a SMOKE dataset (pass --allow-smoke only for tests)")
        manifest = os.path.join(os.path.dirname(os.path.abspath(ns.lipid_splits)), "manifest.json")
        if os.path.isfile(manifest) and meta.get("manifest_sha256") != io_utils.sha256_file(manifest):
            problems.append("lipid manifest.json changed after splits.json was written; re-run splits")
        meta_problems, manifest_obj, per_split = check_lipid_metadata(ns.lipid_splits, meta, ns.verify_hashes)
        problems.extend(meta_problems)
        if manifest_obj:
            declared_slots = (manifest_obj.get("coordinate_slots_per_record") or [None])[0]
            declared_2d = (manifest_obj.get("stored_2d_conformer") or [None])[0]
            metadata = {"n_shards": manifest_obj.get("n_shards"), "declared_slots": declared_slots,
                        "declared_stored_2d": declared_2d, "n_metadata_problems": len(meta_problems)}
        for split in ("train", "valid"):
            try:
                paths, _ = load_splits(ns.lipid_splits, split)
            except (KeyError, FileNotFoundError) as exc:
                problems.append(str(exc))
                continue
            lipid_paths[split] = paths
        if not lipid_paths.get("valid"):
            problems.append("lipid valid split is empty")
    elif ns.lipid_lmdb:
        if not ns.allow_smoke:
            problems.append("--lipid-lmdb is a smoke-test hook; pass --allow-smoke")
        lipid_paths["train"] = [p for p in ns.lipid_lmdb.split(",") if p]
    else:
        problems.append("no lipid data given")

    n_record_violations = 0
    for split, paths in lipid_paths.items():
        chosen = stratified_sample(list(range(len(paths))), ns.lipid_shards, ns.seed)
        results = []
        for i in chosen:
            try:
                r = slot_profile(paths[i], ns.records_per_shard)      # one handle, closed on return
            except Exception as exc:
                problems.append("lipid {} shard {} unreadable: {}".format(split, paths[i], exc))
                continue
            results.append(r)
            if declared_slots is not None:
                for key, n in r["profiles"].items():
                    stored, flat = (int(x) for x in key.split("/"))
                    if stored != declared_slots or (declared_2d and flat == 0):
                        n_record_violations += n
                        if n_record_violations <= 20:
                            problems.append("lipid {} shard {}: {} record(s) with profile {} contradict the "
                                            "declared policy ({} slots, stored 2D {})".format(
                                                split, paths[i], n, key, declared_slots, declared_2d))
        sources["lipid:" + split] = results
        sampled[split] = {"n_shards": len(paths), "n_shards_sampled": len(chosen),
                          "shard_positions_sampled": chosen, "seed": ns.seed,
                          "records_per_shard": ns.records_per_shard}

    summary = {}
    for name, results in sources.items():
        merged = {}
        for r in results:
            for k, v in r["profiles"].items():
                merged[k] = merged.get(k, 0) + v
        key, frac = dominant(merged)
        summary[name] = {"profiles": merged, "dominant": key, "dominant_fraction": round(frac, 4),
                         "n_lmdbs_sampled": len(results)}
        if key is None:
            problems.append("{}: no record sampled".format(name))
            continue
        slots, p2d = runtime_view(key)
        summary[name].update({"training_time_slots": slots, "training_time_p_2d": round(p2d, 4)})
        print("{:<14} stored/flat {} ({:.1%} of {} sampled from {} LMDB(s)) -> training: {} slots, "
              "P(2D) = {:.4f}".format(name, key, frac, sum(merged.values()), len(results), slots, p2d))
        if frac < ns.min_dominant_fraction:
            problems.append("{}: dominant slot profile covers only {:.1%} of the sample ({})".format(
                name, frac, merged))
    dominants = {v["dominant"] for v in summary.values() if v.get("dominant")}
    if len(dominants) > 1:
        problems.append("conformer slot profiles differ between sources: {}. Rebuild the lipid shards "
                        "with the general convention (--store-2d / --no-store-2d, --n-3d)".format(
                            {k: v.get("dominant") for k, v in summary.items()}))
    if metadata:
        print("lipid metadata: {} shards checked (declared {} slots, stored 2D {}), {} problem(s)".format(
            metadata["n_shards"], metadata["declared_slots"], metadata["declared_stored_2d"],
            metadata["n_metadata_problems"]))
    for p in problems:
        print("FAIL  " + p)
    if not problems:
        print("PASS  continual data preflight: one slot profile {} for every source".format(dominants.pop()))
    if ns.json_out:
        io_utils.atomic_write_json(ns.json_out, {"sources": summary, "problems": problems,
                                                 "lipid_sampling": sampled, "lipid_metadata": metadata,
                                                 "n_record_policy_violations": n_record_violations})
    return 0 if not problems else 1


if __name__ == "__main__":
    sys.exit(main())
