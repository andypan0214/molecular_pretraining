#!/usr/bin/env python
"""Prepare a HEART general checkpoint for the continual stage. Read-only on its input.

    python pretrain/tools/init_continual_checkpoint.py GENERAL_CHECKPOINT \
        --data <general ligand dir> --out <continual run dir>/continual_init.pt \
        [--user-dir ./unimol] [--arch unimol_contrastive_base] [--report report.json] \
        [-- <the continual unicore-train command>]

When the continual training command is given after `--` (the H200 launcher
always does this), its architecture/representation flags (ARCH_FLAGS) are
compared with the checkpoint's stored args, and the reference model used for
the strict shape check is built with the command's values. The check then
covers the model training will actually build, not only the checkpoint's own
configuration.

Why this exists instead of pointing `--finetune-from-model` straight at the
general checkpoint:

  1. STRICT SHAPE CHECK. A fresh continual model is built from the registry
     and every parameter is compared with the checkpoint by name and shape,
     including the token embedding (against `len(dictionary)`), the encoder,
     the masked-LM head, the pair/coordinate heads and the contrastive
     projector. Uni-Core itself loads with `strict=False` and only *logs*
     missing or unexpected keys, so a silent partial load is possible; here
     anything missing, unexpected or mis-shaped is an error.
  2. TRAINING-TIME POISONING. Uni-Core restores
     `extra_state["previous_training_time"]` even when the optimizer, the LR
     scheduler, the meters and the dataloader are all reset. A general
     checkpoint carries hundreds of hours there, while
     `tools/stop_time_hours.py` derives `--stop-time-hours` from the (empty)
     continual run directory. The continual job would then exceed its stop
     time on the first update and exit immediately. The checkpoint written
     here therefore contains the model weights only: no `extra_state`, no
     `optimizer_history`, no `last_optimizer_state`, no EMA state.

The result is that the continual stage starts with the general weights but a
new optimizer, a new polynomial-decay schedule over its own
`--total-num-update`, a new fp16 loss scaler and update counter 0, while a
later resubmission resumes `checkpoint_last.pt` from the continual directory
with all of that state intact.
"""
import argparse
import json
import os
import sys
from types import SimpleNamespace

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))  # check_resume_args

# Parameters whose value must match between the general checkpoint and the
# continual stage, or the pretrained weights / input representation do not
# apply. Loss weights are deliberately NOT here: the continual stage uses
# LUMI's continual weights 0.5/1/5, which differ from the general 1/5/10.
ARCH_KEYS = [
    "arch", "encoder_layers", "encoder_embed_dim", "encoder_ffn_embed_dim",
    "encoder_attention_heads", "activation_fn", "pooler_activation_fn",
    "post_ln", "dict_name", "only_polar", "max_atoms", "max_seq_len",
]
# Command-line spelling of the flags compared against the training command.
ARCH_FLAGS = [
    "arch", "encoder-layers", "encoder-embed-dim", "encoder-ffn-embed-dim",
    "encoder-attention-heads", "activation-fn", "pooler-activation-fn",
    "dict-name", "only-polar", "max-atoms", "max-seq-len",
]
# Parameters the continual stage is expected to change (reported, never fatal).
EXPECTED_DIFFERENT = [
    "task", "lr", "warmup_updates", "total_num_update", "max_update", "seed",
    "save_dir", "tmp_save_dir", "data", "batch_size", "batch_size_valid",
    "save_interval_updates", "validate_interval_updates", "keep_interval_updates",
    "num_workers", "log_interval", "tensorboard_logdir", "stop_time_hours",
    "restore_file", "finetune_from_model", "update_freq", "weight_decay",
    "masked_token_loss", "masked_coord_loss", "masked_dist_loss", "mode",
]


def load_checkpoint(path):
    import torch

    try:
        return torch.load(path, map_location="cpu", weights_only=False)
    except TypeError:  # torch < 1.13
        return torch.load(path, map_location="cpu")


def command_arch_values(cmd):
    """Architecture flags of a unicore-train command (last occurrence wins)."""
    from check_resume_args import command_values

    values = command_values(cmd)
    return {k: values[k] for k in ARCH_FLAGS if k in values}


def compare_command(ck_args, cmd_values):
    """[(flag, checkpoint value, command value)] for every differing arch flag."""
    from check_resume_args import same

    out = []
    for flag, wanted in sorted(cmd_values.items()):
        stored = getattr(ck_args, flag.replace("-", "_"), "<absent>")
        if not same(stored, wanted):
            out.append((flag, stored, wanted))
    return out


def _coerce(stored, wanted):
    """Give a command-line string the type of the stored checkpoint value."""
    if isinstance(stored, bool):
        return str(wanted).lower() in ("1", "true", "yes")
    for t in (int, float):
        if isinstance(stored, t):
            try:
                return t(wanted)
            except (TypeError, ValueError):
                return wanted
    return wanted


def build_reference_model(ck_args, data, user_dir, arch=None, dict_name=None, task_name=None,
                          cmd_values=None):
    """Build a fresh continual model from the registry; returns (model, dictionary, args)."""
    from unicore import models, tasks, utils

    utils.import_user_module(SimpleNamespace(user_dir=user_dir))
    args = SimpleNamespace(**{k: v for k, v in vars(ck_args).items()})
    # Build the model training will build: the command's architecture values win.
    for flag, wanted in (cmd_values or {}).items():
        attr = flag.replace("-", "_")
        setattr(args, attr, _coerce(getattr(args, attr, None), wanted))
    args.data = data
    args.task = task_name or "unimol_contrastive_continual"
    if arch:
        args.arch = arch
    if dict_name:
        args.dict_name = dict_name
    # The reference model only needs the architecture; the mixed dataset is
    # never loaded here, so no lipid LMDB is required.
    for attr, default in (("lipid_splits", None), ("lipid_lmdb", None),
                          ("general_data_weight", 0.5), ("lipid_data_weight", 1.0),
                          ("mixture_report", None), ("require_equal_coordinate_slots", False),
                          ("contrastive_view_mode", "independent"), ("view_seed_offset", 1000003),
                          ("invalid_smiles_policy", "skip-2d"), ("max_invalid_smiles_fraction", 0.01)):
        if not hasattr(args, attr):
            setattr(args, attr, default)
    task = tasks.TASK_REGISTRY[args.task].setup_task(args)
    model = models.build_model(args, task)
    return model, task.dictionary, args


def compare(model, ck_model, dictionary):
    """Strict comparison of a fresh model's state_dict with a checkpoint's."""
    ref = {k: tuple(v.shape) for k, v in model.state_dict().items()}
    got = {k: tuple(v.shape) for k, v in ck_model.items()}
    missing = sorted(set(ref) - set(got))
    unexpected = sorted(set(got) - set(ref))
    mismatched = sorted(
        {"param": k, "checkpoint": list(got[k]), "model": list(ref[k])}.__repr__()
        for k in sorted(set(ref) & set(got)) if ref[k] != got[k]
    )
    report = {
        "n_params_model": len(ref),
        "n_params_checkpoint": len(got),
        "n_loaded": len(set(ref) & set(got)) - len(mismatched),
        "missing_in_checkpoint": missing,
        "unexpected_in_checkpoint": unexpected,
        "shape_mismatch": mismatched,
        "coverage": (len(set(ref) & set(got)) - len(mismatched)) / max(1, len(ref)),
        "n_dictionary_types": len(dictionary),
    }
    # The token embedding must match the dictionary the continual stage uses.
    emb = [k for k in ref if k.endswith("embed_tokens.weight")]
    for k in emb:
        report["embedding"] = {"param": k, "model": list(ref[k]),
                               "checkpoint": list(got.get(k, [])),
                               "dictionary_types": len(dictionary)}
        if k in got and got[k][0] != len(dictionary):
            report.setdefault("problems", []).append(
                "{}: checkpoint has {} rows but the dictionary has {} types; the pretrained "
                "vocabulary must not be reordered or extended".format(k, got[k][0], len(dictionary)))
    if missing:
        report.setdefault("problems", []).append(
            "{} parameter(s) are absent from the checkpoint: {}".format(len(missing), missing[:10]))
    if unexpected:
        report.setdefault("problems", []).append(
            "{} checkpoint parameter(s) are not in the continual model: {}".format(
                len(unexpected), unexpected[:10]))
    if mismatched:
        report.setdefault("problems", []).append(
            "{} parameter(s) differ in shape: {}".format(len(mismatched), mismatched[:10]))
    return report


def _with_arch_defaults(ck_args):
    """A copy of the checkpoint args with the registered architecture defaults applied.

    The model constructor applies the same function, so a field the stored
    args omit (e.g. activation_fn) is compared with the value the model used.
    """
    from unicore.models import ARCH_CONFIG_REGISTRY

    out = SimpleNamespace(**vars(ck_args))
    fn = ARCH_CONFIG_REGISTRY.get(getattr(out, "arch", None))
    if fn is not None:
        fn(out)
    return out


def arg_diff(ck_args, args):
    """Differences between the checkpoint's args and the continual args."""
    out = {"must_match": {}, "expected": {}, "other": {}}
    ck = vars(ck_args)
    new = vars(args)
    for key in sorted(set(ck) | set(new)):
        a, b = ck.get(key, "<absent>"), new.get(key, "<absent>")
        if a == b:
            continue
        bucket = "must_match" if key in ARCH_KEYS else ("expected" if key in EXPECTED_DIFFERENT else "other")
        out[bucket][key] = {"checkpoint": _plain(a), "continual": _plain(b)}
    return out


def _plain(v):
    if isinstance(v, (str, int, float, bool)) or v is None:
        return v
    return repr(v)


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    train_cmd = None
    if "--" in argv:
        split = argv.index("--")
        argv, train_cmd = argv[:split], argv[split + 1:]
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("checkpoint", help="completed HEART general checkpoint (read-only)")
    ap.add_argument("--data", required=True, help="general ligand directory holding dict.txt")
    ap.add_argument("--out", required=True, help="continual init checkpoint to write")
    ap.add_argument("--user-dir", default="./unimol")
    ap.add_argument("--task", default="unimol_contrastive_continual")
    ap.add_argument("--arch", default=None)
    ap.add_argument("--dict-name", default=None)
    ap.add_argument("--report", default=None, help="write the full report as JSON")
    ap.add_argument("--allow-partial", action="store_true",
                    help="write the init checkpoint even if parameters are missing or mis-shaped")
    ap.add_argument("--dry-run", action="store_true", help="check only; write nothing")
    ns = ap.parse_args(argv)

    if not os.path.isfile(ns.checkpoint):
        sys.exit("checkpoint not found: {}".format(ns.checkpoint))
    ck = load_checkpoint(ns.checkpoint)
    for key in ("model", "args"):
        if key not in ck:
            sys.exit("{}: no {!r} in this checkpoint; is it a Uni-Core checkpoint?".format(
                ns.checkpoint, key))
    updates = None
    if ck.get("optimizer_history"):
        updates = ck["optimizer_history"][-1].get("num_updates")
    prev_time = float((ck.get("extra_state") or {}).get("previous_training_time", 0.0))

    cmd_values = command_arch_values(train_cmd) if train_cmd else {}
    cmd_mismatch = compare_command(ck["args"], cmd_values)
    model, dictionary, args = build_reference_model(
        ck["args"], ns.data, ns.user_dir, ns.arch, ns.dict_name, ns.task, cmd_values)
    weights = compare(model, ck["model"], dictionary)
    diffs = arg_diff(_with_arch_defaults(ck["args"]), args)

    report = {
        "source_checkpoint": os.path.abspath(ns.checkpoint),
        "source_num_updates": updates,
        "source_previous_training_time_hours": round(prev_time / 3600.0, 4),
        "out": os.path.abspath(ns.out),
        "task": ns.task,
        "weights": weights,
        "arg_differences": diffs,
        "training_command_checked": bool(train_cmd),
        "training_command_arch_values": cmd_values,
        "training_command_arch_mismatch": [
            {"flag": f, "checkpoint": _plain(a), "command": _plain(b)} for f, a, b in cmd_mismatch],
        "stripped_keys": sorted(k for k in ("extra_state", "optimizer_history",
                                            "last_optimizer_state", "ema", "task_state", "loss")
                                if k in ck),
    }
    problems = list(weights.get("problems", []))
    if diffs["must_match"]:
        problems.append("architecture/data settings differ from the checkpoint: {}".format(
            sorted(diffs["must_match"])))
    for flag, stored, wanted in cmd_mismatch:
        problems.append("--{}: the general checkpoint has {!r} but the continual command "
                        "uses {!r}".format(flag, stored, wanted))
    if not train_cmd:
        print("NOTE        : no training command after `--`; the architecture is compared with "
              "the checkpoint's own args only")
    report["problems"] = problems

    print("source      : {} (num_updates {}, recorded training time {:.1f} h)".format(
        ns.checkpoint, updates, prev_time / 3600.0))
    print("dictionary  : {} types from {}".format(len(dictionary),
                                                  os.path.join(ns.data, args.dict_name)))
    print("parameters  : {} in the model, {} in the checkpoint, {} loadable ({:.2%} coverage)".format(
        weights["n_params_model"], weights["n_params_checkpoint"], weights["n_loaded"],
        weights["coverage"]))
    if "embedding" in weights:
        print("embedding   : {} {} (dictionary {} types)".format(
            weights["embedding"]["param"], weights["embedding"]["checkpoint"],
            weights["embedding"]["dictionary_types"]))
    for bucket in ("must_match", "expected"):
        if diffs[bucket]:
            print("args differ ({}): {}".format(bucket, json.dumps(diffs[bucket], indent=2, sort_keys=True)))
    for p in problems:
        print("PROBLEM     : {}".format(p))

    if ns.report:
        report_dir = os.path.dirname(os.path.abspath(ns.report))
        os.makedirs(report_dir, exist_ok=True)
        with open(ns.report, "w", encoding="utf-8", newline="\n") as fh:
            json.dump(report, fh, indent=2, sort_keys=True)
            fh.write("\n")
        print("report      : {}".format(ns.report))

    if problems and not ns.allow_partial:
        print("FAIL        : refusing to write a continual init checkpoint")
        return 1
    if ns.dry_run:
        print("PASS        : --dry-run, nothing written")
        return 0

    import torch

    out_dir = os.path.dirname(os.path.abspath(ns.out))
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)
    # Weights only: a new optimizer, scheduler, scaler and update counter.
    payload = {
        "args": ck["args"],
        "model": ck["model"],
        "heart_continual_init": {
            "source_checkpoint": os.path.abspath(ns.checkpoint),
            "source_num_updates": updates,
            "source_previous_training_time_seconds": prev_time,
            "stripped_keys": report["stripped_keys"],
            "weight_coverage": weights["coverage"],
        },
    }
    tmp = ns.out + ".tmp"
    torch.save(payload, tmp)
    os.replace(tmp, ns.out)
    print("wrote       : {}".format(ns.out))
    print("PASS        : model weights only; optimizer, schedule, fp16 scaler and update "
          "counter start from zero")
    return 0


if __name__ == "__main__":
    sys.exit(main())
