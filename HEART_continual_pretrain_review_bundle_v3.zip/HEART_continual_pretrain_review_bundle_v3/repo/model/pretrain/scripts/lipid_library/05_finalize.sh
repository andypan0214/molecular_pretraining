#!/bin/bash
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=8G
#SBATCH --time=12:00:00
#SBATCH --job-name=lipid-05-final
#SBATCH --output=/home/ypan/heart_liver/model_train/lipid_library/logs/%x-%j.out
#SBATCH --error=/home/ypan/heart_liver/model_train/lipid_library/logs/%x-%j.err
# =============================================================================
# Stage 05 (CPU): fail-closed finalisation (review P0-1).
#   1. `lmdb_writer --finalize` with the SAME options as stage 04: recomputes the
#      expected shard layout from the enumeration + drop list, requires every
#      expected shard with matching configuration/input fingerprints and LMDB
#      hash, and reconciles counts. Only then is manifest.json written. On
#      failure it lists the missing shards and the array task ids to resubmit.
#   2. splits.json from whole shards (refuses smoke data, an empty valid split
#      or overlap). Validation shards: one drawn per stratum of the combination
#      order (v2 review P1; seed SPLIT_SEED, default 1), VALID_FRACTION of the
#      shards (default 0.002) or VALID_SHARDS shards; split_report.json gives the
#      validation fraction, positions and reagent-ID distribution per split.
#   3. record-level validation against the model dict.txt.
#
#   HEART_CONFIRM_LIPID=1 STORE_2D=<as stage 04> sbatch --export=ALL \
#       --dependency=afterany:<04 array id> scripts/lipid_library/05_finalize.sh
# LIPID_ARRAY_SIZE (default 1000) = the stage-04 stride, for the resubmit list.
# VALIDATE_ALL=1 checks every record (slow); the default samples 500 per shard.
# =============================================================================
set -eo pipefail
here="$(dirname "${BASH_SOURCE[0]}")"
[ -f "$here/lipid_lib.sh" ] || here=/home/ypan/heart_liver/model_train/heart-molecular-pretraining/model/pretrain/scripts/lipid_library
# shellcheck source=lipid_lib.sh
. "$here/lipid_lib.sh"
lipid_init "$here/05_finalize.sh"
lipid_writer_args
"$PY" -m lipid_library.lmdb_writer "$LIPID_ENUM" -o "$LIPID_LMDB" "${LIPID_WRITER_ARGS[@]}" \
    --finalize --array-size "${LIPID_ARRAY_SIZE:-${ARRAY_SIZE:-1000}}" \
    || die "finalize failed: see $LIPID_LMDB/finalize_report.json (missing shards / resubmit list)"
if [ -n "${VALID_SHARDS:-}" ]; then
    split_args=(--valid-shards "$VALID_SHARDS")
else
    split_args=(--valid-fraction "${VALID_FRACTION:-0.002}")
fi
split_args+=(--split-seed "${SPLIT_SEED:-1}" --split-method stratified-random)
[ -n "${LIMIT:-}" ] && split_args+=(--allow-smoke)
"$PY" -m lipid_library.splits "$LIPID_LMDB" "${split_args[@]}"
scope=(--sample 500)
[ "${VALIDATE_ALL:-0}" = "1" ] && scope=(--all)
slots=10; [ "$STORE_2D" = "1" ] && slots=11
"$PY" -m lipid_library.validate_lmdb --manifest "$LIPID_LMDB/manifest.json" --dict "$LIPID_DICT" \
    --expect-slots "$slots" --max-atoms "${MAX_ATOMS:-256}" --only-polar 0 "${scope[@]}" \
    --json-out "$LIPID_LMDB/validation.json" || die "validation failed: see $LIPID_LMDB/validation.json"
"$PY" -c 'import json, sys
r = json.load(open(sys.argv[1]))
print("measured_sec_per_molecule = {} (use as SEC_PER_MOLECULE for the full stage 04)".format(
    r.get("measured_sec_per_molecule")))' "$LIPID_LMDB/finalize_report.json"
log "ready: HEART_LIPID_SPLITS=$LIPID_LMDB/splits.json"
