# shellcheck shell=bash
# =============================================================================
# HEART lipid library: shared helpers for the CPU SLURM stages 01-05.
# Sourced (never executed). Reuses ../heart_lib.sh for repository discovery and
# for the proven heart_gpu activation (HEART_SKIP_ENV=1 + HEART_PYTHON is the
# local-testing hook, exactly as in the training launchers). Installs nothing.
#
# Layout (override with the LIPID_* variables):
#   LIPID_ROOT=/home/ypan/heart_liver/model_train/lipid_library
#   ├── input/LUMI_virtual_library_training_lipidLike.xlsx   (copied by the user)
#   ├── bb/          01 building blocks + QC
#   ├── enum/        02 Ugi products (chunked gz CSV + receipts)
#   ├── dedup/       03 duplicate products
#   ├── review/      01b chemistry review sheet
#   ├── lmdb/        04 shard LMDBs, 05 manifest.json + splits.json + validation.json
#   └── logs/        SLURM logs
# =============================================================================

lipid_init() {
    local script_path="$1" lib
    lib="$(dirname "$script_path")/../heart_lib.sh"
    if [ ! -f "$lib" ]; then
        lib="${HEART_REPO:-/home/ypan/heart_liver/model_train/heart-molecular-pretraining}/model/pretrain/scripts/heart_lib.sh"
    fi
    # shellcheck source=../heart_lib.sh
    . "$lib"
    # heart_find_repo expects a script two levels below model/pretrain/scripts
    heart_find_repo "$(dirname "$script_path")/../$(basename "$script_path")"
    heart_paths
    LIPID_ROOT="${LIPID_ROOT:-$BASE/lipid_library}"
    LIPID_INPUT="${LIPID_INPUT:-$LIPID_ROOT/input/LUMI_virtual_library_training_lipidLike.xlsx}"
    LIPID_BB="$LIPID_ROOT/bb"
    LIPID_ENUM="$LIPID_ROOT/enum"
    LIPID_DEDUP="$LIPID_ROOT/dedup"
    LIPID_REVIEW="$LIPID_ROOT/review"
    # A pilot (LIMIT=...) is a different configuration: give it its own directory.
    LIPID_LMDB="${LIPID_LMDB_DIR:-$LIPID_ROOT/lmdb}"
    # The pretrained model's vocabulary; never rebuilt here.
    LIPID_DICT="${LIPID_DICT:-$DATA_PATH/dict.txt}"
    case "$(realpath -m "$LIPID_ROOT")/" in
        "$(realpath -m "$DATA_PATH")"/*) die "LIPID_ROOT must not be inside the general ligand dataset" ;;
        */runs/h200/full/*) die "LIPID_ROOT must not be inside the general H200 run tree" ;;
    esac
    [ "${HEART_CONFIRM_LIPID:-0}" = "1" ] || die "lipid library jobs require HEART_CONFIRM_LIPID=1"
    heart_slurm_info
    echo "LIPID_ROOT  = $LIPID_ROOT"
    echo "LIPID_INPUT = $LIPID_INPUT"
    echo "LIPID_DICT  = $LIPID_DICT"
    heart_activate_env
    export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
    mkdir -p "$LIPID_ROOT/logs"
    cd "$PRETRAIN_DIR"                 # `python -m lipid_library.*` resolves here
}

# Writer options shared by stage 04 (generation) and stage 05 (--finalize): the
# finalize step recomputes the configuration fingerprint, so both MUST use the
# same values. Sets LIPID_WRITER_ARGS (array).
#   STORE_2D (required, 0|1): 1 = LUMI layout (10 3D + 1 stored 2D), 0 = 10 3D
#     only (HEART adds the 2D at training time). Choose the convention of the
#     general ligand LMDB, measured with tools/check_continual_data.py (README 4.2).
lipid_writer_args() {
    case "${STORE_2D:-}" in
        1) LIPID_WRITER_ARGS=(--store-2d) ;;
        0) LIPID_WRITER_ARGS=(--no-store-2d) ;;
        *) die "set STORE_2D=0 or STORE_2D=1 explicitly, after auditing the general LMDB slot policy (README_CONTINUAL.md 4.2)" ;;
    esac
    LIPID_WRITER_ARGS+=(--records-per-shard "${RECORDS_PER_SHARD:-5000}" --n-3d 10 --max-try 15
        --max-iterations 4000 --seed-start "${SEED_START:-0}" --max-atoms "${MAX_ATOMS:-256}"
        --only-polar 0 --dict "$LIPID_DICT" --drop-list "$LIPID_DEDUP/drop_combo_indexes.csv.gz")
    [ -n "${LIMIT:-}" ] && LIPID_WRITER_ARGS+=(--limit "$LIMIT")
    return 0
}

# Array geometry: prints "<task id> <stride>"; a non-array run is task 0 of 1.
#   lipid_array_task <stride variable name> <default stride>
# The STRIDE (the --num-shards / chunk modulus) is an explicit setting, NOT
# SLURM_ARRAY_TASK_COUNT: resubmitting only the failed tasks (--array=17,523,
# the list stage 05 prints) gives SLURM_ARRAY_TASK_COUNT=2, which would change
# the task -> shard mapping (v2 review: matching array parameters). The stride
# defaults to the #SBATCH --array size of the stage and must stay the same for
# every submission into one output directory (lmdb_writer locks it).
lipid_array_task() {
    local var="$1" default="$2" id count
    if [ -z "${SLURM_ARRAY_TASK_ID:-}" ]; then
        echo "0 1"          # not an array job: one task does every shard
        return 0
    fi
    id="$SLURM_ARRAY_TASK_ID"
    count="${!var:-$default}"
    case "$id$count" in *[!0-9]*) die "bad array variables: task id=$id $var=$count" ;; esac
    [ "$id" -lt "$count" ] || die "array task $id is outside 0..$((count - 1)) ($var=$count): the stride must equal the original --array size"
    if [ -n "${SLURM_ARRAY_TASK_MAX:-}" ] && [ "$SLURM_ARRAY_TASK_MAX" -ge "$count" ]; then
        die "--array goes up to $SLURM_ARRAY_TASK_MAX but $var=$count: tasks >= $count would duplicate shards"
    fi
    if [ -n "${SLURM_ARRAY_TASK_COUNT:-}" ] && [ "$SLURM_ARRAY_TASK_COUNT" != "$count" ]; then
        warn "SLURM_ARRAY_TASK_COUNT=$SLURM_ARRAY_TASK_COUNT differs from $var=$count: a partial resubmission; task $id keeps its original shards"
    fi
    echo "$id $count"
}
