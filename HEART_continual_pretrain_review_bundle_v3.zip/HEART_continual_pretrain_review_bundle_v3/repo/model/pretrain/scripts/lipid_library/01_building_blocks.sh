#!/bin/bash
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=4G
#SBATCH --time=00:30:00
#SBATCH --job-name=lipid-01-bb
#SBATCH --output=/home/ypan/heart_liver/model_train/lipid_library/logs/%x-%j.out
#SBATCH --error=/home/ypan/heart_liver/model_train/lipid_library/logs/%x-%j.err
# =============================================================================
# Stage 01 (CPU, minutes): parse + validate the LUMI building-block sheet and
# write the chemistry review sheet (one product per reagent + stratified
# assumption groups, with core/formula/LUMI-assembly checks and drawings).
# No partition is set: CMRI's CPU partition name is not recorded in this repo.
# Check `sinfo -o "%P %l %c %m"` and add `-p <cpu partition>` to sbatch.
#
#   mkdir -p /home/ypan/heart_liver/model_train/lipid_library/{input,logs}
#   cp LUMI_virtual_library_training_lipidLike.xlsx /home/ypan/heart_liver/model_train/lipid_library/input/
#   HEART_CONFIRM_LIPID=1 sbatch --export=ALL scripts/lipid_library/01_building_blocks.sh
# =============================================================================
set -eo pipefail
here="$(dirname "${BASH_SOURCE[0]}")"
[ -f "$here/lipid_lib.sh" ] || here=/home/ypan/heart_liver/model_train/heart-molecular-pretraining/model/pretrain/scripts/lipid_library
# shellcheck source=lipid_lib.sh
. "$here/lipid_lib.sh"
lipid_init "$here/01_building_blocks.sh"

[ -r "$LIPID_INPUT" ] || die "building-block sheet not found: $LIPID_INPUT"
"$PY" -m lipid_library.building_blocks "$LIPID_INPUT" -o "$LIPID_BB"
"$PY" -m lipid_library.review_products "$LIPID_BB" -o "$LIPID_REVIEW" --every-reagent \
    || warn "chemistry review reported problems: inspect $LIPID_REVIEW/review.csv before enumerating"
log "done: $LIPID_BB/summary.json, $LIPID_REVIEW/review.csv, $LIPID_REVIEW/review.svg"
