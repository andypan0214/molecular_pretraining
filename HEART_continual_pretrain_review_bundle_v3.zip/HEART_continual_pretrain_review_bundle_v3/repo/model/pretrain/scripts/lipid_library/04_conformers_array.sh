#!/bin/bash
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=8G
#SBATCH --time=1-00:00:00
#SBATCH --array=0-999%200
#SBATCH --job-name=lipid-04-conf
#SBATCH --output=/home/ypan/heart_liver/model_train/lipid_library/logs/%x-%A_%a.out
#SBATCH --error=/home/ypan/heart_liver/model_train/lipid_library/logs/%x-%A_%a.err
# =============================================================================
# Stage 04 (CPU array): LUMI conformers (ETKDGv3 + MMFF, 10 3D slots, up to 15
# attempts, maxIterations 4000; + 1 stored 2D only with STORE_2D=1) -> HEART
# integer-key shard LMDBs. Task i writes shards s with s % N == i, sequentially,
# where N = LIPID_ARRAY_SIZE (default 1000 = this --array=0-999; NOT the number
# of tasks of a submission, so resubmitting --array=<failed ids> keeps the same
# mapping; lmdb_writer locks N per output directory). One core per task.
# Each task reads ONLY the input files of its own shards, written once by
# stage 03b (v2 review P1); nothing re-reads the 15M-row product stream.
# manifest.json is NOT written here; stage 05 (--finalize) reconciles everything.
#
# SIZING (review P1). Before generating, every task computes its workload from
# the enumeration/dedup records (`lmdb_writer --plan`) and compares it with
# this job's SLURM time limit:
#     ceil(n_shards / N) * RECORDS_PER_SHARD * (SEC_PER_MOLECULE + read s/row) * 1.5 <= time limit
# (read s/row = the gz-CSV parse rate stage 03b measured; input reading is
# ~1e-5 of the conformer cost, but it is included).
# and refuses to start otherwise. SEC_PER_MOLECULE must come from a measured
# CMRI pilot for a full run (stage 05 prints it as measured_sec_per_molecule);
# the 1.9 s/molecule measured on a Windows laptop is used only for pilots.
#   Example (15.24M products): RECORDS_PER_SHARD=5000 -> ~3,049 shards; with
#   --array=0-999 that is 4 shards/task; at 1.9 s/molecule ~10.6 h/task
#   (15.8 h with the 1.5 safety factor) against the 24 h limit. Check
#   MaxArraySize with `scontrol show config | grep MaxArraySize`.
#
# Pilot (own output directory, marked smoke, never finalisable as production):
#   HEART_CONFIRM_LIPID=1 STORE_2D=<0|1> LIMIT=5000 LIPID_LMDB_DIR=<root>/lmdb_pilot \
#       sbatch --export=ALL --array=0 scripts/lipid_library/04_conformers_array.sh
# Full run:
#   HEART_CONFIRM_LIPID=1 STORE_2D=<0|1> SEC_PER_MOLECULE=<pilot value> \
#       sbatch --export=ALL --dependency=afterok:<03 job id> scripts/lipid_library/04_conformers_array.sh
# Unfinished/failed tasks: resubmit the SAME command (completed shards are
# skipped after their fingerprints and hashes are re-verified), or only the
# task ids that stage 05 lists under resubmit_array_tasks: --array=<ids>.
# =============================================================================
set -eo pipefail
here="$(dirname "${BASH_SOURCE[0]}")"
[ -f "$here/lipid_lib.sh" ] || here=/home/ypan/heart_liver/model_train/heart-molecular-pretraining/model/pretrain/scripts/lipid_library
# shellcheck source=lipid_lib.sh
. "$here/lipid_lib.sh"
lipid_init "$here/04_conformers_array.sh"
read -r task count <<< "$(lipid_array_task LIPID_ARRAY_SIZE 1000)"   # = #SBATCH --array size
[ -f "$LIPID_DEDUP/drop_combo_indexes.csv.gz" ] || die "run stage 03 first (drop list missing)"
[ -r "$LIPID_DICT" ] || die "model dict.txt not readable: $LIPID_DICT"
lipid_writer_args

# >>> Sizing guard >>>
spm="${SEC_PER_MOLECULE:-}"
if [ -z "$spm" ]; then
    [ -n "${LIMIT:-}" ] || die "a full run needs SEC_PER_MOLECULE measured by a CMRI pilot (LIMIT=... run; stage 05 reports it)"
    spm=1.9
    warn "pilot: using the Windows-laptop estimate SEC_PER_MOLECULE=1.9 for sizing"
fi
limit_h="${LIPID_TIME_LIMIT_HOURS:-}"
if [ -z "$limit_h" ] && [ -n "${SLURM_JOB_ID:-}" ] && command -v squeue >/dev/null 2>&1; then
    tl="$(squeue -h -j "$SLURM_JOB_ID" -o %l 2>/dev/null | head -1)"
    limit_h="$("$PY" -c 'import sys
t = sys.argv[1].strip()
d, _, hms = t.rpartition("-")
p = [int(x) for x in hms.split(":")]
while len(p) < 3: p.insert(0, 0)
print((int(d or 0) * 24) + p[0] + p[1] / 60 + p[2] / 3600)' "$tl" 2>/dev/null || true)"
fi
plan_json="$("$PY" -m lipid_library.lmdb_writer "$LIPID_ENUM" -o "$LIPID_LMDB" "${LIPID_WRITER_ARGS[@]}" \
    --plan --sec-per-molecule "$spm" --array-size "$count")" || die "cannot compute the shard plan"
echo "$plan_json"
if [ -n "$limit_h" ]; then
    "$PY" -c 'import json, sys
p = json.loads(sys.argv[1]); limit = float(sys.argv[2]); need = 1.5 * p["est_hours_per_task"]
print("sizing: {} shard(s)/task, {} input rows read/task ({} for all tasks), est {:.1f} h x 1.5 = {:.1f} h vs limit {:.1f} h".format(
    p["max_shards_per_task"], p["input_rows_read_per_task"], p["input_rows_read_all_tasks"],
    p["est_hours_per_task"], need, limit))
sys.exit(0 if need <= limit else 1)' "$plan_json" "$limit_h" \
        || die "the per-task workload does not fit the time limit: use a larger --array, a smaller RECORDS_PER_SHARD, or a longer --time"
else
    warn "time limit unknown (not under SLURM and LIPID_TIME_LIMIT_HOURS unset): sizing not enforced"
fi
part="$("$PY" -c 'import json, sys; print(json.loads(sys.argv[1])["partition"])' "$plan_json")"
[ "$part" = "matches" ] || die "shard-input partition $part for this configuration: run stage 03b first, with the same options ($LIPID_LMDB/shard_inputs)"

log "conformer task $task of $count (records per shard ${RECORDS_PER_SHARD:-5000}, seed start ${SEED_START:-0}, store 2D ${STORE_2D})"
"$PY" -m lipid_library.lmdb_writer "$LIPID_ENUM" -o "$LIPID_LMDB" "${LIPID_WRITER_ARGS[@]}" \
    --map-size-gb 64 --commit-every 2000 --shard "$task" --num-shards "$count"
