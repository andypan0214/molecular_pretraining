#!/bin/bash
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=4G
#SBATCH --time=04:00:00
#SBATCH --array=0-63
#SBATCH --job-name=lipid-02-enum
#SBATCH --output=/home/ypan/heart_liver/model_train/lipid_library/logs/%x-%A_%a.out
#SBATCH --error=/home/ypan/heart_liver/model_train/lipid_library/logs/%x-%A_%a.err
# =============================================================================
# Stage 02 (CPU array): Ugi-4CR enumeration of every combination. Task i
# handles the CHUNK_SIZE (50,000) combination chunks c with c % N == i, where N
# is the array size. Locally ~1,000 combinations/s per core, so 15.24M / 64
# tasks is a few minutes each; 4 h is a generous limit. Re-queued or repeated
# tasks skip chunks whose receipt and sha256 match, so resubmitting is safe.
#
#   HEART_CONFIRM_LIPID=1 sbatch --export=ALL scripts/lipid_library/02_enumerate_array.sh
# The chunk stride is LIPID_ENUM_ARRAY_SIZE (default 64 = --array=0-63), not the
# number of tasks in a submission, so `--array=<failed ids>` resubmits are safe.
# =============================================================================
set -eo pipefail
here="$(dirname "${BASH_SOURCE[0]}")"
[ -f "$here/lipid_lib.sh" ] || here=/home/ypan/heart_liver/model_train/heart-molecular-pretraining/model/pretrain/scripts/lipid_library
# shellcheck source=lipid_lib.sh
. "$here/lipid_lib.sh"
lipid_init "$here/02_enumerate_array.sh"
read -r task count <<< "$(lipid_array_task LIPID_ENUM_ARRAY_SIZE 64)"   # = #SBATCH --array size
[ -f "$LIPID_BB/building_blocks.csv" ] || die "run stage 01 first ($LIPID_BB/building_blocks.csv missing)"
log "enumeration task $task of $count"
"$PY" -m lipid_library.enumerate_library "$LIPID_BB" -o "$LIPID_ENUM" \
    --chunk-size "${CHUNK_SIZE:-50000}" --shard "$task" --num-shards "$count"
