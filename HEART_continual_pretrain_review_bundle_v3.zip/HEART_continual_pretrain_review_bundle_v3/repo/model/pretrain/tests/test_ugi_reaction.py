"""The Ugi-4CR template: connectivity, bookkeeping, determinism and the LUMI cross-check."""
import os
import sys

import pytest

TESTS_DIR = os.path.dirname(os.path.abspath(__file__))
PRETRAIN_DIR = os.path.dirname(TESTS_DIR)
if PRETRAIN_DIR not in sys.path:
    sys.path.insert(0, PRETRAIN_DIR)

from lipid_library import ugi  # noqa: E402

rdkit = pytest.importorskip("rdkit")
from rdkit import Chem  # noqa: E402
from rdkit.Chem import AllChem, Descriptors, rdMolDescriptors  # noqa: E402

# (acid, amine, aldehyde, isocyanide) quadruples drawn from the real sheet,
# covering esters, bromides, cis double bonds, rings and an aromatic amine.
QUADS = [
    ("CC(=O)O", "NCCN1CCN(CCN)CC1", "CCCCC(C)C=O", "[C-]#[N+]C(C)CCCCC"),
    ("CCCCCCCC(=O)O", "CN(C)CCN", "CCCCCCC=O", "[C-]#[N+]C"),
    ("CCCCCCCCC(CCCCCC)COC(=O)CCCCC(=O)O", "NC1CCN(CCCO)CC1",
     "CCCCCCCCC(CCCCCC)C(=O)OCCCCC(C)C=O", "[C-]#[N+]C1CCN(C)CC1"),
    ("O=C(O)CCCCBr", "Nc1nccs1", r"CCCCC/C=C\C/C=C\CCCCCCCC=O", "[C-]#[N+]CC(=O)OC"),
    ("CCCCCCCCCCCCCCCC(=O)O", "NCC1CCN(CCCO)CC1", "CCCCCCCCCCCCCCCC=O",
     "[C-]#[N+]CS(=O)(=O)c1ccc(C)cc1"),
]


def mols(quad):
    out = [Chem.MolFromSmiles(s) for s in quad]
    assert all(m is not None for m in out)
    return out


def test_reaction_smarts_compiles_and_is_four_component():
    rxn = ugi.reaction()
    assert rxn.GetNumReactantTemplates() == 4
    assert rxn.GetNumProductTemplates() == 1


@pytest.mark.parametrize("quad", QUADS)
def test_product_has_the_ugi_core_connectivity(quad):
    """R_D-C(=O)-N(R_A)-CH(R_C)-C(=O)-NH-R_B must be present exactly once."""
    smi, info = ugi.product_smiles(*mols(quad))
    prod = Chem.MolFromSmiles(smi)
    assert prod is not None
    core = Chem.MolFromSmarts("[CX3](=O)[NX3]([#6])[CX4;H1]([#6])[CX3](=O)[NX3;H1][#6]")
    matches = prod.GetSubstructMatches(core)
    assert len(matches) >= 1, smi
    # no reactive group survives: no aldehyde, no isocyanide, no free acid
    for name, smarts in (("aldehyde", ugi.ALDEHYDE_SMARTS), ("isocyanide", ugi.ISOCYANIDE_SMARTS),
                         ("acid", ugi.ACID_SMARTS)):
        assert not prod.GetSubstructMatches(Chem.MolFromSmarts(smarts)), (name, smi)
    assert info["formal_charge"] == 0


@pytest.mark.parametrize("quad", QUADS)
def test_water_is_eliminated_formula_bookkeeping(quad):
    """product = acid + amine + aldehyde + isocyanide - H2O."""
    acid, amine, ald, iso = mols(quad)
    smi, _ = ugi.product_smiles(acid, amine, ald, iso)
    prod = Chem.MolFromSmiles(smi)
    def counts(m):
        m = AllChem.AddHs(m)
        out = {}
        for a in m.GetAtoms():
            out[a.GetSymbol()] = out.get(a.GetSymbol(), 0) + 1
        return out
    total = {}
    for m in (acid, amine, ald, iso):
        for k, v in counts(m).items():
            total[k] = total.get(k, 0) + v
    total["H"] = total.get("H", 0) - 2
    total["O"] = total.get("O", 0) - 1
    assert counts(prod) == total, smi


@pytest.mark.parametrize("quad", QUADS)
def test_matches_lumi_core_assembly(quad):
    """The template agrees with LUMI's own core-attachment assembly."""
    acid, amine, ald, iso = quad
    smi, _ = ugi.product_smiles(*mols(quad))
    lumi = ugi.lumi_core_product_smiles(
        {"acid": acid, "amine": amine, "aldehyde": ald, "isocyanide": iso})
    assert smi == lumi


@pytest.mark.parametrize("quad", QUADS)
def test_enumeration_is_deterministic(quad):
    first, info1 = ugi.product_smiles(*mols(quad))
    second, info2 = ugi.product_smiles(*mols(quad))
    assert first == second
    assert info1["n_unique_products"] == info2["n_unique_products"]


def test_new_stereocentre_is_unspecified_assumption_a2():
    smi, _ = ugi.product_smiles(*mols(QUADS[1]))
    prod = Chem.MolFromSmiles(smi)
    centres = Chem.FindMolChiralCenters(prod, includeUnassigned=True, useLegacyImplementation=False)
    unassigned = [i for i, tag in centres if tag == "?"]
    core = prod.GetSubstructMatch(
        Chem.MolFromSmarts("[CX3](=O)[NX3]([#6])[CX4;H1]([#6])[CX3](=O)[NX3;H1][#6]"))
    assert core, smi
    alpha = core[4]
    assert alpha in unassigned, "the Ugi alpha carbon should be racemic (assumption A2)"


def test_reagent_stereochemistry_is_preserved():
    quad = ("CCCCC/C=C\\C/C=C\\CCCCCCCC(=O)O", "CN(C)CCN", "CCCCCCC=O", "[C-]#[N+]C")
    smi, _ = ugi.product_smiles(*mols(quad))
    assert smi.count("/") + smi.count("\\") >= 2, smi


@pytest.mark.parametrize("role,smiles,ok", [
    ("acid", "CCCCCCCC(=O)O", True),
    ("acid", "CCCCCCCC(=O)OC", False),              # ester is not an acid
    ("acid", "CCCCCCCCC(CCCCCC)C(=O)OCCCCC(C)C=O", False),
    ("aldehyde", "CCCCCC=O", True),
    ("aldehyde", "CC(=O)C", False),                 # ketone
    ("isocyanide", "[C-]#[N+]C", True),
    ("isocyanide", "CC#N", False),                  # nitrile
    ("amine", "CN(C)CCN", True),
    ("amine", "CN(C)CCNC(C)=O", False),             # amide, not a free amine
    ("amine", "CCNCC", False),                      # secondary amine
])
def test_eligibility(role, smiles, ok):
    mol = Chem.MolFromSmiles(smiles)
    assert mol is not None
    eligible, n_sites, tier, reason = ugi.check_eligibility(mol, role)
    assert eligible is ok, (role, smiles, reason)


def test_aromatic_amine_is_flagged_assumption_a3():
    mol = Chem.MolFromSmiles("Nc1nccs1")
    eligible, n_sites, tier, _ = ugi.check_eligibility(mol, "amine")
    assert eligible and tier == "other_primary"


def test_multi_site_amine_reports_all_sites_assumption_a1():
    mol = Chem.MolFromSmiles("NCCCN(CCCN)CCCN")
    eligible, n_sites, tier, _ = ugi.check_eligibility(mol, "amine")
    assert eligible and n_sites == 3 and tier == "aliphatic_primary"


def test_unparsable_reagent_raises_not_silently_skips():
    broken = Chem.MolFromSmiles("[C-]#[N+]C1(C[C@@H]2C3)C[C@@H]3C[C@@H](C2)")
    assert broken is None            # the real sheet's B62


def test_product_smiles_round_trips_and_is_canonical():
    for quad in QUADS:
        smi, _ = ugi.product_smiles(*mols(quad))
        back = Chem.MolFromSmiles(smi)
        assert back is not None
        assert Chem.MolToSmiles(back) == smi


def test_mismatched_roles_raise_ugierror():
    acid, amine, ald, iso = mols(QUADS[1])
    with pytest.raises(ugi.UgiError):
        ugi.product_smiles(ald, amine, ald, iso)   # aldehyde in the acid slot


def test_molecular_weight_is_in_a_lipid_like_range():
    for quad in QUADS:
        smi, info = ugi.product_smiles(*mols(quad))
        mw = Descriptors.MolWt(Chem.MolFromSmiles(smi))
        assert 200 < mw < 1500, (mw, smi)
        assert rdMolDescriptors.CalcNumAmideBonds(Chem.MolFromSmiles(smi)) >= 2
