"""Continual H200 launcher and lipid CPU SLURM scripts: syntax, CMRI directives,
agreement with configs/continual_pretrain.yaml, guards, output isolation,
preservation of the general-pretraining sources, and local CPU end-to-end runs.

The end-to-end runs use the existing local-testing hooks (HEART_SKIP_ENV,
HEART_LOCAL_CPU_TEST, HEART_TRAIN_ENTRY, HEART_EXTRA_ARGS) and the real
unicore-train code path with a tiny 2-layer model on tiny synthetic data.
Nothing proves GPU/fp16/SLURM behaviour; those are CMRI-only checks.
"""
import json
import os
import re
import subprocess
import sys

import pytest

from conftest import CONFIG_DIR, MODEL_ROOT, SCRIPTS_DIR, TESTS_DIR, find_bash

import lipid_fixtures as lf

BASH = find_bash()
needs_bash = pytest.mark.skipif(BASH is None, reason="bash not available")
REPO_ROOT = os.path.dirname(MODEL_ROOT)
LAUNCHER = "continual_pretrain_heart-h200.sh"
LIPID_SCRIPTS = ["lipid_library/lipid_lib.sh", "lipid_library/01_building_blocks.sh",
                 "lipid_library/02_enumerate_array.sh", "lipid_library/03_dedup.sh",
                 "lipid_library/04_conformers_array.sh", "lipid_library/05_finalize.sh"]
TINY = ("--num-workers 0 --encoder-layers 2 --encoder-embed-dim 64 --encoder-ffn-embed-dim 128 "
        "--encoder-attention-heads 4 --batch-size 2 --batch-size-valid 2 --max-valid-steps 1 "
        "--mask-prob 0.4")
# The general-pretraining implementation this task must not modify.
PROTECTED = [
    "model/pretrain/scripts/pretrain_heart-h200.sh", "model/pretrain/scripts/pretrain_heart.sh",
    "model/pretrain/scripts/pretrain_smoke.sh", "model/pretrain/scripts/heart_lib.sh",
    "model/pretrain/configs/full_pretrain.yaml", "model/pretrain/configs/pilot.yaml",
    "model/unimol/tasks/unimol_contrastive.py", "model/unimol/models/unimol_contrastive.py",
    "model/unimol/losses/unimol_contrastive.py", "model/unimol/data/lmdb_dataset.py",
    "model/unimol/data/add_2d_conformer_dataset.py",
]


def read(name):
    with open(os.path.join(SCRIPTS_DIR, name), "r", encoding="utf-8") as fh:
        return fh.read()


def sbatch_directives(text):
    return dict(re.findall(r"^#SBATCH --([a-z-]+)=(\S+)", text, flags=re.M))


def _posix(p):
    p = str(p).replace("\\", "/")
    if sys.platform == "win32" and len(p) > 1 and p[1] == ":":
        p = "/" + p[0].lower() + p[2:]
    return p


def _git(*args):
    return subprocess.run(["git", "-C", REPO_ROOT, *args], capture_output=True, timeout=60)


# --------------------------------------------------------------------------- static checks
@needs_bash
@pytest.mark.parametrize("script", [LAUNCHER] + LIPID_SCRIPTS)
def test_new_scripts_parse_and_use_lf(script):
    path = os.path.join(SCRIPTS_DIR, script)
    assert b"\r\n" not in open(path, "rb").read()
    subprocess.run([BASH, "-n", path], check=True)


def test_launcher_has_the_proven_h200_allocation():
    d = sbatch_directives(read(LAUNCHER))
    assert {k: d[k] for k in ("nodes", "ntasks-per-node", "cpus-per-task", "mem", "gres",
                              "partition", "time", "signal")} == {
        "nodes": "1", "ntasks-per-node": "1", "cpus-per-task": "16", "mem": "200G",
        "gres": "gpu:h200:1", "partition": "gpu", "time": "2-00:00:00", "signal": "B:USR1@1800"}
    general = sbatch_directives(read("pretrain_heart-h200.sh"))
    for k in ("nodes", "ntasks-per-node", "cpus-per-task", "mem", "gres", "partition", "time", "signal"):
        assert d[k] == general[k], "continual {} differs from the proven general H200 launcher".format(k)
    assert d["job-name"] != general["job-name"]


@pytest.mark.parametrize("script", [LAUNCHER] + LIPID_SCRIPTS)
def test_no_lumi_author_hardware_settings(script):
    # executable lines only: comments may say that LUMI's A100 settings are NOT used
    text = "\n".join(l for l in read(script).lower().splitlines()
                     if l.strip() and not l.lstrip().startswith("#") or l.startswith("#sbatch"))
    for bad in ("a100", "qos", "cuda-11", "/pkgs/", "bowang"):
        assert bad not in text, (script, bad)


def test_cpu_scripts_request_no_gpu_and_need_confirmation():
    for s in LIPID_SCRIPTS[1:]:
        d = sbatch_directives(read(s))
        assert "gres" not in d and d["cpus-per-task"] == "1", s
    assert "--array" in read("lipid_library/02_enumerate_array.sh")
    assert "--array" in read("lipid_library/04_conformers_array.sh")
    assert "HEART_CONFIRM_LIPID" in read("lipid_library/lipid_lib.sh")


def test_launcher_scientific_values_match_the_continual_config():
    """Every unicore flag recorded in continual_pretrain.yaml appears in the launcher with that value."""
    sys.path.insert(0, os.path.join(MODEL_ROOT, "pretrain", "tools"))
    import yaml_to_env

    _, uc = yaml_to_env.load(os.path.join(CONFIG_DIR, "continual_pretrain.yaml"), [])
    text = read(LAUNCHER)
    values = dict(re.findall(r"^([a-z_]+)=\"?\$?\{?[A-Z_]*:?-?([^\"}\s]*)", text, flags=re.M))
    expect = {"lr": "2e-5", "wd": "1e-4", "warmup_steps": "1000", "max_steps": "200000",
              "masked_token_loss": "0.5", "masked_coord_loss": "1", "masked_dist_loss": "5",
              "x_norm_loss": "0.01", "delta_pair_repr_norm_loss": "0.01", "contrastive_loss": "10.0",
              "mask_prob": "0.15", "noise": "1.0", "noise_type": "uniform", "seed": "1",
              "only_polar": "0", "max_atoms": "256", "validate_interval_updates": "1000",
              "save_interval_updates": "1000", "general_data_weight": "0.5",
              "lipid_data_weight": "1.0", "num_workers": "4", "heads": "64",
              "contrastive_view_mode": "independent"}
    for k, v in expect.items():
        assert values.get(k) == v, (k, values.get(k), v)
    yaml_for = {"lr": "lr", "wd": "weight-decay", "warmup_steps": "warmup-updates",
                "max_steps": "total-num-update", "masked_token_loss": "masked-token-loss",
                "masked_coord_loss": "masked-coord-loss", "masked_dist_loss": "masked-dist-loss",
                "contrastive_loss": "contrastive-loss", "general_data_weight": "general-data-weight",
                "lipid_data_weight": "lipid-data-weight", "num_workers": "num-workers",
                "heads": "encoder-attention-heads", "seed": "seed", "mask_prob": "mask-prob"}
    for k, flag in yaml_for.items():
        assert float(uc[flag]) == float(values[k]), (flag, uc[flag], values[k])
    assert uc["batch-size"] == 448 and "BATCH_SIZE:-448" in text
    assert uc["update-freq"] == 1 and "UPDATE_FREQ:-1" in text
    assert '--adam-betas "(0.9, 0.99)"' in text and "--adam-eps 1e-6" in text
    assert "--clip-norm 1.0" in text and "--lr-scheduler polynomial_decay" in text
    assert "--fp16 --fp16-init-scale 4 --fp16-scale-window 256" in text


def test_launcher_paths_and_output_isolation():
    text = read(LAUNCHER)
    for path in ("/home/ypan/heart_liver/model_train/heart-molecular-pretraining",
                 "/home/ypan/heart_liver/model_train/third_party/Uni-Core",
                 "/home/ypan/heart_liver/model_train/UniMolReference/ligand_data/ligands"):
        assert path in text
    assert 'save_dir="$OUTPUT_ROOT/continual/$run_name"' in text
    assert "heart-lipid-continual-v1" in text
    assert "*/runs/h200/full/*" in text


def test_general_pretraining_sources_are_unmodified():
    """Byte-identical to git HEAD, and git reports no tracked modification at all."""
    if _git("rev-parse", "HEAD").returncode != 0:
        pytest.skip("not a git checkout")
    for rel in PROTECTED:
        head = _git("show", "HEAD:" + rel)
        assert head.returncode == 0, rel
        with open(os.path.join(REPO_ROOT, rel), "rb") as fh:
            assert fh.read().replace(b"\r\n", b"\n") == head.stdout.replace(b"\r\n", b"\n"), rel
    status = _git("status", "--porcelain", "--untracked-files=no").stdout.decode().strip()
    assert status == "", "tracked files modified:\n" + status


# --------------------------------------------------------------------------- launcher runs
@pytest.fixture(scope="module")
def data(tmp_path_factory):
    root = tmp_path_factory.mktemp("cont_scripts")
    general = lf.write_general_lmdb_dir(str(root / "general"), n_3d=2, store_2d=True)
    lipid = lf.full_lipid_pipeline(str(root / "lipid"), limit=8, n_3d=2, store_2d=True)
    return {"root": root, "general": general["dir"], "splits": lipid["splits"]}


def _unicore(args, cwd=MODEL_ROOT):
    cmd = [sys.executable, os.path.join(TESTS_DIR, "unicore_train_entry.py")] + args
    p = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=900,
                       env=dict(os.environ, PYTHONIOENCODING="utf-8"))
    assert p.returncode == 0, (p.stdout + p.stderr)[-4000:]
    return p.stdout + p.stderr


@pytest.fixture(scope="module")
def general_ckpt(data):
    """A real (tiny) HEART general checkpoint: 2 updates of unimol_contrastive."""
    save = str(data["root"] / "general_run")
    _unicore([data["general"], "--user-dir", "./unimol", "--task", "unimol_contrastive",
              "--loss", "unimol_contrastive", "--arch", "unimol_contrastive_base", "--cpu",
              "--optimizer", "adam", "--lr", "1e-4", "--lr-scheduler", "polynomial_decay",
              "--warmup-updates", "1", "--total-num-update", "1000000", "--max-update", "2",
              "--save-interval-updates", "2", "--validate-interval-updates", "2",
              "--only-polar", "0", "--mode", "train", "--contrastive-loss", "10",
              "--masked-token-loss", "1", "--masked-coord-loss", "5", "--masked-dist-loss", "10",
              "--x-norm-loss", "0.01", "--delta-pair-repr-norm-loss", "0.01",
              "--log-format", "simple", "--no-epoch-checkpoints", "--seed", "1",
              "--save-dir", save, "--tmp-save-dir", save] + TINY.split())
    return os.path.join(save, "checkpoint_last.pt")


def env_for(data, out_root, ckpt=None, **extra):
    py = _posix(sys.executable)
    env = dict(os.environ)
    for k in list(env):
        if k.startswith(("SLURM_", "HEART_", "LIPID_")) or k in ("RUN_NAME", "MAX_STEPS", "BATCH_SIZE"):
            env.pop(k)
    env.update(
        HEART_REPO=_posix(REPO_ROOT), HEART_SKIP_ENV="1", HEART_PYTHON=py,
        HEART_TRAIN_ENTRY="{} {}".format(py, _posix(os.path.join(TESTS_DIR, "unicore_train_entry.py"))),
        HEART_DATA_PATH=_posix(data["general"]), HEART_OUTPUT_ROOT=_posix(out_root),
        HEART_LIPID_SPLITS=_posix(data["splits"]), HEART_CONFIRM_CONTINUAL="1",
        MIN_FREE_GB="0", HEART_MEM_INTERVAL="0", PYTHONIOENCODING="utf-8",
        HEART_ALLOW_SMOKE_LIPID="1")
    if ckpt:
        env["HEART_GENERAL_CHECKPOINT"] = _posix(ckpt)
    env.update({k: str(v) for k, v in extra.items()})
    return env


def run_launcher(env):
    return subprocess.run([BASH, os.path.join(SCRIPTS_DIR, LAUNCHER)], env=env,
                          capture_output=True, text=True, timeout=1200)


@needs_bash
@pytest.mark.parametrize("drop,msg", [
    ("HEART_CONFIRM_CONTINUAL", "requires HEART_CONFIRM_CONTINUAL=1"),
    ("HEART_GENERAL_CHECKPOINT", "HEART_GENERAL_CHECKPOINT=<completed general checkpoint> is required"),
    ("HEART_LIPID_SPLITS", "HEART_LIPID_SPLITS=<lipid lmdb dir>/splits.json is required"),
])
def test_launcher_refuses_missing_inputs(data, tmp_path, general_ckpt, drop, msg):
    env = env_for(data, tmp_path / "runs" / "h200", general_ckpt, HEART_DRY_RUN=1)
    env.pop(drop)
    p = run_launcher(env)
    assert p.returncode != 0 and msg in p.stderr, p.stderr[-2000:]


@needs_bash
def test_launcher_refuses_to_write_into_the_general_run_tree(data, tmp_path, general_ckpt):
    env = env_for(data, tmp_path / "runs" / "h200", general_ckpt, HEART_DRY_RUN=1,
                  RUN_NAME="../full/heart-h200-b448-v1")
    p = run_launcher(env)
    assert p.returncode != 0 and "general H200 run tree" in p.stderr


@needs_bash
def test_launcher_refuses_a_resume_with_different_lipid_splits(data, tmp_path, general_ckpt):
    """v2 review (checkpoint resume): the run is pinned to the splits.json it started with."""
    out = tmp_path / "runs" / "h200"
    run_dir = out / "continual" / "heart-lipid-continual-v1"
    run_dir.mkdir(parents=True)
    (run_dir / "lipid_data_identity.txt").write_text("0" * 64 + "\n")
    p = run_launcher(env_for(data, out, general_ckpt, HEART_DRY_RUN=1, HEART_EXTRA_ARGS=TINY))
    assert p.returncode != 0 and "differs from the one this run started with" in p.stderr, p.stderr[-3000:]
    import hashlib

    (run_dir / "lipid_data_identity.txt").write_text(
        hashlib.sha256(open(data["splits"], "rb").read()).hexdigest() + "\n")
    p = run_launcher(env_for(data, out, general_ckpt, HEART_DRY_RUN=1, HEART_EXTRA_ARGS=TINY))
    assert p.returncode == 0, (p.stdout + p.stderr)[-3000:]
    assert "max_open_lmdb_envs" not in p.stderr and "--max-open-lmdb-envs 64" in p.stdout + p.stderr


@needs_bash
def test_launcher_refuses_outside_slurm_without_dry_run(data, tmp_path, general_ckpt):
    p = run_launcher(env_for(data, tmp_path / "runs" / "h200", general_ckpt))
    assert p.returncode != 0 and "only under sbatch" in p.stderr


@needs_bash
def test_launcher_dry_run_checks_the_checkpoint_and_writes_nothing(data, tmp_path, general_ckpt):
    out = tmp_path / "runs" / "h200"
    env = env_for(data, out, general_ckpt, HEART_DRY_RUN=1, HEART_EXTRA_ARGS=TINY)
    p = run_launcher(env)
    assert p.returncode == 0, (p.stdout + p.stderr)[-4000:]
    assert "PASS        : --dry-run, nothing written" in p.stdout
    assert "pre-flight passed" in p.stdout
    assert not (out / "continual" / "heart-lipid-continual-v1").exists()
    cmd = p.stdout.splitlines()[p.stdout.splitlines().index("=== Command ===") + 1]
    for flag in ("--task unimol_contrastive_continual", "--lipid-splits", "--general-data-weight 0.5",
                 "--lipid-data-weight 1.0", "--total-num-update 200000", "--lr 2e-5",
                 "--finetune-from-model"):
        assert flag in cmd, flag


@needs_bash
def test_launcher_dry_run_refuses_an_incompatible_architecture(data, tmp_path, general_ckpt):
    env = env_for(data, tmp_path / "runs" / "h200", general_ckpt, HEART_DRY_RUN=1,
                  HEART_EXTRA_ARGS=TINY.replace("--encoder-attention-heads 4", "--encoder-attention-heads 8"))
    p = run_launcher(env)
    assert p.returncode != 0
    assert "encoder-attention-heads" in p.stdout and "not compatible" in p.stderr


@needs_bash
def test_launcher_new_stage_then_resume_on_cpu(data, tmp_path, general_ckpt):
    """New continual stage from the general checkpoint (early checkpoint at 1, in-job resume
    to 2), then a resubmission resuming to 3. Real unicore-train, tiny model, CPU."""
    import torch

    out = tmp_path / "runs" / "h200"
    run_dir = out / "continual" / "heart-lipid-continual-v1"
    general_before = open(general_ckpt, "rb").read()
    env = env_for(data, out, general_ckpt, HEART_LOCAL_CPU_TEST=1, EARLY_CHECKPOINT_UPDATES=1,
                  HEART_EXTRA_ARGS=TINY + " --max-update 2")
    p = run_launcher(env)
    log = p.stdout + p.stderr
    assert p.returncode == 0, log[-6000:]
    assert open(general_ckpt, "rb").read() == general_before, "the general checkpoint was modified"
    assert "loading pretrained model from" in log and "continual_init.pt" in log
    assert "segment 2/2: resuming checkpoint_last.pt @ 1" in log

    init = torch.load(str(run_dir / "continual_init.pt"), map_location="cpu", weights_only=False)
    assert set(init) == {"args", "model", "heart_continual_init"}
    report = json.load(open(run_dir / "continual_init_report.json", encoding="utf-8"))
    assert report["problems"] == [] and report["training_command_checked"]
    stage = json.load(open(run_dir / "continual_stage.json", encoding="utf-8"))
    assert stage["stage"] == "continual" and stage["total_num_update"] == 200000
    mix = json.load(open(run_dir / "mixture_report.json", encoding="utf-8"))
    assert [d["n_sampled"] for d in mix["train"]["datasets"]] == [3, 4]

    ck = torch.load(str(run_dir / "checkpoint_last.pt"), map_location="cpu", weights_only=False)
    assert ck["optimizer_history"][-1]["num_updates"] == 2
    assert ck["args"].task == "unimol_contrastive_continual"
    assert ck["args"].total_num_update == 200000 and ck["args"].lr == [2e-5]
    # new stage: the schedule restarted (the general checkpoint was at update 2 of 1,000,000)
    # and the 300 h of general training time were not inherited
    assert ck["extra_state"]["previous_training_time"] < 3600

    env["HEART_EXTRA_ARGS"] = TINY + " --max-update 3"
    p2 = run_launcher(env)
    log2 = p2.stdout + p2.stderr
    assert p2.returncode == 0, log2[-6000:]
    assert "RESUMING the continual stage from checkpoint_last.pt @ 2" in log2
    assert "PASS  task is unimol_contrastive_continual" in log2
    assert "loading pretrained model from" not in log2
    ck2 = torch.load(str(run_dir / "checkpoint_last.pt"), map_location="cpu", weights_only=False)
    assert ck2["optimizer_history"][-1]["num_updates"] == 3


@needs_bash
def test_launcher_refuses_to_resume_a_general_checkpoint(data, tmp_path, general_ckpt):
    """A general checkpoint copied in as checkpoint_last.pt must not be 'resumed'."""
    import shutil

    out = tmp_path / "runs" / "h200"
    run_dir = out / "continual" / "heart-lipid-continual-v1"
    run_dir.mkdir(parents=True)
    shutil.copyfile(general_ckpt, run_dir / "checkpoint_last.pt")
    env = env_for(data, out, general_ckpt, HEART_LOCAL_CPU_TEST=1, HEART_ALLOW_ARG_CHANGE=1,
                  HEART_EXTRA_ARGS=TINY + " --max-update 4")
    p = run_launcher(env)
    assert p.returncode != 0
    assert "FAIL  task is unimol_contrastive_continual" in p.stdout
    assert "not a continual-stage checkpoint" in p.stderr


# --------------------------------------------------------------------------- lipid CPU stages
@needs_bash
def test_lipid_cpu_stages_run_end_to_end(data, tmp_path):
    """Stages 01-05 on the mini sheet, with array tasks simulated by SLURM_ARRAY_* variables."""
    root = tmp_path / "lipid_root"
    (root / "input").mkdir(parents=True)
    sheet = lf.write_sheet_csv(str(root / "input" / "sheet.csv"))
    py = _posix(sys.executable)
    base = dict(os.environ)
    for k in list(base):
        if k.startswith(("SLURM_", "HEART_", "LIPID_")):
            base.pop(k)
    base.update(HEART_REPO=_posix(REPO_ROOT), HEART_SKIP_ENV="1", HEART_PYTHON=py,
                HEART_DATA_PATH=_posix(data["general"]), HEART_CONFIRM_LIPID="1",
                LIPID_ROOT=_posix(root), LIPID_INPUT=_posix(sheet), PYTHONIOENCODING="utf-8",
                CHUNK_SIZE="4", RECORDS_PER_SHARD="3", LIMIT="6", VALID_SHARDS="1", STORE_2D="1",
                VALIDATE_ALL="1")

    def stage(script, **extra):
        env = dict(base, **{k: str(v) for k, v in extra.items()})
        p = subprocess.run([BASH, os.path.join(SCRIPTS_DIR, "lipid_library", script)], env=env,
                           capture_output=True, text=True, timeout=1200)
        assert p.returncode == 0, (script, (p.stdout + p.stderr)[-4000:])
        return p.stdout + p.stderr

    refused = subprocess.run([BASH, os.path.join(SCRIPTS_DIR, "lipid_library", "01_building_blocks.sh")],
                             env=dict(base, HEART_CONFIRM_LIPID="0"), capture_output=True, text=True)
    assert refused.returncode != 0 and "HEART_CONFIRM_LIPID=1" in refused.stderr

    stage("01_building_blocks.sh")
    assert (root / "review" / "review.csv").exists()
    # stage 03 must refuse while the enumeration array is incomplete
    # the stride is LIPID_ENUM_ARRAY_SIZE / LIPID_ARRAY_SIZE, not SLURM_ARRAY_TASK_COUNT (v2 review)
    stage("02_enumerate_array.sh", SLURM_ARRAY_TASK_ID=0, SLURM_ARRAY_TASK_COUNT=2, LIPID_ENUM_ARRAY_SIZE=2)
    p = subprocess.run([BASH, os.path.join(SCRIPTS_DIR, "lipid_library", "03_dedup.sh")], env=base,
                       capture_output=True, text=True, timeout=600)
    assert p.returncode != 0 and "enumeration is incomplete" in p.stderr
    # a partial resubmission (--array=1 -> SLURM_ARRAY_TASK_COUNT=1) keeps the original stride
    stage("02_enumerate_array.sh", SLURM_ARRAY_TASK_ID=1, SLURM_ARRAY_TASK_COUNT=1,
          SLURM_ARRAY_TASK_MAX=1, LIPID_ENUM_ARRAY_SIZE=2)
    stage("03_dedup.sh")
    # stage 04 refuses to start before the stage-03b partition exists
    p = subprocess.run([BASH, os.path.join(SCRIPTS_DIR, "lipid_library", "04_conformers_array.sh")],
                       env=dict(base, SLURM_ARRAY_TASK_ID="0", LIPID_ARRAY_SIZE="2"),
                       capture_output=True, text=True, timeout=600)
    assert p.returncode != 0 and "run stage 03b first" in p.stderr, p.stdout + p.stderr
    stage("03b_partition.sh")
    for task in range(2):
        stage("04_conformers_array.sh", SLURM_ARRAY_TASK_ID=task, SLURM_ARRAY_TASK_COUNT=2, LIPID_ARRAY_SIZE=2)
    # a task id beyond the stride is refused instead of silently duplicating shards
    p = subprocess.run([BASH, os.path.join(SCRIPTS_DIR, "lipid_library", "04_conformers_array.sh")],
                       env=dict(base, SLURM_ARRAY_TASK_ID="2", LIPID_ARRAY_SIZE="2"),
                       capture_output=True, text=True, timeout=600)
    assert p.returncode != 0 and "outside 0..1" in p.stderr
    out = stage("05_finalize.sh", LIPID_ARRAY_SIZE=2)
    assert "ready: HEART_LIPID_SPLITS=" in out
    manifest = json.load(open(root / "lmdb" / "manifest.json", encoding="utf-8"))
    assert manifest["n_records"] == 6 and manifest["n_shards"] == 2
    assert manifest["coordinate_slots_per_record"] == [11]
    validation = json.load(open(root / "lmdb" / "validation.json", encoding="utf-8"))
    assert validation["n_problems"] == 0
    # every input row was read once by 03b; tasks read only their own shards' input files
    index = json.load(open(root / "lmdb" / "shard_inputs" / "partition_index.json", encoding="utf-8"))
    assert index["n_shards"] == 2 and index["n_input_rows"] == 6
    assert json.load(open(root / "lmdb" / "split_report.json", encoding="utf-8"))["n_shards"] == {"train": 1, "valid": 1}
