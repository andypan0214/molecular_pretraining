"""Continual stage: mixed general+lipid sampler, continual task, views, one training step,
strict checkpoint initialisation and the continual-stage resume guard.

All data is tiny and synthetic (tmp_path); the real 150 GB ligand LMDB, real
checkpoints and the GPU are never touched. One forward/backward step uses the
tiny 2-layer CPU architecture of conftest.task_args.
"""
import argparse
import copy
import json
import os
import pickle
import subprocess
import sys

import numpy as np
import pytest

from conftest import MODEL_ROOT, TOOLS_DIR, task_args

import lipid_fixtures as lf

torch = pytest.importorskip("torch")
pytest.importorskip("rdkit")
pytest.importorskip("lmdb")
pytest.importorskip("unicore")


# --------------------------------------------------------------------------- shared tiny data
@pytest.fixture(scope="module")
def mixed_data(tmp_path_factory):
    """general stand-in (6 train / 2 valid) + lipid shards (8 records: 4 train / 4 valid)."""
    root = str(tmp_path_factory.mktemp("continual"))
    general = lf.write_general_lmdb_dir(os.path.join(root, "general"), n_3d=2, store_2d=True)
    lipid = lf.full_lipid_pipeline(os.path.join(root, "lipid"), limit=8, n_3d=2, store_2d=True)
    return {"root": root, "general": general, "lipid": lipid}


def _merged(paths, weights, seed=1):
    from unimol.data.merged_sampling_dataset import MergedSampledLMDBDataset

    return MergedSampledLMDBDataset(paths, weights, seed=seed)


def _train_paths(mixed_data):
    from lipid_library import splits

    lipid, _ = splits.load_splits(mixed_data["lipid"]["splits"], "train")
    return [os.path.join(mixed_data["general"]["dir"], "train.lmdb")] + lipid


# --------------------------------------------------------------------------- MergedSampledLMDBDataset
def test_weights_are_per_dataset_fractions_not_a_batch_ratio(unimol_pkg, mixed_data):
    paths = _train_paths(mixed_data)
    ds = _merged(paths, [0.5, 1.0])
    counts = ds.mixture_counts()
    assert [c["n_records"] for c in counts] == [6, 4]
    # LUMI: int(len(keys) * weight) records sampled without replacement
    assert [c["n_sampled"] for c in counts] == [3, 4]
    assert len(ds) == 7
    # the general share of an epoch is 3/7, not the 1/3 a "1:2 ratio" would suggest
    assert counts[0]["fraction_of_epoch"] == pytest.approx(3 / 7)
    assert "NOT" in ds.mixture_summary() or "not set the mini-batch ratio" in ds.mixture_summary()


def test_sampling_is_deterministic_per_seed_and_without_replacement(unimol_pkg, mixed_data):
    paths = _train_paths(mixed_data)
    a, b = _merged(paths, [0.5, 1.0], seed=1), _merged(paths, [0.5, 1.0], seed=1)
    assert all(np.array_equal(x, y) for x, y in zip(a.selected, b.selected))
    for sel, n in zip(a.selected, a.sizes):
        assert len(set(sel.tolist())) == len(sel) and sel.min() >= 0 and sel.max() < n
    seeds = {tuple(_merged(paths, [0.5, 1.0], seed=s).selected[0].tolist()) for s in range(1, 12)}
    assert len(seeds) > 1, "the subset should depend on the seed"


def test_index_mapping_reads_the_right_record(unimol_pkg, mixed_data):
    import lmdb

    paths = _train_paths(mixed_data)
    ds = _merged(paths, [0.5, 1.0])
    for i in range(len(ds)):
        db, rec = ds.dataset_of(i)
        env = lmdb.open(paths[db], subdir=False, readonly=True, lock=False)
        with env.begin() as txn:
            expected = pickle.loads(txn.get(str(rec).encode("ascii")))
        env.close()
        assert ds[i]["smi"] == expected["smi"]
    with pytest.raises(IndexError):
        ds.dataset_of(len(ds))


def test_epoch_covers_each_sampled_record_once_and_batches_mix_sources(unimol_pkg, mixed_data):
    from unicore.data import EpochShuffleDataset

    paths = _train_paths(mixed_data)
    ds = _merged(paths, [1.0, 1.0])
    order = list(EpochShuffleDataset(ds, len(ds), seed=1).ordered_indices())
    assert sorted(order) == list(range(len(ds)))
    sources = [ds.dataset_of(i)[0] for i in order]
    # with shuffling the first half of an epoch is not a single source
    assert len(set(sources[: len(sources) // 2])) == 2


@pytest.mark.parametrize("weights,msg", [([0.0, 1.0], "outside"), ([1.5, 1.0], "outside"),
                                         ([1.0], "entries")])
def test_invalid_weights_are_rejected(unimol_pkg, mixed_data, weights, msg):
    with pytest.raises(ValueError, match=msg):
        _merged(_train_paths(mixed_data), weights)


def test_smiles_keyed_lumi_lmdb_is_rejected(unimol_pkg, mixed_data, tmp_path):
    bad = lf.write_smiles_keyed_lmdb(str(tmp_path / "lumi_style.lmdb"))
    with pytest.raises(ValueError, match="contiguous ASCII integer keys"):
        _merged([_train_paths(mixed_data)[0], bad], [0.5, 1.0])


def test_pickling_drops_open_environments(unimol_pkg, mixed_data):
    ds = _merged(_train_paths(mixed_data), [0.5, 1.0])
    _ = ds[0]
    assert ds.open_env_count() == 1
    clone = pickle.loads(pickle.dumps(ds))
    assert clone.open_env_count() == 0          # v2 P0: the LRU of open envs is never pickled
    assert clone[1]["smi"] == ds[1]["smi"]


def test_reader_opens_one_environment_per_process(unimol_pkg, mixed_data):
    """Same records in a fresh (spawned) process: the fork/spawn safety of patch H3."""
    ds = _merged(_train_paths(mixed_data), [0.5, 1.0])
    _ = ds[0]                                   # opened in the parent first
    payload = pickle.dumps(ds)
    code = ("import pickle,sys; from unicore import utils; from types import SimpleNamespace;"
            "utils.import_user_module(SimpleNamespace(user_dir=sys.argv[1]));"
            "ds=pickle.loads(sys.stdin.buffer.read());"
            "print('|'.join(ds[i]['smi'] for i in range(len(ds))))")
    p = subprocess.run([sys.executable, "-c", code, os.path.join(MODEL_ROOT, "unimol")],
                       input=payload, capture_output=True, cwd=MODEL_ROOT, timeout=300)
    assert p.returncode == 0, p.stderr.decode()[-2000:]
    child = p.stdout.decode().strip().splitlines()[-1].split("|")
    assert child == [ds[i]["smi"] for i in range(len(ds))]


# --------------------------------------------------------------------------- continual task
def continual_args(mixed_data, **overrides):
    base = dict(lipid_splits=mixed_data["lipid"]["splits"], lipid_lmdb=None,
                general_data_weight=0.5, lipid_data_weight=1.0, mixture_report=None,
                require_equal_coordinate_slots=False, allow_smoke_lipid_data=True,
                invalid_smiles_policy="skip-2d",
                max_invalid_smiles_fraction=0.01, batch_size=4,
                masked_token_loss=0.5, masked_coord_loss=1.0, masked_dist_loss=5.0)
    base.update(overrides)
    return task_args(mixed_data["general"]["dir"], **base)


def make_continual(mixed_data, split="train", **overrides):
    from unimol.tasks.unimol_contrastive_continual import UniMolTaskContrastiveContinual

    task = UniMolTaskContrastiveContinual.setup_task(continual_args(mixed_data, **overrides))
    task.load_dataset(split)
    ds = task.dataset(split)
    ds.set_epoch(1)
    return task, ds


def test_continual_task_is_registered_and_reuses_the_general_task(unimol_pkg):
    from unicore.tasks import TASK_REGISTRY

    assert "unimol_contrastive" in TASK_REGISTRY
    cont = TASK_REGISTRY["unimol_contrastive_continual"]
    assert issubclass(cont, TASK_REGISTRY["unimol_contrastive"])
    ap = argparse.ArgumentParser(add_help=False)
    cont.add_args(ap)
    ns = ap.parse_args(["data"])
    assert ns.general_data_weight == 0.5 and ns.lipid_data_weight == 1.0
    assert ns.contrastive_view_mode == "independent"


def test_continual_task_uses_the_pretrained_dictionary_unchanged(unimol_pkg, mixed_data):
    task, _ = make_continual(mixed_data)
    with open(os.path.join(mixed_data["general"]["dir"], "dict.txt"), encoding="utf-8") as fh:
        symbols = [line.split()[0] for line in fh if line.strip()]
    for i, s in enumerate(symbols):
        assert task.dictionary.index(s) == i, "token ids must keep the dict.txt order"
    assert len(task.dictionary) == len(symbols) + 1          # + [MASK], as in general training


def test_mixture_report_records_real_counts(unimol_pkg, mixed_data, tmp_path):
    report = str(tmp_path / "mixture.json")
    task, ds = make_continual(mixed_data, mixture_report=report)
    data = json.load(open(report, encoding="utf-8"))["train"]
    assert [d["n_sampled"] for d in data["datasets"]] == [3, 4]
    assert data["n_molecules_per_epoch"] == 7 == len(ds)
    assert data["general_fraction"] == pytest.approx(3 / 7)
    slots = {d["name"].split(":")[0]: d["stored_slots"] for d in data["coordinate_slots"]}
    assert slots == {"general": [3], "lipid": [3]}


def test_unequal_coordinate_slots_can_be_refused(unimol_pkg, mixed_data, tmp_path):
    lipid_1 = lf.full_lipid_pipeline(str(tmp_path / "lipid1"), limit=4, n_3d=1, store_2d=True)
    with pytest.raises(ValueError, match="different conformer slot profiles"):
        make_continual(mixed_data, lipid_splits=lipid_1["splits"],
                       require_equal_coordinate_slots=True)
    # without the flag it is only a warning
    make_continual(mixed_data, lipid_splits=lipid_1["splits"])


def test_missing_lipid_data_is_an_error(unimol_pkg, mixed_data):
    with pytest.raises(ValueError, match="no lipid LMDB"):
        make_continual(mixed_data, lipid_splits=None, lipid_lmdb=None)


def test_valid_split_uses_the_lipid_valid_shards(unimol_pkg, mixed_data):
    _, ds = make_continual(mixed_data, split="valid")
    # general valid 2 * 0.5 = 1, lipid valid shard 4 * 1.0 = 4
    assert len(ds) == 5


def test_training_time_2d_slot_is_added_once(unimol_pkg, mixed_data):
    """3 stored slots (2 3D + 1 stored 2D) + 1 runtime 2D = 4; never 12 silently."""
    task, ds = make_continual(mixed_data)
    raw = ds.dataset.defn["net_input.src_tokens"]
    # walk down to the Add2DConformerDataset
    from unimol.data import Add2DConformerDataset

    node, found = raw, None
    for _ in range(40):
        if isinstance(node, Add2DConformerDataset):
            found = node
            break
        node = getattr(node, "dataset", None)
        if node is None:
            break
    assert found is not None
    assert all(len(found[i]["coordinates"]) == 4 for i in range(len(found)))


def test_independent_views_differ_and_the_batch_is_mixed(unimol_pkg, mixed_data):
    task, ds = make_continual(mixed_data)
    sample = ds[0]
    v0, v1 = sample["view_0"], sample["view_1"]
    assert v0["target.smi_name"] == v1["target.smi_name"]
    differs = (not torch.equal(v0["net_input.src_coord"], v1["net_input.src_coord"])
               or not torch.equal(v0["net_input.src_tokens"], v1["net_input.src_tokens"]))
    assert differs, "independent views must differ in conformer, mask or noise"
    batch = ds.collater([ds[i] for i in range(len(ds))])
    assert batch["net_input"]["src_tokens"].shape[0] == 2 * len(ds)
    lipid_smiles = set()
    from lipid_library import io_utils

    for shard in ("shard-00000", "shard-00001"):
        p = os.path.join(mixed_data["lipid"]["lmdb_dir"], shard, "records.csv.gz")
        lipid_smiles |= {r["smi"] for r in io_utils.read_gz_csv(p)}
    names = batch["target"]["smi_name"]
    assert any(n in lipid_smiles for n in names) and any(n not in lipid_smiles for n in names)


def test_identical_view_mode_still_available(unimol_pkg, mixed_data):
    _, ds = make_continual(mixed_data, contrastive_view_mode="identical")
    s = ds[0]
    assert torch.equal(s["view_0"]["net_input.src_coord"], s["view_1"]["net_input.src_coord"])


def test_one_training_step_has_finite_losses_and_gradients(unimol_pkg, mixed_data):
    from unimol.losses.unimol_contrastive import UniMolLossContrastive
    from unimol.models.unimol_contrastive import UniMolModelContrastive

    task, ds = make_continual(mixed_data)
    batch = ds.collater([ds[i] for i in range(4)])
    torch.manual_seed(0)
    model = UniMolModelContrastive(copy.deepcopy(task.args), task.dictionary).train()
    loss_fn = UniMolLossContrastive(task)
    loss, sample_size, logs = loss_fn(model, batch)
    assert torch.isfinite(loss)
    for k in ("masked_token_loss", "masked_coord_loss", "masked_dist_loss", "contrastive_loss"):
        assert torch.isfinite(torch.as_tensor(logs[k])), k
    loss.backward()
    grads = [p.grad for p in model.parameters() if p.grad is not None]
    assert grads and all(torch.isfinite(g).all() for g in grads)
    assert model.proj_head[0].weight.grad.abs().sum() > 0


# --------------------------------------------------------------------------- checkpoint init / stage
def _general_checkpoint(mixed_data, path, drop_param=None, **arg_overrides):
    """A fake but structurally real HEART general checkpoint (tiny architecture)."""
    from unimol.models.unimol_contrastive import UniMolModelContrastive
    from unimol.tasks.unimol_contrastive import UniMolTaskContrastive

    ns = task_args(mixed_data["general"]["dir"], task="unimol_contrastive",
                   arch="unimol_contrastive_base", lr=[1e-5], total_num_update=1000000,
                   **arg_overrides)
    args = argparse.Namespace(**vars(ns))
    task = UniMolTaskContrastive.setup_task(args)
    torch.manual_seed(0)
    model = UniMolModelContrastive(copy.deepcopy(args), task.dictionary)
    state = model.state_dict()
    if drop_param:
        state.pop(drop_param)
    torch.save({
        "args": args, "model": state,
        "optimizer_history": [{"num_updates": 123456, "lr_scheduler_state": {"best": 1.0},
                               "loss_name": "UniMolLossContrastive", "optimizer_name": "UnicoreAdam"}],
        "last_optimizer_state": {"state": {}, "param_groups": []},
        "extra_state": {"previous_training_time": 300 * 3600.0, "train_iterator": {"epoch": 3}},
    }, path)
    return path, args


def _run_init(ck, data_dir, out, *cmd):
    argv = [sys.executable, os.path.join(TOOLS_DIR, "init_continual_checkpoint.py"), ck,
            "--data", data_dir, "--out", out, "--user-dir", "./unimol",
            "--report", out + ".report.json"]
    if cmd:
        argv += ["--"] + list(cmd)
    return subprocess.run(argv, cwd=MODEL_ROOT, capture_output=True, text=True, timeout=600,
                          env=dict(os.environ, PYTHONIOENCODING="utf-8"))


TINY_CMD = ["unicore-train", "DATA", "--arch", "unimol_contrastive_base", "--encoder-layers", "2",
            "--encoder-embed-dim", "64", "--encoder-ffn-embed-dim", "128",
            "--encoder-attention-heads", "4", "--max-atoms", "256", "--only-polar", "0",
            "--dict-name", "dict.txt", "--lr", "2e-5"]


def test_init_checkpoint_strips_optimizer_schedule_and_time(unimol_pkg, mixed_data, tmp_path):
    ck, _ = _general_checkpoint(mixed_data, str(tmp_path / "general.pt"))
    before = open(ck, "rb").read()
    out = str(tmp_path / "run" / "continual_init.pt")
    p = _run_init(ck, mixed_data["general"]["dir"], out, *TINY_CMD)
    assert p.returncode == 0, p.stdout + p.stderr
    assert open(ck, "rb").read() == before, "the general checkpoint must stay read-only"
    init = torch.load(out, map_location="cpu", weights_only=False)
    assert set(init) == {"args", "model", "heart_continual_init"}
    assert init["heart_continual_init"]["source_num_updates"] == 123456
    assert init["heart_continual_init"]["weight_coverage"] == 1.0
    assert sorted(init["heart_continual_init"]["stripped_keys"]) == [
        "extra_state", "last_optimizer_state", "optimizer_history"]
    report = json.load(open(out + ".report.json", encoding="utf-8"))
    assert report["training_command_checked"] and report["problems"] == []
    assert report["weights"]["missing_in_checkpoint"] == []


def test_init_refuses_an_architecture_change_in_the_command(unimol_pkg, mixed_data, tmp_path):
    ck, _ = _general_checkpoint(mixed_data, str(tmp_path / "general.pt"))
    cmd = TINY_CMD + ["--encoder-attention-heads", "8"]
    out = str(tmp_path / "init.pt")
    p = _run_init(ck, mixed_data["general"]["dir"], out, *cmd)
    assert p.returncode == 1 and not os.path.exists(out)
    assert "encoder-attention-heads" in p.stdout


def test_init_refuses_a_partial_checkpoint(unimol_pkg, mixed_data, tmp_path):
    ck, _ = _general_checkpoint(mixed_data, str(tmp_path / "general.pt"),
                                drop_param="proj_head.0.weight")
    out = str(tmp_path / "init.pt")
    p = _run_init(ck, mixed_data["general"]["dir"], out, *TINY_CMD)
    assert p.returncode == 1 and not os.path.exists(out)
    assert "absent from the checkpoint" in p.stdout


def test_init_refuses_a_different_vocabulary(unimol_pkg, mixed_data, tmp_path):
    ck, _ = _general_checkpoint(mixed_data, str(tmp_path / "general.pt"))
    other = tmp_path / "other_dict"
    other.mkdir()
    lines = open(os.path.join(mixed_data["general"]["dir"], "dict.txt"), encoding="utf-8").read()
    (other / "dict.txt").write_text(lines.rstrip("\n") + "\nXx\n", encoding="utf-8")
    p = _run_init(ck, str(other), str(tmp_path / "init.pt"), *TINY_CMD)
    assert p.returncode == 1
    assert "dictionary has" in p.stdout or "differ in shape" in p.stdout


def _stage_ck(path, task="unimol_contrastive_continual", total=200000, optimizer=True, lr=2e-5):
    args = argparse.Namespace(task=task, total_num_update=total, lr=[lr], warmup_updates=1000,
                              general_data_weight=0.5, lipid_data_weight=1.0)
    ck = {"args": args, "model": {"w": torch.zeros(1)},
          "optimizer_history": [{"num_updates": 5000, "lr_scheduler_state": {"best": 1.0}}],
          "extra_state": {"previous_training_time": 3600.0}}
    if optimizer:
        ck["last_optimizer_state"] = {"state": {}}
    torch.save(ck, path)
    return path


def _stage(ck, *extra):
    return subprocess.run([sys.executable, os.path.join(TOOLS_DIR, "check_continual_stage.py"), ck,
                           "--expect-task", "unimol_contrastive_continual",
                           "--expect-total-num-update", "200000"] + list(extra),
                          capture_output=True, text=True, timeout=300)


def test_stage_check_accepts_a_continual_checkpoint(tmp_path):
    stage = tmp_path / "continual_stage.json"
    stage.write_text(json.dumps({"stage": "continual", "task": "unimol_contrastive_continual",
                                 "total_num_update": 200000, "lr": 2e-5, "warmup_updates": 1000,
                                 "general_data_weight": 0.5, "lipid_data_weight": 1.0}))
    p = _stage(_stage_ck(str(tmp_path / "c.pt")), "--stage-file", str(stage))
    assert p.returncode == 0, p.stdout


@pytest.mark.parametrize("kwargs,msg", [
    ({"task": "unimol_contrastive"}, "task is"),                 # general ckpt copied into the run dir
    ({"total": 1000000}, "total-num-update"),                     # general 1M schedule
    ({"optimizer": False}, "optimizer state"),                    # would silently restart optimizer
])
def test_stage_check_refuses_wrong_checkpoints(tmp_path, kwargs, msg):
    p = _stage(_stage_ck(str(tmp_path / "c.pt"), **kwargs))
    assert p.returncode == 1
    assert any(msg in line and line.startswith("FAIL") for line in p.stdout.splitlines()), p.stdout


def test_stage_check_refuses_a_changed_lr_against_the_stage_file(tmp_path):
    stage = tmp_path / "continual_stage.json"
    stage.write_text(json.dumps({"stage": "continual", "task": "unimol_contrastive_continual",
                                 "lr": 2e-5}))
    p = _stage(_stage_ck(str(tmp_path / "c.pt"), lr=1e-4), "--stage-file", str(stage))
    assert p.returncode == 1
