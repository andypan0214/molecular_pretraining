"""Regression and scale tests for HEART_continual_v2_second_review.md.

    P0     bounded LMDB file handles in the mixed continual loader
    P1-IO  SLURM array tasks read only their own shards' inputs (stage 03b partition)
    P1-VAL representative (stratified, seeded) lipid validation split + report
    P1-PRE data preflight covers every shard's metadata and samples across all shard ids
    ARRAY  the array stride is explicit and locked (partial resubmission is safe)

Everything is synthetic and written under pytest tmp_path. "Scale" tests use
hundreds of tiny LMDB shards / tens of thousands of product rows, which is
enough to show that open handles and rows read do not grow with the number of
shards x tasks; real CMRI sizes are projections, never claimed here.
"""
import ctypes
import gzip
import json
import os
import pickle
import random
import subprocess
import sys

import numpy as np
import pytest

from conftest import MODEL_ROOT, TOOLS_DIR, task_args

import lipid_fixtures as lf
from lipid_library import enumerate_library, io_utils, lmdb_writer, provenance, splits

lmdb = pytest.importorskip("lmdb")
pytest.importorskip("rdkit")


# =========================================================================== helpers
def os_handle_count():
    """Open file descriptors (Linux/macOS) or kernel handles (Windows) of this process."""
    if sys.platform == "win32":
        from ctypes import wintypes

        k32 = ctypes.WinDLL("kernel32", use_last_error=True)
        k32.GetCurrentProcess.restype = wintypes.HANDLE
        k32.GetProcessHandleCount.argtypes = [wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)]
        k32.GetProcessHandleCount.restype = wintypes.BOOL
        n = wintypes.DWORD()
        assert k32.GetProcessHandleCount(k32.GetCurrentProcess(), ctypes.byref(n)), ctypes.get_last_error()
        return n.value
    for d in ("/proc/self/fd", "/dev/fd"):
        if os.path.isdir(d):
            return len(os.listdir(d))
    pytest.skip("no way to count open handles on this platform")


def _record(i, slots=3, store_2d=True, tag=""):
    rng = np.random.default_rng(i)
    coords = []
    for k in range(slots):
        c = rng.normal(size=(3, 3)).astype(np.float32)
        if store_2d and k == slots - 1:
            c[:, 2] = 0.0
        coords.append(c)
    return {"smi": "CCO" + tag, "atoms": ["C", "C", "O"], "coordinates": coords}


def _write_lmdb(path, records):
    for p in (path, path + "-lock"):
        if os.path.exists(p):
            os.remove(p)
    env = lmdb.open(path, subdir=False, map_size=1 << 17, lock=True)
    with env.begin(write=True) as txn:
        for i, r in enumerate(records):
            txn.put(str(i).encode("ascii"), pickle.dumps(r, protocol=4))
    env.close()
    if os.path.exists(path + "-lock"):
        os.remove(path + "-lock")


def make_synthetic_lipid(root, n_shards, n_records=3, slots=3, store_2d=True, bad_shard=None,
                         valid_shards=2, split_seed=1):
    """A finalised-looking lipid LMDB directory (manifest, receipts, splits.json) of tiny shards."""
    os.makedirs(root, exist_ok=True)
    shards = []
    for sid in range(n_shards):
        d = os.path.join(root, "shard-{:05d}".format(sid))
        os.makedirs(d, exist_ok=True)
        n_slots = slots - 1 if sid == bad_shard else slots          # damaged records, consistent metadata
        recs = [_record(sid * 100 + i, n_slots, store_2d and sid != bad_shard, tag=str(sid))
                for i in range(n_records)]
        path = os.path.join(d, "train.lmdb")
        _write_lmdb(path, recs)
        entry = {"shard_id": sid, "dir": os.path.basename(d), "lmdb": os.path.basename(d) + "/train.lmdb",
                 "n_records": n_records, "n_skipped": 0, "n_input_rows": n_records,
                 "lmdb_sha256": io_utils.sha256_file(path), "input_fingerprint": "x",
                 "first_combo_index": sid * n_records, "last_combo_index": sid * n_records + n_records - 1,
                 "coordinate_slots_per_record": slots, "stored_2d_conformer": store_2d,
                 "n_3d_slots_per_record": slots - int(store_2d), "n_2d_filled_total": 0}
        receipt = {k: entry[k] for k in ("shard_id", "lmdb_sha256", "n_records", "coordinate_slots_per_record",
                                         "stored_2d_conformer")}
        receipt["lmdb"] = "train.lmdb"
        io_utils.atomic_write_json(os.path.join(d, "shard.json"), receipt)
        shards.append(entry)
    manifest = {"format_version": 1, "complete": True, "smoke": False, "config_fingerprint": "synthetic",
                "n_shards": n_shards, "n_input_rows": n_shards * n_records,
                "n_records": n_shards * n_records, "n_skipped": 0,
                "coordinate_slots_per_record": [slots], "stored_2d_conformer": [store_2d], "shards": shards}
    io_utils.atomic_write_json(os.path.join(root, "manifest.json"), manifest)
    split = splits.build_splits(root, valid_shards=valid_shards, split_seed=split_seed)
    io_utils.atomic_write_json(os.path.join(root, "splits.json"), split)
    return os.path.join(root, "splits.json")


class EnvTracker:
    """Wraps lmdb.open to measure how many environments are open at the same time."""

    def __init__(self, real):
        self.real, self.current, self.peak, self.total = real, 0, 0, 0

    def __call__(self, *a, **k):
        env = self.real(*a, **k)
        self.current += 1
        self.total += 1
        self.peak = max(self.peak, self.current)
        tracker = self

        class Proxy:
            closed = False

            def __getattr__(self, name):
                return getattr(env, name)

            def close(self):
                if not self.closed:
                    self.closed = True
                    tracker.current -= 1
                env.close()

        return Proxy()


# =========================================================================== P0 bounded LMDB handles
@pytest.fixture(scope="module")
def many_shards(tmp_path_factory):
    """300 tiny integer-keyed LMDBs (3 records each): 'thousands of shards' in miniature."""
    root = str(tmp_path_factory.mktemp("many_shards"))
    paths = []
    for s in range(300):
        p = os.path.join(root, "s{:03d}.lmdb".format(s))
        _write_lmdb(p, [_record(s * 10 + i, tag="-{}-{}".format(s, i)) for i in range(3)])
        paths.append(p)
    return paths


def _merged(paths, max_open, weights=None, seed=1):
    from unimol.data.merged_sampling_dataset import MergedSampledLMDBDataset

    return MergedSampledLMDBDataset(paths, weights or [1.0] * len(paths), seed=seed, max_open_envs=max_open)


def _direct(path, key):
    env = lmdb.open(path, subdir=False, readonly=True, lock=False)
    try:
        with env.begin() as txn:
            return pickle.loads(txn.get(str(key).encode("ascii")))
    finally:
        env.close()


def test_p0_construction_leaves_no_handle_open(unimol_pkg, many_shards):
    before = os_handle_count()
    ds = _merged(many_shards, 8)
    assert ds.open_env_count() == 0
    assert os_handle_count() - before < 20, "probing 300 LMDBs at init must close each one"
    assert len(ds) == 900


def test_p0_open_environments_stay_bounded_and_reads_stay_correct(unimol_pkg, many_shards):
    ds = _merged(many_shards, 8)
    order = list(range(len(ds)))
    random.Random(0).shuffle(order)          # shuffled epoch: every access may hit another shard
    peak = 0
    for i in order:
        rec = ds[i]
        db, key = ds.dataset_of(i)
        assert rec["smi"] == "CCO-{}-{}".format(db, key)
        peak = max(peak, ds.open_env_count())
    assert peak == 8
    assert ds.env_stats["evicted"] >= len(many_shards) - 8
    # spot-check bytes against a direct read after hundreds of evictions
    for i in order[:25]:
        db, key = ds.dataset_of(i)
        np.testing.assert_array_equal(ds[i]["coordinates"][0], _direct(many_shards[db], key)["coordinates"][0])


def test_p0_os_handle_count_is_bounded_unlike_an_unbounded_cache(unimol_pkg, many_shards):
    """Kernel handles/FDs, not just the bookkeeping, stay bounded (control: unbounded cache)."""
    order = list(range(900))
    random.Random(1).shuffle(order)

    def growth(max_open):
        ds = _merged(many_shards, max_open)
        before = os_handle_count()
        for i in order:
            ds[i]
        grown = os_handle_count() - before
        ds.close()
        return grown, ds

    bounded, _ = growth(8)
    unbounded, _ = growth(10 ** 6)
    assert unbounded >= 300, unbounded          # >= 1 handle per LMDB without the bound
    assert bounded <= 8 * 4, bounded            # a few handles per open env, at most 8 envs
    assert os_handle_count() < 2000


def test_p0_evicted_environment_is_closed(unimol_pkg, many_shards):
    ds = _merged(many_shards[:5], 2)
    ds[0]                                       # opens LMDB 0
    env0 = ds._envs[0]
    ds[3]
    ds[6]                                       # LMDB 1 and 2: LMDB 0 is evicted
    assert 0 not in ds._envs and ds.open_env_count() == 2
    with pytest.raises(lmdb.Error):
        env0.begin()                            # really closed, not just forgotten
    assert ds[1]["smi"] == "CCO-0-1"            # and transparently reopened


def test_p0_close_releases_all_and_rejects_bad_bound(unimol_pkg, many_shards):
    ds = _merged(many_shards[:20], 16)
    for i in range(len(ds)):
        ds[i]
    assert ds.open_env_count() == 16
    ds.close()
    assert ds.open_env_count() == 0
    assert ds[59]["smi"] == "CCO-19-2"
    with pytest.raises(ValueError, match="max_open_envs"):
        _merged(many_shards[:2], 0)


def test_p0_selection_is_identical_with_and_without_eviction(unimol_pkg, many_shards):
    """Resume safety: the bound changes handles, never which record an index maps to."""
    a = _merged(many_shards, 4, weights=[0.5] * 300, seed=7)
    b = _merged(many_shards, 10 ** 6, weights=[0.5] * 300, seed=7)
    assert all(np.array_equal(x, y) for x, y in zip(a.selected, b.selected))
    for i in range(0, len(a), 7):
        assert a[i]["smi"] == b[i]["smi"]


def test_p0_spawned_worker_is_bounded(unimol_pkg, many_shards):
    """A spawned DataLoader-style worker: no handle is pickled, and its own LRU is bounded."""
    ds = _merged(many_shards, 4)
    for i in range(0, 60, 3):
        ds[i]                                   # parent holds 4 envs before "spawning"
    payload = pickle.dumps(ds)
    code = ("import pickle,sys,random; from unicore import utils; from types import SimpleNamespace;"
            "utils.import_user_module(SimpleNamespace(user_dir=sys.argv[1]));"
            "ds=pickle.loads(sys.stdin.buffer.read()); n0=ds.open_env_count();"
            "o=list(range(len(ds))); random.Random(3).shuffle(o); peak=0; out=[]\n"
            "for i in o:\n out.append(ds[i]['smi']); peak=max(peak, ds.open_env_count())\n"
            "print(n0, peak, ds.env_stats['evicted']); print('|'.join(out))")
    p = subprocess.run([sys.executable, "-c", code, os.path.join(MODEL_ROOT, "unimol")],
                       input=payload, capture_output=True, cwd=MODEL_ROOT, timeout=300)
    assert p.returncode == 0, p.stderr.decode()[-2000:]
    first, smis = p.stdout.decode().strip().splitlines()[-2:]
    n0, peak, evicted = (int(x) for x in first.split())
    assert n0 == 0 and peak == 4 and evicted >= 296
    order = list(range(len(ds)))
    random.Random(3).shuffle(order)
    assert smis.split("|") == [ds[i]["smi"] for i in order]


@pytest.mark.skipif(not hasattr(os, "fork"), reason="fork() is not available on this platform")
def test_p0_forked_worker_discards_inherited_handles(unimol_pkg, many_shards):
    ds = _merged(many_shards, 4)
    for i in range(0, 60, 3):
        ds[i]
    r, w = os.pipe()
    pid = os.fork()
    if pid == 0:                                # child
        try:
            out = [ds.open_env_count()]
            peak = 0
            for i in range(len(ds)):
                ds[i]
                peak = max(peak, ds.open_env_count())
            out.append(peak)
            os.write(w, json.dumps(out).encode())
        finally:
            os._exit(0)
    os.close(w)
    os.waitpid(pid, 0)
    n0, peak = json.loads(os.read(r, 1000).decode())
    assert n0 == 0 and peak == 4
    assert ds.open_env_count() == 4             # the parent's handles were untouched


# =========================================================================== P0 in the continual task
@pytest.fixture(scope="module")
def task_data(tmp_path_factory):
    root = tmp_path_factory.mktemp("v2_task")
    general = lf.write_general_lmdb_dir(str(root / "general"), n_3d=2, store_2d=True)      # "3/1"
    lipid = make_synthetic_lipid(str(root / "lipid"), 120, slots=3, store_2d=True)         # "3/1"
    return {"general": general["dir"], "splits": lipid, "root": root}


def _task(general, splits_path, **kw):
    from unimol.tasks.unimol_contrastive_continual import UniMolTaskContrastiveContinual

    args = task_args(general, lipid_splits=splits_path, lipid_lmdb=None, general_data_weight=1.0,
                     lipid_data_weight=1.0, mixture_report=None, require_equal_coordinate_slots=True,
                     allow_smoke_lipid_data=False, invalid_smiles_policy="skip-2d",
                     max_invalid_smiles_fraction=0.01, batch_size=4, **kw)
    return UniMolTaskContrastiveContinual.setup_task(args)


def test_p0_task_bounds_handles_and_closes_them_before_workers(unimol_pkg, task_data, monkeypatch):
    import unimol.tasks.unimol_contrastive_continual as mod

    made = []

    class Recording(mod.MergedSampledLMDBDataset):
        def __init__(self, *a, **k):
            super().__init__(*a, **k)
            self.peak = 0
            made.append(self)

        def _get_env(self, i):
            env = super()._get_env(i)
            self.peak = max(self.peak, self.open_env_count())
            return env

    monkeypatch.setattr(mod, "MergedSampledLMDBDataset", Recording)
    task = _task(task_data["general"], task_data["splits"], max_open_lmdb_envs=6, slot_check_shards=12)
    task.load_dataset("train")
    merged = made[-1]
    assert len(merged.db_paths) == 1 + 118 and merged.max_open_envs == 6
    assert merged.peak <= 6
    assert merged.open_env_count() == 0, "the parent must not carry LMDB handles into workers"
    ds = task.dataset("train")
    ds.set_epoch(1)
    for i in range(0, len(ds), 9):
        assert ds[i] is not None                # full transform chain over evicting reads
    assert merged.peak <= 6 and merged.env_stats["evicted"] > 0


def test_p1_task_slot_check_spreads_over_all_shards_and_checks_manifest(unimol_pkg, task_data, tmp_path):
    import shutil

    task = _task(task_data["general"], task_data["splits"], slot_check_shards=10)
    from unimol.data.merged_sampling_dataset import MergedSampledLMDBDataset

    paths = [os.path.join(task_data["general"], "train.lmdb")] + task.lipid_lmdbs("train")[0]
    merged = MergedSampledLMDBDataset(paths, [1.0] * len(paths), max_open_envs=4)
    report = task._coordinate_slot_check(merged, task.lipid_lmdbs("train")[1])
    lipid = report[-1]
    assert lipid["n_lmdbs"] == 118 and lipid["n_lmdbs_probed"] == 10
    assert lipid["lmdb"][0] == paths[1] and lipid["lmdb"][-1] == paths[-1]   # first AND last shard
    # a splits.json whose declared slot count contradicts the records is refused
    lip = str(tmp_path / "lipid")
    shutil.copytree(os.path.dirname(task_data["splits"]), lip)
    meta = json.load(open(os.path.join(lip, "splits.json"), encoding="utf-8"))
    meta["coordinate_slots_per_record"] = [4]
    io_utils.atomic_write_json(os.path.join(lip, "splits.json"), meta)
    with pytest.raises(ValueError, match="finalised manifest"):
        _task(task_data["general"], os.path.join(lip, "splits.json")).load_dataset("train")


# =========================================================================== P1-IO array input reads
def _synthetic_products(root, n):
    d = os.path.join(root, "products")
    os.makedirs(os.path.join(d, "products"), exist_ok=True)
    w = io_utils.AtomicGzCsvWriter(os.path.join(d, "products", "products-0-{}.csv.gz".format(n)),
                                   enumerate_library.PRODUCT_FIELDS)
    for i in range(n):
        w.writerow([i, "A1-B1-C1-D{}".format(i), "A1", "B1", "C1", "D1", "CC" + "C" * (i % 7) + "O", 0, 0, 0, 1])
    w.close()
    return d


def _stub_write_shard(calls):
    def stub(rows, out_dir, shard_id, opts, config_fingerprint=None):
        calls.append((shard_id, len(rows)))
        return {"n_records": len(rows), "n_skipped": 0, "n_3d_slots_total": 0, "n_2d_filled_total": 0,
                "seconds": 0.0, "skip_reasons": {}, "unsupported_atoms": {}}
    return stub


def test_p1_io_array_tasks_read_each_row_once_not_array_size_times(tmp_path, monkeypatch):
    """20,000 rows, 200 shards, 50 tasks: tasks read 20,000 rows in total (old code: 1,000,000)."""
    n, rps, tasks = 20000, 100, 50
    products = _synthetic_products(str(tmp_path), n)
    out = str(tmp_path / "lmdb")
    common = [products, "-o", out, "--store-2d", "--records-per-shard", str(rps)]
    lmdb_writer.ROWS_READ.update(products=0, shard_inputs=0)
    assert lmdb_writer.main(common + ["--partition"]) == 0
    assert lmdb_writer.ROWS_READ == {"products": n, "shard_inputs": 0}          # one pass, once
    calls = []
    monkeypatch.setattr(lmdb_writer, "write_shard", _stub_write_shard(calls))
    per_task = []
    for t in range(tasks):
        lmdb_writer.ROWS_READ.update(products=0, shard_inputs=0)
        assert lmdb_writer.main(common + ["--shard", str(t), "--num-shards", str(tasks)]) == 0
        assert lmdb_writer.ROWS_READ["products"] == 0, "an array task must not stream the products"
        per_task.append(lmdb_writer.ROWS_READ["shard_inputs"])
    assert sum(per_task) == n                       # ~ dataset size, not tasks x dataset size
    assert max(per_task) == (n // rps // tasks) * rps
    assert sorted(s for s, _ in calls) == list(range(n // rps))     # every shard once, none twice


def test_p1_io_partition_inputs_are_verified_and_locked(tmp_path):
    products = _synthetic_products(str(tmp_path), 300)
    out = str(tmp_path / "lmdb")
    common = [products, "-o", out, "--store-2d", "--records-per-shard", "100", "--n-3d", "1",
              "--max-try", "3", "--max-iterations", "100", "--map-size-gb", "0.25"]
    with pytest.raises(SystemExit, match="--partition"):
        lmdb_writer.main(common + ["--shard", "0", "--num-shards", "3"])      # no partition yet
    assert lmdb_writer.main(common + ["--partition"]) == 0
    assert lmdb_writer.main(common + ["--partition"]) == 0                    # idempotent reuse
    # a damaged input file is refused, never used
    f = os.path.join(out, "shard_inputs", "input-00001.csv.gz")
    rows = gzip.open(f, "rt", encoding="utf-8").read().replace("CCO", "CCN", 1)
    with gzip.open(f, "wt", encoding="utf-8", newline="") as fh:
        fh.write(rows)
    with pytest.raises(SystemExit, match="sha256 differs"):
        lmdb_writer.main(common + ["--shard", "1", "--num-shards", "3"])
    # a different stride for the same output directory is refused
    with pytest.raises(SystemExit, match="different configuration"):
        lmdb_writer.main(common + ["--shard", "0", "--num-shards", "2"])
    # another --records-per-shard cannot reuse this partition (or the shards)
    with pytest.raises(SystemExit, match="different configuration"):
        lmdb_writer.main([products, "-o", out, "--store-2d", "--records-per-shard", "50", "--partition"])


def test_p1_io_plan_includes_input_reading_and_partition_state(tmp_path, capsys):
    from test_review_fixes import _bb, _enum

    bb = _bb(tmp_path)
    enum = str(tmp_path / "enum")
    assert _enum(bb, enum) == 0
    out = str(tmp_path / "l")
    base = [enum, "-o", out, "--store-2d", "--records-per-shard", "5"]
    assert lmdb_writer.main(base + ["--plan", "--sec-per-molecule", "1", "--array-size", "2"]) == 0
    plan = json.loads(capsys.readouterr().out)
    assert plan["partition"] == "missing" and plan["read_rate_source"] == "assumed"
    assert plan["input_rows_read_per_task"] == 10 and plan["input_rows_read_all_tasks"] == 16
    assert plan["input_rows_read_if_every_task_streamed"] == 32
    assert lmdb_writer.main(base + ["--partition"]) == 0
    capsys.readouterr()
    assert lmdb_writer.main(base + ["--plan", "--sec-per-molecule", "1", "--array-size", "2"]) == 0
    plan = json.loads(capsys.readouterr().out)
    assert plan["partition"] == "matches" and plan["read_rate_source"] == "measured by --partition"
    assert plan["est_hours_per_task"] >= round(10 * 1 / 3600.0, 2)


def test_p1_io_finalize_requires_a_matching_partition(tmp_path):
    from test_review_fixes import _bb, _enum, _writer

    bb = _bb(tmp_path)
    enum = str(tmp_path / "enum")
    assert _enum(bb, enum) == 0
    out = str(tmp_path / "lmdb")
    assert _writer(enum, out, rps=8) == 0                       # single process: builds the partition
    index_path = os.path.join(out, "shard_inputs", "partition_index.json")
    index = json.load(open(index_path, encoding="utf-8"))
    index["shards"][1]["input_fingerprint"] = "0" * 64
    io_utils.atomic_write_json(index_path, index)
    assert _writer(enum, out, "--finalize", rps=8) == 1
    report = json.load(open(os.path.join(out, "finalize_report.json"), encoding="utf-8"))
    assert any("partition does not match" in p for p in report["problems"])


# =========================================================================== P1-VAL validation split
def test_p1_val_selection_is_reproducible_stratified_and_seeded():
    ids = list(range(3049))
    k = splits._n_valid(len(ids), None, splits.DEFAULT_VALID_FRACTION)
    assert k == 6
    a = splits.select_valid_shards(ids, k, seed=1)
    assert a == splits.select_valid_shards(ids, k, seed=1)
    assert a != splits.select_valid_shards(ids, k, seed=2)
    strata = splits._strata(ids, k)
    assert [sum(1 for v in a if v in set(g)) for g in strata] == [1] * k    # one per stratum
    assert a != ids[-k:] and splits.select_valid_shards(ids, k, method="last") == ids[-k:]
    # dispersion over combination-index space, for many seeds
    for seed in range(20):
        v = splits.select_valid_shards(ids, k, seed=seed)
        assert v[0] < len(ids) / k and v[-1] >= len(ids) - len(ids) / k
    assert splits._n_valid(2, None, 0.002) == 1 and splits._n_valid(10, 3, 0.002) == 3


def test_p1_val_split_report_on_a_large_synthetic_manifest(tmp_path):
    root = str(tmp_path / "lipid")
    make_synthetic_lipid(root, 40, valid_shards=4)
    s, report = splits.build_splits(root, valid_shards=4, split_seed=3, with_report=True, reagents="none")
    assert s["split_method"] == "stratified-random" and s["representative"] is True
    assert "NOT a scaffold" in s["split_kind"]
    pos = report["valid_combo_index_positions"]
    assert len(pos) == 4 and min(pos) < 0.25 and max(pos) > 0.75
    assert report["valid_fraction_records"] == pytest.approx(4 / 40)
    legacy = splits.build_splits(root, valid_shards=4, split_method="last")
    assert legacy["representative"] is False and legacy["warnings"]
    assert legacy["shard_ids"]["valid"] == [36, 37, 38, 39]


def test_p1_val_reagent_distribution_shows_the_last_shard_bias(tmp_path):
    """Mini library: amine is the most significant digit, so the last shards hold one amine only."""
    from test_review_fixes import _bb, _enum

    bb = _bb(tmp_path)
    enum = str(tmp_path / "enum")
    assert _enum(bb, enum) == 0
    out = str(tmp_path / "lmdb")
    assert lmdb_writer.main([enum, "-o", out, "--records-per-shard", "2", "--n-3d", "1", "--max-try", "3",
                             "--max-iterations", "100", "--map-size-gb", "0.25", "--store-2d"]) == 0
    assert splits.main([out, "--valid-shards", "2", "--split-method", "last"]) == 0
    last = json.load(open(os.path.join(out, "split_report.json"), encoding="utf-8"))
    assert last["reagents"]["amine"]["valid"]["n_distinct"] == 1
    assert splits.main([out, "--valid-shards", "2", "--split-seed", "1"]) == 0
    strat = json.load(open(os.path.join(out, "split_report.json"), encoding="utf-8"))
    assert strat["reagents"]["amine"]["valid"]["n_distinct"] == 2
    assert strat["reagents"]["amine"]["fraction_of_train_reagents_seen_in_valid"] == 1.0
    data = json.load(open(os.path.join(out, "splits.json"), encoding="utf-8"))
    assert set(data["shard_ids"]["train"]).isdisjoint(data["shard_ids"]["valid"])
    assert data["valid_fraction_records"] == strat["valid_fraction_records"]


# =========================================================================== P1-PRE preflight coverage
@pytest.fixture(scope="module")
def pre_general(tmp_path_factory):
    return lf.write_general_lmdb_dir(str(tmp_path_factory.mktemp("pre_general")), n_3d=2, store_2d=True)["dir"]


def _pre(general, splits_path, *extra):
    return subprocess.run([sys.executable, os.path.join(TOOLS_DIR, "check_continual_data.py"),
                           "--general", general, "--lipid-splits", splits_path, *extra],
                          capture_output=True, text=True, timeout=600)


def test_p1_pre_damaged_late_shard_is_found(tmp_path, pre_general):
    """Records of shard 90 of 100 are damaged; the old preflight (first 64 shards) passed this."""
    sp = make_synthetic_lipid(str(tmp_path / "lipid"), 100, bad_shard=90)
    p = _pre(pre_general, sp, "--lipid-shards", "256")
    assert p.returncode == 1 and "shard-00090" in p.stdout and "contradict the declared policy" in p.stdout
    # the sample is spread over all shard ids, not the first ones
    j = str(tmp_path / "pre.json")
    _pre(pre_general, sp, "--lipid-shards", "10", "--json-out", j)
    sampled = json.load(open(j, encoding="utf-8"))["lipid_sampling"]["train"]
    assert sampled["n_shards_sampled"] == 10 and max(sampled["shard_positions_sampled"]) >= 88
    assert min(sampled["shard_positions_sampled"]) <= 9


def test_p1_pre_clean_library_passes(tmp_path, pre_general):
    sp = make_synthetic_lipid(str(tmp_path / "lipid"), 100)
    p = _pre(pre_general, sp)
    assert p.returncode == 0, p.stdout + p.stderr
    assert "100 shards checked" in p.stdout and "PASS" in p.stdout


@pytest.mark.parametrize("damage,msg", [
    ("receipt", "receipt shard.json missing"),
    ("lmdb", "LMDB missing"),
    ("count", "entries, manifest says"),
    ("policy", "declares 4 slots"),
    ("unassigned", "in no split"),
])
def test_p1_pre_every_shards_metadata_is_checked(tmp_path, pre_general, damage, msg):
    root = str(tmp_path / "lipid")
    sp = make_synthetic_lipid(root, 100)
    manifest_path = os.path.join(root, "manifest.json")
    manifest = json.load(open(manifest_path, encoding="utf-8"))
    late = manifest["shards"][97]
    if damage == "receipt":
        os.remove(os.path.join(root, late["dir"], "shard.json"))
    elif damage == "lmdb":
        os.remove(os.path.join(root, late["lmdb"]))
    elif damage == "count":
        late["n_records"] = 4
        manifest["n_records"] += 1
    elif damage == "policy":
        late["coordinate_slots_per_record"] = 4
    elif damage == "unassigned":
        meta = json.load(open(sp, encoding="utf-8"))
        meta["train"] = [x for x in meta["train"] if x != late["lmdb"]]
        io_utils.atomic_write_json(sp, meta)
    io_utils.atomic_write_json(manifest_path, manifest)
    p = _pre(pre_general, sp, "--lipid-shards", "4")
    assert p.returncode == 1 and msg in p.stdout, p.stdout


def test_p1_pre_holds_at_most_one_lmdb_open(tmp_path, pre_general, monkeypatch):
    sys.path.insert(0, TOOLS_DIR)
    import check_continual_data

    sp = make_synthetic_lipid(str(tmp_path / "lipid"), 150)
    tracker = EnvTracker(lmdb.open)
    monkeypatch.setattr(lmdb, "open", tracker)
    assert check_continual_data.main(["--general", pre_general, "--lipid-splits", sp]) == 0
    assert tracker.peak == 1 and tracker.current == 0
    assert tracker.total >= 150 + 150                # every shard counted, every sampled shard read
