"""Building blocks, enumeration, conformers, LMDB writing, dedup, splits and validation."""
import gzip
import json
import os
import sys

import pytest

TESTS_DIR = os.path.dirname(os.path.abspath(__file__))
PRETRAIN_DIR = os.path.dirname(TESTS_DIR)
if PRETRAIN_DIR not in sys.path:
    sys.path.insert(0, PRETRAIN_DIR)

import lipid_fixtures as lf  # noqa: E402
from lipid_library import building_blocks, conformers, dedup, enumerate_library, io_utils, splits  # noqa: E402

pytest.importorskip("rdkit")
pytest.importorskip("lmdb")


# --------------------------------------------------------------------------- building blocks
def test_xlsx_reader_matches_the_csv_reader(tmp_path):
    xlsx = lf.write_sheet_xlsx(str(tmp_path / "sheet.xlsx"))
    csv_path = lf.write_sheet_csv(str(tmp_path / "sheet.csv"))
    rows_x, meta_x = building_blocks.read_table(xlsx)
    rows_c, meta_c = building_blocks.read_table(csv_path)
    assert meta_x["sheet_names"] == ["Sheet1"] and meta_x["sheet_used"] == "Sheet1"
    assert meta_x["columns"] == meta_c["columns"] == ["ID", "SMILES", "Category"]
    strip = lambda rows: [{k: v for k, v in r.items() if k != "__row__"} for r in rows]  # noqa: E731
    assert strip(rows_x) == strip(rows_c)


def test_missing_column_is_rejected(tmp_path):
    p = tmp_path / "bad.csv"
    p.write_text("ID,SMILES\nA1,CCN\n", encoding="utf-8")
    with pytest.raises(SystemExit):
        building_blocks.read_table(str(p))


def test_unknown_sheet_is_rejected(tmp_path):
    xlsx = lf.write_sheet_xlsx(str(tmp_path / "sheet.xlsx"))
    with pytest.raises(KeyError):
        building_blocks.read_table(xlsx, sheet="NoSuchSheet")


def test_validation_accepts_the_mini_sheet(tmp_path):
    summary = lf.build_building_blocks(str(tmp_path / "bb"))
    assert summary["counts_per_role"] == {"amine": 2, "isocyanide": 2, "aldehyde": 2, "acid": 2}
    assert summary["n_combinations"] == 16
    assert summary["n_rejected"] == 0


def test_validation_rejects_every_bad_row_with_its_reason(tmp_path):
    summary = lf.build_building_blocks(str(tmp_path / "bb"), include_bad=True)
    reasons = {r["id"]: r["reason"] for r in summary["rejected"]}
    assert "cannot parse" in reasons["B9"]
    assert "not eligible as acid" in reasons["D9"]
    assert "duplicate ID" in reasons["A1"]
    assert "duplicate structure" in reasons["A9"]
    assert "unknown Category" in reasons["X9"]
    assert "empty SMILES" in reasons["Y9"]
    assert summary["counts_per_role"] == {"amine": 2, "isocyanide": 2, "aldehyde": 2, "acid": 2}


def test_building_block_order_is_deterministic_and_contiguous(tmp_path):
    first = tmp_path / "a"
    second = tmp_path / "b"
    lf.build_building_blocks(str(first))
    lf.build_building_blocks(str(second))
    a = (first / "building_blocks.csv").read_text(encoding="utf-8")
    b = (second / "building_blocks.csv").read_text(encoding="utf-8")
    assert a == b
    by_role = building_blocks.load_building_blocks(str(first / "building_blocks.csv"))
    for role, rows in by_role.items():
        assert [r["role_index"] for r in rows] == list(range(len(rows)))


def test_real_sheet_expectations_are_recorded():
    """The specification's counts are in the code, so a mismatch is reported."""
    assert building_blocks.EXPECTED_COUNTS == {"amine": 64, "isocyanide": 62,
                                              "aldehyde": 64, "acid": 61}
    product = 1
    for v in building_blocks.EXPECTED_COUNTS.values():
        product *= v
    assert product == 15491072


# --------------------------------------------------------------------------- enumeration
def test_combination_space_is_a_bijection(tmp_path):
    bb = str(tmp_path / "bb")
    lf.build_building_blocks(bb)
    by_role = building_blocks.load_building_blocks(os.path.join(bb, "building_blocks.csv"))
    space = enumerate_library.CombinationSpace(by_role)
    assert space.total == 16
    seen = set()
    for i in range(space.total):
        rows = space.decode(i)
        key = tuple(r["id"] for r in rows)
        assert key not in seen
        seen.add(key)
        assert space.encode([r["role_index"] for r in rows]) == i
    with pytest.raises(IndexError):
        space.decode(space.total)


def test_chunk_bounds_cover_the_range_exactly():
    chunks = enumerate_library.chunk_bounds(10, 4)
    assert chunks == [(0, 4), (4, 8), (8, 10)]
    shard0 = enumerate_library.chunk_bounds(10, 4, shard=0, num_shards=2)
    shard1 = enumerate_library.chunk_bounds(10, 4, shard=1, num_shards=2)
    assert sorted(shard0 + shard1) == chunks


def test_enumeration_is_restartable_and_byte_identical(tmp_path):
    bb = str(tmp_path / "bb")
    lf.build_building_blocks(bb)
    out = str(tmp_path / "products")
    lf.build_products(bb, out, limit=16, chunk_size=8)
    first = (open(os.path.join(out, "products", "products-0-8.csv.gz"), "rb").read())
    receipt = json.load(open(os.path.join(out, "products", "products-0-8.done.json"), encoding="utf-8"))
    assert receipt["n_products"] == 8 and receipt["n_failures"] == 0
    assert receipt["products_sha256"] == io_utils.sha256_file(
        os.path.join(out, "products", "products-0-8.csv.gz"))
    # a second run skips completed chunks
    assert enumerate_library.main([bb, "-o", out, "--limit", "16", "--chunk-size", "8"]) == 0
    assert open(os.path.join(out, "products", "products-0-8.csv.gz"), "rb").read() == first
    # --force regenerates byte-identically (determinism)
    assert enumerate_library.main([bb, "-o", out, "--limit", "16", "--chunk-size", "8", "--force"]) == 0
    assert open(os.path.join(out, "products", "products-0-8.csv.gz"), "rb").read() == first


def test_a_corrupted_chunk_is_regenerated(tmp_path):
    bb = str(tmp_path / "bb")
    lf.build_building_blocks(bb)
    out = str(tmp_path / "products")
    lf.build_products(bb, out, limit=8, chunk_size=8)
    path = os.path.join(out, "products", "products-0-8.csv.gz")
    with open(path, "ab") as fh:
        fh.write(b"corrupt")
    assert not enumerate_library.chunk_is_complete(out, 0, 8)
    assert enumerate_library.main([bb, "-o", out, "--limit", "8", "--chunk-size", "8"]) == 0
    assert enumerate_library.chunk_is_complete(out, 0, 8)


def test_sharded_enumeration_covers_the_same_products(tmp_path):
    bb = str(tmp_path / "bb")
    lf.build_building_blocks(bb)
    whole, parts = str(tmp_path / "whole"), str(tmp_path / "parts")
    lf.build_products(bb, whole, limit=16, chunk_size=4)
    for shard in range(2):
        assert enumerate_library.main([bb, "-o", parts, "--limit", "16", "--chunk-size", "4",
                                       "--shard", str(shard), "--num-shards", "2"]) == 0
    from lipid_library.lmdb_writer import iter_products

    assert (sorted(r["product_smiles"] for r in iter_products(whole))
            == sorted(r["product_smiles"] for r in iter_products(parts)))


# --------------------------------------------------------------------------- conformers
def test_conformer_record_has_lumi_slot_layout():
    record, stats = conformers.smi2coords_pretrain("CCCCCCCC(=O)NC", n_3d=3, store_2d=True,
                                                   max_try=5, max_iteration=200)
    assert len(record["coordinates"]) == 4 == stats["n_coordinate_slots"]
    assert stats["stored_2d"] is True
    assert stats["n_3d_success"] + stats["n_2d_filled"] == 3
    assert len(stats["is_3d"]) == 4 and stats["is_3d"][-1] is False
    n_atoms = len(record["atoms"])
    for c in record["coordinates"]:
        assert c.shape == (n_atoms, 3) and str(c.dtype) == "float32"


def test_no_stored_2d_option_gives_only_3d_slots():
    record, stats = conformers.smi2coords_pretrain("CCO", n_3d=2, store_2d=False,
                                                   max_try=5, max_iteration=200)
    assert len(record["coordinates"]) == 2 and stats["stored_2d"] is False


def test_2d_coordinates_are_flat_and_3d_are_not():
    import numpy as np

    twod = conformers.smi2_2Dcoords("CCCCCCCC=O")
    assert float(np.abs(twod[:, 2]).max()) == 0.0
    threed, stats = conformers.smi2_3Dcoords("CCCCCCCC=O", cnt=2, max_try=5, max_iteration=200)
    assert stats["n_3d_success"] >= 1
    assert float(np.abs(threed[0][:, 2]).max()) > 0.0


def test_3d_conformers_are_not_assumed_distinct():
    coords, stats = conformers.smi2_3Dcoords("CCO", cnt=5, max_try=10, max_iteration=200)
    assert conformers.n_distinct(coords) <= len(coords)
    assert conformers.n_distinct([coords[0], coords[0].copy()]) == 1


def test_oversized_molecule_uses_2d_only_like_lumi():
    long_chain = "C" * 450
    record, stats = conformers.smi2coords_pretrain(long_chain, n_3d=2, store_2d=True,
                                                   max_try=2, max_iteration=50,
                                                   max_atoms_for_3d=400)
    assert stats["oversized"] is True
    assert stats["n_3d_success"] == 0 and stats["n_2d_filled"] == 2
    assert all(f is False for f in stats["is_3d"])
    assert len(record["coordinates"]) == 3


def test_unparsable_smiles_raises():
    with pytest.raises(conformers.ConformerError):
        conformers.smi2coords_pretrain("C1CC", n_3d=1, max_try=2, max_iteration=50)


# --------------------------------------------------------------------------- LMDB writing
def test_lmdb_is_heart_compatible(tmp_path):
    paths = lf.full_lipid_pipeline(str(tmp_path), limit=8, n_3d=2)
    manifest = json.load(open(os.path.join(paths["lmdb_dir"], "manifest.json"), encoding="utf-8"))
    assert manifest["n_records"] == 8 and manifest["n_shards"] == 2
    assert manifest["key_convention"].startswith("contiguous ASCII integers")
    assert manifest["record_keys"] == ["smi", "atoms", "coordinates"]

    import lmdb
    import pickle

    lmdb_path = os.path.join(paths["lmdb_dir"], manifest["shards"][0]["lmdb"])
    env = lmdb.open(lmdb_path, subdir=False, readonly=True, lock=False)
    with env.begin() as txn:
        n = txn.stat()["entries"]
        keys = sorted(k.decode() for k in txn.cursor().iternext(values=False))
        assert keys == sorted(str(i) for i in range(n))
        rec = pickle.loads(txn.get(b"0"))
    env.close()
    assert sorted(rec) == ["atoms", "coordinates", "smi"]      # no 'target'
    assert len(rec["coordinates"]) == 3                        # 2 3D + 1 stored 2D


def test_lmdb_dataset_of_heart_reads_the_shard(unimol_pkg, tmp_path):
    # unimol imported through --user-dir (conftest), exactly as unicore-train does
    from unimol.data import LMDBDataset

    paths = lf.full_lipid_pipeline(str(tmp_path), limit=8, n_3d=2)
    manifest = json.load(open(os.path.join(paths["lmdb_dir"], "manifest.json"), encoding="utf-8"))
    ds = LMDBDataset(os.path.join(paths["lmdb_dir"], manifest["shards"][0]["lmdb"]))
    assert len(ds) == 4
    rec = ds[0]
    assert len(rec["atoms"]) == rec["coordinates"][0].shape[0]


def test_writer_rejects_unsupported_atoms_and_oversized_records(tmp_path):
    """A record whose atoms are outside dict.txt is skipped and reported, not mapped."""
    from lipid_library import lmdb_writer

    products_dir = str(tmp_path / "products")
    os.makedirs(os.path.join(products_dir, "products"))
    w = io_utils.AtomicGzCsvWriter(
        os.path.join(products_dir, "products", "products-0-3.csv.gz"), enumerate_library.PRODUCT_FIELDS)
    rows = [
        (0, "A1-B1-C1-D1", "CCCCCCCC(=O)N(C)C(C)C(=O)NC"),         # 17 heavy atoms: kept
        (1, "A1-B1-C1-D2", "CCCCCCCC(=O)N(C)C(C)C(=O)NC[Zr]"),     # Zr is not in dict.txt
        (2, "A1-B1-C2-D1", "C" * 60),                              # 60 heavy > --max-atoms 40
    ]
    for idx, combo, smi in rows:
        w.writerow([idx, combo, "A1", "B1", "C1", "D1", smi, 0, 0, 0, 1])
    w.close()
    out = str(tmp_path / "lmdb")
    rc = lmdb_writer.main([products_dir, "-o", out, "--records-per-shard", "10", "--n-3d", "1",
                           "--max-try", "3", "--max-iterations", "100", "--map-size-gb", "0.25",
                           "--dict", lf.DICT_FIXTURE, "--max-atoms", "40", "--only-polar", "0",
                           "--store-2d"])
    assert rc == 0
    receipt = json.load(open(os.path.join(out, "shard-00000", "shard.json"), encoding="utf-8"))
    assert receipt["n_records"] == 1
    assert receipt["n_skipped"] == 2
    assert receipt["unsupported_atoms"] == {"Zr": 1}
    reasons = " ".join(receipt["skip_reasons"])
    assert "not in dict.txt" in reasons and "--max-atoms" in reasons


def test_shard_is_skipped_when_complete_and_rebuilt_when_corrupted(tmp_path):
    from lipid_library import lmdb_writer

    paths = lf.full_lipid_pipeline(str(tmp_path), limit=4, n_3d=1)
    out = paths["lmdb_dir"]
    assert lmdb_writer.shard_is_complete(out, 0)
    lmdb_path = os.path.join(out, "shard-00000", "train.lmdb")
    with open(lmdb_path, "ab") as fh:
        fh.write(b"\0")
    assert not lmdb_writer.shard_is_complete(out, 0)


# --------------------------------------------------------------------------- dedup
def test_dedup_finds_duplicate_products(tmp_path):
    from lipid_library import lmdb_writer

    products_dir = str(tmp_path / "products")
    os.makedirs(os.path.join(products_dir, "products"))
    w = io_utils.AtomicGzCsvWriter(
        os.path.join(products_dir, "products", "products-0-4.csv.gz"), enumerate_library.PRODUCT_FIELDS)
    for idx, smi in [(0, "CCO"), (1, "CCN"), (2, "CCO"), (3, "CCO")]:
        w.writerow([idx, "combo%d" % idx, "A1", "B1", "C1", "D1", smi, 0, 0, 0, 1])
    w.close()
    out = str(tmp_path / "dedup")
    summary = dedup.run(products_dir, out)
    assert summary == {"n_product_rows": 4, "n_unique_products": 2, "n_duplicate_rows": 2,
                       "n_duplicate_groups": 1, "n_chunks": 1}
    drops = dedup.load_drop_set(os.path.join(out, "drop_combo_indexes.csv.gz"))
    assert drops == [2, 3]                      # the lowest index of the group is kept
    rows = list(io_utils.read_gz_csv(os.path.join(out, "duplicates.csv.gz")))
    assert {r["kept_combo_index"] for r in rows} == {"0"}


def test_drop_list_is_honoured_by_the_writer(tmp_path):
    """The drop list must come from dedup of THIS enumeration (provenance), then it is honoured."""
    from lipid_library import lmdb_writer, provenance

    bb = str(tmp_path / "bb")
    lf.build_building_blocks(bb)
    products = str(tmp_path / "products")
    lf.build_products(bb, products, limit=8, chunk_size=8)
    drop_dir = str(tmp_path / "drops")
    os.makedirs(drop_dir)
    w = io_utils.AtomicGzCsvWriter(os.path.join(drop_dir, "drop.csv.gz"), ["combo_index"])
    for i in (1, 3, 5):
        w.writerow([i])
    w.close()
    argv = [products, "-o", str(tmp_path / "lmdb"), "--records-per-shard", "100", "--n-3d", "1",
            "--max-try", "3", "--max-iterations", "100", "--map-size-gb", "0.25", "--store-2d",
            "--drop-list", os.path.join(drop_dir, "drop.csv.gz")]
    # REGRESSION P0-2: a drop list without provenance for this enumeration is refused
    with pytest.raises(SystemExit, match="re-run dedup"):
        lmdb_writer.main(argv)
    enum_fp = provenance.read_config(products, "enumeration")["fingerprint"]
    io_utils.atomic_write_json(os.path.join(drop_dir, "summary.json"), {"enumeration_fingerprint": enum_fp})
    argv[2] = str(tmp_path / "lmdb2")
    assert lmdb_writer.main(argv) == 0
    rows = list(io_utils.read_gz_csv(os.path.join(argv[2], "shard-00000", "records.csv.gz")))
    assert [int(r["combo_index"]) for r in rows] == [0, 2, 4, 6, 7]
    manifest = json.load(open(os.path.join(argv[2], "manifest.json"), encoding="utf-8"))
    assert manifest["complete"] and manifest["n_input_rows"] == 5      # 8 products - 3 dropped


# --------------------------------------------------------------------------- splits + validation
def test_splits_assign_whole_shards_without_overlap(tmp_path):
    paths = lf.full_lipid_pipeline(str(tmp_path), limit=8, n_3d=1)
    data = json.load(open(paths["splits"], encoding="utf-8"))
    assert set(data["train"]).isdisjoint(data["valid"])
    # v2 review P1: the valid shard is drawn (seeded), no longer always the last one
    assert sorted(data["shard_ids"]["train"] + data["shard_ids"]["valid"]) == [0, 1]
    assert len(data["shard_ids"]["valid"]) == 1
    assert data["shard_ids"]["valid"] == splits.select_valid_shards([0, 1], 1, seed=1)
    assert data["split_method"] == "stratified-random" and data["split_seed"] == 1
    train, _ = splits.load_splits(paths["splits"], "train")
    valid, _ = splits.load_splits(paths["splits"], "valid")
    assert len(train) == len(valid) == 1
    assert all(os.path.isfile(p) for p in train + valid)


def test_single_shard_split_requires_explicit_smoke_overlap(tmp_path):
    bb = str(tmp_path / "bb")
    lf.build_building_blocks(bb)
    products = str(tmp_path / "products")
    lf.build_products(bb, products, limit=4, chunk_size=4)
    out = str(tmp_path / "lmdb")
    lf.build_lipid_lmdbs(products, out, records_per_shard=100, limit=4, n_3d=1)   # passes the flag
    data = json.load(open(os.path.join(out, "splits.json"), encoding="utf-8"))
    assert data["warnings"] and data["smoke"] is True
    # REGRESSION (finalization safety): without the flag a single shard is refused
    with pytest.raises(SystemExit, match="overlap"):
        splits.main([out, "--allow-smoke"])
    assert not os.path.exists(os.path.join(out, "splits.json")), "a refused split must not leave splits.json"


def test_validate_lmdb_passes_and_detects_problems(tmp_path):
    from lipid_library import validate_lmdb

    paths = lf.full_lipid_pipeline(str(tmp_path), limit=8, n_3d=2)
    assert validate_lmdb.main(["--splits", paths["splits"], "--split", "train",
                               "--dict", lf.DICT_FIXTURE, "--all", "--expect-slots", "3"]) == 0
    # a wrong expected slot count is reported as a problem
    assert validate_lmdb.main(["--splits", paths["splits"], "--split", "train",
                               "--all", "--expect-slots", "11"]) == 1
    # reports the training-time count (one more, added by Add2DConformerDataset)
    train, _ = splits.load_splits(paths["splits"], "train")
    result = validate_lmdb.check_lmdb(train[0], check_all=True)
    assert result["slot_counts"] == {"3": 4}
    assert result["slots_at_training_time"] == {"4": 4}
    assert result["problems"] == []


def test_validate_lmdb_rejects_smiles_keys(tmp_path):
    from lipid_library import validate_lmdb

    path = lf.write_smiles_keyed_lmdb(str(tmp_path / "smiles.lmdb"))
    result = validate_lmdb.check_lmdb(path, check_all=True)
    assert any("contiguous" in p or "not ASCII integers" in p for p in result["problems"])


# --------------------------------------------------------------------------- added in the resumed session
def test_seed_start_zero_reproduces_lumi_duplicate_and_one_avoids_it():
    """RDKit ETKDG seed 0 == seed 1, so LUMI's seed sequence 0,1,... duplicates slot 0/1."""
    smi = "CCCCCCCCN(C)CC(=O)NCCCC"
    lumi, _ = conformers.smi2_3Dcoords(smi, cnt=3, max_try=5, max_iteration=200, seed_start=0)
    shifted, _ = conformers.smi2_3Dcoords(smi, cnt=3, max_try=5, max_iteration=200, seed_start=1)
    assert conformers.n_distinct(lumi[:2]) == 1
    assert conformers.n_distinct(shifted) == 3
    assert (lumi[1] == shifted[0]).all()          # the same seed sequence, shifted by one


def test_shard_lmdb_is_compacted(tmp_path):
    paths = lf.full_lipid_pipeline(str(tmp_path), limit=4, n_3d=1)
    lmdb_path = os.path.join(paths["lmdb_dir"], "shard-00000", "train.lmdb")
    # --map-size-gb 0.25 would be a 256 MiB file without compaction
    assert os.path.getsize(lmdb_path) < 4 * 1024 * 1024
    assert not os.path.exists(lmdb_path + ".partial")
    assert not os.path.exists(lmdb_path + ".compact")


def _writer_common(products, out, rps):
    return [products, "-o", out, "--records-per-shard", str(rps), "--n-3d", "1", "--max-try", "3",
            "--max-iterations", "100", "--map-size-gb", "0.25", "--store-2d"]


def _full_products(tmp_path, chunk_size=8):
    bb = str(tmp_path / "bb")
    lf.build_building_blocks(bb)
    products = str(tmp_path / "products")
    lf.build_products(bb, products, chunk_size=chunk_size)        # all 16 combinations: not smoke
    return bb, products


def test_interrupted_array_cannot_be_finalised(tmp_path):
    """REGRESSION P0-1: a partial array must not yield a usable manifest/splits."""
    from lipid_library import lmdb_writer

    _, products = _full_products(tmp_path)
    out = str(tmp_path / "lmdb")
    common = _writer_common(products, out, 4)
    assert lmdb_writer.main(common + ["--partition"]) == 0          # stage 03b (v2 review P1)
    # only array task 0 of 2 ran: shards 0 and 2 exist, 1 and 3 are missing
    assert lmdb_writer.main(common + ["--shard", "0", "--num-shards", "2"]) == 0
    assert not os.path.exists(os.path.join(out, "manifest.json")), "array tasks must not write the manifest"
    assert lmdb_writer.main(common + ["--finalize", "--array-size", "2"]) == 1
    report = json.load(open(os.path.join(out, "finalize_report.json"), encoding="utf-8"))
    assert report["complete"] is False and report["missing_shards"] == [1, 3]
    assert report["resubmit_array_tasks"] == [1]
    assert not os.path.exists(os.path.join(out, "manifest.json"))
    with pytest.raises(SystemExit, match="no manifest"):
        splits.main([out])
    # a stale manifest from an earlier attempt is removed, not left usable
    io_utils.atomic_write_json(os.path.join(out, "manifest.json"), {"complete": True, "shards": []})
    assert lmdb_writer.main(common + ["--finalize"]) == 1
    assert not os.path.exists(os.path.join(out, "manifest.json"))
    # the remaining task completes the array; finalize now reconciles every count
    assert lmdb_writer.main(common + ["--shard", "1", "--num-shards", "2"]) == 0
    assert lmdb_writer.main(common + ["--finalize"]) == 0
    manifest = json.load(open(os.path.join(out, "manifest.json"), encoding="utf-8"))
    assert manifest["complete"] is True and manifest["smoke"] is False
    assert [x["shard_id"] for x in manifest["shards"]] == [0, 1, 2, 3]
    assert manifest["n_input_rows"] == 16 == manifest["n_records"] + manifest["n_skipped"]
    assert splits.main([out]) == 0
    # a re-queued array task skips its verified shards
    assert lmdb_writer.main(common + ["--shard", "0", "--num-shards", "2"]) == 0


def test_finalize_detects_an_unexpected_extra_shard(tmp_path):
    from lipid_library import lmdb_writer

    _, products = _full_products(tmp_path, 16)
    out = str(tmp_path / "lmdb")
    common = _writer_common(products, out, 8)
    assert lmdb_writer.main(common) == 0
    os.makedirs(os.path.join(out, "shard-00007"))
    assert lmdb_writer.main(common + ["--finalize"]) == 1
    report = json.load(open(os.path.join(out, "finalize_report.json"), encoding="utf-8"))
    assert report["extra_shards"] == [7]


def test_finalize_detects_a_count_mismatch(tmp_path):
    """records + skipped must equal the shard's input rows."""
    from lipid_library import lmdb_writer

    _, products = _full_products(tmp_path, 16)
    out = str(tmp_path / "lmdb")
    common = _writer_common(products, out, 8)
    assert lmdb_writer.main(common) == 0
    rp = os.path.join(out, "shard-00001", "shard.json")
    r = json.load(open(rp, encoding="utf-8"))
    r["n_records"] -= 1
    io_utils.atomic_write_json(rp, r)
    assert lmdb_writer.main(common + ["--finalize"]) == 1
    report = json.load(open(os.path.join(out, "finalize_report.json"), encoding="utf-8"))
    assert any("!= input rows" in x for x in report["problems"])


def test_validate_max_atoms_follows_the_hydrogen_policy(tmp_path):
    from lipid_library import validate_lmdb

    paths = lf.full_lipid_pipeline(str(tmp_path), limit=4, n_3d=1)
    lmdb_path = os.path.join(paths["lmdb_dir"], "shard-00000", "train.lmdb")
    r0 = validate_lmdb.check_lmdb(lmdb_path, check_all=True, max_atoms=40, only_polar=0)
    r1 = validate_lmdb.check_lmdb(lmdb_path, check_all=True, max_atoms=40, only_polar=-1)
    assert r0["max_n_atoms_after_h_policy"] < r0["max_n_atoms"]
    assert not any("--max-atoms" in p for p in r0["problems"])     # heavy atoms <= 40
    assert any("--max-atoms" in p for p in r1["problems"])         # with H > 40


def test_review_products_checks_every_reagent(tmp_path):
    from lipid_library import review_products

    bb = str(tmp_path / "bb")
    lf.build_building_blocks(bb)
    products = str(tmp_path / "products")
    lf.build_products(bb, products, limit=16, chunk_size=16)
    out = str(tmp_path / "review")
    assert review_products.main([bb, "-o", out, "--products-dir", products, "--every-reagent",
                                 "--first", "4"]) == 0
    summary = json.load(open(os.path.join(out, "summary.json"), encoding="utf-8"))
    assert summary["per_group"]["every_reagent"] == 8
    assert summary["n_core_ok"] == summary["n_formula_ok"] == summary["n_reviewed"]
    assert summary["enumeration_output_compared"] >= 4
    assert summary["enumeration_output_compared"] == summary["enumeration_output_identical"]
    assert summary["n_lumi_different"] == 0 and summary["failures"] == []
    assert os.path.getsize(os.path.join(out, "review.svg")) > 1000
