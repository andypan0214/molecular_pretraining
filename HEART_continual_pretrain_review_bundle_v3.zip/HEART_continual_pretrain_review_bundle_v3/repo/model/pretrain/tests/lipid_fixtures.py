"""Helpers that build tiny lipid-pipeline fixtures for the continual tests.

Plain functions rather than pytest fixtures, so the existing conftest.py is
not modified. Everything is written into a pytest tmp_path; no real data,
checkpoint or LMDB is touched.
"""
import os
import pickle
import sys

TESTS_DIR = os.path.dirname(os.path.abspath(__file__))
PRETRAIN_DIR = os.path.dirname(TESTS_DIR)
MODEL_ROOT = os.path.dirname(PRETRAIN_DIR)
if PRETRAIN_DIR not in sys.path:
    sys.path.insert(0, PRETRAIN_DIR)          # so `import lipid_library` works
DICT_FIXTURE = os.path.join(PRETRAIN_DIR, "tests", "fixtures", "dict.txt")

# Four tiny reagents per role: enough for 2x2x2x2 = 16 combinations.
MINI_SHEET = [
    ("A1", "CN(C)CCN", "Amines"),
    ("A2", "NCCN1CCOCC1", "Amines"),
    ("B1", "[C-]#[N+]C", "Isocyanides"),
    ("B2", "[C-]#[N+]C1CCCC1", "Isocyanides"),
    ("C1", "CCCCCC=O", "Lipid Aldehydes"),
    ("C2", "CCCCCCCC=O", "Lipid Aldehydes"),
    ("D1", "CCCCCCCC(=O)O", "Lipid Carboxylic Acids"),
    ("D2", "CN(C)CC(=O)O", "Lipid Carboxylic Acids"),
]
# Rows that must be rejected, with the reason each one exercises.
BAD_ROWS = [
    ("B9", "[C-]#[N+]C1(C[C@@H]2C3)C[C@@H]3C[C@@H](C2)", "Isocyanides"),   # unclosed ring (as in the real sheet)
    ("D9", "CCCCCCCC(=O)OC", "Lipid Carboxylic Acids"),                     # ester, not an acid
    ("A1", "CCN", "Amines"),                                                # duplicate ID
    ("A9", "CN(C)CCN", "Amines"),                                           # duplicate structure of A1
    ("X9", "CCO", "Unknown Category"),                                      # unknown category
    ("Y9", "", "Amines"),                                                   # empty SMILES
]


def write_sheet_csv(path, rows=MINI_SHEET, include_bad=False):
    lines = ["ID,SMILES,Category"]
    for rid, smi, cat in list(rows) + (list(BAD_ROWS) if include_bad else []):
        lines.append("{},{},{}".format(rid, smi, cat))
    with open(path, "w", encoding="utf-8", newline="\n") as fh:
        fh.write("\n".join(lines) + "\n")
    return path


def write_sheet_xlsx(path, rows=MINI_SHEET, sheet_name="Sheet1"):
    """Minimal .xlsx with shared strings, to exercise io_utils.read_xlsx_rows."""
    import zipfile

    header = ["ID", "SMILES", "Category"]
    table = [header] + [[r[0], r[1], r[2]] for r in rows]
    shared, index = [], {}
    for row in table:
        for cell in row:
            if cell not in index:
                index[cell] = len(shared)
                shared.append(cell)

    def col(i):
        return chr(ord("A") + i)

    sheet_rows = []
    for r, row in enumerate(table, start=1):
        cells = "".join(
            '<c r="{}{}" t="s"><v>{}</v></c>'.format(col(c), r, index[v]) for c, v in enumerate(row))
        sheet_rows.append('<row r="{}">{}</row>'.format(r, cells))
    ns = 'xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"'
    rel_ns = 'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"'
    with zipfile.ZipFile(path, "w") as z:
        z.writestr("[Content_Types].xml",
                   '<?xml version="1.0"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
                   '<Default Extension="xml" ContentType="application/xml"/>'
                   '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
                   '</Types>')
        z.writestr("_rels/.rels",
                   '<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                   '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument"'
                   ' Target="xl/workbook.xml"/></Relationships>')
        z.writestr("xl/workbook.xml",
                   '<?xml version="1.0"?><workbook {} {}><sheets><sheet name="{}" sheetId="1" r:id="rId1"/>'
                   '</sheets></workbook>'.format(ns, rel_ns, sheet_name))
        z.writestr("xl/_rels/workbook.xml.rels",
                   '<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                   '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet"'
                   ' Target="worksheets/sheet1.xml"/><Relationship Id="rId2"'
                   ' Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings"'
                   ' Target="sharedStrings.xml"/></Relationships>')
        z.writestr("xl/worksheets/sheet1.xml",
                   '<?xml version="1.0"?><worksheet {}><sheetData>{}</sheetData></worksheet>'.format(
                       ns, "".join(sheet_rows)))
        z.writestr("xl/sharedStrings.xml",
                   '<?xml version="1.0"?><sst {} count="{}" uniqueCount="{}">{}</sst>'.format(
                       ns, len(shared), len(shared),
                       "".join("<si><t>{}</t></si>".format(s) for s in shared)))
    return path


def build_building_blocks(out_dir, include_bad=False):
    """Run the building-block stage on the mini sheet. Returns its summary dict."""
    from lipid_library import building_blocks

    os.makedirs(out_dir, exist_ok=True)
    csv_path = write_sheet_csv(os.path.join(out_dir, "sheet.csv"), include_bad=include_bad)
    rows, meta = building_blocks.read_table(csv_path)
    accepted, rejected = building_blocks.validate_rows(rows)
    summary = building_blocks.build_summary(accepted, rejected, meta)
    building_blocks.write_outputs(out_dir, accepted, rejected, summary)
    return summary


def build_products(bb_dir, out_dir, limit=None, chunk_size=8):
    from lipid_library import enumerate_library

    argv = [bb_dir, "-o", out_dir, "--chunk-size", str(chunk_size)]
    if limit is not None:
        argv += ["--limit", str(limit)]
    assert enumerate_library.main(argv) == 0
    return out_dir


def build_lipid_lmdbs(products_dir, out_dir, records_per_shard=4, limit=8, n_3d=2,
                      store_2d=True, extra_argv=()):
    """Small lipid LMDB set: fast conformers (n_3d=2) but the same code path."""
    from lipid_library import lmdb_writer, splits

    argv = [products_dir, "-o", out_dir, "--records-per-shard", str(records_per_shard),
            "--n-3d", str(n_3d), "--max-try", "5", "--max-iterations", "200",
            "--map-size-gb", "0.25", "--dict", DICT_FIXTURE]
    if limit is not None:
        argv += ["--limit", str(limit)]
    argv.append("--store-2d" if store_2d else "--no-store-2d")
    argv.extend(extra_argv)
    assert lmdb_writer.main(argv) == 0
    split_argv = [out_dir, "--valid-shards", "1", "--allow-smoke"]
    if records_per_shard >= (limit or 0):
        split_argv.append("--allow-smoke-overlap")      # a single shard: smoke-only overlap
    assert splits.main(split_argv) == 0
    return os.path.join(out_dir, "splits.json")


def full_lipid_pipeline(root, limit=8, n_3d=2, store_2d=True):
    """building blocks -> products -> LMDB shards -> splits.json. Returns paths."""
    bb = os.path.join(root, "bb")
    products = os.path.join(root, "products")
    lmdbs = os.path.join(root, "lmdb")
    summary = build_building_blocks(bb)
    build_products(bb, products, limit=limit)
    splits_path = build_lipid_lmdbs(products, lmdbs, limit=limit, n_3d=n_3d, store_2d=store_2d)
    return {"bb_dir": bb, "products_dir": products, "lmdb_dir": lmdbs,
            "splits": splits_path, "bb_summary": summary}


def write_general_lmdb_dir(out_dir, n_3d=2, store_2d=True, n_train=6, n_valid=2):
    """A stand-in 'general' dataset with the same record layout as the lipid one.

    Built from the existing synthetic 8-SMILES fixture molecules so the mixed
    loader can be tested without the real 150 GB Uni-Mol ligand LMDB.
    """
    import lmdb
    import shutil

    from lipid_library.conformers import smi2coords_pretrain

    sys.path.insert(0, os.path.join(PRETRAIN_DIR, "tools"))
    import make_fixture_lmdb

    os.makedirs(out_dir, exist_ok=True)
    smiles = [smi for _, smi in make_fixture_lmdb.TEST_SMILES if smi != "C1CC"]
    records = []
    for smi in smiles:
        record, _ = smi2coords_pretrain(smi, n_3d=n_3d, store_2d=store_2d,
                                        max_try=5, max_iteration=200)
        records.append(record)
    splits = {"train": records[:n_train], "valid": records[n_train:n_train + n_valid]}
    for split, items in splits.items():
        path = os.path.join(out_dir, split + ".lmdb")
        for p in (path, path + "-lock"):
            if os.path.exists(p):
                os.remove(p)
        env = lmdb.open(path, map_size=64 * 1024 * 1024, subdir=False)
        with env.begin(write=True) as txn:
            for i, item in enumerate(items):
                txn.put(str(i).encode("ascii"), pickle.dumps(item, protocol=4))
        env.close()
    shutil.copyfile(DICT_FIXTURE, os.path.join(out_dir, "dict.txt"))
    return {"dir": out_dir, "n_train": len(splits["train"]), "n_valid": len(splits["valid"])}


def write_smiles_keyed_lmdb(path, n=3):
    """An LMDB with LUMI's SMILES keys, which the mixed loader must reject."""
    import lmdb

    from lipid_library.conformers import smi2coords_pretrain

    for p in (path, path + "-lock"):
        if os.path.exists(p):
            os.remove(p)
    env = lmdb.open(path, map_size=16 * 1024 * 1024, subdir=False)
    with env.begin(write=True) as txn:
        for smi in ["CCO", "CCN", "CCC"][:n]:
            record, _ = smi2coords_pretrain(smi, n_3d=1, store_2d=True, max_try=3, max_iteration=100)
            txn.put(smi.encode("ascii"), pickle.dumps(record, protocol=4))
    env.close()
    return path
