"""Regression tests for HEART_continual_independent_review.md (2026-11-04).

Each test reproduces one reviewed defect on tiny synthetic data and asserts the
fail-closed behaviour now in place. Section tags: P0-1 incomplete dataset,
P0-2 stale outputs, P1-2D slot policy, P1-sizing, P1-chemistry, P1-H200,
REC-* additional recommendations.
"""
import json
import math
import os
import re
import subprocess
import sys

import pytest

from conftest import MODEL_ROOT, SCRIPTS_DIR, TOOLS_DIR, find_bash

import lipid_fixtures as lf
from lipid_library import (building_blocks, enumerate_library, io_utils, lmdb_writer, provenance,
                           splits, ugi, validate_lmdb)

pytest.importorskip("rdkit")
pytest.importorskip("lmdb")
BASH = find_bash()
needs_bash = pytest.mark.skipif(BASH is None, reason="bash not available")
REPO_ROOT = os.path.dirname(MODEL_ROOT)
B62 = "[C-]#[N+]C1(C[C@@H]2C3)C[C@@H]3C[C@@H](C2)"


def _bb(tmp_path, name="bb", rows=lf.MINI_SHEET):
    out = str(tmp_path / name)
    os.makedirs(out, exist_ok=True)
    sheet = lf.write_sheet_csv(os.path.join(out, "sheet.csv"), rows=rows)
    r, meta = building_blocks.read_table(sheet)
    acc, rej = building_blocks.validate_rows(r)
    building_blocks.write_outputs(out, acc, rej, building_blocks.build_summary(acc, rej, meta))
    return out


def _enum(bb, out, *extra):
    return enumerate_library.main([bb, "-o", out, "--chunk-size", "8", *extra])


def _writer(products, out, *extra, rps=8, store="--store-2d"):
    return lmdb_writer.main([products, "-o", out, "--records-per-shard", str(rps), "--n-3d", "1",
                             "--max-try", "3", "--max-iterations", "100", "--map-size-gb", "0.25",
                             store, *extra])


# =========================================================================== P0-2 stale outputs
def test_p0_2_changed_excel_cannot_reuse_enumeration(tmp_path):
    bb = _bb(tmp_path)
    enum = str(tmp_path / "enum")
    assert _enum(bb, enum) == 0
    changed = list(lf.MINI_SHEET)
    changed[0] = ("A1", "CN(C)CCCN", "Amines")          # a corrected/edited reagent
    bb2 = _bb(tmp_path, "bb2", rows=changed)
    with pytest.raises(SystemExit, match="different configuration"):
        _enum(bb2, enum)
    assert _enum(bb2, str(tmp_path / "enum2")) == 0      # a new directory is fine


def test_p0_2_source_sheet_hash_is_part_of_the_configuration(tmp_path):
    bb = _bb(tmp_path)
    cfg = enumerate_library.enumeration_config(bb, 16, 8, 0, 16)
    assert cfg["source_sheet_sha256"] == json.load(
        open(os.path.join(bb, "summary.json"), encoding="utf-8"))["input"]["source_sha256"]
    assert len(cfg["building_blocks_sha256"]) == 64


def test_p0_2_changed_reaction_policy_cannot_reuse_chunks(tmp_path, monkeypatch):
    bb = _bb(tmp_path)
    enum = str(tmp_path / "enum")
    assert _enum(bb, enum) == 0
    monkeypatch.setattr(ugi, "POLICY_VERSION", "ugi-policy-v2-test")
    with pytest.raises(SystemExit, match="different configuration"):
        _enum(bb, enum)
    # a chunk receipt from another configuration is never treated as reusable
    with pytest.raises(provenance.StaleOutputError):
        enumerate_library.chunk_is_complete(enum, 0, 8, config_fingerprint="0" * 64)


def test_p0_2_limit_smoke_enumeration_is_a_different_configuration(tmp_path):
    bb = _bb(tmp_path)
    enum = str(tmp_path / "enum")
    assert _enum(bb, enum, "--limit", "4") == 0
    rec = json.load(open(os.path.join(enum, "enumeration_complete.json"), encoding="utf-8"))
    assert rec["smoke"] is True and rec["n_combinations"] == 4
    with pytest.raises(SystemExit, match="different configuration"):
        _enum(bb, enum)                                   # full run into the smoke directory


def test_p0_2_downstream_reads_only_the_listed_chunks(tmp_path):
    """A stray chunk (e.g. from an old --limit run) is ignored, not globbed in."""
    bb = _bb(tmp_path)
    enum = str(tmp_path / "enum")
    assert _enum(bb, enum) == 0
    listed = lmdb_writer.product_chunks(enum)
    stray = os.path.join(enum, "products", "products-0-4.csv.gz")
    with open(os.path.join(enum, "products", "products-0-8.csv.gz"), "rb") as src, open(stray, "wb") as dst:
        dst.write(src.read())
    assert lmdb_writer.product_chunks(enum) == listed
    assert stray not in lmdb_writer.product_chunks(enum)


@pytest.mark.parametrize("first,second", [
    (["--seed-start", "0"], ["--seed-start", "1"]),
    ([], ["--limit", "4"]),
    (["--store-2d"], ["--no-store-2d"]),
])
def test_p0_2_changed_writer_options_cannot_reuse_shards(tmp_path, first, second):
    bb = _bb(tmp_path)
    enum = str(tmp_path / "enum")
    assert _enum(bb, enum) == 0
    out = str(tmp_path / "lmdb")

    def run(opts):
        store = "--no-store-2d" if "--no-store-2d" in opts else "--store-2d"
        return _writer(enum, out, *[o for o in opts if o not in ("--store-2d", "--no-store-2d")],
                       store=store)

    assert run(first) == 0
    with pytest.raises(SystemExit, match="different configuration"):
        run(second)


def test_p0_2_changed_products_cannot_reuse_shards(tmp_path):
    bb = _bb(tmp_path)
    enum = str(tmp_path / "enum")
    assert _enum(bb, enum) == 0
    out = str(tmp_path / "lmdb")
    assert _writer(enum, out) == 0
    changed = list(lf.MINI_SHEET)
    changed[0] = ("A1", "CN(C)CCCN", "Amines")
    enum2 = str(tmp_path / "enum2")
    assert _enum(_bb(tmp_path, "bb2", rows=changed), enum2) == 0
    with pytest.raises(SystemExit, match="different configuration"):
        _writer(enum2, out)


def test_p0_2_shard_with_other_inputs_is_refused(tmp_path):
    bb = _bb(tmp_path)
    enum = str(tmp_path / "enum")
    assert _enum(bb, enum) == 0
    out = str(tmp_path / "lmdb")
    assert _writer(enum, out) == 0
    fp = provenance.read_config(out, "lmdb_writer")["fingerprint"]
    with pytest.raises(provenance.StaleOutputError, match="different input rows"):
        lmdb_writer.shard_is_complete(out, 0, True, fp, "f" * 64)


def test_p0_2_smoke_output_is_never_production(tmp_path):
    bb = _bb(tmp_path)
    enum = str(tmp_path / "enum")
    assert _enum(bb, enum) == 0
    out = str(tmp_path / "lmdb")
    assert _writer(enum, out, "--limit", "12", rps=4) == 0
    manifest = json.load(open(os.path.join(out, "manifest.json"), encoding="utf-8"))
    assert manifest["smoke"] is True
    with pytest.raises(SystemExit, match="SMOKE"):
        splits.main([out])
    assert splits.main([out, "--allow-smoke", "--valid-shards", "1"]) == 0
    assert json.load(open(os.path.join(out, "splits.json"), encoding="utf-8"))["smoke"] is True


def test_p0_2_receipts_record_provenance(tmp_path):
    """REC per-shard reproducibility: versions, fingerprints, inputs and options in every receipt."""
    bb = _bb(tmp_path)
    enum = str(tmp_path / "enum")
    assert _enum(bb, enum) == 0
    out = str(tmp_path / "lmdb")
    assert _writer(enum, out) == 0
    r = json.load(open(os.path.join(out, "shard-00000", "shard.json"), encoding="utf-8"))
    for k in ("config_fingerprint", "input_fingerprint", "n_input_rows", "first_combo_index",
              "last_combo_index", "records_csv_sha256", "versions", "conformer_seed_start"):
        assert r.get(k) is not None, k
    assert r["versions"]["rdkit"]
    cfg = provenance.read_config(out, "lmdb_writer")["config"]
    assert cfg["enumeration_fingerprint"] == provenance.read_config(enum, "enumeration")["fingerprint"]
    ecfg = provenance.read_config(enum, "enumeration")["config"]
    assert ecfg["ugi_policy"]["reaction_smarts"] == ugi.UGI_SMARTS
    assert ecfg["building_blocks_sha256"] and ecfg["source_sheet_sha256"]


def test_p0_2_concurrent_array_tasks_share_one_lock(tmp_path):
    out = str(tmp_path / "x")
    a = provenance.lock_config(out, "s", {"k": 1})
    assert provenance.lock_config(out, "s", {"k": 1}) == a
    with pytest.raises(provenance.StaleOutputError, match="changed: k"):
        provenance.lock_config(out, "s", {"k": 2})


# =========================================================================== P0-1 completeness
def test_p0_1_dedup_requires_a_complete_enumeration(tmp_path):
    from lipid_library import dedup

    bb = _bb(tmp_path)
    enum = str(tmp_path / "enum")
    assert enumerate_library.main([bb, "-o", enum, "--chunk-size", "8", "--shard", "0",
                                   "--num-shards", "2"]) == 0          # half of the chunks
    assert enumerate_library.main([bb, "-o", enum, "--chunk-size", "8", "--check-complete"]) == 1
    assert not os.path.exists(os.path.join(enum, "enumeration_complete.json"))
    with pytest.raises(SystemExit, match="enumeration_complete.json"):
        dedup.main([enum, "-o", str(tmp_path / "dedup"), "--require-complete"])
    assert enumerate_library.main([bb, "-o", enum, "--chunk-size", "8", "--shard", "1",
                                   "--num-shards", "2"]) == 0
    assert enumerate_library.main([bb, "-o", enum, "--chunk-size", "8", "--check-complete"]) == 0
    assert dedup.main([enum, "-o", str(tmp_path / "dedup"), "--require-complete"]) == 0
    summary = json.load(open(os.path.join(tmp_path, "dedup", "summary.json"), encoding="utf-8"))
    assert summary["enumeration_fingerprint"] == provenance.read_config(enum, "enumeration")["fingerprint"]


def test_p0_1_empty_valid_split_is_refused(tmp_path):
    bb = _bb(tmp_path)
    enum = str(tmp_path / "enum")
    assert _enum(bb, enum) == 0
    out = str(tmp_path / "lmdb")
    assert _writer(enum, out, rps=4) == 0
    with pytest.raises(SystemExit, match="validation split is empty"):
        splits.main([out, "--valid-shards", "0"])


# =========================================================================== P1 2D slot policy
def test_p1_2d_runtime_view():
    assert validate_lmdb.runtime_view("10/0") == (11, 1 / 11)     # 10 3D stored + HEART 2D
    assert validate_lmdb.runtime_view("11/1") == (12, 2 / 12)     # LUMI 11 stored + HEART 2D


@pytest.fixture(scope="module")
def slot_data(tmp_path_factory):
    root = tmp_path_factory.mktemp("slots")
    general = lf.write_general_lmdb_dir(str(root / "general"), n_3d=2, store_2d=False)   # "2/0"
    same = lf.full_lipid_pipeline(str(root / "same"), limit=8, n_3d=2, store_2d=False)
    other = lf.full_lipid_pipeline(str(root / "other"), limit=8, n_3d=1, store_2d=True)   # "2/1"
    return {"general": general["dir"], "same": same["splits"], "other": other["splits"]}


def _check_data(general, splits_path, *extra):
    return subprocess.run([sys.executable, os.path.join(TOOLS_DIR, "check_continual_data.py"),
                           "--general", general, "--lipid-splits", splits_path, *extra],
                          capture_output=True, text=True, timeout=300)


def test_p1_2d_same_slot_count_but_different_2d_policy_is_refused(slot_data):
    """2 stored slots each, but 2/0 vs 2/1: same count, different P(2D) -> hard failure."""
    p = _check_data(slot_data["general"], slot_data["other"], "--allow-smoke")
    assert p.returncode == 1, p.stdout
    assert "profiles differ" in p.stdout
    assert "P(2D) = 0.3333" in p.stdout and "P(2D) = 0.6667" in p.stdout


def test_p1_2d_matching_policy_passes_and_reports_probabilities(slot_data):
    p = _check_data(slot_data["general"], slot_data["same"], "--allow-smoke")
    assert p.returncode == 0, p.stdout
    assert p.stdout.count("P(2D) = 0.3333") == 4        # general train/valid, lipid train/valid
    assert "PASS" in p.stdout


def test_p1_2d_preflight_refuses_smoke_lipid_data_by_default(slot_data):
    p = _check_data(slot_data["general"], slot_data["same"])
    assert p.returncode == 1 and "SMOKE" in p.stdout


def test_p1_2d_task_hard_fails_on_a_profile_mismatch(unimol_pkg, slot_data):
    from conftest import task_args
    from unimol.tasks.unimol_contrastive_continual import UniMolTaskContrastiveContinual

    args = task_args(slot_data["general"], lipid_splits=slot_data["other"], lipid_lmdb=None,
                     general_data_weight=1.0, lipid_data_weight=1.0, mixture_report=None,
                     require_equal_coordinate_slots=True, allow_smoke_lipid_data=True,
                     invalid_smiles_policy="skip-2d", max_invalid_smiles_fraction=0.01, batch_size=4)
    task = UniMolTaskContrastiveContinual.setup_task(args)
    with pytest.raises(ValueError, match="different conformer slot profiles"):
        task.load_dataset("train")
    args.lipid_splits = slot_data["same"]
    task = UniMolTaskContrastiveContinual.setup_task(args)
    task.load_dataset("train")                                 # matching policy loads


def test_p1_2d_task_refuses_smoke_lipid_data_unless_allowed(unimol_pkg, slot_data):
    from conftest import task_args
    from unimol.tasks.unimol_contrastive_continual import UniMolTaskContrastiveContinual

    args = task_args(slot_data["general"], lipid_splits=slot_data["same"], lipid_lmdb=None,
                     general_data_weight=1.0, lipid_data_weight=1.0, mixture_report=None,
                     require_equal_coordinate_slots=True, allow_smoke_lipid_data=False,
                     invalid_smiles_policy="skip-2d", max_invalid_smiles_fraction=0.01, batch_size=4)
    task = UniMolTaskContrastiveContinual.setup_task(args)
    with pytest.raises(ValueError, match="SMOKE"):
        task.load_dataset("train")


def test_p1_2d_writer_requires_an_explicit_store_2d_choice(tmp_path):
    with pytest.raises(SystemExit):
        lmdb_writer.build_parser().parse_args([str(tmp_path), "-o", str(tmp_path / "o")])


# =========================================================================== P1 sizing
def test_p1_sizing_plan_and_default_geometry():
    text = open(os.path.join(SCRIPTS_DIR, "lipid_library", "04_conformers_array.sh"), encoding="utf-8").read()
    assert "#SBATCH --array=0-999%200" in text and "#SBATCH --time=1-00:00:00" in text
    lib = open(os.path.join(SCRIPTS_DIR, "lipid_library", "lipid_lib.sh"), encoding="utf-8").read()
    rps = int(re.search(r"RECORDS_PER_SHARD:-(\d+)", lib).group(1))
    shards = math.ceil(15_241_216 / rps)
    hours = math.ceil(shards / 1000) * rps * 1.9 / 3600 * 1.5
    assert hours <= 24, "default geometry must fit the default time limit at the measured rate"


def test_p1_sizing_plan_cli(tmp_path, capsys):
    bb = _bb(tmp_path)
    enum = str(tmp_path / "enum")
    assert _enum(bb, enum) == 0
    assert lmdb_writer.main([enum, "-o", str(tmp_path / "l"), "--store-2d", "--records-per-shard", "5",
                             "--plan", "--sec-per-molecule", "3600", "--array-size", "2"]) == 0
    plan = json.loads(capsys.readouterr().out)
    assert plan["n_rows"] == 16 and plan["n_shards"] == 4 and plan["max_shards_per_task"] == 2
    assert plan["est_hours_per_task"] == 10.0


def _lipid_env(root, data_dir=None, **extra):
    py = sys.executable.replace("\\", "/")
    env = {k: v for k, v in os.environ.items() if not k.startswith(("SLURM_", "HEART_", "LIPID_"))}
    env.update(HEART_REPO=REPO_ROOT.replace("\\", "/"), HEART_SKIP_ENV="1", HEART_PYTHON=py,
               HEART_CONFIRM_LIPID="1", LIPID_ROOT=str(root).replace("\\", "/"),
               HEART_DATA_PATH=str(data_dir or root).replace("\\", "/"), PYTHONIOENCODING="utf-8")
    env.update({k: str(v) for k, v in extra.items()})
    return env


@needs_bash
def test_p1_sizing_stage04_refuses_an_unmeasured_full_run_and_an_oversized_task(tmp_path):
    root = tmp_path / "root"
    bb = _bb(root, "bb")
    assert _enum(bb, str(root / "enum")) == 0
    from lipid_library import dedup

    assert dedup.main([str(root / "enum"), "-o", str(root / "dedup"), "--require-complete"]) == 0
    import shutil

    data = tmp_path / "general"
    data.mkdir()
    shutil.copyfile(lf.DICT_FIXTURE, str(data / "dict.txt"))
    script = os.path.join(SCRIPTS_DIR, "lipid_library", "04_conformers_array.sh")
    p = subprocess.run([BASH, script], env=_lipid_env(root, data, STORE_2D=1), capture_output=True, text=True)
    assert p.returncode != 0 and "SEC_PER_MOLECULE measured by a CMRI pilot" in p.stderr, p.stderr
    p = subprocess.run([BASH, script], env=_lipid_env(root, data, STORE_2D=1, SEC_PER_MOLECULE=3600,
                                                      RECORDS_PER_SHARD=8, LIPID_TIME_LIMIT_HOURS=1),
                       capture_output=True, text=True)
    assert p.returncode != 0 and "does not fit the time limit" in p.stderr, p.stdout + p.stderr
    assert not os.path.exists(str(root / "lmdb" / "shard-00000")), "nothing may be generated"
    p = subprocess.run([BASH, script], env=_lipid_env(root, data), capture_output=True, text=True)
    assert p.returncode != 0 and "STORE_2D=0 or STORE_2D=1" in p.stderr


# =========================================================================== P1 chemistry
def test_p1_chem_b62_error_is_reported_verbatim_with_a_proposal_not_applied(tmp_path):
    rows = list(lf.MINI_SHEET) + [("B62", B62, "Isocyanides")]
    out = _bb(tmp_path, rows=rows)
    issues = list(__import__("csv").DictReader(open(os.path.join(out, "reagent_issues.csv"), encoding="utf-8")))
    b62 = [r for r in issues if r["id"] == "B62"][0]
    assert b62["input_smiles"] == B62                                  # exact source string
    assert "SMILES Parse Error: unclosed ring for input" in b62["reason"]
    cands = json.loads(b62["proposed_corrections"])
    from rdkit import Chem

    adamantyl = Chem.MolToSmiles(Chem.MolFromSmiles("[C-]#[N+]C12CC3CC(CC(C3)C1)C2"), isomericSmiles=False)
    assert any(Chem.MolToSmiles(Chem.MolFromSmiles(c["candidate"]), isomericSmiles=False) == adamantyl
               and c["formula"] == "C11H15N" for c in cands)
    assert "not modified" in b62["status"]
    by_role = building_blocks.load_building_blocks(os.path.join(out, "building_blocks.csv"))
    assert "B62" not in {r["id"] for r in by_role["isocyanide"]}      # rejected, never repaired


def test_p1_chem_alternative_ugi_sites_are_reported():
    acid, amine, ald, iso = (Chem_mol(s) for s in ("CC(=O)O", "NCCCN(C)CCCCN", "CCCCC=O", "[C-]#[N+]C"))
    smi, info = ugi.product_smiles(acid, amine, ald, iso)
    assert info["n_unique_products"] == 2 and len(info["alternative_products"]) == 2
    assert smi == sorted(Chem_canon(a) for a in info["alternative_products"])[0]


def Chem_mol(s):
    from rdkit import Chem

    return Chem.MolFromSmiles(s)


def Chem_canon(s):
    from rdkit import Chem

    return Chem.MolToSmiles(Chem.MolFromSmiles(s))


def test_p1_chem_review_writes_mapping_table_and_drawings(tmp_path):
    from lipid_library import review_products

    rows = list(lf.MINI_SHEET) + [("A9", "NCCCN(C)CCCCN", "Amines"), ("B62", B62, "Isocyanides")]
    bb = _bb(tmp_path, rows=rows)
    out = str(tmp_path / "review")
    assert review_products.main([bb, "-o", out, "--every-reagent"]) == 0
    md = open(os.path.join(out, "review.md"), encoding="utf-8").read()
    assert "NOT verified LUMI output" in md and "Representative mappings" in md
    assert "B62" in md and "C11H15N" in md and "not applied" in md
    review = list(__import__("csv").DictReader(open(os.path.join(out, "review.csv"), encoding="utf-8")))
    multi = [r for r in review if "A9" in r["combo_id"]]
    assert multi and all(" | " in r["alternative_products"] for r in multi)
    # FINDING: for an asymmetric diamine LUMI's first-match assembly picks the other NH2
    summary = json.load(open(os.path.join(out, "summary.json"), encoding="utf-8"))
    assert summary["n_lumi_other_site_A1"] >= 1 and summary["n_lumi_different"] == 0
    assert any(r["lumi_assembly"].startswith("other_site_A1") for r in multi)
    assert os.path.getsize(os.path.join(out, "review.svg")) > 1000


# =========================================================================== P1 H200 readiness
def _launcher_env(tmp_path, **extra):
    py = sys.executable.replace("\\", "/")
    dummy = tmp_path / "general.pt"
    dummy.write_bytes(b"x")
    env = {k: v for k, v in os.environ.items() if not k.startswith(("SLURM_", "HEART_"))}
    env.update(HEART_REPO=REPO_ROOT.replace("\\", "/"), HEART_SKIP_ENV="1", HEART_PYTHON=py,
               HEART_OUTPUT_ROOT=str(tmp_path / "runs" / "h200").replace("\\", "/"),
               HEART_CONFIRM_CONTINUAL="1", HEART_GENERAL_CHECKPOINT=str(dummy).replace("\\", "/"),
               MIN_FREE_GB="0", HEART_MEM_INTERVAL="0", PYTHONIOENCODING="utf-8")
    env.update({k: str(v) for k, v in extra.items()})
    return env


def _launch(env):
    return subprocess.run([BASH, os.path.join(SCRIPTS_DIR, "continual_pretrain_heart-h200.sh")],
                          env=env, capture_output=True, text=True, timeout=600)


@needs_bash
@pytest.mark.parametrize("extra,msg", [
    ({"RUN_NAME": "my-smoke-run"}, "reserved for HEART_CONTINUAL_SMOKE_UPDATES"),
    ({"HEART_CONTINUAL_SMOKE_UPDATES": "20", "RUN_NAME": "heart-lipid-continual-v1"}, "containing 'smoke'"),
    ({"HEART_CONTINUAL_SMOKE_UPDATES": "x"}, "positive integer"),
])
def test_p1_h200_smoke_runs_are_isolated(tmp_path, slot_data, extra, msg):
    env = _launcher_env(tmp_path, HEART_DRY_RUN=1, HEART_DATA_PATH=slot_data["general"],
                        HEART_LIPID_SPLITS=slot_data["same"], **extra)
    p = _launch(env)
    assert p.returncode != 0 and msg in p.stderr, p.stderr[-1500:]


@needs_bash
def test_p1_h200_preflight_refuses_a_slot_policy_mismatch(tmp_path, slot_data):
    env = _launcher_env(tmp_path, HEART_DRY_RUN=1, HEART_DATA_PATH=slot_data["general"],
                        HEART_LIPID_SPLITS=slot_data["other"], HEART_ALLOW_SMOKE_LIPID=1)
    p = _launch(env)
    assert p.returncode != 0
    assert "continual data preflight failed" in p.stderr and "profiles differ" in p.stdout


@needs_bash
def test_p1_h200_preflight_refuses_smoke_lipid_data_in_production(tmp_path, slot_data):
    env = _launcher_env(tmp_path, SLURM_JOB_ID="123", HEART_DATA_PATH=slot_data["general"],
                        HEART_LIPID_SPLITS=slot_data["same"], HEART_ALLOW_SMOKE_LIPID=1)
    p = _launch(env)
    assert p.returncode != 0 and "for local tests and dry runs only" in p.stderr
    env.pop("HEART_ALLOW_SMOKE_LIPID")
    p = _launch(env)
    assert p.returncode != 0 and "SMOKE" in p.stdout


def test_p1_h200_launcher_always_requires_equal_slot_profiles():
    text = open(os.path.join(SCRIPTS_DIR, "continual_pretrain_heart-h200.sh"), encoding="utf-8").read()
    assert "--require-equal-coordinate-slots" in text
    assert "check_continual_data.py" in text


def test_p1_h200_pinned_unicore_finetune_resets_optimizer_state():
    """The --finetune-from-model path used for a new stage resets optimizer/scheduler/meters/dataloader
    in the pinned Uni-Core source (also exercised end to end in test_continual_scripts)."""
    unicore = pytest.importorskip("unicore")
    src = open(os.path.join(os.path.dirname(unicore.__file__), "checkpoint_utils.py"), encoding="utf-8").read()
    block = src[src.index("if args.finetune_from_model is not None and first_launch"):][:900]
    for flag in ("reset_optimizer = True", "reset_lr_scheduler = True", "reset_meters = True",
                 "reset_dataloader = True"):
        assert flag in block, flag


# =========================================================================== REC memory
def test_rec_memory_index_arrays_are_compact(unimol_pkg, slot_data):
    from unimol.data.merged_sampling_dataset import MergedSampledLMDBDataset

    paths = [os.path.join(slot_data["general"], "train.lmdb")] + splits.load_splits(slot_data["same"], "train")[0]
    full = MergedSampledLMDBDataset(paths, [1.0, 1.0])
    assert full.index_memory_bytes() == 0                     # weight 1.0: identity, no array
    half = MergedSampledLMDBDataset(paths, [0.5, 1.0])
    assert half._sel[0].dtype.name == "uint32" and half.index_memory_bytes() == 4 * 3
    assert [half.dataset_of(i) for i in range(len(half))] == [
        (0, int(x)) for x in half.selected[0]] + [(1, j) for j in range(half._n_sampled[1])]
