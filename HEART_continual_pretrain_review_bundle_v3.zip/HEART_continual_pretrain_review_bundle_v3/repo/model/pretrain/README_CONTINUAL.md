# HEART × LUMI lipid continual pretraining

This continues a **completed HEART general checkpoint** on a weighted mixture of:

* the Uni-Mol general ligand LMDB, and
* a LUMI-style virtual **Ugi-4CR lipid library** enumerated from `LUMI_virtual_library_training_lipidLike.xlsx`.

It keeps HEART's model, tokenizer (`dict.txt`), losses, parameter shapes and independent contrastive views. The general-pretraining code, launchers and configs are not modified. The continual pieces are separate files.

**Status: revision 2.** This revision addresses the independent review `HEART_continual_independent_review.md`. It has been tested locally on CPU with tiny data only. **Nothing has been run on CMRI. It is not approved for production** until the CMRI audits and the H200 smoke run in §4 pass.

## 1. Pipeline and files

```
Excel (251 reagents)
  └─ building_blocks    validate, roles, QC, reagent_issues.csv (exact RDKit errors + proposals) → bb/
  └─ review_products    chemistry review: review.md / .csv / .svg, alternative Ugi sites          → review/
  └─ enumerate_library  Ugi products, chunked; config-locked; --check-complete                     → enum/
  └─ dedup              duplicate products (requires a complete enumeration)                     → dedup/
  └─ lmdb_writer        --partition: read products ONCE → per-shard input files                   → lmdb/shard_inputs/
                        conformers → integer-key shards (array; each task reads only its inputs)
                        --finalize → manifest.json                                                → lmdb/
  └─ splits             whole-shard train/valid, stratified seeded draw (refuses incomplete/smoke/
                        empty/overlap) + split_report.json                                        → lmdb/splits.json
  └─ validate_lmdb      record-level QC; slot_profile() for the 2D-policy audit
tools/check_continual_data.py   read-only launch preflight: every shard's metadata, records sampled
                                across all shard ids, identical slot policy
unicore-train --task unimol_contrastive_continual
```

| File | Purpose |
|---|---|
| `pretrain/lipid_library/*.py` | Generation stages (`python -m lipid_library.<stage>` from `model/pretrain`). `provenance.py` provides the configuration fingerprints and output-directory locks |
| `pretrain/scripts/lipid_library/0*_*.sh` (01, 02, 03, 03b, 04, 05), `lipid_lib.sh` | CMRI CPU SLURM stages |
| `unimol/data/merged_sampling_dataset.py` | LUMI `MergedLMDBDatasetWithSampling` semantics with compact index arrays and a bounded, LRU-closed set of open LMDB environments per process |
| `unimol/tasks/unimol_contrastive_continual.py` | Continual task (a subclass of HEART `unimol_contrastive`) |
| `pretrain/scripts/continual_pretrain_heart-h200.sh` | H200 launcher. `pretrain_heart-h200.sh` is unchanged |
| `pretrain/tools/init_continual_checkpoint.py`, `check_continual_stage.py`, `check_continual_registry.py`, `check_continual_data.py` | Init, resume, registry and data guards |
| `pretrain/tests/test_review_fixes.py`, `test_v2_review_fixes.py` | Regression and scale tests per item of the first and second review |

## 2. Scientific conventions

**Ugi reaction: a reconstruction, not a verified LUMI reproduction.** LUMI-lab does not publish the code that built its 15M library or the reference structures. The template, assumptions A1–A4 and the cross-checks are documented in `ugi.py` and `review/review.md`.

Results of the local review on the real sheet (295 products, including every reagent and 11 multi-site amines):

* core and formula checks: 295/295;
* LUMI core-assembly cross-check: identical 281, identical except E/Z 14, different 0.

**A1, multi-site reagents.** The template keeps the lexicographically smallest product. LUMI's own assembly attaches at the *first* matching group in input atom order. These rules agree for every real-sheet combination reviewed, even though 7 of those combinations have alternative products. They **do differ for an asymmetric diamine** (shown by a regression test). `review.csv` lists every alternative product so a chemist can decide.

Also flagged:

* hydrazine "amines": A34, A41, A48;
* aryl and heteroaryl amines (A3);
* the N-isocyanide B33.

**B62 is rejected and not repaired.**

* Source: `[C-]#[N+]C1(C[C@@H]2C3)C[C@@H]3C[C@@H](C2)`
* RDKit: `SMILES Parse Error: unclosed ring for input`
* Proposals (in `bb/reagent_issues.csv`; **not applied**):
  * `append 'C1'` → C11H15N, which is **1-adamantyl isocyanide** (the stereo tags are meaningless on that symmetric cage);
  * `append '1'` → C10H13N.

Without B62 there are **15,241,216 combinations**; with a corrected B62 there would be 15,491,072. The data owner decides.

**Conformers.** LUMI `smi2coords_pretrain` is reused: ETKDGv3 then MMFF, 15 attempts, 4000 iterations and 10 3D slots. There is per-record 3D/2D accounting. Seed policy D6: RDKit seed 0 equals seed 1, so `SEED_START=0` (LUMI) duplicates slot 0/1, and `SEED_START=1` does not.

**2D policy (review P1): decided on CMRI, enforced in code.** The lipid writer has **no default**: `--store-2d` stores 10 3D + 1 2D (the LUMI layout), and `--no-store-2d` stores 10 3D only. HEART's `Add2DConformerDataset` adds one 2D conformer at training time to *every* record of *both* sources. So:

* lipid 11/1 against general 10/0 gives P(2D) of 2/12 against 1/11, a silent distribution mismatch;
* the convention must therefore match the general LMDB.

Three layers enforce it:

1. `tools/check_continual_data.py` measures the stored/2D-like slot profile of the general `train`/`valid` and lipid `train`/`valid`, and fails if they differ;
2. the launcher runs it before training (dry run included);
3. the launcher always passes `--require-equal-coordinate-slots`, so the task also fails on a mismatch.

The general LMDB convention is **not known locally**. Measure it first (§4.2).

**HEART LMDB compatibility.**

* Contiguous ASCII integer keys per shard.
* Records hold only `smi`/`atoms`/`coordinates`.
* A heavy-atom limit of 256, matching `--only-polar 0`.
* `dict.txt` is checked and never extended.
* Compacted shards.

**Mixture sampling.** LUMI semantics: `int(N·w)` records are sampled without replacement, once, seeded by `--seed`. The same 50% of the general data is used every epoch (as in LUMI), and a resume reads the same subset. Expected composition is about 38% general / 62% lipid, and the real numbers go to `mixture_report.json`. Index memory per process is about 38 MB (`uint32`, and no array for weight 1.0); the real 15M+ datasets have not been benchmarked.

**Reproducibility and staleness (review P0-2).**

* Each stage locks its output directory to a configuration fingerprint (`<stage>_config.json`). The enumeration fingerprint covers the Excel and `building_blocks.csv` hashes, the full Ugi policy and RDKit version, the chunk size and the range. The writer fingerprint covers every conformer/filter option, `--limit`, the `dict.txt` hash, the drop-list hash and its enumeration provenance, and the enumeration fingerprint.
* Every chunk and shard receipt records the fingerprint. Shard receipts also record an input fingerprint (combo indexes + SMILES).
* Any mismatch fails; nothing is silently reused. A changed configuration needs **a new output directory**.
* `--limit` and partial ranges are *smoke* configurations and can never be finalised or split as production.

**Completeness (review P0-1).**

* `enumerate_library --check-complete` writes `enumeration_complete.json`, which lists the exact chunks downstream stages read.
* `lmdb_writer --finalize` recomputes the expected shards from the enumeration, the drop list and `--records-per-shard`. It requires every expected shard (no missing, extra or duplicate IDs), matching fingerprints, verified LMDB hashes and exact count reconciliation (records + skipped = input rows; inputs = products − dropped).
* Only then is `manifest.json` written. On failure it is removed, together with `splits.json`, and `finalize_report.json` lists the array tasks to resubmit.

**Checkpoints.** New stage: a weights-only init, strictly checked against the actual training command and loaded through `--finetune-from-model`. In pinned Uni-Core `ace6fae` that path resets the optimizer, LR scheduler, meters and dataloader on first launch; this is checked in the source by a test and exercised end to end locally. Resume: from `checkpoint_last.pt`, guarded by `check_resume_args.py` and `check_continual_stage.py`.

## 3. Windows local tests (executed)

```bash
# Git Bash, from ...\heart-molecular-pretraining\model; Uni-Core ace6fae source checkout on PYTHONPATH
export PYTHONPATH="<Uni-Core ace6fae checkout>;C:/XuLab/Heart_liverPorject/pretrain/heart-molecular-pretraining/model"
PY=../../.venv_heart_cpu/Scripts/python.exe
$PY -m pytest pretrain/tests/test_ugi_reaction.py pretrain/tests/test_lipid_pipeline.py pretrain/tests/test_review_fixes.py -q -p no:cacheprovider
$PY -m pytest pretrain/tests/test_continual_loader.py pretrain/tests/test_continual_scripts.py -q -p no:cacheprovider
```

## 4. CMRI sequence (NOT executed; each step gates the next)

### 4.1 Deploy and register

Copy the files listed in the bundle `MANIFEST` into `/home/ypan/heart_liver/model_train/heart-molecular-pretraining`. Then:

```bash
git status --short                    # only the new files should appear
cd model && python pretrain/tools/check_continual_registry.py --user-dir ./unimol    # in heart_gpu
mkdir -p /home/ypan/heart_liver/model_train/lipid_library/{input,logs}
sinfo -o "%P %l %c %m"; scontrol show config | grep MaxArraySize   # CPU partition, array limit
```

### 4.2 Read-only audit of the general LMDB conformer policy (decides STORE_2D)

```bash
cd /home/ypan/heart_liver/model_train/heart-molecular-pretraining/model/pretrain
python -c "
from lipid_library.validate_lmdb import slot_profile, runtime_view
for s in ('train','valid'):
    p = slot_profile('/home/ypan/heart_liver/model_train/UniMolReference/ligand_data/ligands/%s.lmdb' % s, 256)
    print(s, p['n_records'], p['profiles'], {k: runtime_view(k) for k in p['profiles']})"
```

* Dominant profile `10/0` → use `STORE_2D=0`.
* Dominant profile `11/1` → use `STORE_2D=1`.
* Anything else → stop and review.

### 4.3 CPU generation: pilot, then full

```bash
export HEART_CONFIRM_LIPID=1 STORE_2D=<from 4.2>
j1=$(sbatch --parsable --export=ALL scripts/lipid_library/01_building_blocks.sh)
#   → chemist reviews lipid_library/review/review.md + review.svg and bb/reagent_issues.csv (B62)
j2=$(sbatch --parsable --export=ALL --dependency=afterok:$j1 scripts/lipid_library/02_enumerate_array.sh)
j3=$(sbatch --parsable --export=ALL --dependency=afterok:$j2 scripts/lipid_library/03_dedup.sh)
# pilot (own directory; smoke; measures CMRI speed). 03b writes the per-shard inputs ONCE.
export PILOT=/home/ypan/heart_liver/model_train/lipid_library/lmdb_pilot
LIMIT=5000 LIPID_LMDB_DIR=$PILOT sbatch --export=ALL --dependency=afterok:$j3 scripts/lipid_library/03b_partition.sh
LIMIT=5000 LIPID_LMDB_DIR=$PILOT LIPID_ARRAY_SIZE=1 \
  sbatch --export=ALL --array=0 scripts/lipid_library/04_conformers_array.sh
LIMIT=5000 LIPID_LMDB_DIR=$PILOT LIPID_ARRAY_SIZE=1 \
  sbatch --export=ALL scripts/lipid_library/05_finalize.sh      # prints measured_sec_per_molecule
# full run
j3b=$(sbatch --parsable --export=ALL scripts/lipid_library/03b_partition.sh)   # reads the 15M products once
# the job refuses to start if ceil(shards/N)·RECORDS_PER_SHARD·(SEC_PER_MOLECULE + read s/row)·1.5 exceeds its
# time limit, or if the 03b partition is missing / made with other options
SEC_PER_MOLECULE=<pilot value> sbatch --export=ALL --dependency=afterok:$j3b scripts/lipid_library/04_conformers_array.sh
sbatch --export=ALL --dependency=afterany:<04 array id> scripts/lipid_library/05_finalize.sh
# finalize failed? → resubmit ONLY the listed tasks (the stride stays LIPID_ARRAY_SIZE=1000, so
# task ids keep their shards): sbatch --export=ALL --array=<resubmit_array_tasks> 04_...; then 05 again
```

Array strides are explicit settings, not the size of a submission: `LIPID_ENUM_ARRAY_SIZE` (default 64, stage 02) and `LIPID_ARRAY_SIZE` (default 1000, stages 03b/04/05). Keep them equal to the `#SBATCH --array` range of the first submission; `lmdb_writer` locks the stage-04 stride per output directory.

Validation split (stage 05, v2 review): `VALID_FRACTION` of the shards (default 0.002, about 6 shards or 30k records for the full library) or `VALID_SHARDS`, one shard drawn from each stratum of the combination order with `SPLIT_SEED` (default 1). `split_report.json` lists the validation fraction, where the validation shards sit in combination order, and the reagent-ID distribution per split. This is a random whole-shard split, **not** a scaffold or reagent hold-out.

Defaults: `RECORDS_PER_SHARD=5000`, `--array=0-999%200` and a 24 h limit, i.e. 4 shards per task for 15.24M products. At 1.9 s/molecule that is 10.6 h per task, or 15.8 h with the 1.5× safety factor. A second local measurement gave 2.9 s/molecule, which would be about 24 h, so **the pilot rate decides**. The cost is of the order of 8,000–12,000 CPU-hours and about 230 GB (with 11 stored slots).

### 4.4 H200: read-only checks, dry run, isolated smoke run, then production

```bash
cd /home/ypan/heart_liver/model_train/heart-molecular-pretraining/model
python pretrain/tools/check_continual_data.py --general /home/ypan/heart_liver/model_train/UniMolReference/ligand_data/ligands \
    --lipid-splits /home/ypan/heart_liver/model_train/lipid_library/lmdb/splits.json --sample 256
python pretrain/tools/init_continual_checkpoint.py <general checkpoint> --data <ligands dir> --out /tmp/x.pt --dry-run
cd pretrain
export HEART_CONFIRM_CONTINUAL=1 HEART_GENERAL_CHECKPOINT=<…/runs/h200/full/heart-h200-b448-v1/checkpoint_best.pt> \
       HEART_LIPID_SPLITS=/home/ypan/heart_liver/model_train/lipid_library/lmdb/splits.json
HEART_DRY_RUN=1 bash scripts/continual_pretrain_heart-h200.sh
# the launcher also checks `ulimit -n` >= 2*MAX_OPEN_LMDB_ENVS + 512 (default 64 envs per process,
# LRU-closed) and pins the run to the sha256 of splits.json (a resume with another split is refused)
# short real-data H200 smoke run → runs/h200/continual/heart-lipid-continual-smoke (never the production dir)
HEART_CONTINUAL_SMOKE_UPDATES=200 sbatch --export=ALL --time=02:00:00 scripts/continual_pretrain_heart-h200.sh
#   check: "loading pretrained model from …continual_init.pt", num_updates restarts at 1, finite losses,
#   GPU memory at batch 448, mixture_report.json, checkpoint_last.pt @ 200
# production (only after the smoke run is reviewed)
sbatch --export=ALL scripts/continual_pretrain_heart-h200.sh
```

## 5. Not verified locally (CMRI-only)

* The general LMDB slot profile.
* The real CPU speed and the job sizing.
* The CPU partition and MaxArraySize.
* H200 fp16 and memory at batch 448 with lipids up to 256 heavy atoms.
* Real general-checkpoint compatibility.
* SLURM signals and time limits.
* Linux fork with 4 workers (the fork test is skipped on Windows), and the cost of reopening
  evicted shard LMDBs on the CMRI file system (about 30 µs on a local laptop disk).
* Memory on the real 15M+ datasets.
