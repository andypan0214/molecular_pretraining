# Copyright (c) DP Technology.
# This source code is licensed under the MIT license found in the
# LICENSE file in the root directory of this source tree.
#
# HEART continual pretraining task: the general ligand LMDB mixed with the
# enumerated lipid LMDBs, everything else identical to HEART's general
# pretraining task.
#
# Scientific reference: LUMI-lab `model/unimol/tasks/
# unimol_contrastive_mixed_sampling.py` (task `unimol_contrastive_mixed_sampling`)
# and `model/pretrain/continual_pretrain.sh` @ 611e02b.
#
# What this task keeps from HEART's own `unimol_contrastive` (and therefore
# does NOT revert to LUMI's version):
#   * the model, tokenizer, dictionary, losses and parameter shapes, so a
#     HEART general checkpoint loads into it unchanged;
#   * HEART's independent augmented contrastive views
#     (--contrastive-view-mode independent, patch P3). LUMI's mixed-sampling
#     task calls `ds[index]` twice through the stock Uni-Mol data modules,
#     whose per-index LRU caches and (seed, epoch, index) seeding make the
#     two "views" byte-identical, so its positives differ only by dropout;
#   * the P6 invalid-SMILES policy for the training-time 2D conformer;
#   * the shared LMDB reader / 2D-conformer step and
#     PairSampledNestedDictionaryDataset collation (imported from the general
#     task module, which this file does not modify).
#
# What it adds:
#   * MergedSampledLMDBDataset over [general] + lipid shard LMDBs with LUMI's
#     data-weight semantics (see unimol/data/merged_sampling_dataset.py);
#   * --lipid-splits / --lipid-lmdb to point at the lipid shards, while the
#     positional `data` argument stays the general ligand directory, so
#     `dict.txt` -- the pretrained vocabulary -- is still read from there and
#     never rebuilt or reordered;
#   * a report of the real sampled counts and mini-batch proportions, and a
#     consistency check of the stored coordinate-slot counts across datasets
#     (so the 2D conformer policy cannot differ silently between them).

import json
import logging
import os

from unicore.data import (
    AppendTokenDataset,
    Dictionary,
    EpochShuffleDataset,
    FromNumpyDataset,
    PrependTokenDataset,
    RawArrayDataset,
    RightPadDataset,
    RightPadDataset2D,
    TokenizeDataset,
)
from unicore.tasks import UnicoreTask, register_task
from unimol.data import (
    Add2DConformerDataset,
    AtomTypeDataset,
    ConformerSampleDataset,
    CroppingDataset,
    DistanceDataset,
    EdgeTypeDataset,
    KeyDataset,
    MaskPointsDataset,
    NormalizeDataset,
    RemoveHydrogenDataset,
    RightPadDatasetCoord,
)
from unimol.data.merged_sampling_dataset import MergedSampledLMDBDataset
from unimol.tasks.unimol_contrastive import (
    PairSampledNestedDictionaryDataset,
    UniMolTaskContrastive,
)

logger = logging.getLogger(__name__)


def _split_list(value):
    if value is None:
        return []
    if isinstance(value, (list, tuple)):
        items = list(value)
    else:
        items = [p for part in str(value).split(",") for p in part.split(os.pathsep)]
    return [i.strip() for i in items if i.strip()]


@register_task("unimol_contrastive_continual")
class UniMolTaskContrastiveContinual(UniMolTaskContrastive):
    """HEART continual pretraining on a weighted general + lipid LMDB mixture."""

    @staticmethod
    def add_args(parser):
        UniMolTaskContrastive.add_args(parser)
        parser.add_argument(
            "--lipid-splits",
            default=None,
            help="splits.json written by pretrain/lipid_library/splits.py; its "
            "'train'/'valid' lists give the lipid LMDBs for each split",
        )
        parser.add_argument(
            "--lipid-lmdb",
            default=None,
            help="comma-separated lipid LMDB files used for every split "
            "(alternative to --lipid-splits; for smoke tests)",
        )
        parser.add_argument(
            "--general-data-weight",
            default=0.5,
            type=float,
            help="LUMI continual value: fraction of the general ligand records "
            "used per epoch (NOT a mini-batch ratio)",
        )
        parser.add_argument(
            "--lipid-data-weight",
            default=1.0,
            type=float,
            help="LUMI continual value: fraction of each lipid LMDB's records used per epoch",
        )
        parser.add_argument(
            "--mixture-report",
            default=None,
            help="write the sampled counts and proportions of each split to this JSON file",
        )
        parser.add_argument(
            "--require-equal-coordinate-slots",
            action="store_true",
            help="fail if the general and lipid records do not have the same conformer slot "
            "profile (stored slots / 2D-like slots); the H200 launcher always passes it",
        )
        parser.add_argument(
            "--max-open-lmdb-envs",
            default=64,
            type=int,
            help="per-process bound on open LMDB environments of the mixed dataset (LRU, "
            "closed on eviction); a full lipid library has ~3,050 shard LMDBs (v2 review P0)",
        )
        parser.add_argument(
            "--slot-check-shards",
            default=256,
            type=int,
            help="lipid shard LMDBs probed by the coordinate-slot check, spread evenly over "
            "all shard IDs (the general LMDB is always probed)",
        )
        parser.add_argument(
            "--allow-smoke-lipid-data",
            action="store_true",
            help="accept a lipid splits.json marked smoke (local tests only)",
        )

    @classmethod
    def setup_task(cls, args, **kwargs):
        # The dictionary is the pretrained model's dict.txt from the general
        # data directory: the continual stage must not reorder or extend the
        # embedding vocabulary.
        dictionary = Dictionary.load(os.path.join(args.data, args.dict_name))
        logger.info("dictionary: {} types (from {})".format(
            len(dictionary), os.path.join(args.data, args.dict_name)))
        return cls(args, dictionary)

    # ------------------------------------------------------------------ data paths
    @staticmethod
    def _load_splits_json(path, split):
        """Resolve a lipid splits.json into absolute LMDB paths.

        Read here rather than through pretrain/lipid_library so the user
        module works with cwd = model/ and no extra sys.path entry, exactly
        as `unicore-train --user-dir ./unimol` is run.
        """
        with open(path, encoding="utf-8") as fh:
            meta = json.load(fh)
        if split not in meta:
            raise KeyError("{}: no {!r} split (have {})".format(
                path, split, sorted(k for k in ("train", "valid") if k in meta)))
        if meta.get("complete") is not True:
            raise ValueError("{}: not a complete, finalised lipid dataset (run lmdb_writer "
                             "--finalize and splits)".format(path))
        base = os.path.dirname(os.path.abspath(path))
        paths = [os.path.normpath(os.path.join(base, rel)) for rel in meta[split]]
        missing = [p for p in paths if not os.path.isfile(p)]
        if missing:
            raise FileNotFoundError("{}: missing LMDB file(s) {}".format(path, missing))
        return paths, meta

    def lipid_lmdbs(self, split):
        if getattr(self.args, "lipid_splits", None):
            paths, meta = self._load_splits_json(self.args.lipid_splits, split)
            if meta.get("smoke") and not getattr(self.args, "allow_smoke_lipid_data", False):
                raise ValueError("{}: a SMOKE lipid dataset; refusing it for training (pass "
                                 "--allow-smoke-lipid-data for local tests only)".format(
                                     self.args.lipid_splits))
            if not paths:
                raise ValueError("{}: the {!r} lipid split is empty".format(self.args.lipid_splits, split))
            return paths, meta
        paths = _split_list(getattr(self.args, "lipid_lmdb", None))
        missing = [p for p in paths if not os.path.isfile(p)]
        if missing:
            raise FileNotFoundError("--lipid-lmdb: missing file(s) {}".format(missing))
        return paths, {}

    @staticmethod
    def _slot_profile(record):
        """"<stored slots>/<2D-like slots>" of one record (2D-like: every z == 0)."""
        import numpy as np

        coords = record["coordinates"]
        flat = sum(1 for c in coords if np.asarray(c).size and float(np.abs(np.asarray(c)[:, 2]).max()) < 1e-6)
        return "{}/{}".format(len(coords), flat)

    @staticmethod
    def _spread(n, k):
        """k indexes spread evenly over 0..n-1 (both ends included), deterministic."""
        if n <= 0 or k <= 0:
            return []
        k = min(k, n)
        if k == 1:
            return [0]
        return sorted({int(round(j * (n - 1) / (k - 1))) for j in range(k)})

    def _coordinate_slot_check(self, merged, lipid_meta=None):
        """Report (and with --require-equal-coordinate-slots, reject) differing slot profiles.

        HEART's Add2DConformerDataset appends one 2D conformer at training
        time to every record of every source. If one source stores 10 3D slots
        and the other 10 3D + 1 2D, the conformer-sampling distributions differ
        (P(2D) 1/11 vs 2/12). The profile compared is stored slots / 2D-like
        slots from records spread over each dataset (review fix P1).

        v2 review: lipid shards are probed across ALL shard IDs (evenly spread,
        at most --slot-check-shards of them, 4 records each), aggregated into
        one lipid profile, and the stored-slot count is cross-checked against
        the slot count the finalised manifest declares (splits.json). Handles
        stay bounded by the LRU of MergedSampledLMDBDataset.
        """
        def probe_dataset(i, k):
            start = merged.cumulative_length[i]
            n = merged.cumulative_length[i + 1] - start
            profiles = {}
            for j in self._spread(n, k):
                key = self._slot_profile(merged[start + j])
                profiles[key] = profiles.get(key, 0) + 1
            return profiles

        def dominant(profiles):
            return max(sorted(profiles), key=lambda key: profiles[key]) if profiles else None

        per_dataset = []
        general = probe_dataset(0, 8)
        per_dataset.append({"lmdb": merged.db_paths[0], "name": merged.names[0], "profiles": general,
                            "dominant_profile": dominant(general),
                            "stored_slots": sorted({int(k.split("/")[0]) for k in general})})
        lipid_ids = list(range(1, len(merged.db_paths)))
        probed = [lipid_ids[j] for j in self._spread(len(lipid_ids),
                                                     getattr(self.args, "slot_check_shards", 256))]
        lipid = {}
        for i in probed:
            for key, v in probe_dataset(i, 4).items():
                lipid[key] = lipid.get(key, 0) + v
        if lipid_ids:
            per_dataset.append({"lmdb": [merged.db_paths[i] for i in probed], "name": "lipid",
                                "n_lmdbs": len(lipid_ids), "n_lmdbs_probed": len(probed),
                                "profiles": lipid, "dominant_profile": dominant(lipid),
                                "stored_slots": sorted({int(k.split("/")[0]) for k in lipid})})
        for d in per_dataset:
            logger.info("conformer slots in %s: stored/2D-like %s (+1 2D added at training time "
                        "by Add2DConformerDataset)", d["name"], d["profiles"])
        problems = []
        observed = sorted({d["dominant_profile"] for d in per_dataset if d["dominant_profile"]})
        if len(observed) > 1:
            problems.append(
                "the mixed datasets have different conformer slot profiles (stored/2D-like) {}: "
                "the conformer-sampling distribution would differ between general and lipid "
                "records. Rebuild the lipid LMDBs with the general convention "
                "(--store-2d/--no-store-2d, --n-3d).".format(
                    [(d["name"], d["dominant_profile"]) for d in per_dataset]))
        declared = (lipid_meta or {}).get("coordinate_slots_per_record")
        if declared is not None and lipid_ids:
            declared = sorted(declared) if isinstance(declared, list) else [declared]
            if len(declared) != 1:
                problems.append("the lipid manifest declares several slot counts {}".format(declared))
            elif per_dataset[-1]["stored_slots"] != declared:
                problems.append("lipid records store {} coordinate slots but the finalised manifest "
                                "declares {}".format(per_dataset[-1]["stored_slots"], declared))
        if problems:
            if getattr(self.args, "require_equal_coordinate_slots", False):
                raise ValueError(" ".join(problems))
            for msg in problems:
                logger.warning("WARNING: %s", msg)
        return per_dataset

    # ------------------------------------------------------------------ dataset build
    def load_dataset(self, split, combine=False, **kwargs):
        general_path = os.path.join(self.args.data, split + ".lmdb")
        if not os.path.isfile(general_path):
            raise FileNotFoundError("general dataset not found: {}".format(general_path))
        lipid_paths, lipid_meta = self.lipid_lmdbs(split)
        if not lipid_paths:
            raise ValueError(
                "no lipid LMDB for split {!r}: pass --lipid-splits (preferred) or "
                "--lipid-lmdb. Continual pretraining on the general data alone would "
                "just continue the general stage with a new schedule.".format(split))

        paths = [general_path] + list(lipid_paths)
        weights = [self.args.general_data_weight] + [self.args.lipid_data_weight] * len(lipid_paths)
        names = ["general:" + split] + ["lipid:" + os.path.basename(os.path.dirname(p)) for p in lipid_paths]
        merged = MergedSampledLMDBDataset(
            paths, weights, seed=self.args.seed, names=names,
            max_open_envs=getattr(self.args, "max_open_lmdb_envs", 64))
        slot_report = self._coordinate_slot_check(merged, lipid_meta)
        # v2 review P0: no LMDB handle of the checks survives into DataLoader workers
        merged.close()

        counts = merged.mixture_counts()
        general_sampled = counts[0]["n_sampled"]
        lipid_sampled = sum(c["n_sampled"] for c in counts[1:])
        total = general_sampled + lipid_sampled
        logger.info("split %s: general %d (%.2f%%) + lipid %d (%.2f%%) = %d molecules per epoch; "
                    "expected average mini-batch composition at batch size %s: %.1f general / "
                    "%.1f lipid", split, general_sampled, 100.0 * general_sampled / total,
                    lipid_sampled, 100.0 * lipid_sampled / total, total,
                    getattr(self.args, "batch_size", "?"),
                    (getattr(self.args, "batch_size", 0) or 0) * general_sampled / total,
                    (getattr(self.args, "batch_size", 0) or 0) * lipid_sampled / total)
        if getattr(self.args, "mixture_report", None):
            self._write_mixture_report(split, counts, slot_report, lipid_meta)

        raw_dataset = merged
        if self.args.mode == "train":
            raw_dataset = Add2DConformerDataset(
                raw_dataset, "smi", "atoms", "coordinates",
                invalid_policy=getattr(self.args, "invalid_smiles_policy", "skip-2d"),
                max_invalid_fraction=getattr(self.args, "max_invalid_smiles_fraction", 0.01),
            )

        views = [self._build_view(raw_dataset, self.args.seed, self.args.seed)]
        if getattr(self.args, "contrastive_view_mode", "identical") == "independent":
            view_seed = self.args.seed + self.args.view_seed_offset
            views.append(self._build_view(raw_dataset, view_seed, view_seed))
        dataset = PairSampledNestedDictionaryDataset(*[{"net_input": n, "target": t} for n, t in views])
        if split in ["train", "train.small"]:
            dataset = EpochShuffleDataset(dataset, len(dataset), self.args.seed)
        self.datasets[split] = dataset

    def _write_mixture_report(self, split, counts, slot_report, lipid_meta):
        path = self.args.mixture_report
        report = {}
        if os.path.isfile(path):
            try:
                with open(path, encoding="utf-8") as fh:
                    report = json.load(fh)
            except (ValueError, OSError):
                report = {}
        report[split] = {
            "datasets": counts,
            "coordinate_slots": slot_report,
            "n_molecules_per_epoch": sum(c["n_sampled"] for c in counts),
            "general_fraction": counts[0]["n_sampled"] / max(1, sum(c["n_sampled"] for c in counts)),
            "seed": self.args.seed,
            "general_data_weight": self.args.general_data_weight,
            "lipid_data_weight": self.args.lipid_data_weight,
            "lipid_splits_meta": {k: v for k, v in (lipid_meta or {}).items() if k != "shards"},
            "contrastive_view_mode": getattr(self.args, "contrastive_view_mode", None),
        }
        tmp = "{}.tmp.{}".format(path, os.getpid())
        directory = os.path.dirname(os.path.abspath(path))
        if directory:
            os.makedirs(directory, exist_ok=True)
        with open(tmp, "w", encoding="utf-8", newline="\n") as fh:
            json.dump(report, fh, indent=2, sort_keys=True)
            fh.write("\n")
        os.replace(tmp, path)
        logger.info("mixture report: %s", path)

    def _build_view(self, raw_dataset, coord_seed, mask_seed):
        """One contrastive view. Same transform chain as HEART's general task."""
        smi_dataset = KeyDataset(raw_dataset, "smi")
        dataset = ConformerSampleDataset(raw_dataset, coord_seed, "atoms", "coordinates")
        dataset = AtomTypeDataset(raw_dataset, dataset)
        dataset = RemoveHydrogenDataset(
            dataset, "atoms", "coordinates",
            self.args.remove_hydrogen, self.args.remove_polar_hydrogen,
        )
        dataset = CroppingDataset(dataset, self.seed, "atoms", "coordinates", self.args.max_atoms)
        dataset = NormalizeDataset(dataset, "coordinates", normalize_coord=True)
        token_dataset = KeyDataset(dataset, "atoms")
        token_dataset = TokenizeDataset(
            token_dataset, self.dictionary, max_seq_len=self.args.max_seq_len
        )
        coord_dataset = KeyDataset(dataset, "coordinates")
        expand_dataset = MaskPointsDataset(
            token_dataset,
            coord_dataset,
            self.dictionary,
            pad_idx=self.dictionary.pad(),
            mask_idx=self.mask_idx,
            noise_type=self.args.noise_type,
            noise=self.args.noise,
            seed=mask_seed,
            mask_prob=self.args.mask_prob,
            leave_unmasked_prob=self.args.leave_unmasked_prob,
            random_token_prob=self.args.random_token_prob,
        )

        def prepend_and_append(ds, pre_token, app_token):
            ds = PrependTokenDataset(ds, pre_token)
            return AppendTokenDataset(ds, app_token)

        encoder_token_dataset = KeyDataset(expand_dataset, "atoms")
        encoder_target_dataset = KeyDataset(expand_dataset, "targets")
        encoder_coord_dataset = KeyDataset(expand_dataset, "coordinates")

        src_dataset = prepend_and_append(
            encoder_token_dataset, self.dictionary.bos(), self.dictionary.eos()
        )
        tgt_dataset = prepend_and_append(
            encoder_target_dataset, self.dictionary.pad(), self.dictionary.pad()
        )
        encoder_coord_dataset = prepend_and_append(encoder_coord_dataset, 0.0, 0.0)
        encoder_distance_dataset = DistanceDataset(encoder_coord_dataset)

        edge_type = EdgeTypeDataset(src_dataset, len(self.dictionary))
        coord_dataset = FromNumpyDataset(coord_dataset)
        coord_dataset = prepend_and_append(coord_dataset, 0.0, 0.0)
        distance_dataset = DistanceDataset(coord_dataset)
        return {
            "src_tokens": RightPadDataset(src_dataset, pad_idx=self.dictionary.pad()),
            "src_coord": RightPadDatasetCoord(encoder_coord_dataset, pad_idx=0),
            "src_distance": RightPadDataset2D(encoder_distance_dataset, pad_idx=0),
            "src_edge_type": RightPadDataset2D(edge_type, pad_idx=0),
        }, {
            "tokens_target": RightPadDataset(tgt_dataset, pad_idx=self.dictionary.pad()),
            "distance_target": RightPadDataset2D(distance_dataset, pad_idx=0),
            "coord_target": RightPadDatasetCoord(coord_dataset, pad_idx=0),
            "smi_name": RawArrayDataset(smi_dataset),
        }
