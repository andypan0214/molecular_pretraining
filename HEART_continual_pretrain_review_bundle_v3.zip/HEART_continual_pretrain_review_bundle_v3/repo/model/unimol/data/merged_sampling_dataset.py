# Copyright (c) DP Technology.
# This source code is licensed under the MIT license found in the
# LICENSE file in the root directory of this source tree.
#
# HEART continual pretraining: weighted mixture of several pretraining LMDBs.
#
# Scientific reference: LUMI-lab `model/unimol/tasks/
# unimol_contrastive_mixed_sampling.py::MergedLMDBDatasetWithSampling`
# @ 611e02b. LUMI's semantics are kept exactly:
#
#   * `data_weights[i]` subsamples `int(len(keys_i) * w_i)` records of dataset
#     i WITHOUT replacement; it is a fraction of that dataset's own size, not
#     a mixing ratio. With LUMI's continual values (general 0.5, lipid 1.0)
#     and the HEART dataset sizes, half of the general ligand records and all
#     lipid records form one epoch, and a mini-batch contains them in the
#     proportion of those two sampled counts -- *not* 1:2. `mixture_summary()`
#     reports the real numbers so the ratio is never assumed;
#   * the datasets are concatenated (general first), and one epoch is one
#     pass over the concatenation. Uni-Core's EpochShuffleDataset then
#     shuffles the concatenated index space, so mini-batches are mixed.
#
# HEART changes, all of them engineering (no change to which records are
# sampled for a given seed):
#
#   H1. LUMI materialises every key of every LMDB (`list(txn.cursor()
#       .iternext(values=False))`) and then `np.random.choice` over those key
#       bytes. For HEART's 18.8M-record ligand train.lmdb that is minutes of
#       I/O and gigabytes of RAM per worker. HEART's LMDBs use contiguous
#       ASCII integer keys (see lmdb_dataset.py patch P1), so the sampling is
#       done over integer indexes 0..N-1 taken from `txn.stat()`, and keys are
#       formatted on access. Non-integer-keyed LMDBs are rejected with a
#       message pointing at pretrain/lipid_library, rather than silently
#       falling back to a full key scan.
#   H2. LUMI samples with the global NumPy RNG, so the subset depends on
#       whatever consumed randomness earlier in the process and cannot be
#       reproduced after a resume. HEART uses an explicit
#       `np.random.default_rng(seed, dataset_index)` and stores the selected
#       indexes sorted, so a resumed continual run reads exactly the same
#       subset of each dataset.
#   H3. LUMI opens its LMDB environments in `__init__` and keeps them, which
#       breaks across `fork()` (DataLoader workers) -- the same defect HEART
#       patched as P5 for the single-dataset reader. Environments here are
#       opened per process (tracked by PID), dropped when the dataset is
#       pickled, and every read uses a short-lived transaction.
#   H6. (v2 review P0) Bounded LMDB handles. A full lipid library is ~3,050
#       shard LMDBs; keeping every environment a process ever touched would
#       hold thousands of file descriptors + mmaps per DataLoader worker and
#       exceed a typical `ulimit -n`. Open environments are now an LRU of at
#       most `max_open_envs` (default 64) per process: the least recently used
#       one is closed explicitly when another must be opened. `close()` drops
#       every handle (the task calls it after its checks, before DataLoader
#       workers fork/spawn), and a process that inherits handles through
#       fork() discards them and opens its own. Reads are unchanged: the same
#       index -> (LMDB, key) mapping, so eviction never changes what is read.
#   H4. Record reads are cached with a bounded `lru_cache(maxsize=16)` keyed
#       on (dataset instance, index), exactly as HEART's LMDBDataset does, so
#       the two contrastive views of one molecule share a single LMDB read.

import logging
import os
import pickle
from collections import OrderedDict
from functools import lru_cache

import lmdb
import numpy as np

logger = logging.getLogger(__name__)


class MergedSampledLMDBDataset:
    """Weighted, deterministic mixture of several integer-keyed pretraining LMDBs."""

    DEFAULT_MAX_OPEN_ENVS = 64

    def __init__(self, db_paths, data_weights, seed=1, names=None, max_open_envs=DEFAULT_MAX_OPEN_ENVS):
        if len(db_paths) == 0:
            raise ValueError("no LMDB given")
        if len(data_weights) != len(db_paths):
            raise ValueError("data_weights has {} entries for {} LMDBs".format(
                len(data_weights), len(db_paths)))
        for w in data_weights:
            if not 0.0 < float(w) <= 1.0:
                raise ValueError("data weight {} outside (0, 1]: a weight is the fraction of a "
                                 "dataset's records used per epoch, not a mixing ratio".format(w))
        self.db_paths = [os.path.abspath(p) for p in db_paths]
        self.data_weights = [float(w) for w in data_weights]
        self.seed = int(seed)
        self.names = list(names) if names is not None else [os.path.basename(p) for p in self.db_paths]
        if int(max_open_envs) < 1:
            raise ValueError("max_open_envs must be >= 1 (got {})".format(max_open_envs))
        self.max_open_envs = int(max_open_envs)
        self._envs = OrderedDict()      # db_index -> lmdb.Environment, LRU order (H6)
        self._env_pid = os.getpid()
        self.env_stats = {"opened": 0, "evicted": 0}

        self.sizes, self._sel, self._n_sampled = [], [], []
        for i, path in enumerate(self.db_paths):
            if not os.path.isfile(path):
                raise FileNotFoundError("{} not found".format(path))
            env = self.connect_db(path)
            try:
                with env.begin() as txn:
                    n = txn.stat()["entries"]
                    if n > 0:
                        for probe in (0, n - 1):
                            if txn.get("{}".format(probe).encode("ascii")) is None:
                                raise ValueError(
                                    "{}: has {} entries but key b'{}' is missing. The mixed "
                                    "continual loader requires contiguous ASCII integer keys "
                                    "0..N-1 (HEART convention). LUMI's extended_lipid writer "
                                    "uses SMILES keys; rebuild the LMDB with "
                                    "pretrain/lipid_library/lmdb_writer.py".format(path, n, probe))
            finally:
                env.close()
            self.sizes.append(n)
            k = int(n * self.data_weights[i])          # LUMI: int(len(keys) * weight)
            rng = np.random.default_rng([self.seed, i])  # H2: reproducible per dataset
            # H5 (memory): weight 1.0 needs no index array (identity); a subset is
            # stored as uint32 when it fits (4 bytes per sampled record instead of
            # 8). For 9.4M general + 15.2M lipid records that is ~38 MB per process
            # instead of ~197 MB, before copy-on-write sharing across workers.
            if k >= n:
                idx = None
                k = n
            else:
                idx = rng.choice(n, size=k, replace=False)
                idx.sort()
                idx = idx.astype(np.uint32 if n < 2 ** 32 else np.int64)
            self._sel.append(idx)
            self._n_sampled.append(k)

        self.cumulative_length = [0]
        for k in self._n_sampled:
            self.cumulative_length.append(self.cumulative_length[-1] + k)
        self._len = self.cumulative_length[-1]
        if self._len == 0:
            raise ValueError("the mixture is empty: every weight sampled 0 records")
        for line in self.mixture_summary().splitlines():
            logger.info("%s", line)

    # ----------------------------------------------------------------- reporting
    def mixture_counts(self):
        """Per-dataset {name, path, weight, n_records, n_sampled, fraction_of_epoch}."""
        out = []
        for i, path in enumerate(self.db_paths):
            n_sampled = self._n_sampled[i]
            out.append({
                "name": self.names[i],
                "lmdb": path,
                "data_weight": self.data_weights[i],
                "n_records": self.sizes[i],
                "n_sampled": n_sampled,
                "fraction_of_epoch": (n_sampled / self._len) if self._len else 0.0,
            })
        return out

    def mixture_summary(self):
        lines = ["mixed continual dataset: {} LMDB(s), {} records per epoch (seed {})".format(
            len(self.db_paths), self._len, self.seed)]
        for c in self.mixture_counts():
            lines.append("  {:<28} weight {:<5} {:>12} records -> {:>12} sampled "
                         "({:6.2f}% of an epoch, {:6.2f}% of a mini-batch on average)".format(
                             c["name"][:28], c["data_weight"], c["n_records"], c["n_sampled"],
                             100.0 * c["fraction_of_epoch"], 100.0 * c["fraction_of_epoch"]))
        lines.append("  NOTE: a data weight is the fraction of that dataset used per epoch "
                     "(LUMI semantics), so the weights do not set the mini-batch ratio.")
        return "\n".join(lines)

    def dataset_of(self, idx):
        """(dataset_index, record_index_within_that_lmdb) for a mixture index."""
        if not 0 <= idx < self._len:
            raise IndexError("index {} outside 0..{}".format(idx, self._len - 1))
        db_index = int(np.searchsorted(self.cumulative_length, idx, side="right")) - 1
        relative = idx - self.cumulative_length[db_index]
        sel = self._sel[db_index]
        return db_index, int(relative if sel is None else sel[relative])

    @property
    def selected(self):
        """Sampled record indexes per dataset (materialised on demand; reporting/tests)."""
        return [np.arange(n, dtype=np.int64) if sel is None else sel.astype(np.int64)
                for sel, n in zip(self._sel, self._n_sampled)]

    def index_memory_bytes(self):
        """Bytes held by the sampled-index arrays of this process."""
        return int(sum(0 if sel is None else sel.nbytes for sel in self._sel))

    # ----------------------------------------------------------------- lmdb access
    @staticmethod
    def connect_db(lmdb_path):
        return lmdb.open(
            lmdb_path,
            subdir=False,
            readonly=True,
            lock=False,
            readahead=False,
            meminit=False,
            max_readers=256,
        )

    def __getstate__(self):
        # H3/H6: never pickle open environments into DataLoader workers
        state = self.__dict__.copy()
        state.pop("_envs", None)
        state.pop("_env_pid", None)
        return state

    def __setstate__(self, state):
        self.__dict__.update(state)
        self._envs = OrderedDict()
        self._env_pid = os.getpid()

    def _own_envs(self):
        """This process's LRU; handles inherited through fork() are discarded, not reused."""
        pid = os.getpid()
        if getattr(self, "_env_pid", None) != pid or getattr(self, "_envs", None) is None:
            # Inherited Environment objects belong to the parent's LMDB state;
            # LMDB forbids using them after fork(). Dropping the references
            # releases this process's copies of the fds/maps (readonly, no lock
            # file), which does not affect the parent.
            self._envs = OrderedDict()
            self._env_pid = pid
        return self._envs

    def _get_env(self, db_index):
        envs = self._own_envs()
        env = envs.get(db_index)
        if env is not None:
            envs.move_to_end(db_index)
            return env
        while len(envs) >= self.max_open_envs:
            _, old = envs.popitem(last=False)
            old.close()
            self.env_stats["evicted"] += 1
        env = self.connect_db(self.db_paths[db_index])
        envs[db_index] = env
        self.env_stats["opened"] += 1
        return env

    def open_env_count(self):
        """LMDB environments this process holds open (<= max_open_envs)."""
        envs = getattr(self, "_envs", None)
        if envs is None or getattr(self, "_env_pid", None) != os.getpid():
            return 0
        return len(envs)

    def close(self):
        """Close every environment of this process (call before DataLoader workers start)."""
        envs = getattr(self, "_envs", None)
        if envs is not None and getattr(self, "_env_pid", None) == os.getpid():
            while envs:
                _, env = envs.popitem(last=False)
                env.close()
        self._envs = OrderedDict()
        self._env_pid = os.getpid()

    def __len__(self):
        return self._len

    @lru_cache(maxsize=16)
    def __getitem__(self, idx):
        db_index, record_index = self.dataset_of(idx)
        with self._get_env(db_index).begin() as txn:
            raw = txn.get("{}".format(record_index).encode("ascii"))
        if raw is None:
            raise KeyError("{}: key b'{}' not found".format(self.db_paths[db_index], record_index))
        return pickle.loads(raw)
