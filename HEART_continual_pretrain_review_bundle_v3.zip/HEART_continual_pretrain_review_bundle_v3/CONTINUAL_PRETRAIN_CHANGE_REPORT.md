# HEART × LUMI lipid continual pretraining: change report (revision 3)

Date: 2026-11-04. Revision 3 responds to `HEART_continual_v2_second_review.md` ("changes requested before 15M production or H200 production training"). It is for a third independent review. The revision-2 response to the first review is kept unchanged as Appendix A.

> **No `git commit`, `git push`, `git pull`, PR, merge, rebase, reset, clean or branch/remote change was made. No SLURM job, GPU training, full-scale enumeration or full-scale conformer generation was run or submitted. Nothing was uploaded. No package was installed. No tracked (general-pretraining) file and no checkpoint was modified.**

## 1. Repository and Git state

| Item | Value |
|---|---|
| Local Git root | `C:\XuLab\Heart_liverPorject\pretrain\heart-molecular-pretraining` |
| Branch / HEAD | `main` / `ff40a145bfd43d1e1f334e76879d140c934bd27c` (unchanged) |
| Remote | `origin https://github.com/andypan0214/heart-molecular-pretraining.git` (not contacted) |
| Status before revision 3 | 0 tracked modifications, 33 untracked new files (revision 2) |
| Status after revision 3 | **0 tracked modifications**; **35 untracked new files** (33 + `03b_partition.sh`, `test_v2_review_fixes.py`) |

## 2. Response to the second review

| Review item | Fix (files) | Regression / scale tests (`tests/…`) |
|---|---|---|
| **P0: LMDB file-descriptor exhaustion** | `MergedSampledLMDBDataset` (H6) keeps open environments in a per-process **LRU of at most `max_open_envs`** (default 64). The least recently used one is **closed explicitly** on eviction. The LRU is PID-aware: a process that inherits handles through `fork()` discards them and opens its own. It is never pickled (`__getstate__`/`__setstate__`). `close()` drops every handle. Construction opens and closes one LMDB at a time. The task closes the parent's handles after its checks (`merged.close()`), so DataLoader workers fork or spawn with none. Eviction never changes the index → (LMDB, key) mapping, so the selection and resume are identical. New task option `--max-open-lmdb-envs` (in the yaml and launcher). The launcher checks `ulimit -n` ≥ 2·`MAX_OPEN_LMDB_ENVS` + 512 (train + valid datasets per process), raising the soft limit if allowed, and otherwise refuses. The general `lmdb_dataset.py` reader is unchanged (`merged_sampling_dataset.py`, `unimol_contrastive_continual.py`, `continual_pretrain_heart-h200.sh`, `continual_pretrain.yaml`) | `test_v2_review_fixes::test_p0_*` (9). Over 300 synthetic shard LMDBs: construction leaves 0 handles; a shuffled epoch peaks at exactly 8 open envs with correct records, byte-checked after hundreds of evictions; **OS handle growth ≤ 32 with the bound against ≥ 300 for the unbounded control** (Win32 `GetProcessHandleCount` or `/proc/self/fd`); an evicted env is really closed (`lmdb.Error`) and is reopened transparently; `close()` and a bound of 0 is rejected; the selection is identical with and without eviction (resume); a spawned worker gets 0 handles and peaks at 4; a forked worker discards inherited handles while the parent keeps its own (**skipped on Windows**, runs on Linux). In the task, over 118 lipid shards with a bound of 6: peak ≤ 6 during checks and transform-chain reads, and **0 open envs in the parent after `load_dataset`**. `test_continual_loader::test_pickling_drops_open_environments` was updated to the new attribute |
| **P1: every array task re-parses the 15M product stream** | New **shard-input partition** (`lmdb_writer --partition`, new stage `03b_partition.sh`, one CPU job). It reads the deduplicated product stream once and writes `shard_inputs/input-NNNNN.csv.gz` per shard plus `partition_index.json`, holding per shard the row count, input fingerprint, file sha256 and first/last combo index, plus the measured read rate. The partition is locked by `provenance` to the enumeration identity, drop-list identity, `--records-per-shard` and `--limit`. An array task (`--shard`) requires a matching partition, reads **only its own shards' files**, verifies each file's sha256 and recomputes its input fingerprint. An already-complete shard is skipped without reading its input. `--finalize` still streams the products once (independent recount) and also requires the partition to agree. `--plan` includes input reading: read s/row (measured by the partition, or an assumed 1e-4), rows read per task, rows read by all tasks, rows read if every task streamed, per-task read hours, partition hours, and `partition: matches|stale|missing`. Stage 04 refuses to start unless the partition matches. A single-process run builds the partition itself (`lmdb_writer.py`, `03b_partition.sh`, `04_conformers_array.sh`) | `test_v2_review_fixes::test_p1_io_*` (4). **Scale test: 20,000 rows, 200 shards, 50 tasks → the partition parses 20,000 product rows once; the tasks parse 0 product rows and 20,000 shard-input rows in total (the revision-2 design: 1,000,000); every shard is processed exactly once.** Also covered: a task before the partition is refused; the partition is idempotent; a damaged input file is refused ("sha256 differs"); another stride or `--records-per-shard` in the same directory is refused; the plan reports read cost and partition state; finalize fails on a partition that disagrees with the stream. Plus `test_lipid_pipeline::test_interrupted_array_cannot_be_finalised` (now with 03b) and `test_continual_scripts::test_lipid_cpu_stages_run_end_to_end` (04 refused before 03b; 03b → 04 tasks → 05) |
| **P1: biased validation split** | `splits.py`: the default is **`stratified-random`**. The shard list, which follows combination order with the amine as the most significant digit, is cut into K contiguous strata, and one shard is drawn per stratum by sha256(`seed:shard_id`) rank. That is reproducible on every Python/NumPy version and spreads validation over the whole combination-index range. K = `--valid-shards`, or round(`--valid-fraction` × n_shards), default 0.002 (6 of 3,049 shards). `random` (unstratified) and `last` (the revision-2 behaviour, marked `representative: false` with a warning) remain for comparison. `splits.json` records `split_method`, `split_seed`, `representative`, `valid_fraction_records` and an explicit `split_kind`: "NOT a scaffold or reagent hold-out". New `split_report.json` records the validation fraction (records and shards), each validation shard's position in combination order with quantiles, combo ranges, and per role the reagent-ID counts for train and valid, distinct counts, maximum share, valid reagents not in train, and the fraction of train reagents seen in valid. Disjointness, combo-range overlap and the fail-closed checks are unchanged. Stage 05 uses `VALID_FRACTION` / `VALID_SHARDS` and `SPLIT_SEED` (`splits.py`, `05_finalize.sh`) | `test_v2_review_fixes::test_p1_val_*` (3): reproducible for one seed and different for another; exactly one shard per stratum; dispersion over 20 seeds on 3,049 shards (first shard in the first stratum, last in the last); K = 6 by default. A 40-shard manifest gives positions spanning < 0.25 to > 0.75, a validation fraction of 0.1, and `last` flagged as non-representative. **On the real mini library (amine-major order), `last` validation contains 1 amine and `stratified-random` contains both**; the report shows 100% of train amines seen in valid; disjoint. `test_lipid_pipeline::test_splits_assign_whole_shards_without_overlap` was updated (the validation shard is now drawn, no longer always the last) |
| **P1: preflight samples only the first 64 lipid shards** | `check_continual_data.py`: (a) checks the **metadata of every shard**, with no sampling. Each split shard must be in the manifest exactly once and in one split only; no manifest shard may be unassigned. Each shard needs its LMDB and a readable receipt that agrees with the manifest (sha256, record count, slot count, stored-2D flag). The LMDB entry count must equal the manifest count, using one short-lived open per shard. Every shard's slot policy must equal the manifest's single declared policy, which must agree with `splits.json`. The manifest totals must reconcile. `--verify-hashes` recomputes every sha256. (b) **Records are sampled across all shard IDs**: one shard per stratum (`--lipid-shards`, default 256, sha256-ranked with `--seed`), `--records-per-shard` (4) records each. Every sampled record must store exactly the declared slot count, and must have a flat slot when a stored 2D is declared. Corrupt or unreadable shards fail. (c) The cross-source dominant-profile check is unchanged. At most **one** LMDB is open at any time. The launcher passes `--lipid-shards` (`HEART_DATA_CHECK_SHARDS`). The task's own slot check now probes lipid shards spread over all IDs (`--slot-check-shards`, 256, first and last included), aggregates them, and cross-checks the manifest-declared slot count (`check_continual_data.py`, `unimol_contrastive_continual.py`, launcher) | `test_v2_review_fixes::test_p1_pre_*` (8). **Damaged records in shard 90 of 100, with consistent metadata, are found; the revision-2 tool (first 64 shards) would pass them.** 10 sampled shards span positions ≤ 9 to ≥ 88; a clean 100-shard library passes. Each of these damages to shard 97 fails: missing receipt, missing LMDB, wrong entry count, contradictory slot policy, shard in no split. **Peak concurrently open LMDBs = 1** over 150 shards, measured by wrapping `lmdb.open`. Task: `test_p1_task_slot_check_spreads_over_all_shards_and_checks_manifest` (10 of 118 shards probed including first and last; a contradicting `splits.json` declaration is refused) |

### 2.1 Pre-handoff self-review (requested by the reviewer) and what it changed

| Area reviewed | Finding | Action / test |
|---|---|---|
| **Matching SLURM array parameters** | Stage 04 used `SLURM_ARRAY_TASK_COUNT` as the shard stride. Resubmitting only the failed tasks, as stage 05 advises (`--array=17,523`), gives a count of 2: task 17 then died, and with other IDs the task → shard mapping would change, so two tasks could write one shard. Stage 02 had the same pattern for chunks | `lipid_array_task <VAR> <default>` uses an **explicit stride**: `LIPID_ARRAY_SIZE` (default 1000 = `#SBATCH --array=0-999`, used by 03b/04/05) and `LIPID_ENUM_ARRAY_SIZE` (default 64 = `--array=0-63`). It refuses a task ID ≥ stride or `SLURM_ARRAY_TASK_MAX` ≥ stride, and warns on a partial resubmission. `lmdb_writer` locks `--num-shards` per output directory (`array_geometry_config.json`), so a second stride is refused. Tests: `test_lipid_cpu_stages_run_end_to_end` (stage-02 partial resubmission with count 1 keeps the stride; task 2 of stride 2 refused); `test_p1_io_partition_inputs_are_verified_and_locked` (other stride refused); `test_p1_sizing_plan_and_default_geometry` (defaults fit 24 h). Real-product smoke: the stride-3 task was refused |
| **Worker FD usage** | Per process: ≤ `MAX_OPEN_LMDB_ENVS` envs for the train mixture plus ≤ 7 for the valid mixture (6 valid shards + general). Each env is 1 fd plus a mapping with `lock=False`; on Windows the measured cost is 1 handle per env. The parent holds 0 after `load_dataset`. Uni-Core re-creates workers per epoch from that parent | The launcher budget was corrected to 2·N + 512. Tests above |
| **Finite / safe mixed-data operation** | Weights must lie in (0, 1]; an empty mixture, empty split or smoke data is refused; integer keys are probed at construction; the epoch length is fixed (`cumulative_length`); eviction only affects handles | Existing tests plus `test_p0_selection_is_identical_with_and_without_eviction` |
| **Checkpoint resume** | The mixture is a pure function of (paths, weights, seed), unaffected by the LRU. **Gap:** a resubmission after re-running stage 05 with another `SPLIT_SEED`, or after a regenerated library, would silently change the train/valid shards mid-run | The launcher now pins the run to the **sha256 of `splits.json`** (`lipid_data_identity.txt`, written on the first non-dry start, compared on every start including dry runs). A mismatch is refused unless `HEART_ALLOW_ARG_CHANGE=1`. `splits.json` itself pins the manifest hash and thus every shard's LMDB sha256. Test: `test_continual_scripts::test_launcher_refuses_a_resume_with_different_lipid_splits`. The real CPU new-stage → early-checkpoint → resume tests pass with the pin in place |

## 3. Observed locally vs projected for CMRI

**Observed** on the laptop: Windows 11, NTFS SSD, `scratchpad/measure_v3.py`; raw values in bundle `test_results/04_local_measurements_laptop.json`.

* 1,000 shard LMDBs, 3,000 shuffled reads:
  * with the bound of 64: OS handle growth **64**, 2,806 evictions, 89 µs/read;
  * unbounded: growth **1,000**, 52 µs/read;
  * one `lmdb.open` + `close`: 29 µs.
* Partition of 200,000 synthetic rows into 1,000 shards: 13.3 s, i.e. **6.65e-5 s/row** including the partition writes. A task reading 5 shards (1,000 rows): 6 ms.
* Real-product smoke (real sheet, 1,000 enumerated products, `--no-store-2d --records-per-shard 3 --limit 6`; table in §5):
  * a task before 03b was refused;
  * the partition gave 2 shards / 6 rows;
  * each task parsed **0 product rows and 3 input rows**;
  * a partial finalize listed `--array=1`;
  * a stride-3 task was refused;
  * the full finalize was complete (6 records), and the split and validation found 0 problems.

**Projected (not measured; CMRI costs unknown):**

* Partition of 15.24M rows: ≈ 0.3 h at the laptop rate (the plan default assumes 1e-4 s/row ≈ 0.42 h).
* Rows parsed by stage-04 tasks: 15.24M in total and 20,000 per task at the defaults. The revision-2 design parsed ≈ 1.5e10.
* Input reading is about 1e-5 of the conformer cost per task.
* LRU misses: with ~3,050 lipid shards and 64 open envs, most lipid reads reopen a shard. At the local 29 µs per open that is ≈ 13 ms per batch of 448, assuming every read misses, and it runs inside the loader workers. **On a networked file system the open cost may be much higher**: measure it in the H200 smoke run (README §4.4). If it matters, raise `MAX_OPEN_LMDB_ENVS`, within `ulimit -n`, or use larger shards.

## 4. Files (all new and untracked; no tracked file modified or deleted)

New in revision 3:

* `model/pretrain/scripts/lipid_library/03b_partition.sh`
* `model/pretrain/tests/test_v2_review_fixes.py` (25 tests)

Changed in revision 3:

* `unimol/data/merged_sampling_dataset.py` (H6 LRU)
* `unimol/tasks/unimol_contrastive_continual.py` (`--max-open-lmdb-envs`, `--slot-check-shards`, close before workers, spread probe, manifest cross-check)
* `lipid_library/lmdb_writer.py` (partition, array-geometry lock, read-aware `--plan`, finalize partition check)
* `lipid_library/splits.py` (rewritten: stratified seeded split, `split_report.json`)
* `tools/check_continual_data.py` (rewritten: all-shard metadata, stratified record sampling)
* `scripts/lipid_library/lipid_lib.sh`, `02_enumerate_array.sh`, `04_conformers_array.sh`, `05_finalize.sh`
* `scripts/continual_pretrain_heart-h200.sh` (FD budget, `--max-open-lmdb-envs`, `--lipid-shards`, splits identity pin)
* `configs/continual_pretrain.yaml`
* `README_CONTINUAL.md`
* `tests/test_continual_loader.py`, `test_lipid_pipeline.py` and `test_continual_scripts.py` (updated for the new behaviour, plus one new launcher test)

The complete list is in the bundle's `git/untracked_inventory.txt` and `MANIFEST_SHA256.txt`.

## 5. Tests actually run (Windows 11, `.venv_heart_cpu` Python 3.11.7, torch 2.2.2+cpu, RDKit 2024.09.6, lmdb 1.8.1, Uni-Core `ace6fae` source checkout on PYTHONPATH)

The command prefix (Git Bash, from `model/`) is below. Raw outputs are in bundle `test_results/0[1-3]_*.txt`.

```bash
PYTHONPATH="<Uni-Core ace6fae>;<repo>/model" ../../.venv_heart_cpu/Scripts/python.exe -m pytest <target> -q -p no:cacheprovider -rs
```

| Target | Result | Observed |
|---|---|---|
| `pretrain/tests/test_v2_review_fixes.py` (new) | PASS | **24 passed, 1 skipped** (the Linux-only fork test) in 34 s |
| `pretrain/tests --ignore test_scripts.py --ignore test_unicore_train_e2e.py` (all continual tests and the original light general tests) | PASS | **292 passed, 2 skipped** (both fork tests) in 204 s. Includes the real `unicore-train` CPU runs (new stage → early checkpoint → resume, with the splits pin), CPU stages 01 → 03 → 03b → 04 → 05, and `test_notebook.py` |
| `test_scripts.py test_unicore_train_e2e.py` (original general e2e/launcher) | PASS | **70 passed** in 148 s |
| Real products (see §3): partition → array tasks 0/1 with a partial finalize and a refused stride → finalize → splits → validate | PASS | each task parsed 0 product rows; complete [SMOKE] manifest; 0 validation problems |
| `bash -n` on every lipid stage script and the launcher | PASS | also run inside the suite |

**Skipped, and why:**

* `test_lmdb_workers.py` fork test (original): fork is unavailable on Windows;
* `test_v2_review_fixes.py::test_p0_forked_worker_discards_inherited_handles`: fork is unavailable on Windows. It runs on Linux/CMRI. Spawn is tested.


## 6. Open items

**CMRI-only, not verified, and no claim is made that they were tested:**

* the general-ligand LMDB slot audit (`STORE_2D`);
* the CPU pilot speed, the real partition read rate, SLURM `MaxArraySize` and time-limit behaviour;
* full enumeration, dedup, partition and conformers;
* `ulimit -n` on the H200 node, the LMDB open cost on the CMRI file system, and Linux fork with 4 workers;
* strict initialisation from the real general checkpoint, fp16 and memory at batch 448 with long lipids;
* memory on the 15M+ data.

**Scientific decisions still open (not coding bugs; unchanged by this revision):**

1. **B62.** The submitted SMILES has an unclosed ring. It is rejected, which reduces the library from 15,491,072 to 15,241,216 combinations. The original string is preserved in `bb/reagent_issues.csv`, and the proposed correction (`…C1`, 1-adamantyl isocyanide) is **not** applied. An explicit decision by the data owner is needed before claiming to reproduce the original 15M library.
2. **Ugi reaction site and chemistry.** The template is a reconstruction. Multi-site amines (A1 rule: lexicographic vs. LUMI's first-match), hydrazines, the N-isocyanide B33 and stereo handling need chemical sign-off before full production.
3. **Conformer seed.** `SEED_START=0` keeps LUMI's behaviour (the slot-0/1 duplicate); `1` is a documented deviation. Neither is automatically correct.
4. **Validation split.** The default is now stratified random over whole shards: representative of the library distribution, but **not** a scaffold or reagent hold-out. If the scientific goal is generalisation to unseen reagents, a reagent hold-out is a different, deliberate choice.

**Behaviour changes to know on CMRI:**

* stage **03b** must run between 03 and 04;
* `LIPID_ARRAY_SIZE` must equal the first `--array` size for every resubmission;
* changing `--records-per-shard`, `--limit`, the drop list or the stride needs a new `LIPID_LMDB_DIR`;
* a continual run directory is pinned to its `splits.json`.

## 7. Unexecuted CMRI commands

The exact commands are in `model/pretrain/README_CONTINUAL.md` §4:

1. §4.1 deploy and registry check;
2. §4.2 read-only general LMDB slot audit → `STORE_2D`;
3. §4.3 stages 01, 02, 03, **03b**, a pilot (03b, 04, 05 in `lmdb_pilot` with `LIPID_ARRAY_SIZE=1`), the full 03b → 04 with the measured `SEC_PER_MOLECULE` → 05, resubmitting only the listed task IDs;
4. §4.4 `check_continual_data.py`, init `--dry-run`, launcher dry run, the `HEART_CONTINUAL_SMOKE_UPDATES=200` H200 smoke run (also measure the loader throughput and LMDB reopen cost), review, then production `sbatch`.

## 8. Statement

**No commit, push, pull or job submission occurred.** No remote system was contacted or changed. No full-scale generation or GPU job was run. The general-pretraining model, launchers, configs, checkpoints, logs and datasets were not modified (byte-identical to HEAD, verified by test; `git status --untracked-files=no` is empty).

---

## Appendix A. Revision 2: response to the first review (`HEART_continual_independent_review.md`), unchanged

| Review item | Fix (files) | Regression tests (`tests/…`) |
|---|---|---|
| **P0-1: an incomplete dataset could be declared ready** | `enumerate_library --check-complete` writes `enumeration_complete.json` (exact chunk list, counts, hashes); downstream reads only those chunks. `dedup --require-complete`. `lmdb_writer --finalize` (replaces `--manifest-only`) recomputes the expected shard layout from enumeration + drop list + `--records-per-shard`, and requires every expected ID with no missing/extra/duplicate IDs, matching configuration and input fingerprints, verified LMDB sha256, and records + skipped = input rows, inputs = products − dropped. Only then is `manifest.json` (`"complete": true`) written; otherwise `manifest.json`/`splits.json` are removed and `finalize_report.json` lists missing shards and the array task IDs to resubmit. Array tasks never write the manifest. `splits.py` refuses an absent/incomplete manifest. Stage 05 runs finalize first and fails closed (`lmdb_writer.py`, `enumerate_library.py`, `dedup.py`, `splits.py`, `05_finalize.sh`) | `test_lipid_pipeline::test_interrupted_array_cannot_be_finalised` (partial array → finalize exit 1, missing [1,3], resubmit [1], no manifest, splits refused, stale manifest removed; completed array → reconciled), `::test_finalize_detects_an_unexpected_extra_shard`, `::test_finalize_detects_a_count_mismatch`, `test_review_fixes::test_p0_1_dedup_requires_a_complete_enumeration`, `::test_p0_1_empty_valid_split_is_refused`, `test_continual_scripts::test_lipid_cpu_stages_run_end_to_end` |
| **P0-2: stale outputs when inputs or options change** | New `provenance.py`. Each stage locks its output directory to a SHA-256 configuration fingerprint (`<stage>_config.json`, created atomically with O_EXCL, so concurrent array tasks are safe); a mismatch fails with "use a new output directory". The enumeration config covers the Excel sha256, `building_blocks.csv` sha256, the full `ugi.policy()` (`POLICY_VERSION`, all SMARTS, A1–A4), RDKit/Python/numpy/lmdb versions, chunk size, range and a smoke flag. The writer config covers every conformer/filter option (`--n-3d`, `--store-2d`, `--max-try`, `--max-iterations`, `--seed-start`, `--max-atoms`, `--only-polar`, `--allow-2d-only`, `--records-per-shard`, `--limit`), `CONFORMER_POLICY_VERSION`, the `dict.txt` sha256, the drop-list sha256 plus its enumeration provenance (a drop list from another enumeration is refused), and the enumeration fingerprint. Every chunk/shard receipt stores the fingerprint; shard receipts also store an input fingerprint (combo indexes + SMILES), first/last combo index, counts, the `records.csv` hash and versions. A receipt with another fingerprint raises instead of being reused. `--limit`/partial runs are marked smoke and can never be finalised or split as production without `--allow-smoke`; the task and launcher refuse smoke splits | `test_review_fixes::test_p0_2_*` (11 tests): changed Excel, source hash recorded, changed reaction policy, `--limit` enumeration, stray chunk ignored, writer `--seed-start` / `--limit` / `--no-store-2d` changes, changed products, other input rows, smoke never production, receipt provenance, lock semantics. Also `test_lipid_pipeline::test_drop_list_is_honoured_by_the_writer` (unprovenanced drop list refused) |
| **P1: 2D conformer policy** | `--store-2d`/`--no-store-2d` is now **required** (no default) in `lmdb_writer`, and `STORE_2D=0\|1` is required by stages 04/05. New read-only `tools/check_continual_data.py` measures the stored/2D-like slot profile of general `train`/`valid` and lipid `train`/`valid` (records spread over each file), prints training-time slots and P(2D), and fails on any difference, on incomplete/smoke lipid data, or on a manifest changed after `splits.json`. The launcher runs it in every preflight (dry run included) and always passes `--require-equal-coordinate-slots`. The task compares stored/2D-like *profiles*, not only counts. README §4.2 gives the CMRI audit that decides `STORE_2D`. **The real general convention is still unverified (CMRI-only)** | `test_review_fixes::test_p1_2d_*` (7): runtime P(2D) (10/0 → 1/11, 11/1 → 2/12); same slot count but different 2D policy refused by the tool and by the task; matching policy passes on all four sources; smoke refused; writer requires the explicit choice. `::test_p1_h200_preflight_refuses_a_slot_policy_mismatch` |
| **P1: 48-hour CPU-array sizing** | `lmdb_writer --plan` computes rows, shards, shards per task and hours per task from the enumeration/dedup records (no streaming). Stage 04 refuses to start unless ceil(shards/N) × RECORDS_PER_SHARD × SEC_PER_MOLECULE × 1.5 ≤ the job's actual SLURM time limit. A full run (no `LIMIT`) **requires** a pilot-measured `SEC_PER_MOLECULE`; finalize reports `measured_sec_per_molecule`. New defaults: `RECORDS_PER_SHARD=5000`, `--array=0-999%200`, `--time=1-00:00:00` (4 shards/task for 15.24M; 10.6 h at 1.9 s, 15.8 h with the factor). Pilots use their own `LIPID_LMDB_DIR`. Resubmission is documented (same command, or `--array=<resubmit_array_tasks>`) | `test_review_fixes::test_p1_sizing_plan_and_default_geometry`, `::test_p1_sizing_plan_cli`, `::test_p1_sizing_stage04_refuses_an_unmeasured_full_run_and_an_oversized_task` (also: nothing generated when refused; STORE_2D required) |
| **P1: don't silently change the chemical design space** | `bb/reagent_issues.csv` records the exact source string, the verbatim RDKit error and *proposed* corrections with formulas, marked "source data not modified" (`building_blocks.rdkit_error`, `correction_candidates`). `ugi.build_product` returns every alternative product. `review_products` adds the `alternative_products` column, classifies LUMI-assembly differences (identical / identical except stereo / **other_site_A1** / DIFFERENT) and writes `review.md` (rejected reagents + proposals, representative-mapping table) beside `review.svg` (2D renders). The documentation states clearly that this is not a strict LUMI replication | `test_review_fixes::test_p1_chem_b62_error_is_reported_verbatim_with_a_proposal_not_applied`, `::test_p1_chem_alternative_ugi_sites_are_reported`, `::test_p1_chem_review_writes_mapping_table_and_drawings` (records the asymmetric-diamine finding below) |
| **P1: H200 production readiness** | New isolated smoke mode `HEART_CONTINUAL_SMOKE_UPDATES=N`: RUN_NAME must contain "smoke", production names may not, and it writes to `runs/h200/continual/heart-lipid-continual-smoke`. README §4.4 gives the CMRI sequence of read-only data preflight, init `--dry-run`, launcher dry run, H200 smoke run (with what to check), then production. The pinned Uni-Core `--finetune-from-model` reset path is verified in source by a test and end to end locally. **Real H200/fp16/checkpoint behaviour remains unverified (CMRI-only)** | `test_review_fixes::test_p1_h200_smoke_runs_are_isolated` (3), `::test_p1_h200_preflight_refuses_smoke_lipid_data_in_production`, `::test_p1_h200_launcher_always_requires_equal_slot_profiles`, `::test_p1_h200_pinned_unicore_finetune_resets_optimizer_state`; `test_continual_scripts::test_launcher_new_stage_then_resume_on_cpu` |
| Rec: finalization safety | `splits.py` refuses an empty valid or train split, overlapping shard IDs or combo-index ranges, and a single shard unless `--allow-smoke-overlap` (always marked smoke). A refused split removes `splits.json` | `test_lipid_pipeline::test_single_shard_split_requires_explicit_smoke_overlap`, `test_review_fixes::test_p0_1_empty_valid_split_is_refused` |
| Rec: per-shard reproducibility | see P0-2 | `test_review_fixes::test_p0_2_receipts_record_provenance` |
| Rec: memory | Sampled indexes are stored as `uint32`, with no array for weight 1.0 (~38 MB instead of ~197 MB per process at real sizes); `index_memory_bytes()`. Not benchmarked on the real data | `test_review_fixes::test_rec_memory_index_arrays_are_compact` |
| Rec: regression | All original general tests re-run (§5); protected sources byte-identical | `test_continual_scripts::test_general_pretraining_sources_are_unmodified` |

**New finding (chemistry, A1).** For an *asymmetric* multi-site amine (test reagent `NCCCN(C)CCCCN`), LUMI's core-attachment assembly attaches at the first matching NH2 in atom order, while the template keeps the lexicographically smallest product. Both are valid Ugi adducts at different sites. On the **real** sheet the two rules agree for all 295 reviewed products: 11 multi-site amines and 7 combinations with alternative products, with 0 `other_site_A1` cases. A chemist should still choose the rule.
