# HEART H200 — Additional Chemistry Evidence for PI slides

A new, independent Jupyter Notebook. **No HEART retraining, no checkpoint updates, no Slurm jobs, no modifications to the existing 10K notebook or source LMDB.** The **only** learned parameters in the new downstream benchmark are simple Ridge-regression heads fitted on the benchmark's labeled training partition, while HEART is frozen throughout.

## Files

- `HEART_Chemistry_Slide_Evidence.ipynb` — run in Jupyter (`Python (heart_gpu)` kernel).
- `chemistry_tests.py` — source for all measurements/figures; notebook imports it. No external CLI jobs.
- `README.md` — this document.

## Suggested HPC installation

Extract the entire ZIP under an accessible HOME directory, for example:

```bash
cd /home/ypan/heart_liver/model_train
unzip -o HEART_Chemistry_Slide_Evidence.zip
```

Open `/home/ypan/heart_liver/model_train/HEART_Chemistry_Slide_Evidence/HEART_Chemistry_Slide_Evidence.ipynb` in Jupyter. If Jupyter's file explorer maps to `/mnt/home`, the Notebook automatically searches both `/home` and `/mnt/home`; in Section 0, **verify printed paths before running any inference**. The original checkpoint and original Uni-Mol LMDB remain in their respective `/project`, `/scratch` or `/home` locations; the notebook autodetects known paths.

Existing output root automatically detected from prior results:

```
/project/yli4/ypan/heart_evaluation/general_audit_10k_v2/
  checkpoint_evaluation/            # existing 10K train/validation — READ ONLY
  validation_10k_seed17/             # existing numeric-key metadata — READ ONLY
  full_ligand_audit/raw/             # optional existing raw audit hashes — READ ONLY
  chemistry_slide_evidence/          # NEW outputs only
    slides_from_existing_10k/
    structural_similarity/
    benchmark_csv/
    benchmark_generated_lmdb/
    external_embeddings/
    independent_property_benchmarks/
    geometry_examples/
```

Some installations show `/mnt/project/yli4/ypan` instead of `/project/yli4/ypan`; use the actual path reported by Section 0. **Files are not automatically copied back to HOME**; Jupyter can view/download plots from the printed result path.

## Step-by-step execution

1. **Section 0 — path check**. Confirm existing model, Uni-Core, checkpoint, original 10K outputs, metadata.
2. **Section 1 — existing 10K slide figures**. Runs immediately (no GPU), converts existing metrics to slide-quality PNG + vector PDF.
3. **Section 2 — structure-neighbor retrieval**. Runs immediately (no GPU), measures whether CLS similarity aligns with ECFP molecular topology relative to controls with similar heavy atom counts. Saves raw pair CSV, bootstrap CI, slide figures and example molecule drawings. Does not do the expensive 10K×10K embedding matrix.
4. **Section 3 — external benchmark CSVs**. Official DeepChem sources:
   - ESOL: https://deepchemdata.s3-us-west-1.amazonaws.com/datasets/delaney-processed.csv
   - FreeSolv: https://deepchemdata.s3-us-west-1.amazonaws.com/datasets/SAMPL.csv
   - Lipophilicity: https://deepchemdata.s3-us-west-1.amazonaws.com/datasets/Lipophilicity.csv

   **If your HPC has no outbound internet**, download the three small CSVs using your workstation's browser and upload them through Jupyter to the exact `BENCHMARK_CSV` directory printed by Section 3. Or set `TRY_DOWNLOAD_BENCHMARKS=True` only when external download is permitted. Do **not** upload assay labels into the original ligand training LMDB.
5. **Section 4 — prepare benchmark 3D molecules**. Set `RUN_BUILD_BENCHMARK_INPUTS=True` **only once**; use RDKit ETKDGv3 with a fixed seed to generate input coordinates. Saved separately under a NEW LMDB plus labels manifest. The exact original Uni-Mol `dict.txt` is copied, never changed. Summary reports molecule failures/exclusions.
6. **Section 5 — frozen checkpoint extraction**. In a GPU-backed `heart_gpu` Jupyter kernel, set `RUN_EXTERNAL_INFERENCE=True`. The script uses the original task and model, strictly loads `checkpoint_best.pt`, then creates `external_cls.npy` without gradients. It reuses completed outputs on subsequent runs. **No Slurm submission**. Note generated 3D geometries are not experimental conformers and may influence results.
7. **Section 6 — independent experimental benchmark**. Set `RUN_EXTERNAL_BENCHMARKS=True` after section 5. CPU-only linear probes. For each dataset, three scaffold-separated splits `(17,31,53)` and two labeled training fractions `(20%,100%)`; identical splits and validation tuning across mean-only, heavy-atom, RDKit descriptors, Morgan-ECFP4, frozen HEART CLS. Report held-out test RMSE, MAE, R², and variation. Produces PNG and vector PDF bar charts, predicted-vs-measured plots, sample-efficiency charts, and raw CSVs.
8. **Section 7 optional**: set `RUN_3D_EXAMPLES=True` to perform **only three** additional original-LMDB frozen inference forwards to illustrate target, noisy and recovered atomic coordinates, no model update.
9. **Section 8** lists files actually produced.

## What counts as convincing proof?

- **Slide 1 (already supported)**: atom-class accuracy vs majority baseline, 3D coordinate denoising vs corrupted input, train/validation consistency.
- **Slide 2 (new evidence, results not yet known)**: experimental property prediction from *frozen* CLS, compared under the **same scaffold splits** against heavy atom count, RDKit descriptor and Morgan-ECFP4 baselines. Pre-register interpretation: a higher-performing HEART embedding suggests transfer beyond the original pretraining objectives, but good numbers alone never prove general chemical knowledge for every task.
- **Backup**: chemical structure retrieval versus size-matched random pairs, and optional true checkpoint 3D examples.

**Do not present benchmark results before they are generated.** The full ligand audit previously checked **raw** exact SMILES overlap (including train–validation) but not full canonical identity; external benchmark overlap is reported only when the prior sorted raw hash files exist. Even zero raw overlap does not rule out alternate SMILES of the same chemical compound. In addition, scaffold-split benchmark testing means unseen scaffolds within the **labeled downstream dataset**, not necessarily unseen molecules during the unsupervised pretraining stage. For more stringent claims of true pretraining external generalization, an independent molecular source with verified identity non-overlap is needed.

### Source references

- DeepChem dataset loader documentation: https://deepchem.readthedocs.io/en/stable/api_reference/moleculenet.html
- MoleculeNet benchmarking original study: https://doi.org/10.1039/C7SC02664A
- Existing HEART source: `andypan0214/heart-molecular-pretraining-v2`, branch `v2/lipid-continual`. Original `unimol_contrastive` task/model/loss retained unmodified.

## Validation performed before delivery

- `nbformat.validate`; compile all notebook cells; Python helper `py_compile`.
- A **synthetic chemistry smoke test** (not a HEART performance claim) executed the downstream scaffold-split analysis, baselines, CSV/PDF writing and retrieval figures.
- Not possible outside your HPC: running the real frozen H200 checkpoint, original 18.84M LMDB, downloading the three external CSVs, or producing scientific measurements. No synthetic fixture data or fake model results included in the ZIP.
